import axios from 'axios';
import '../Adapter';

export const MENULISTRESULT = 'MENULISTRESULT';
export const menuListRequest = () => {
    return dispatch => {
        return new Promise((resolve, reject) => {
            axios('/getMenuList').then((res) => {
                console.log(res)
                dispatch(menuListResult(res.data.menuList));
                resolve();
            });
        });
    };
};
export const menuListResult = (menuList) => {
    return {
        type: MENULISTRESULT,
        menuList
    };
};

export const CHANGENUMREQUEST = 'CHANGENUMBERREQUEST';
export const changeNumRequest = (index, i, str) => {
    return {
        type: CHANGENUMREQUEST,
        index,
        i,
        str
    };
};
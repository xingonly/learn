import {MENULISTRESULT, CHANGENUMREQUEST} from './Action';

let menuList = (state, action) => {
    switch (action.type) {
    case MENULISTRESULT: return action.menuList;
    case CHANGENUMREQUEST:
        if (action.str === 'up') {
            state[action.index].children[action.i].num += 1;
        } else if (action.str === 'down') {
            state[action.index].children[action.i].num -= 1;
        }
        return state;
    default: return state;
    }
};
let reducer = (state = {menuList: []}, action) => {
    return {
        menuList: menuList(state.menuList, action)
    };
};

export default reducer;
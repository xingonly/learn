import React, { Component } from 'react';
import './App.css';
import {Provider} from 'react-redux';
import store from './Redux/configStore';
import './css/common.css';
import './css/reset.css';
import './fonts/iconfont.css';
import Home from './components/Home';

class App extends Component {
    render () {
        return (
            <Provider store={store}>
                <div className="App">
                    <Home/>
                </div>
            </Provider>
        );
    }
}

export default App;

import axios from 'axios';
import adapter from 'axios-mock-adapter';

const mock = new adapter(axios);

const arr = ['热销', '烧饼类', '进店必买', '酱肉类', '凉菜类', '汤类', '饮料类'];
let menuList = arr.map((val, index) => {
    return {
        title: val,
        children: new Array(5).fill().map((v, i) => {
            return {
                name: val + i,
                img: 'img/menu1.png',
                trait: i % 2 === 0 ? (val + i) : '',
                recommend: val + i,
                price: 20,
                num: 0
            };
        })
    };
});

mock.onGet('/getMenuList').reply((config) => {
    return [200, {menuList: menuList}];
});
import React, { Component } from 'react';

class ShopCarBox extends Component {
    constructor (props) {
        super(props);
    }
    render () {
        return (
            <div className={this.props.flag ? 'ShopCarBox' : 'ShopCarBox disShopCarBox'}>
                <div>
                    <h2>
                        <span>已选商品</span>
                        <span>清空</span>
                    </h2>
                    <ul>
                        {
                            this.props.menuList.map((val, index) => {
                                return val.children.map((v, i) => {
                                    return v.num > 0 && <li key={i}>
                                        <span>{v.name}</span>
                                        <div>
                                            <b>￥{v.num * v.price}</b>
                                            <button className="buttonBox-btn" onClick={() => this.props.changeNum(index, i, 'down')}>-</button>
                                            {v.num}
                                            <button className="buttonBox-btn" onClick={() => this.props.changeNum(index, i, 'up')}>+</button>
                                        </div>
                                    </li>;
                                });
                            })
                        }
                    </ul>
                </div>
            </div>
        );
    }
}

export default ShopCarBox;

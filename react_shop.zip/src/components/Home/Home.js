import React, { Component } from 'react';
import ShopCar from '../shopCar';

class Home extends Component {
    render () {
        return (
            <div className="Home">
                <ShopCar/>
            </div>
        );
    }
}

export default Home;

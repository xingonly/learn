import React, { Component } from 'react';
import './shopCar.css';
import {connect} from 'react-redux';
import {menuListRequest, changeNumRequest} from '../../Redux/Action';
import ShopCarBox from '../shopCarBox';

class ShopCar extends Component {
    constructor () {
        super();
        this.state = {
            actInd: 0,
            allPrice: 0,
            flag: false
        };
        this.changeNum = this.changeNum.bind(this);
        this.clearAll = this.clearAll.bind(this);
    }
    render () {
        let menuList = Array.from(this.props.menuList);
        return (
            <div className="ShopCar">
                <ul className="ShopCarLeft">
                    {
                        menuList.map((val, index) => {
                            return <li key={index} className={this.state.actInd === index ? 'act' : ''} onClick={() => this.changeTab(index)}><a href={`#${val.title}`}>{val.title}</a></li>;
                        })
                    }
                </ul>
                <div className="ShopCarRight" onTouchStart={(e) => this.scrollFn(e)}>
                    {
                        menuList.map((val, index) => {
                            return <div key={index}>
                                <h4 id={val.title}>{val.title}</h4>
                                {
                                    val.children.map((v, i) => {
                                        return <dl key={i}>
                                            <dt><img src={require(`../../${v.img}`)} alt=""/></dt>
                                            <dd>
                                                <h3>{v.name}</h3>
                                                <span>{v.trait}</span>
                                                <p>{v.recommend}</p>
                                                <strong>￥<b>{v.price}</b></strong>
                                                <div className="buttonBox">
                                                    {
                                                        v.num > 0 ? <button className="buttonBox-btn" onClick={() => this.changeNum(index, i, 'down')}>-</button> : null
                                                    }
                                                    {
                                                        v.num > 0 && v.num
                                                    }
                                                    <button className="buttonBox-btn" onClick={() => this.changeNum(index, i, 'up')}>+</button>
                                                </div>
                                            </dd>
                                        </dl>;
                                    })
                                }
                            </div>;
                        })
                    }
                </div>
                <ShopCarBox menuList={menuList} changeNum={this.changeNum} flag={this.state.flag} clearAll={this.clearAll}/>
                <div className="ShopCarBottom" onClick={() => this.changeFlag()}>
                    <div>
                        ￥{this.state.allPrice}
                    </div>
                    <div>
                        去结算
                    </div>
                </div>
            </div>
        );
    }
    componentWillMount () {
        this.props.dispatch(menuListRequest()).then(() => {
            this.countAllPrice();
        });
    }
    changeNum (index, i, str) {
        this.props.dispatch(changeNumRequest(index, i, str));
        this.countAllPrice();
        this.forceUpdate();
    }
    countAllPrice () {
        let allPrice = 0;
        this.props.menuList.map((val, index) => {
            val.children.map((v, i) => {
                allPrice += v.price * v.num;
            });
        });
        this.setState({
            allPrice
        });
    }
    changeTab (actInd) {
        this.setState({
            actInd
        });
    }
    changeFlag () {
        this.setState({
            flag: !this.state.flag
        });
    }
    clearAll () {}
    scrollFn (e) {
        console.log(e.touches);
    }
}

export default connect(state => {
    return {
        menuList: state.menuList
    };
})(ShopCar);

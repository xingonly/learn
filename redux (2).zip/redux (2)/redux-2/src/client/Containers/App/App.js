import React, { Component } from 'react';

import { connect } from 'react-redux'
import { fetchPost, selectSubReddit } from 'Redux/actions'

class App extends React.Component {
    constructor(props) {
        super(props)
        this.fetchEvent = this.fetchEvent.bind(this)
    }
    fetchEvent(string) {
        const { dispatch } = this.props;
        dispatch(selectSubReddit(string))
        const promiseEvent = dispatch(fetchPost(string))
        promiseEvent.then((idx) => { console.log(idx) })
    }
    render() {
        console.log(9999)
        const { postBySubreddit, selectSubReddit } = this.props.data;
        console.log(this.props.data);
        return (
            <div>
                hello react
                <button onClick={() => { this.fetchEvent('reactjs') }}>reactjs</button>
                <button onClick={() => { this.fetchEvent('frontend') }}>frontend</button>
                <ul>
                    {
                        postBySubreddit[selectSubReddit] &&
                        postBySubreddit[selectSubReddit]['items'].map((item, idx) => {
                            return <li key={idx}>{selectSubReddit + JSON.stringify(item)}</li>
                        })

                    }
                </ul>
            </div>
        )
    }
}
const mapStateToProps = (state) => {
    return {
        data: state,
    }
}
export default connect(mapStateToProps)(App);



import React from 'react'
import ReactDom from 'react-dom'
import App from './Containers/App'
import { Provider } from 'react-redux'

import thunk from 'redux-thunk'  //


import { createStore, applyMiddleware } from 'redux'

import { selectSubReddit, fetchPost } from 'Redux/actions'

import rooterReducer from 'Redux/reducers'

const store = createStore(rooterReducer, applyMiddleware(thunk))


console.log(thunk,'thunk')
ReactDom.render(
    <Provider store={store}>
        <App />
    </Provider>,
    document.getElementById('app')
)





const selectSubReddit = (subreddit) => {
    return {
        type: 'selectSubReddit',
        subreddit,
    }
}

const requestPost = (subreddit) => {
    return {
        type: 'requestPost',
        subreddit,
    }
}

const receivePost = (subreddit, json) => {

    return {
        type: 'receivePost',
        subreddit,
        postData: json.data.children.map(child => child.data),
    }
}

const fetchPost = (subreddit) => {

    return async dispatch => {
        dispatch(requestPost(subreddit));
        const idx = await fetch(`http://www.subreddit.com/r/${subreddit}.json`)
            .then(response => response.json())
            .then(json => {
                dispatch(receivePost(subreddit, json))
                return '111'
            })
        return idx;
    }
}
export {
    fetchPost,
    receivePost,
    requestPost,
    selectSubReddit,
}
import {combineReducers} from 'redux'

function selectSubReddit(state = 'reactjs', action) {  //frontend
    switch (action.type) {
    case 'selectSubReddit':
        return action.subreddit;
    default:
        return state
    }
}

function poster(state={
    isFetching:false,
    items:[],
},action){
    switch(action.type){
    case 'requestPost':
        return Object.assign({},state,{
            isFetching:true,
        });
    case 'receivePost':
        console.log(4)
        console.log(action)
        return Object.assign({},state,{
            isFetching:false,
            items:action.postData,
        });
    default :
        return state;
    }
}

function postBySubreddit(state={},action){
    console.log(5)
    switch(action.type){
    case 'requestPost':
    case 'receivePost':
        return Object.assign({},state,{
            [action.subreddit] :poster(state[action.subreddit],action),
        })
    default:
        return state;
    }
}

const rootReducer=combineReducers({
    selectSubReddit,
    postBySubreddit,
})

export default rootReducer
import React from 'react'
import ReactDom from 'react-dom'
import App from './Containers/App'

import { Provider } from 'react-redux'
import { createStore, applyMiddleware } from 'redux'

import thunk from 'redux-thunk'
import createSagaMiddleware from 'redux-saga'

import rootRe from 'Redux/reducers'
import sagas from 'Redux/sagas'


const sagaMiddle = createSagaMiddleware();

const store = createStore(rootRe, applyMiddleware(thunk, sagaMiddle))

sagaMiddle.run(sagas)

ReactDom.render(
    <Provider store={store}>
        <App />
    </Provider>
    ,
    document.getElementById('app')
)


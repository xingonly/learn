import React, { Component } from 'react';

import { connect } from 'react-redux'

class App extends React.Component {
    constructor(props) {
        super(props)
        this.state = {

        }
    }

    render() {
        const { updateData } = this.props.state;
        console.log(this.props)
        return (
            <div>
                {updateData.code}
                {updateData.msg}
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        state,
    }
}

export default connect(mapStateToProps)(App);

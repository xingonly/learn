export default {
    fetchData:(url='/',params)=>{
        return  fetch(url).then((res)=>res.json()).then((json)=>json)
    },
}


import {combineReducers} from 'redux'


const updateData=(state={code:0,msg:'init'},action)=>{
    switch(action.type){
    case 'UPDATA':
        console.log(action.data)
        return Object.assign({},state,action.data)
    default :
        return state;
    }
}

const rootRe=combineReducers({
    updateData,
})

export default rootRe;
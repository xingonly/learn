import { call, put } from 'redux-saga/effects'
import Api from './Api'


export default function* fetchData() {
    const data = yield call(Api.fetchData, '/products')
    console.log(data)
    yield put({
        type:"UPDATA",
        data,
    })
}



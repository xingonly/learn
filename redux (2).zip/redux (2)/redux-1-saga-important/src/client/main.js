import React from 'react'
import ReactDom from 'react-dom'
import App from './Containers/App'

import { createStore, applyMiddleware, compose } from 'redux' //创建store  申请中间件  合并函数
import rootReducer from 'Redux/reducers' //引入 reducer 创建store时候需要传进去
import thunk from 'redux-thunk' // 进行异步操作等

import createSagaMiddleware from 'redux-saga'  //导出创建saga创建方法
import watchSaga from 'Redux/sagas'// 引入saga函数 在创建完store时候，需要run起来将sagas函数传进去
const sagaMiddleware = createSagaMiddleware();

const store = createStore(rootReducer, compose(applyMiddleware(sagaMiddleware,thunk), //sagas中间件 对应的文件 sagas ；  还会有thunk 对应的文件是actions
    window.__REDUX_DEVTOOLS_EXTENSION__ && window.__REDUX_DEVTOOLS_EXTENSION__()
));  //react devTool));

sagaMiddleware.run(watchSaga) //run一遍 gernation 函数

import { Provider } from 'react-redux' 

ReactDom.render(
    <Provider store={store}>
        <App />
    </Provider>,
    document.getElementById('app')
)


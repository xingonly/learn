const fetchInfo=(url='/',method='GET',params)=>{  //定义请求数据的方法 
    return fetch(url,{//返回 fetch 
        body:JSON.stringify(params),
        method,
    }).then((res)=>res.json()).then(json=>json)
}

export default {
    fetchInfo,  //以对象的方法 抛出去
}
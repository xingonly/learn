import React, { Component } from 'react';

import {connect} from 'react-redux'  //连接 redux


class App extends React.Component {
    constructor(props) {
        super(props)
    }
    clickEvent(){
        const {dispatch} =this.props;
        dispatch({type:'FETCH_INFO'}) //派发任务 saga的takeEvery会监听type类型相同发，执行saga函数
    }
    componentWillReceiveProps(nextProps) {
        const {userInfo} =nextProps;  //接收到新的props  可以在这执行需求操作  比如跳转路由 ： 比如验证返回数据信息，存储在localStorage
        //console.log(userInfo)
    }
    
    render() {
        console.log(this.props)
        return (
            <div>
                hello react
                <button onClick={()=>{this.clickEvent()}}> Login </button>
            </div>
        )
    }
}


//连接 reducer 返回的state 
const mapStateToProps=(state)=>{
    return {
        userInfo:state.userInfo,
    }
}
//简单的connect 只会传递一个dispatch方法 而不会将reducer数据传到props上
export default  connect(mapStateToProps)(App);

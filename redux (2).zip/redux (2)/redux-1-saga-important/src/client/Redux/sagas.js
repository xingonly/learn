
import { call, put, takeEvery } from 'redux-saga/effects'
import Api from 'Utils/Api'// 引入Api 其中有请求数据的方法

const fetchUserInfo = function* (action) {
    try {
        //第一种方法
        // const info = yield call(fetch, '/api/userinfo')  // 会简化我们的操作，进行处理后返回Promise给我们
        // const result = yield info.json().then((json) => json)    //json 就是取回来的数据
        // // console.log(result) //{code: 1, userName: "cjs", psw: 123}  
        // yield put({type:'NEW_DATA',userInfo:result})
        //第二种方法
        const info =yield call(Api.fetchInfo, '/api/userinfo2 ','POST',{type:'user'}) // 参数 ：请求地址，  请求方式 ， 参数
        // console.log(result) //{code: 1, userName: "cjs", psw: 123}   
        // 拿回来的值 可以进行判断 是否派发action
        yield put({type:'NEW_DATA',userInfo:info})
    } catch (e) {
        console.log(e.toString()) //报错信息
    }
}

const watchSaga = function* () {
    yield takeEvery('FETCH_INFO', fetchUserInfo) // 监听new_data 的action的发布 然后执行fetchUserInfo
}

export default watchSaga
import {combineReducers} from 'redux'  //合并reducer

const initState={  //初始化数据 
    userName:'hyj',
    psw:123,
}

const fetchData=(state=initState,action)=>{
    switch(action.type){ //判断action.type 执行需求
    case 'NEW_DATA':
        return Object.assign({},state,{
            ...action.userInfo,
        })
    default :
        return state
    }
}

const rootReducer=combineReducers({
    userInfo:fetchData,
})

export default rootReducer
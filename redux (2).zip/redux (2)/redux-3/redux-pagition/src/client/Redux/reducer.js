
import { combineReducers } from 'redux'

const change = (state = {
    currentPage: 0,
    pageSize: 5,
    total: 0,
    data: [],
}, action) => {
    switch (action.type) {
    case 'CURRENTPAGE':
        return Object.assign({}, state, {
            currentPage: action.cur, //更新当前页码
        })
    case 'CURRENTSIZE':
        return Object.assign({}, state, {
            pageSize: action.size, //更新当前每页多少条

        })
    case 'RECEIVEPOST':
        return Object.assign({}, state, {
            total: action.total,
            data: action.data,

        })
    default:
        return state
    }
}


export default combineReducers({
    change,
})
const currentPaged = (cur) => {
    cur = Number(cur);
    return {
        type: 'CURRENTPAGE',
        cur,
    }
}

const currentSize = (size) => {
    size = Number(size);
    return {
        type: 'CURRENTSIZE',
        size,
    }
}

const receivePost = (json, total) => {
    return {
        type: 'RECEIVEPOST',
        data: json,
        total,
    }
}


const data = []
for (var i = 0; i < 100; i++) {
    data.push({
        id: i,
        name: i + 'hyj',
    })
}
const fetchPost = (state) => {  
    return (dispatch) => {
        setTimeout(() => {  //根据state对象的  当前页  和  每页多少条  去截取 所需要的数据
            const json = data.slice((state.currentPage) * state.pageSize, (state.currentPage + 1) * state.pageSize);
            const total = Math.ceil(data.length / state.pageSize); //计算页码个数
            dispatch(receivePost(json, total)) //派发action 将数据 和页码个数 传过去
        }, 1000)
    }
}

export {
    currentPaged,
    receivePost,
    fetchPost,
    currentSize,
}



import React from 'react'
import ReactDom from 'react-dom'
import App from './Containers/App'

import thunk from 'redux-thunk'
import rooterReducer from 'Redux/reducer'
import { createStore, applyMiddleware } from 'redux'



const store = createStore(rooterReducer, applyMiddleware(thunk))  //引入中间件  thunk 是一个函数 可以在action中进行非纯函数操作

import { Provider } from 'react-redux'

ReactDom.render(
    <Provider store={store}>
        <App />
    </ Provider >,
    document.getElementById('app')
)


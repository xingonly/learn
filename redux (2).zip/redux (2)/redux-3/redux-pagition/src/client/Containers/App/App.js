import React, { Component } from 'react';
import Table from 'Containers/Table'

import { connect } from 'react-redux'
import { currentPaged, fetchPost, currentSize } from 'Redux/actions'

class App extends React.Component {
    constructor(props) {
        super(props)
        this.changPage = this.changPage.bind(this)
        this.changeSize = this.changeSize.bind(this)

    }

    componentWillMount() {
        const { dispatch, data } = this.props;
        dispatch(fetchPost(data.change))
    }

    shouldComponentUpdate(nextProps, nextState) {
        console.log(1)
        const AcurrentPage = this.props.data.change.currentPage //旧的页码
        const ApageSize = this.props.data.change.pageSize//旧的每页总条数
        const { currentPage, pageSize, total } = nextProps.data.change //新的页码 新的每页总条数 新的页码总个数
        const { dispatch, data } = nextProps;
        if (AcurrentPage !== currentPage || pageSize !== ApageSize) { //如果当前页码发生改变 或者这页码总条数发生改变 则请求新的数据
            dispatch(fetchPost(data.change))
        }
        if (currentPage >= total) { //解决请求当前页大于 页码总个数 
            dispatch(currentPaged(total - 1));
        }
        return true;
    }

    changPage(idx) {
        const { dispatch } = this.props;
        const AcurrentPage = this.props.data.change.currentPage
        if (AcurrentPage === idx) { return ; }// 如果是当前页就不改变 页码
        dispatch(currentPaged(idx))

    }

    changeSize(size) {
        const { dispatch, data } = this.props;
        dispatch(currentSize(size))
    }
    render() {
        console.log(2)
        const { data } = this.props;
        return (
            <div>
                hello react
                <Table data={data} changePage={this.changPage} changeSize={this.changeSize} />
            </div>

        )
    }
}

const mapStateToProps = (state) => {
    return {
        data: state,
    }
}

export default connect(mapStateToProps)(App);

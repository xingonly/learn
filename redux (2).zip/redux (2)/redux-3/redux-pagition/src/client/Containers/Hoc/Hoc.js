import React from 'react'


const Hoc = (Component) => {
    return class extends React.Component {
        constructor() {
            super()
        }
        render() {
            let { data, total } = this.props.data.change
            const { changePage, changeSize } = this.props;
            return (
                <div>
                    hoc
                    < Component data={data} />
                    <div>
                        {
                            Array.from({ length: total }).map((item, idx) => {
                                return <span key={idx} onClick={() => {
                                    changePage(idx)
                                }}>{`第${idx + 1}页`}</span>
                            })
                        }
                        <select onChange={(e) => { changeSize(e.target.value) }}>
                            <option value="5">5</option>
                            <option value="10">10</option>
                            <option value="15">15</option>
                            <option value="20">20</option>
                        </select>
                    </div>
                </ div>
            )
        }
    }
}


export default Hoc;
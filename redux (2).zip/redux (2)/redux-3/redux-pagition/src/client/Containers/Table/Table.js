import React from 'react'
import Hoc from 'Containers/Hoc'

class Table extends React.Component {
    constructor() {
        super()
    }
    render() {
        const { data } = this.props;
        return (
            <div>
                {
                    data.map((item,idx) => {
                        return <p key={idx}>{item.name}</p>
                    })
                }
            </div>
        )
    }
}
export default Hoc(Table);
import React from 'react';
import { connect } from 'dva';
import Footer from "../../components/Footer/skict";
import Head from "../../components/Header/Head";
import Product from "../../components/Products/Products";


class Products extends React.Component{

    render(){
        return (
            <div className = "productWrap">
                {/* 头部 */}
                <Head/>
                {/* 主体 */}
                <Product />
                {/* 底部 */}
                <div className = "compute"> <Footer/> </div>
            </div>
        )
    }
}
const mapStateToProps = (state) => {
    return{
        data:state.Products.json
    }
}
export default connect(mapStateToProps)(Products);

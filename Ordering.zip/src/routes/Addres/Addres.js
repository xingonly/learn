import React from "react";
import "./Addres.css";

class Addres extends React.Component{
    constructor(){
        super()
        this.state = {

        }
    }
    render(){
        return(
            <div className = "addresWrap">
                <div className = "addresTop">
                    <div className = "addresLeft">
                        <img src = "http://fuss10.elemecdn.com/c/cd/c12745ed8a5171e13b427dbc39401jpeg.jpeg?imageView2/1/w/750/h/750" alt = ""/>
                    </div>
                    <div className = "addresRight">
                        <h2>满记甜品旗親店(西直]西珎广坊凱徳MALL店)</h2>
                        <span>营业中</span>
                        <ul>
                            <li>x</li>
                            <li>x</li>
                            <li>x</li>
                            <li>x</li>
                        </ul>
                        <p><span>口味8.5</span> <span>坏境8.5</span><span>服务8.5</span></p>
                    </div>
                </div>
                <div className = "addres">
                    <div className = "addresLeft">
                        <span>西直冂外大街1号西坏广場T1,五展21号(近西直)店地鉄站)</span>
                    </div>
                    <div className = "addresRight">
                        tel
                    </div>
                </div>
                <div className = "addresMsg1">
                    <h4>配送信息</h4>
                    <ul>
                        <li>10:00-21:00</li>
                        <li>起送$20配送Y6満50元免返費</li>
                        <li>送达</li>
                        <li>朝外SOHO、凱徳MALL等</li>
                    </ul>
                </div>
                <div className = "addresMsg2">
                    <h4>活动与服努</h4>
                    <ul>
                        <li>10:00-21:00</li>
                        <li>満30減10;満60元減15元(在线支付麦享)</li>
                        <li>折扣商品3.7折起</li>
                    </ul>
                </div>
            </div>
        )
    }
}
export default Addres;

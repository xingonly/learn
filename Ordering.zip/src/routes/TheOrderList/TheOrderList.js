import React from "react";
import { connect } from "dva";
import TheOrderLists from "../../components/TheOrderList/TheOrderList";

class TheOrderList extends React.Component {
    constructor() {
        super()
        this.state = {

        }
    }
    render() {
        return (
            <div>
                <TheOrderLists />
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {

    }
}
export default connect(mapStateToProps)(TheOrderList);

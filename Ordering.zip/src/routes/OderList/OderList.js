import React from "react";
import { connect } from "dva";
import "./OderList.scss";
import Bscroll from "better-scroll";
class OderList extends React.Component {
    constructor() {
        super()
        this.state = {
            data: {},
            flag: true,
            prices: {
                "lunchBox": 2,
                "delivery": 3,
                "onlinePayment": 8,
            }
        }
        this.scroll = this.scroll.bind(this);
    }
    componentDidMount() {
        const data = JSON.parse(localStorage.getItem("OderData"));
        this.setState({
            data,
        })
    }
    scroll(node) {
        if (node) {
            const newBscroll = new Bscroll(node, {
                scrolly: true,
                click: true,
            })
            newBscroll.refresh();
        }
    }
    GoBack() {
        this.props.history.push("/Products");
    }
    goAddress() {
        this.setState({
            show: false,
        })
        this.props.dispatch({
            type: "Products/getUserInfo"
        })
        //this.props.history.push("/MyAddres");
    }
    goPay() {
        this.props.history.push("/Pay");
    }
    toMyaddres() {
        this.props.history.push("/MyAddres");
    }
    render() {
        const { allPrice, datas } = this.state.data;
        const { addresUserInfo } = this.props;
        const { lunchBox, delivery, onlinePayment } = this.state.prices;
        const nums = lunchBox + delivery - onlinePayment;
        return (
            <div className="Oder-wrap">
                <header className="Oder-header">
                    <div className="Oder-top">
                        <span onClick={() => {
                            this.GoBack();
                        }}>{"<"}</span>
                        <b>确认订单</b>
                        <span></span>
                    </div>
                    <div className="Oder-address">
                        <span className={this.state.flag ? "shows" : "hides"} onClick={() => {
                            this.goAddress();
                        }}>+添加收货地址</span>
                        <div className="Oder-add-addres shows">
                            {
                                addresUserInfo && addresUserInfo.map((item, key) => {
                                    return (
                                        <div key={key}>
                                            <b> {item.address}{"...."}</b>
                                            <div>{item.name}先生  收  {item.tel}</div><strong className="Oder-toAddres" onClick={() => {
                                                this.toMyaddres()
                                            }
                                            }>{">"}</strong>
                                        </div>
                                    )
                                })
                            }
                        </div>
                    </div>
                </header>
                <section className="Oder-section" ref={this.scroll}>
                    <div className="contentList">
                        <div className="Oder-time">
                            <p><span className="Oder-time-left">送达时间</span><span>尽快送达（12：53送达）></span></p>
                            <p><span className="Oder-time-left">支付方式</span><span>在线支付</span></p>
                        </div>
                        <div className="Oder-content">
                            <h4 className="Oder-content-title">吉野家<span> ( 上地三街店 ) </span></h4>
                            <ul className="Oder-content-List">
                                {
                                    datas && datas.map((item, key) => {
                                        return (
                                            <li key={key}>
                                                <div className="lis">
                                                    <div>
                                                        <b>{item.name}</b><span>x  {item.count}</span><i>{item.price}/份</i>
                                                    </div>
                                                    <div className="allprice">
                                                        ${item.count * item.price}
                                                    </div>
                                                </div>
                                                <div className="lis-dec">
                                                    <div><span>餐盒</span><span>￥{lunchBox * item.count}</span></div>
                                                    <div><span>配送</span><span>￥{delivery * item.count}</span></div>
                                                    <div><span>在线支付</span><span>优惠￥{onlinePayment * item.count}</span></div>
                                                </div>
                                            </li>
                                        )
                                    })
                                }
                            </ul>
                        </div>
                    </div>
                </section>
                <footer className="Oder-footer">
                    <div className="Oder-footer-left">合计：￥{allPrice - nums}</div>
                    <div className="Oder-footer-right" onClick={() => {
                        this.goPay();
                    }}>去支付</div>
                </footer>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        addresUserInfo: state.Products.addresUserIfon
    }
}
export default connect(mapStateToProps)(OderList);

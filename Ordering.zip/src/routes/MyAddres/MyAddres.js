import React from "react";
import { connect } from "dva";
import { withRouter } from 'react-router-dom';
import "./MyAddres.css";

class MyAdders extends React.Component {
    constructor() {
        super()
        this.state = {
            arrAddress: [{
                "id": 1,
                "address": "北京八维学院研修学院篮球场",
                "tel": "联系电话：132xxxxxxxx",
                "name": "刘xx"
            }, {
                "id": 2,
                "address": "北京八维学院研修学院篮球场122",
                "tel": "联系电话：132xxxxxxxx",
                "name": "杨xx"
            }]
        }
    }
    toAddAddres() {
        this.props.history.push("/AddAddres");
    }
    gobackAddres(item) {
        this.props.history.push({
            pathname: "/defaultAddres", state: {
                item,
            }
        });
    }
    componentDidMount() {
        this.props.dispatch({
            type: "Products/getUserInfo"
        })
    }
    goback() {
        this.props.history.push("/defaultAddres");
    }
    render() {
        const { otherAddress } = this.props.location.state;
        return (
            <div className="MyAddersWrap">
                <header className="MyAddersHeader"><span onClick={() => this.goback()}>{"<"}</span>
                    <span>我的地址</span>
                    <span>{""}</span>
                </header>
                <section className="myAdders-section">
                    {
                        otherAddress ? otherAddress.map((item, key) => {
                            return (
                                <div className="myaddres" key={key}>
                                    <p>姓名：<b className="addres-name">{item.name}</b> <span className="addres-tel"> {item.tel}</span></p>
                                    <div>
                                        <b>地址:</b><span> {item.address}</span>
                                        <span className="addres-suer" onClick={() => {
                                            this.gobackAddres(item);
                                        }}>确认添加</span>
                                    </div>
                                </div>
                            )
                        }) : "暂无地址"
                    }
                </section>
                <footer className="MyAddersFooter" onClick={() => {
                    this.toAddAddres();
                }}>新增收货地址</footer>
            </div>
        )
    }
}
const mapStateToProps = (state) => {
    return {
        nums: state.nums
    }
}
export default connect(mapStateToProps)(withRouter(MyAdders));

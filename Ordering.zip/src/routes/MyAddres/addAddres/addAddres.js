import React from "react";
import "./addAddres.css";
import { withRouter } from 'react-router-dom';

class Add extends React.Component {
    constructor() {
        super()
        this.state = {

        }
    }
    gobackto() {
        this.props.history.push("/MyAddres");
    }
    render() {
        return (
            <div className="MyAddersWrap">
                <header className="MyAddersHeader"><span onClick={() => {
                    this.gobackto();
                }}>{"<"}</span>
                    <span>新增收货地址</span>
                    <span>{""}</span></header>
                <section className="MyAddersSection">
                    <ul className="userInfo">
                        <li> <label htmlFor="">姓名：</label><input type="text" /></li>
                        <li> <label htmlFor="">手机号：</label><input type="text" /></li>
                        <li> <label htmlFor="">送餐地址：</label><input type="text" /></li>
                        <li><button>提交</button></li>
                    </ul>
                </section>
            </div>
        )
    }
}

export default withRouter(Add);

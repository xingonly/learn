import React from "react";
import BScroll from 'better-scroll';
import Footer from "../../components/Footer/skict";
import "./Detail.css";

class Detail extends React.Component{
    constructor(){
        super()
        this.state = {
            data:{},
        }
        this.scroll = this.scroll.bind(this);
    }
    back(){
        this.props.history.push({ pathname:'/Products'})
        localStorage.setItem("DetailData","")
    }
    scroll(node){
        if(node){
            let newScoll = new BScroll(node,{
                scrollY:true,
                click:true,
            });
            newScoll.refresh();
        }
    }
    componentDidMount(){
        this.setState({
            data:JSON.parse(localStorage.getItem("DetailData")),
        })
    }
    render(){
        const { data } = this.state;
        return(
            <div ref = {this.scroll}  className = "Detailwrapper">
                <div className = "Detailwrap">
                    <div className = "top">
                        <img src = {data.image} alt=""/>
                    </div>
                    <div className = "DetailSection">
                        <h2>{data.name}</h2>
                        <div>
                            <span>{data.price}元</span>
                            <span><button>加入购物车</button></span>
                        </div>
                        <h4>菜品详情</h4>
                        <p>{data.info}</p>
                    </div>
                    <div className = "Goback" onClick = {()=>{
                        this.back();
                    }}>{'<'}</div>
                </div>
                <div className = "compute">
                    <Footer/>
                </div>
            </div>
        )
    }
}

export default Detail;

import React from "react";
import { connect } from "dva";
import "./Pay.scss";

class Pay extends React.Component {
    constructor() {
        super()
        this.state = {
            nums: ["1", "2", "3", "4", "5", "6", "7", "8", "9", "x", "0", "."],
            valNums: "",
            up: false,
        }
    }
    value(val) {
        if (val === "x") {
            this.setState({
                valNums: ""
            })
        } else {
            let value = this.refs.text.value;
            value += val;
            this.setState({
                valNums: value
            })
        }
    }
    clear() {
        this.setState({
            valNums: this.state.valNums.slice(0, this.state.valNums.length - 1)
        })
    }
    goPay() {
        if (this.state.valNums !== "") {
            alert("调起支付接口了...,支付金额：" + this.state.valNums + "元");
            this.setState({
                valNums: ""
            })
        } else {
            alert("没有输入金额...")
        }
    }
    render() {
        return (
            <div className="pay-wrap">
                <header className="pay-header">
                    <p>满记甜品旗舰店（西直门西环广场凯丽大街十巷）</p>
                </header>
                <div className="pay-content">
                    <div className="pay-tit">订单金额（元）</div>
                    <div className="pay-money">
                        <label htmlFor="">￥</label><input ref="text" onFocus={() => {
                            this.setState({
                                up: false
                            })
                        }} onBlur={() => {
                            // this.setState({
                            //     up: true
                            // })
                        }} value={this.state.valNums} type="text" placeholder="请输入金额" />
                    </div>
                    <div className="pay-tit">备注</div>
                    <div className="pay-remark">
                        <label htmlFor=""></label><input type="text" placeholder="如包间号、服务员等" />
                    </div>
                    <div className="pay-expense">
                        实付金额（元）：<b>${this.state.valNums}</b>
                    </div>
                </div>
                <div className="pay-suer" onClick={() => {
                    this.goPay()
                }
                }>
                    确认付款
              </div>
                <div className={this.state.up ? "pay-computed up" : "pay-computed down"} >
                    <div className="pay-left">
                        {
                            this.state.nums.map((item, key) => {
                                return (
                                    <span key={key} value="1" onClick={(e) => {
                                        this.value(e.target.innerHTML);
                                    }}>{item}</span>
                                )
                            })
                        }
                    </div>
                    <div className="pay-right">
                        <div onClick={(e) => {
                            this.clear()
                        }} className="pay-right-top">x</div>
                        <div onClick={() => {
                            this.setState({
                                up: true,
                            })
                        }} className="pay-right-bottom">完成</div>
                    </div>
                </div>
            </div >
        )
    }
}

const mapStateToProps = (state) => {
    return {

    }
}
export default connect(mapStateToProps)(Pay)

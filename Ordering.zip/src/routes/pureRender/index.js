import React from "react";
import { Lis1, Lis2, Lis3 } from "../../components/pRender/index";
import index from "../../utils/pureRender";
// import classNames from "../../utils/classNames";自己封装类库
import "./style.css";
import classNames from "classnames";
class Index extends React.Component {
    constructor() {
        super()
        this.state = {
            flag: true,
        }
        this.shouldComponentUpdate = index;
    }
    render() {
        return (
            <div>
                <Lis1 flag={this.state.flag} />
                <Lis2 flag={this.state.flag} />
                <Lis3 flag={this.state.flag} />
                <button onClick={() => {
                    this.setState({
                        flag: false
                    })
                }} className={classNames("hide1", "show1", "action1", "position")}>set props</button>
            </div>
        )
    }
}
export default Index;

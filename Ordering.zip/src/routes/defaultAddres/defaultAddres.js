import React from "react";
import { connect } from "dva";
import { Address, Menu } from "../../components/defaultAddress";
import "../OderList/OderList.scss";
import "./defaultAddres.scss";


class OderList extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            flag: true,
            prices: {
                "lunchBox": 2,
                "delivery": 3,
                "onlinePayment": 8,
            },
        }
    }
    componentDidMount() {
        //下面方法是对页面是否刷新保存数据，重新加载数据丢失，取消不刷新页面，保存数据
        window.onbeforeunload = (e) => {
            if (e) {
                e.returnValue = "关闭提示..."
            }
            return "关闭提示"
        }
    }
    GoBack() {
        //返回商品页
        this.props.history.push("/Products");
    }
    goPay() {
        //跳转支付路由
        this.props.history.push("/Pay");
    }
    render() {
        //通过reduces分发下来的数据，并解构
        const { allPrice, datas, addresUserInfo, nums } = this.props;
        // const { lunchBox, delivery, onlinePayment } = this.state.prices;
        // const num = (lunchBox + delivery - onlinePayment) * nums;

        return (
            <div className="Oder-wrap">
                <header className="Oder-header">
                    <div className="Oder-top">
                        <span onClick={() => {
                            this.GoBack();
                        }}>{"<"}</span>
                        <b>确认订单</b>
                        <span></span>
                    </div>
                    {/* 地址组件，并其向下分发数据 */}
                    <Address addresUserInfo={addresUserInfo} />
                </header>
                <section className="Oder-section" >
                    {/* 客户所选择的的商品列表数据 */}
                    <Menu allPrice={allPrice ? allPrice : ""} datas={datas ? datas : ""} nums={nums} />
                    <div className="heji">
                        小计：￥{allPrice}
                    </div>
                </section>
                <footer className="Oder-footer">
                    <div className="Oder-footer-left">合计：￥{allPrice}</div>
                    <div className="Oder-footer-right" onClick={() => {
                        this.goPay();
                    }}>去支付</div>
                </footer>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    //接受所有数据通过此路由进行对组件分发所需的数据
    return {
        //地址
        addresUserInfo: state.Products.addresUserInfo,
        //商品列表数据
        datas: state.Products.datas,
        //总价
        allPrice: state.Products.allPrice,
        //商品个数
        nums: state.Products.nums
    }
}
export default connect(mapStateToProps)(OderList);

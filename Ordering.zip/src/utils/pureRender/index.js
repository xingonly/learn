//第三方包检测传入的值进行比较，如果相等返回true，如果不相等返回false，用is方法
import { is } from 'immutable';
export default function (nextProps, nextState) {
    //参数一定是对象
    //获取构造函数上的props
    const thisPropsA = this.props || {};
    //获取下一个props
    const thisPropsB = nextProps || {};
    //获取构造函数上的state
    const thisStateA = this.state || {};
    //获取下一个state
    const thisStateB = nextState || {};
    //判断this.props与nextProps的长度是不是相等，不相等进行渲染，return true ，如果相等不进行渲染，return false ，state也同理
    if (Object.keys(thisPropsA).length !== Object.keys(thisPropsB).length || Object.keys(thisStateA).length !== Object.keys(thisStateB).length) {
        return true;
    }
    //判断对象中的key值是否相等，不相等返回turn，进行渲染，相等反之---> 这是props的判断与更改
    //这里用到了obj.hasOwnProperty()方法，检测对象的属性，用第三方包的is()比较相等是否
    for (let keyA in thisPropsB) {
        if (!thisPropsA.hasOwnProperty(keyA) || !is(thisPropsA[keyA], thisPropsB[keyA])) {
            return true;
        }
    }
    //判断对象中的key值是否相等，不相等返回turn，进行渲染，相等反之---> 这是state的判断与更改
    //这里用到了obj.hasOwnProperty()方法，检测对象的属性，用第三方包的is()比较相等是否
    for (let keyB in thisStateB) {
        if (!thisStateA.hasOwnProperty(keyB) || !is(thisStateA[keyB], thisStateB[keyB])) {
            return true;
        }
    }
    return false;
    //true渲染
    //false不渲染
}
/**
* 调用次方法在组件中，调用方式
*import index from "../../utils/pureRender";引入这个js文件，
*this.shouldComponentUpdate = index；在construct函数中调用
*/


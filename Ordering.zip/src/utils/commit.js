
const getData = (LocalData, oldData) => {
    oldData && oldData.map(item => {
        item.foods.map((items) => {
            Object.keys(LocalData).map(key => {
                if (key * 1 === items.pid) {
                    items.count = LocalData[key];
                }
            })
            return items;
        })
    })
}

const ato = (every) => {
    // console.log(JSON.parse(localStorage.getItem("dataItem")));
    let Obj = {
    };

    every.forEach(item => {
        Obj[item.pid] = item.count;
    });
    return Object.assign({}, JSON.parse(localStorage.getItem("dataItem")), Obj);
}

export {
    getData,
    ato,
}

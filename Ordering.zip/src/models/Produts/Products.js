// import { dataList} from "../../services/shop/products.js";
import { ato, getData } from "../../utils/commit.js";
import axios from "axios";
/**
 * 数据请求通过axios数据拦截请求
 * {
 *      1.商品所有数据dataList，发起请求
 *      2.用户地址数据getUserInfo，发请求
 * }
 */
export default {
    //配发类型的时候必须以这种格式[Products/dataList]发送
    namespace: 'Products',
    state: {},
    effects: {
        // {1}
        //call异步请求数据
        //put执行
        *dataList({ payload }, { call, put }) { // eslint-disable-line
            const json = yield axios.get("/getJson").then(res => res.data).catch(err => {
                return {
                    code: 0,
                    datas: []
                }
            })
            //请求回来的数据
            const dataLists = json.data;
            if (json.code) {
                const localStorageData = JSON.parse(localStorage.getItem('dataItem'));
                //如果本地存储有数据就去本地区取，如果没有智能取从新请求，进行页面的渲染
                localStorageData && getData(localStorageData, dataLists);
                //发送到reducer上
                yield put({ type: "data", payload: { json: dataLists } });
                //发送到reducer上，在执行shopCar，返回数据单state上
                yield put({ type: "shopCart", payload: {} });
                return Promise.resolve(1);
            } else {
                return Promise.reject(0);
            }
        },
        // {2}
        *getUserInfo({ payload }, { call, put }) {
            const addresUserInfo = yield axios("/userInfo").then(res => {
                return res.data;
            })
            if (addresUserInfo.code) {
                yield put({
                    type: "AddresUserIfon", payload: {
                        addresUserInfo: addresUserInfo,
                    }
                    //type:发送的类型
                    //payload是发送的请求回来的数据
                })
            }
        }
    },
    reducers: {
        //首次页面的数据请求保存在state里，要解构原先的state，合并请求过来的数据
        data(state, action) {
            //state:老的state，action就是通过effects中的yield put 发送过来的数据
            return {
                //
                ...state, ...action.payload
            }
        },
        //清楚本地存储的数据，做清空购物车
        clearPrice(state, action) {
            localStorage.clear();
            return {
                ...state,
                datas: [],
            };
        },
        //购物车加减和数据的保存在页面
        shopCart(state, action) {
            //通过解构接收加或减传过来的参数
            const { pid, num } = action.payload;
            //通过解构state里的原数据
            const { json } = state;
            //购物车总价
            let allPrice = 0,
                //存放你的选中的商品
                datas = [];
            //遍历原数据判断出点击的当前的一项，选定此项的加和减，并计算价格
            json.forEach((item) => {
                item.foods.forEach(i => {
                    if (i.pid === pid) {
                        num !== 1 ? i.count-- : i.count++;
                        i.count = i.count <= 0 ? 0 : i.count;
                    }
                    //确认的数据添加进datas中，保存数据
                    if (i.count) {
                        datas.push(i);
                    }
                    //计算总价
                    allPrice += i.count ? i.price * i.count : 0;
                })
            });
            //同时存入本地存储
            localStorage.setItem("dataItem", JSON.stringify(ato(datas)));
            //返回数据单state上
            return { ...state, allPrice, datas }
        },
        //地址存储
        AddresUserIfon(state, action) {
            const { addresUserInfo } = action.payload;
            return {
                ...state, addresUserInfo
            }
        }
    },
};

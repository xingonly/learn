import axios from "axios";
/**
 * 最精髓的是在state上定义一个值，来保存数据请求不一样的类型
 * 便于判断数据的渲染
 * 首次全部列表赋值
 * 条件符合在通过条件找到对应的数据
 * 并替换掉首次的数据进行渲染
 */
export default {
    namespace: 'TheOrderList',
    state: {
        lsArr: [],
        data: []
    },
    effects: {
        *getTheOrderData({ payload }, { call, put }) {
            const TheOrderDataJson = yield axios.get("/TheOrderData", { userInfo: payload.uid }).then(res => {
                return res.data;
            }).catch(err => {
                return {
                    code: 0
                }
            })
            if (TheOrderDataJson.code) {
                yield put({
                    type: "oderList",
                    TheOrderDataJson: TheOrderDataJson.result.content,
                })
            } else {
                alert("接口错了...");
            }
        },
        *odetItemList({ payload }, { call, put }) {
            yield put({ type: "setOderIndex", index: payload.index });
        }
    },
    reducers: {
        oderList(state, action) {
            return {
                ...state, lsArr: action.TheOrderDataJson, data: action.TheOrderDataJson
            };
        },
        setOderIndex(state, action) {
            let newData = [];
            state.data.map((item, key) => {
                if (item.type === action.index) {
                    newData.push(item);
                } else if (action.index === 0) {
                    newData.push(item);
                }
            })
            return {
                ...state, lsArr: [...newData]
            }
        }
    },
};

import React from "react";
import { connect } from "dva";
import "./Computed.css";

class Computed extends React.Component {
    constructor() {
        super()
        this.state = {
            flag: false,
        }
    }
    changeFlag() {
        this.setState({
            flag: true,
        })
    }
    render() {
        const { item, result } = this.props;
        const { count } = item;
        return (
            <div className="computed-wrap" onClick={(e) => e.stopPropagation()}>
                {
                    count === 0 && !this.state.flag ? <div id="btnHide" onClick={() => {
                        this.changeFlag();
                    }}>选规则</div> : <div>
                            <span onClick={() => result(item.pid, -1)} className="cutBut">-</span>
                            <b className="temp">{count}</b>
                            <span onClick={() => result(item.pid, 1)} className="cutBut">+</span>
                        </div>
                }
            </div>
        )
    }
}


const mapStateToProps = (state) => {
    return {
        count: state.Products,
    }
}
export default connect(mapStateToProps)(Computed);


import React from "react";
import { connect } from "dva";
import { withRouter } from "dva/router";
import Computed from "./Computed/Computed";

class ProItem extends React.Component{
    constructor(){
        super()
        this.state = {

        }
    }
    toParams(k){
        this.props.history.push({ pathname:'/Detail',state:{data : k}})
        localStorage.setItem("DetailData",JSON.stringify(k));
    }
    render(){
        const { item } = this.props;
        return (
            <div  className = "title">
                <h4>{item.name}</h4>
                {
                    item.foods.map((i,k)=>{
                        return(
                            <dl key = {k} onClick = {()=>{
                                    this.toParams(i);
                                }}>
                                <dt><img src = {i.image} alt=""/></dt>
                                <dd>
                                    <p>{i.name}</p>
                                    <div>
                                        <span><b>{i.price}</b>/元</span>
                                        <Computed
                                            item = { i }
                                            count = {i.count}
                                            result = {(pid,num)=>{
                                                this.props.dispatch({
                                                    type:"Products/shopCart",
                                                    payload:{
                                                        pid,
                                                        num,
                                                        id:item.id
                                                    }
                                                })
                                            }}
                                        />
                                    </div>
                                </dd>
                            </dl>
                        )
                    })
                }
            </div>
        )
    }
}
export default withRouter(connect()(ProItem));

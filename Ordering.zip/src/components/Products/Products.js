import React from 'react';
import { connect } from 'dva';
import BScroll from 'better-scroll';
import './Products.scss';
import ProItem from "./productItem/productItem";

class Products extends React.Component {
    constructor() {
        super()
        this.state = {
            index: 0,
            scrolly: 0,
        }
        this.scroll = this.scroll.bind(this);
        this.scroll1 = this.scroll1.bind(this);
        this.newArr = [];
        this.scrolls = 0;
    }
    componentDidMount() {
        const { dispatch } = this.props;
        dispatch({
            type: "Products/dataList",
        }).then(res => {
            this.getHeight();
        })
    }
    shouldComponentUpdate(nextProps, nextState) {
        if (nextState.index !== this.state.index && this.newArr.length > 0) {
            return false;
        }
        return true;
    }
    toAdders() {
        this.props.history.push({ pathname: '/Addres' });
    }
    scroll(node) {
        if (node) {
            this.newBScroll = new BScroll(node, {
                scrollY: true,
                click: true,
            })
            this.newBScroll.refresh();
        }
    }
    changeClass(i) {
        this.setState({
            index: i,
        }, () => {
            let title = this.refs.content.getElementsByClassName("title");
            let elH = title[i];
            this.newBScroll.scrollToElement(elH, 200);
        });
    }
    scroll1(node) {
        if (node) {
            this.newBScroll = new BScroll(node, {
                probeType: 3,
                scrollY: true,
                click: true,
            })
            this.newBScroll.on("scroll", (pos) => {
                this.scrolls = Math.abs(Math.round(pos.y));
                this.setState({
                    index: this.getIndex(),
                })
            });
            this.newBScroll.refresh();
        }
    }
    getHeight() {
        let allNode = document.getElementsByTagName("h4");
        for (let i = 0; i < allNode.length; i++) {
            let h = allNode[i].offsetTop;
            this.newArr.push(h);
        }
    }
    getIndex() {
        let cur = this.newArr.findIndex((item) => item > this.scrolls);
        cur = (cur === -1) ? this.newArr.length : cur;
        //cur = cur - 1;
        return cur;
    }
    render() {
        return (
            <section className="productsection">
                {/* 左边 */}
                <div className="left" ref={this.scroll}>
                    <ul>
                        {
                            this.props.data ? this.props.data.map((item, key) => {
                                return <li key={key} className={this.state.index === key ? "show" : "hide"} onClick={(e) => {
                                    this.changeClass(key);
                                }}>{item.name}</li>
                            }) : "未加载商品数据"
                        }
                    </ul>
                </div>
                {/* 右边 */}
                <div className="right" id="right" ref={this.scroll1}>
                    <div className="content" ref="content">
                        {
                            this.props.data ? this.props.data.map((item, key) => {
                                return <ProItem item={item} key={key} />
                            }) : "未加载商品数据"
                        }
                    </div>
                </div>
            </section>
        )
    }
}
const mapStateToProps = (state) => {
    return {
        data: state.Products.json
    }
}
export default connect(mapStateToProps)(Products);

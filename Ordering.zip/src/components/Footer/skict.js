import React from "react";
import { connect } from 'dva';
import { withRouter } from "dva/router";
import "./skict.css";
import Computed from "../Products/productItem/Computed/Computed";
import logo from '../../../public/images/images/1_03.png';

class Footer extends React.Component {
    constructor() {
        super()
        this.state = {
            total: 0,
            flag: true,
        }
    }
    choise() {
        if (this.props.allPrice === 0) {
            alert("您没有购买的商品，请选择...")
            return;
        }
        let counts = 0;
        this.props.datas && this.props.datas.map((item) => {
            counts += item.count;
        })
        localStorage.setItem("OderData", JSON.stringify(this.props));
        this.props.history.push({
            pathname: "/defaultAddres",
            state: {
                nums: counts,
                item: this.props.datas,
            }
        })
    }
    clearData() {
        this.props.dispatch({ type: "Products/clearPrice" });
        this.props.dispatch({ type: "Products/dataList" });
        this.props.dispatch({ type: "Products/getUserInfo" })
        this.setState({
            flag: true,
        });
        this.forceUpdate();
    }
    upOrDown() {
        if (this.props.allPrice === 0) {
            return;
        }
        this.setState({
            flag: !this.state.flag,
        })
    }
    setClass() {
        if (this.props.allPrice === 0) {
            return;
        }
        this.setState({
            flag: true,
        })
    }
    render() {
        const { allPrice, datas } = this.props;
        return (
            <div>
                <div className="compute">
                    <div className="logo" onClick={() => {
                        this.upOrDown();
                    }}><img src={logo} width="20" height="20" alt="" /></div>
                    <div className="price" onClick={() => {
                        this.upOrDown();
                    }}>￥{allPrice ? allPrice : 0}</div>
                    <div className="result" onClick={() => {
                        this.choise();
                    }}>选好了</div>
                </div>
                <div className={this.state.flag ? "shopcart-list shopcart-list-down" : "shopcart-list shopcart-list-up"}>
                    <div className="list-header">
                        <h1 className="title">购物车</h1> <span onClick={() => {
                            this.clearData();
                        }} className="empty">清空</span>
                    </div>
                    <div className="list-content">
                        {
                            datas && datas.map((item, key) => {
                                return (
                                    <li key={key}>
                                        <div>{item.name}</div>
                                        <Computed
                                            item={item}
                                            count={item.count}
                                            result={(pid, num) => {
                                                this.props.dispatch({
                                                    type: "Products/shopCart",
                                                    payload: {
                                                        pid,
                                                        num,
                                                        id: item.id
                                                    }
                                                })
                                            }}
                                        />
                                    </li>
                                )
                            })
                        }
                    </div>
                </div>
                <div className={this.state.flag ? "list-mask list-mask-hide" : "list-mask list-mask-show"} onClick={() => this.setClass()}></div>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        allPrice: state.Products.allPrice,
        datas: state.Products.datas
    }
}
export default withRouter(connect(mapStateToProps)(Footer));

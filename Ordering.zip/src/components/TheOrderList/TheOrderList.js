import React from "react";
import { connect } from "dva";
import "./TheOrderList.scss";
import img from "../../../public/images/images/1_03.png";

class TheOrderList extends React.Component {
    constructor() {
        super()
        this.state = {
            arr: [
                "全部",
                "待消费",
                "以完成",
                "以退款"
            ],
            index: 0,
        }
    }
    changeColor(i) {
        this.setState({
            index: i
        })
        this.props.dispatch({
            type: "TheOrderList/odetItemList",
            payload: {
                index: i
            }
        })
    }
    componentDidMount() {
        this.props.dispatch({
            type: "TheOrderList/getTheOrderData", payload: {
                uid: "1002"
            }
        })
    }

    render() {
        const { newData } = this.props;
        return (
            <div className="TheOrderList-wrap">
                <header className="TheOrderList-header">
                    订单管理
                </header>
                <section className="TheOrderList-section">
                    <div className="TheOrderList-allTit">
                        {
                            this.state.arr.map((item, key) => {
                                return <span className={this.state.index === key ? "action" : ""} key={key} onClick={() => {
                                    this.changeColor(key)
                                }
                                }>{item}</span>
                            })
                        }
                    </div>
                    {
                        newData && newData.map((item, key) => {
                            return (
                                <div className="TheOrderList-list" key={key}>
                                    <h1>
                                        <span>{item.storename}</span><span>{item.typeStatic}</span>
                                    </h1>
                                    <h2><span>{item.createTime}</span><span>{item.price}</span></h2>
                                    <dl>
                                        <dt>
                                            <img src={item.productImg} width="100" height="80" alt="" />
                                        </dt>
                                        <dd>
                                            <span>{item.getThis}</span><span>
                                                {
                                                    item.unsubscribe.map((item, i) => {
                                                        return (<button key={i}>{item}</button>)
                                                    })
                                                }
                                            </span>
                                        </dd>
                                    </dl>
                                </div>
                            )
                        })
                    }
                </section>
            </div>
        )
    }
}
const mapStateToProps = (state) => {
    return {
        newData: state.TheOrderList.lsArr,
    }
}
export default connect(mapStateToProps)(TheOrderList);

import React from "react";
// import classNames from "../../utils/classNames";
import classNames from "classnames";
class Lis2 extends React.Component {
    constructor() {
        super()
        this.state = {
            arr: ["1"]
        }
    }
    render() {
        console.log("renser 2")
        return (
            <div className={classNames("hide1", "show1", "action1")}>
                Lis2
            </div>
        )
    }
}
export default Lis2;

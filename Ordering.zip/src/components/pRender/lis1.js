import React from "react";
// import classNames from "../../utils/classNames";
import classNames from "classnames";
class Lis1 extends React.Component {
    constructor() {
        super()
        this.state = {
            arr: ["0"]
        }
    }
    render() {
        console.log(this.state.arr);
        console.log("renser 1")
        return (
            <div className={classNames("hide1", "show1", "action1")} >
                Lis1
            </div>
        )
    }
}
export default Lis1;

import React from 'react';
import { connect } from 'dva';
import { withRouter } from "dva/router";
// import { Icon } from "antd";
import './Head.css';
import img from '../../../public/images/1_03.png';

class Head extends React.Component{
    constructor(){
        super()
        this.state = {
        }
      }
    toAdders(){
        this.props.history.push({ pathname:'/Addres'});
    }

    render(){
        return (
            <header className = "header">
                <dl>
                    <dd>
                        <img src = {img} alt = ""/>
                    </dd>
                    <dt>
                        <h3>满记甜品（西单大学城店）</h3>
                        <span>营业中</span>
                    </dt>
                    <b className = "headerRight" onClick = {() =>{
                        this.toAdders()
                    }}>></b>
                    {/* <Icon type = "right"/> */}
                </dl>
            </header>
        )
    }
}
const mapStateToProps = (state) => {
    return{

    }
}
export default withRouter(connect(mapStateToProps)(Head));

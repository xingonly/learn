import React from "react";

class Option extends React.Component {
    constructor() {
        super()
        this.state = {

        }
    }
    render() {
        return (
            <div>
                Option
            </div>
        )
    }
}

export default Option;

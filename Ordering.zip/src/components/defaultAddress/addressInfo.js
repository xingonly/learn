import React from "react";
import { connect } from "dva";
import { withRouter } from "dva/router";
import indexs from "../../utils/pureRender";

class Address extends React.Component {
    constructor() {
        super()
        this.state = {

        }
        this.shouldComponentUpdate = indexs;
    }
    componentDidMount() {
        this.props.dispatch({
            type: "Products/getUserInfo"
        })
    }
    toMyaddres(otherAddress) {
        //跳转页面并进行路由传值
        this.props.history.push({
            pathname: "/MyAddres", state: {
                otherAddress: otherAddress
            }
        });
    }
    goAddress(otherAddress) {
        //向reducer派发一个类型，
        this.props.dispatch({
            type: "Products/getUserInfo"
        })
        //跳转页面并进行路由传值
        this.props.history.push({
            pathname: "/MyAddres", state: {
                otherAddress: otherAddress
            }
        });
    }
    render() {
        return (
            <div className="Oder-address">
                {
                    this.props.addresUserInfo && this.props.addresUserInfo.defaultInfo ? <div className="Oder-add-addres shows">
                        <div>
                            <b>{this.props.addresUserInfo.defaultInfo[0].address && this.props.addresUserInfo.defaultInfo[0].address}{"...."}</b>
                            <div>{this.props.addresUserInfo.defaultInfo[0].name && this.props.addresUserInfo.defaultInfo[0].name}  收  {this.props.addresUserInfo.defaultInfo[0].tel && this.props.addresUserInfo.defaultInfo[0].tel}</div>
                            <strong className="Oder-toAddres" onClick={() => {
                                this.toMyaddres(this.props.addresUserInfo && this.props.addresUserInfo.otherAddress);
                            }
                            }>{">"}</strong>
                        </div>
                    </div> : <span onClick={() => {
                        this.goAddress(this.props.addresUserInfo && this.props.addresUserInfo.otherAddress);
                    }}>+ 添加收货地址</span>
                }
            </div>
        )
    }
}
const mapStateToProps = (state) => {
    return {
    }
}
export default connect(mapStateToProps)(withRouter(Address));

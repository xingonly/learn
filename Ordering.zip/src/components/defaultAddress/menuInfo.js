import React from "react";
import Bscroll from "better-scroll";
import indexs from "../../utils/pureRender";

class Menu extends React.Component {
    constructor() {
        super()
        this.state = {
            prices: {
                "lunchBox": 2,
                "delivery": 3,
                "onlinePayment": 8,
            },
        }
        this.scroll = this.scroll.bind(this);
        this.shouldComponentUpdate = indexs;
    }
    scroll(node) {
        if (node) {
            const newBscroll = new Bscroll(node, {
                scrolly: true,
                click: true,
            })
            newBscroll.refresh();
        }
    }
    render() {
        const { datas } = this.props;
        const { lunchBox, delivery, onlinePayment } = this.state.prices;
        return (
            <div className="content" ref={this.scroll}>
                <div className="contentList">
                    <div className="Oder-time">
                        <p><span className="Oder-time-left">送达时间</span><span>尽快送达（12：53送达）></span></p>
                        <p><span className="Oder-time-left">支付方式</span><span>在线支付</span></p>
                    </div>
                    <div className="Oder-content">
                        <h4 className="Oder-content-title">吉野家<span> ( 上地三街店 ) </span></h4>
                        <ul className="Oder-content-List">
                            {
                                datas ? datas.map((item, key) => {
                                    return (
                                        <li key={key}>
                                            <div className="lis">
                                                <div>
                                                    <b>{item.name}</b><span>x  {item.count}</span><i>{item.price}/份</i>
                                                </div>
                                                <div className="allprice">
                                                    ${item.count * item.price}
                                                </div>
                                            </div>
                                            <div className="lis-dec">
                                                <div><span>餐盒</span><span>￥{lunchBox * item.count}</span></div>
                                                <div><span>配送</span><span>￥{delivery * item.count}</span></div>
                                                <div><span>在线支付</span><span>优惠￥{onlinePayment * item.count}</span></div>
                                            </div>
                                        </li>
                                    )
                                }) : <div className="dataWu">暂无数据</div>
                            }
                        </ul>
                    </div>
                </div>
            </div>
        )
    }
}

export default Menu;

import axios from "axios";
import AxoisMockAdapte from "axios-mock-adapter";
import data from "./data.json";
import userInfo from "./userInfo.json";
import TheOrderData from "./TheOrderList.json";
const mock = new AxoisMockAdapte(axios);

mock.onGet("/getJson").reply(200, data);
mock.onGet("/userInfo").reply(200, userInfo);
mock.onGet("/TheOrderData").reply((config) => {
    return new Promise((resolve, reject) => {
        const { userInfo } = config;
        // console.log(TheOrderData);
        let oderData = {};
        TheOrderData.map((item) => {
            if (item.userIfon === userInfo) {
                oderData = { ...item };
            }
        })
        return resolve([200, { code: 1, result: oderData }])
    })
});


import React from 'react';
import { Router, Route, Switch, Redirect } from 'dva/router';
import Products from "./routes/Products/product.js";
import Detail from "./routes/Detail/Detail";
import Addres from "./routes/Addres/Addres";
import MyAddres from "./routes/MyAddres/MyAddres";
import AddAddres from "./routes/MyAddres/addAddres/addAddres.js";
import OderList from './routes/OderList/OderList.js';
import Pay from './routes/Pay/Pay.js';
import defaultAddres from './routes/defaultAddres/defaultAddres.js';
import TheOrderList from './routes/TheOrderList/TheOrderList.js';
import pureRender from './routes/pureRender/index';

function RouterConfig({ history }) {
    return (
        <Router history={history}>
            <Switch>
                <Route path="/" exact render={() => <Redirect to="/Products" />} />
                <Route path="/Products" component={Products} />
                <Route path="/Detail" component={Detail} />
                <Route path="/Addres" component={Addres} />
                <Route path="/MyAddres" component={MyAddres} />
                <Route path="/AddAddres" component={AddAddres} />
                <Route path="/OderList" component={OderList} />
                <Route path="/Pay" component={Pay} />
                <Route path="/defaultAddres" component={defaultAddres} />
                <Route path="/TheOrderList" component={TheOrderList} />
                <Route path="/pureRender" component={pureRender} />
            </Switch>
        </Router>
    );
}

export default RouterConfig;

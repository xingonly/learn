import request from "../../utils/request";

const dataList = (url,options)=>{
  return request(url,options);
}
export {
    dataList,
}

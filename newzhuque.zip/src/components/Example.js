import React ,{Component} from 'react';
import { Link } from "react-router-dom";
import request from "../utils/request"
class Example extends Component{
  componentDidMount(){
    console.log("请求开始")
    request("https://www.baidu.com/",{
      method:"POST",
      headers:{'content-type':'application/json'}
    }).then((data) => {
      console.log("请求接口成功")
      console.log(data)
    })
    console.log("请求结束")
  }
  render(){
    return (
      <div>
        Example
        <Link to={"/products"}>跳转下个页面</Link>
      </div>
    );
  }
  
};


export default Example;

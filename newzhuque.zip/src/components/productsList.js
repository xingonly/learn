import React from 'react';
import PropTypes from "prop-types"
import { Table, Popconfirm, Button } from 'antd';
const ProductsList = ({products,onDelete}) => {
    console.log(products)
  const columns = [{
    title:"Name",
    dataIndex:"name"
  },{
    title:"Actions",
    render:(record)=>{
      return (
        <Popconfirm title="Delete?" onConfirm={() => onDelete(record.key)}>
          <Button>Delete</Button>
        </Popconfirm>
      )
    }
  }]
  return (
    <Table
      dataSource={products}
      columns={columns}

    ></Table>
  );
};
ProductsList.propTypes = {    
  products:PropTypes.array.isRequired,
  onDelete:PropTypes.func.isRequired,
};

export default ProductsList;

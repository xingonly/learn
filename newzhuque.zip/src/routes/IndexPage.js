import React from 'react';
import { connect } from 'dva';
//import styles from './IndexPage.css';
import Example from "../components/Example"
function IndexPage(props) {
  console.log(props)
  return (
    <div>
      <button onClick={()=>{props.dispatch({type:"cont/asd",name:'aaa'})}}>点击</button>
      {props.a.a}
      {
        props.a.b && props.a.b
      }
      <button onClick={() => { props.dispatch({type:'num/add'}) }}>add</button>
      {
        props.num
      }
      <Example/>
    </div>
  );
}

IndexPage.propTypes = {
};
let mapState = (state,own) => {
  return {
    a:state.cont,
    num:state.num
  }
}
export default connect(mapState)(IndexPage);

import React from 'react';
import { connect } from "dva"
import ProductsList from "../components/productsList"
function Products({ dispatch, products }) {
    function handleDelete(key) {
        dispatch({
          type: 'products/delete',
          payload: key,
        });
      }
    return (
        <div>
            <h2>List of Products</h2>
            <ProductsList onDelete={handleDelete} products={products}/>
        </div>
    
  );
}

let mapState = (state,own) => {
    return {
        products:state.products
    }
  }
export default connect(mapState)(Products);

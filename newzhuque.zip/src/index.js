import dva from 'dva';
import './index.css';
import mock from "../mock/res.js"
mock()
// 1. Initialize
const app = dva({
    initialState:{
        products:[
            { name:"dva1",key:1 },
            { name:"dva2",key:2 }
        ]
    }
});

// 2. Plugins
// app.use({});

// 3. Model
//接受发送过来的action
app.model(require('./models/example').default);
app.model(require('./models/add').default);
app.model(require("./models/products").default)

// 4. Router
app.router(require('./router').default);

// 5. Start
app.start('#root');

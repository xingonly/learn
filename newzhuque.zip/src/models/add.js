
export default {

  namespace: 'num',

  state: 1,

  subscriptions: {
    setup({ dispatch, history }) {  // eslint-disable-line
    },
  },

  effects: {
  },

  reducers: {
    add(state, action) {
        switch(action.type){
            case 'num/add':return ++state;
            default : return 1;
        }
    },
  }
};
import axios from "axios"
export default {

  namespace: 'cont',

  state: {a:1},

  subscriptions: {
    setup({ dispatch, history }) {  // eslint-disable-line
    },
  },

  effects: {
    *asd(a, { call, put }) {  // eslint-disable-line
      let res = yield call(axios,{url:"/list",params:{a:a.name}})
      yield put({ type: 'save',data:res.data});
    },
  },

  reducers: {                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                              
    save(state, action) {
      return {...state,b:action.data.name};
    },
  },

};

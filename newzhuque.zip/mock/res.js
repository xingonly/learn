import axios from "axios"
import axiosMock from "axios-mock-adapter"
let mock = new axiosMock(axios)
export default function getList(){
    mock.onGet("/list").reply(200,{
        name:"zhangsan"
    })
}
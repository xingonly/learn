const aside = [
    {
        id:"1",
        title:"推荐专区"
    },{
        id:"2",
        title:"爆品区"
    },{
        id:"3",
        title:"夏季专区"
    },{
        id:"4",
        title:"居家"
    }
]

const content = {
    "1":{
        pic:"img",
        title:"推荐专区分类",
        list:[
            {

            }
        ]
    },
    "2":{
        pic:"img",
        title:"推荐专区分类",
        list:[
            {
                
            }
        ]
    },
    "3":{
        pic:"img",
        title:"推荐专区分类",
        list:[
            {
                
            }
        ]
    },
    "4":{
        pic:"img",
        title:"推荐专区分类",
        list:[
            {
                
            }
        ]
    }
}
export { aside , content }
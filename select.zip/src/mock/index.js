import Mock from "mockjs"
import  { aside as mainClassAside, content as mainClassContent } from "./mainClassAside"
Mock.setup({
    timeout:"400-600"
})
Mock.mock("/mainclass/aside",(req,res)=>{
    return mainClassAside
})
Mock.mock("/mainclass/content",(req,res)=>{
    let id = JSON.parse(req.body).id
    return mainClassContent[id]
})
import React, { Component } from 'react';
import {
  NavLink,
  Route,
  Redirect,
  Switch
} from "react-router-dom"
import "./main.css"
class Main extends Component {
  render() {
    let { childrouter, match } = this.props
    return (
      <div id="App">
        <section id="sect">
          
          <Switch>
            {
              childrouter.map((item, key) => {
                return (
                  <Route key={key} path={match.match.url + item.path} component={item.component}></Route>
                )
              })
            }
            <Redirect from={match.match.url} to={match.match.url + "/home"} />
          </Switch>
        </section>
        <footer id="foot">
          {
            childrouter.map((item, key) => {
              return (
                <div key={key} className="fot" >
                  <NavLink to={match.match.url + item.path} activeClassName="bg"><i className={item.icon}></i>{item.name}</NavLink>
                </div>
              )
            })
          }
        </footer>
      </div>
    );
  }
}

export default Main;

import React, { Component } from 'react';
class Knowledge extends Component {
  render() {
    return (
      <div>
        Knowledge
      </div>
    );
  }
}

export default Knowledge;

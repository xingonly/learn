import React, { Component } from 'react';
import SearchInput from "./ification_pages/searchInput"
import Aside from "./ification_pages/Aside"
import Conent from "./ification_pages/Conent"
import './ification.css'
class Ification extends Component {
  render() {
    return (
      <div className="ifica">
        <div className="ifica_top">
          <SearchInput />
        </div>
        <div className="ifica_section">
          <div className="ifica_aside">
            <Aside/>
          </div>
          <div className="ifica_conent">
            <Conent />
          </div>
        </div>
      </div>
    );
  }
}

export default Ification;

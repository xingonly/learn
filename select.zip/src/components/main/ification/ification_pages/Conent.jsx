import React, { Component } from 'react';
import { withRouter } from "react-router-dom";
import { connect } from "react-redux"
import { getMainClassContent } from "../../../../store/actions"
class Content extends Component {
  constructor(){
    super()
    this.state={
      id:"1"
    }
  }
  render() {
    let { location , content } = this.props;
    return (
      <div>
        
      </div>
    );
  }
  componentDidMount(){
    let { location } = this.props;
    let id = location.search.slice(location.search.indexOf("=")+1)
    id && this.setState({
      id:id
    })
    console.log(id)

    this.props.getContent(id)
    
  }
  componentDidUpdate(){

  
   
  }

}
Content = withRouter(Content)
let mapState = (state)=>{
  return {
    content:state.asideclass.content
  }
}
let mapAction = (dispatch)=>{
  return {
    getContent(id){
      dispatch(getMainClassContent(id));
    }
  }
}
export default connect(mapState,mapAction)(Content);

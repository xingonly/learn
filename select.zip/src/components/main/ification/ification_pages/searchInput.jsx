import React, { Component } from 'react';
class SearchInput extends Component {
  render() {
    return (
      <div>
        <input type="text" placeholder="搜索商品, 共10922款好物"/>
      </div>
    );
  }
}

export default SearchInput;

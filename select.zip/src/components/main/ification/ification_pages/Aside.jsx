import React, { Component } from 'react';
import { connect } from "react-redux"
import { getMainClassAside } from "../../../../store/actions"
import {
  NavLink
} from "react-router-dom"
import { withRouter } from "react-router-dom"
class Aside extends Component {
  render() {
    let { aside , match } = this.props
    return (
      <div>
        <ul>
          {
            aside && aside.map((val, key) => {
              let to = {
                 pathname:match.url,
                 search:`?id=${val.id}`
              }
              return (
                <li key={key}>
                  <NavLink to={ to }>{val.title}</NavLink>
                </li>
              )
            })
          }
        </ul>
      </div>
    );
  }
  //组建加载完成后
  componentDidMount() {
    this.props.initAsideData()
  }
}
Aside = withRouter(Aside)
let mapState = (state) => {
  return {
    aside: state.asideclass.aside
  }
}
let mapDispath = (dispatch) => {
  return {
    initAsideData() {
      dispatch(getMainClassAside);
    }
  }
}
export default connect(mapState, mapDispath)(Aside);

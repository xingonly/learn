import React, { Component } from 'react';
class Me extends Component {
  render() {
    return (
      <div>
        Me
      </div>
    );
  }
}

export default Me;

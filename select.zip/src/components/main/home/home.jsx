import React, { Component } from 'react';
import "./home.css"
class Home extends Component {
  render() {
    return (
      <header id="head">
        <div className="line">
          <h3>网易严选</h3>
          <h4><input type="text"/></h4>
        </div>
        <div className="nav">
          <ul>
            <li><span>推荐</span></li>
            <li><span>推荐</span></li>
            <li><span>推荐</span></li>
            <li><span>推荐</span></li>
            <li><span>推荐</span></li>
            <li><span>推荐</span></li>
            <li><span>推荐</span></li>
            <li><span>推荐</span></li>
            <li><span>推荐</span></li>
          </ul>
        </div>
      </header>
    );
  }
}

export default Home;

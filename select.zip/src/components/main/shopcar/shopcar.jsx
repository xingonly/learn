import React, { Component } from 'react';
class Shopcar extends Component {
  render() {
    return (
      <div>
        Shopcar
      </div>
    );
  }
}

export default Shopcar;

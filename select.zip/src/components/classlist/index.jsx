import React, { Component } from 'react';
class ClassList extends Component {
  render() {
    return (
      <div>
      ClassList
      </div>
    );
  }
}

export default ClassList;

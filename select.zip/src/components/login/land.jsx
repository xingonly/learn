import React, { Component } from 'react';
class App extends Component {
  render() {
    return (
      <div>
        land
      </div>
    );
  }
}

export default App;

import React, { Component } from 'react';
class Search extends Component {
  render() {
    return (
      <div>
        <input type="text"/>
      </div>
    );
  }
}

export default Search;

import React from "react"
import {
    BrowserRouter as Router,
    Route,
    Switch,
    Redirect
} from "react-router-dom"
import { config } from "./config"
export default function RootRouter() {
    return <Router>
        <Switch>
            {
                config.map((item, key) => {
                    return <Route 
                        key={key} 
                        path={item.path} 
                        render={(match)=>{
                            let Trans = item.component
                            return <Trans 
                                match={match} 
                                childrouter={item.children}>
                            </Trans>
                        }}>
                    </Route>
                })
            }
            <Redirect from={"/"} to={"/main"}/>
        </Switch>
    </Router>
}
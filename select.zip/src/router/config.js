import React from "react"
import Loadable from "react-loadable"

export function Loading(){
    return <div>loading...</div>
}

export const config = [
    {
        path:"/land",
        component:Loadable({
            loader:()=>import("../components/login/land"),
            loading:Loading
        })
    },{
        path:"/register",
        component:Loadable({
            loader:()=>import("../components/login/register"),
            loading:Loading
        })
    },{
        path:"/search",
        component:Loadable({
            loader:()=>import("../components/search/index"),
            loading:Loading
        })
    },{
        path:"/details",
        component:Loadable({
            loader:()=>import("../components/details/index"),
            loading:Loading
        })
    },{
        path:"/main",
        component:Loadable({
            loader:()=>import("../components/main/index"),
            loading:Loading
        }),
        children:[
            {
                icon:"icon iconfont icon-shouye",
                name:"首页",
                path:"/home",
                component:Loadable({
                    loader:()=>import("../components/main/home/home"),
                    loading:Loading
                })
            },{
                icon:"icon iconfont icon-faxiandingdan",
                name:"识物",
                path:"/knowledge",
                component:Loadable({
                    loader:()=>import("../components/main/knowledge/knowledge"),
                    loading:Loading
                })
            },{
                icon:"icon iconfont icon-fenlei",
                name:"分类",
                path:"/ification",
                component:Loadable({
                    loader:()=>import("../components/main/ification/ification"),
                    loading:Loading
                })
            },{
                icon:"icon iconfont icon-gouwuche",
                name:"购物车",
                path:"/shopcar",
                component:Loadable({
                    loader:()=>import("../components/main/shopcar/shopcar"),
                    loading:Loading
                })
            },{
                icon:"icon iconfont icon-wode",
                name:"个人",
                path:"/me",
                component:Loadable({
                    loader:()=>import("../components/main/me/me"),
                    loading:Loading
                })
            }
        ]
    },{
        path:"/classlist",
        component:Loadable({
            loader:()=>import("../components/classlist/index"),
            loading:Loading
        })
    }
    
]
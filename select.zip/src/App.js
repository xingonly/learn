import React, { Component } from 'react';
import './App.css';
import RootRouter from "./router/index"
import store from "./store/index"
import {Provider} from "react-redux"
class App extends Component {
  render() {
    return (
      <Provider store={store}>
        <RootRouter/>
      </Provider>
    );
  }
}

export default App;

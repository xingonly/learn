import {MAINCLASS_INIT_ASIDE,MAINCLASS_INIT_CONTENT} from "../actions/index"
let MainClass = {
    [MAINCLASS_INIT_ASIDE](state,action){
        state.aside=action.aside
    },
    [MAINCLASS_INIT_CONTENT](state,action){
        state.content=action.content
    }
}
let mainclass = (state={},action)=>{
    MainClass[action.type] && MainClass[action.type](state,action)
    return {...state}
}
export default mainclass

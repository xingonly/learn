import { combineReducers } from "redux"
import asideclass from "./asideclass"
let reducer = combineReducers({
    asideclass
})
export default reducer
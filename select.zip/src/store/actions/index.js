import axios from "axios"

export const MAINCLASS_INIT_ASIDE = "MAINCLASS_INIT_ASIDE"
//真dispatch
export const getMainClassAside = (dispatch)=>{
    axios.get("/mainclass/aside").then((res)=>{
        let aside = res.data
        dispatch({type:MAINCLASS_INIT_ASIDE,aside})
    })
}

export const MAINCLASS_INIT_CONTENT = " MAINCLASS_INIT_CONTENT"
export const getMainClassContent = (id) => {
    return (dispatch)=>{
        axios.get("/mainclass/content",{
            data:{
                id:id
            }
        }).then((res)=>{
            let content = res.data
            dispatch({type:MAINCLASS_INIT_CONTENT,content})
        }) 
    }
}
 
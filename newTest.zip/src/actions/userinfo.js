import * as actionTypes from '../constants/redux'
import resource from '../util/resource'

export function update(data) {
    return {
        type: actionTypes.USERINFO_UPDATE,
        data
    }
}

export const changeId = (data) => {
    return {
        type: actionTypes.ID,
        data: data
    }
}

export const users = () => (dispatch, getState) => {
    dispatch({
        type: actionTypes.USERINFO_UPDATE,
        data: {
            name: 'czl'
        }
    })
}
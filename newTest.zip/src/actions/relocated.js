import * as actionTypes from '../constants/redux'

const actions = {
    changeParams: function (data) {
        return {
            type: actionTypes.Params_CHANGE,
            payload: data
        }
    },
    changeStep: function (data) {
        return {
            type: actionTypes.CHANGE_STEP,
            payload: data
        }
    }
}

export default actions;
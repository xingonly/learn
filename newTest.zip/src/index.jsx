import React from 'react'
import { render } from 'react-dom'
import { Provider } from 'react-redux'
import configureStore from './store/configureStore'
import DevTools from './store/DevTools'

import './static/scss/app.scss'
// import 'react-datetime/css/react-datetime.css'

import './util/requestNextAnimationFrame'

// 创建 Redux 的 store 对象
const store = configureStore()

import routes from './routes'

render(
    <Provider store={store}>
        <div>
            {routes()}
            <DevTools />
        </div>
    </Provider>,
    document.getElementById('root')
)




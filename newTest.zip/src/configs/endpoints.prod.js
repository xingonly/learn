// const PROTOCOL = 'http://';
//本地调试走webpack代理或是nginx代理

//版本发布
const http = '';

const httpWork = 'https://42.123.99.87:11500';

const serverUser = '/xixiu-user';

const serverServer = '/xixiu-server';

const workServer = '/xixiu-work';

const apiRoutesUser = {
  login: '/security/tokenAuthen',
  logout: '/security/clear'
  // 暂时没有图片验证码
  // imgcode: '/security/imgcode'
};

const apiRoutesDataAnalysis = {
    getPoorPeopleStatus: '/dataStatistics/getPoorPeopleStatus',
    getStatisticsData2: '/dataStatistics/getStatisticsData2',
    // 获取贫困和非贫困村数--通过参数区分
    getIsPoorCounty: '/regions/countByIspoor'
};

const apiRoutersWork = {
    // 获取签到镇数据
    getRegionSignTown: '/signInLog/countTownSign',
    // 获取签到村数据
    getRegionSign: '/signInLog/countRegionSign',
    // 分页查询签到日志
    getSignLog: '/signInLog/getSignInLogByPage',
    // 获取签到日期-YYYY-MM-DD
    getSignDate: '/signInLog/getSignInDate',
    // 获取日期签到记录详情
    getSignInDetail: '/signInLog/getSignInDetail'
};

const pUser = Object.keys(apiRoutesUser).reduce((whole, key) => ({
    ...whole,
    [key]: `${http}${serverUser}${apiRoutesUser[key]}`,
}), {});

const dataAnalysis = Object.keys(apiRoutesDataAnalysis).reduce((whole, key) => ({
    ...whole,
    [key]: `${http}${serverServer}${apiRoutesDataAnalysis[key]}`,
}), {});

const workApi = Object.keys(apiRoutersWork).reduce((whole, key) => ({
    ...whole,
    [key]: `${httpWork}${workServer}${apiRoutersWork[key]}`,
}), {});

export { pUser, dataAnalysis, workApi } ;

import React from 'react'
import createHistory from 'history/createHashHistory'
import {Route, HashRouter as Router, Redirect, Switch} from 'react-router-dom'
import App from '../containers/App'
import Login from '../containers/Login'
import Main from '../containers/Main'

let history = createHistory()

const routes = () => (
    <Router history={history}>
        <div>
            <Route exact path="/" render={() => (
                <Redirect to="/login"/>
            )}/>
            {/* 登录 */}
            <Route path='/login' component={Login}/>
            <Route path='/main' component={(props) => (
                <App {...props}>
                 <Main/>
                </App>
            )}/>
        </div>
    </Router>
);

export default routes

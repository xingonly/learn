import React,{Component} from 'react';
import style from './index.scss';

export default class MySelect extends Component {
    constructor(props) {
        super(props);
        this.state = {
            display: false,
            afterIcon: false,
        }
    }
    titleClick = () => {
        if(this.state.display === false) {
            this.setState({
                display: true,
                afterIcon: true
            })
        }else {
            this.setState({
                display: false,
                afterIcon: false
            })
        }
    };
    blur = () => {
        this.setState({
            display: false,
            afterIcon: false
        })
    };
    render() {
        return (
            <div className={`${style['my-select']} ${this.state.afterIcon ? style['bottom-after'] : style['top-after']}`}
                 onClick={this.titleClick}
                 onBlur={this.blur}
                 tabIndex="1"
                 style={{width: `${this.props.width}${this.props.measure}`}}
            >
                <span className="text-overflow"
                      title={this.props.value}
                      style={{width: `${this.props.width*.7}${this.props.measure}`}}
                >
                    {
                        this.props.value
                    }
                </span>
                <div className={style['select-content']} style={this.state.display ? {display: 'block', width: `${this.props.width}${this.props.measure}`} : {display: 'none', width: `${this.props.width}${this.props.measure}`}}>
                    <ul>
                        {
                            this.props.options.map((obj, index) => (
                                <li className="text-overflow"
                                    onClick={this.props.handleClick.bind(this, obj,this.props.name)}
                                    key={index}
                                    title={obj.label}
                                    style={{width: `${this.props.width*.8}${this.props.measure}`}}
                                >{obj.label}</li>
                            ))
                        }

                    </ul>
                </div>
            </div>
        )
    }

}

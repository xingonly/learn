// 上帝保佑,永无bug

import React, {Component} from "react";
import style from './Modal.scss';

export default class Modal extends Component {

    constructor (props) {
      super(props);
    }

    componentDidMount () {
      this.loadDataToForm(this.props.data);
    }

    loadDataToForm = (data) => {
      var obj = {};
      if(this.props.type === 'hbase')
      {
          obj = data.data;
      }else{
          obj = data;
      }
      for(let key in obj)
      {
        if(!document.querySelector("*[data-key=" + key + "]"))
        {
          continue;
        }
        document.querySelector('*[data-key=' + key + ']').value = obj[key];
      }
    }

    handleOk = (e) => {
      var doms = document.querySelectorAll('*[data-key]');
      var result = {};
      if(!doms)
      {
        return;
      }
      for(let i = 0;i < doms.length;i++)
      {
          try {
              var obj = JSON.parse(doms[i].getAttribute('data-key'));
              if(!result[obj.belongTo])
              {
                  result[obj.belongTo] = {};
                  if(obj.type)
                  {
                      switch(obj.type)
                      {
                          case '浮点型':
                              result[obj.belongTo][obj.key] = parseFloat(doms[i].value);
                              break;
                          case '整型':
                              result[obj.belongTo][obj.key] = parseInt(doms[i].value);
                              break;
                          case '字符串':
                              result[obj.belongTo][obj.key] = doms[i].value + '';
                              break;
                          case '数组':
                              let list = (doms[i].value + '').split(',');
                              for(let j = 0;j < list.length;j++)
                              {
                                  list[j] = parseFloat(list[j]);
                              }
                              result[obj.belongTo][obj.key] = list;
                              break;
                      }
                  }else{
                      if(!obj.key)
                      {
                          continue;
                      }
                      if(obj.value)
                      {
                          result[obj.belongTo][obj.key] = obj.value;
                      }else{
                          result[obj.belongTo][obj.key] = doms[i].value;
                      }
                  }

              }else{
                  if(obj.type)
                  {
                      switch(obj.type)
                      {
                          case '浮点型':
                              result[obj.belongTo][obj.key] = parseFloat(doms[i].value);
                              break;
                          case '整型':
                              result[obj.belongTo][obj.key] = parseInt(doms[i].value);
                              break;
                          case '字符串':
                              result[obj.belongTo][obj.key] = doms[i].value + '';
                              break;
                          case '数组':
                              let list = (doms[i].value + '').split(',');
                              for(let j = 0;j < list.length;j++)
                              {
                                  list[j] = parseFloat(list[j]);
                              }
                              result[obj.belongTo][obj.key] = list;
                              break;
                      }
                  }else{
                      if(obj.value)
                      {
                          result[obj.belongTo][obj.key] = obj.value;
                      }else{
                          result[obj.belongTo][obj.key] = doms[i].value;
                      }
                  }
              }
          }catch(e){
              result[doms[i].getAttribute('data-key')] = doms[i].value || doms[i].getAttribute('value');
          }
      }
      if(this.props.handleOk)
      {
        this.props.handleOk(result);
      }
    }

    handleCancel = (e) => {
      if(this.props.handleCancel)
      {
        this.props.handleCancel();
      }
    }

    render() {
        return (
            <div className={style.container}>
              <div className={style.content} style={this.props.width ? {width: this.props.width} : {}}>
                <div className={style.title}>
                  <span>
                    {this.props.title}
                  </span>
                  <img src={require('./images/cancel.png')} onClick={this.handleCancel}/>
                </div>
                <div className={style.form}>{this.props.content}</div>
                <div className={style.bottom}>
                  <button className={style.ok} onClick={this.handleOk}>确定</button>
                  <button className={style.cancel} onClick={this.handleCancel}>取消</button>
                </div>
              </div>
            </div>
        )
    }
}

// 上帝保佑,永无bug
import React, {Component} from "react";
import style from './InfoTips.scss';

export default class InfoTips extends Component {

    constructor (props) {
        super(props);
    }

    componentDidMount (){
        // let img = this.refs.img;
        // img.src = require('./images/loading.gif');
    }

    handleOk = () => {
        if(this.props.handleOk)
        {
            this.props.handleOk();
        }
    }


    handleCancel = (e) => {
        if(this.props.handleCancel)
        {
            this.props.handleCancel();
        }
    }

    render() {
        return (
            <div className={style.container}>
                <div className={style.content} style={this.props.width ? {width: this.props.width} : {}}>
                    <div className={style.title}>
                      <span>
                        信息提示
                      </span>
                      <img src={require('./images/cancel.png')} onClick={this.handleCancel}/>
                    </div>
                    <div className={style.form}>
                        <img ref='img' src={this.props.test ? require('./images/loading.gif') : (this.props.fail ? require('./images/fail.png') : require('./images/success.png'))} />
                            <div>{this.props.content}</div>
                    </div>
                    <div className={style.bottom}>
                        <button className={style.ok} onClick={this.handleOk}>确定</button>
                    </div>
                </div>
            </div>
        )
    }
}

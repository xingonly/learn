import React, {Component} from 'react'
import style from './style.scss'
import Title from '../../components/Title'

export default class Card extends Component {

    constructor () {
        super();
    }

    open = (e) => {
        if(this.props.handleOpen)
        {
            this.props.handleOpen(this.props);
        }
    }

    close = (e) => {
        if(this.props.handleClose)
        {
            this.props.handleClose(this.props);
        }
    }

    render() {

        return (
            <div className={style.container + ' ' + (this.props.className || '')} style={this.props.margin ? {padding: 0} : {}}>
                <div className={style.head} style={this.props.margin ? {marginTop: '0.6rem'} : {}}>
                    {/*<h3 className={style.title}>*/}
                        {/*<span>{this.props.title}</span>*/}
                        {/*<img className={style.border_left} src={require('./images/title_border_left.png')}/>*/}
                        {/*<img className={style.border_right} src={require('./images/title_border_right.png')}/>*/}
                    {/*</h3>*/}
                    <div style={{width: '100%'}}>
                        <Title name={this.props.title} />
                    </div>

                    {/*<div className={style.subTitle}>*/}
                        {/*{this.props.subTitle}*/}
                    {/*</div>*/}
                    {
                        this.props.tool ? (this.props.open ? (
                            <div className={style.tool}>
                                <img src={require('./images/close.png')} onClick={this.close}/>
                            </div>
                        ) : (
                            <div className={style.tool}>
                                <img src={require('./images/open.png')} onClick={this.open}/>
                            </div>
                        )) : ''
                    }
                </div>
                <div className={'card_content ' + style.content} style={this.props.margin ? {marginBottom: '0.6rem',paddingBottom: '0'} : {}}>
                    {this.props.children}
                </div>
                <div className={style.footer}>
                    {this.props.footer}
                </div>
            </div>
        )
    }
}

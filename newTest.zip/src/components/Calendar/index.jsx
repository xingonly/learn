import React, {Component} from 'react';
import style from './style.scss';

class Calendar extends Component {

	render() {
		return (
			<div className={style.container}>
        <div className={style.s}></div>
        <table>

        </table>
			</div>
		)
	}
}

export default Calendar;

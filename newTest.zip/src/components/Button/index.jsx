// 上帝保佑,永无bug

import React, {Component} from "react"
import PureRenderMixin from 'react-addons-pure-render-mixin'
import './style.css'

export default class Button extends Component {

    constructor(props) {
        super(props)
        this.shouldComponentUpdate = PureRenderMixin.shouldComponentUpdate.bind(this)
    }

    componentDidMount() {
        let buttons = document.querySelectorAll('.my-button')
        for(let i = buttons.length - 1; i >= 0; i-- ) {
            buttons[i].onclick = function (e) {
                let rect = buttons[i].getBoundingClientRect()

                let span = buttons[i].querySelector('.my-button-ink'),
                    // 页面点击左边 - 父级位置 - 自身高度/宽度的一半，以使其从中心可控;
                    x = e.pageX - rect.left - span.clientWidth / 2,
                    y = e.pageY - rect.top - span.clientHeight / 2

                // 快速双击停止上一个动画
                span.classList.remove('animate')
                span.style.left = x + 'px'
                span.style.top = y + 'px'
                setTimeout(function () {
                    span.classList.add('animate')
                }, 0);
            }
        }
    }

    render() {
        return (
            <button className={this.props.className ? this.props.className + ' my-button' : 'my-button'} ref="button" onClick={this.props.onClick}>
                <span>{this.props.value}</span>
                <span className='my-button-ink' style={{backgroundColor: this.props.color || null }}></span>
            </button>
        )
    }
}

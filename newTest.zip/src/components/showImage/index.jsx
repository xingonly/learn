import React, { Component } from 'react'
import style from './style.scss'
import draggable from './drag'
import { Message } from 'antd'

export default class ShowImg extends Component{
  constructor(props){
    super(props);
    let  winHeight = document.documentElement.clientHeight;
    let  winWidth = document.documentElement.clientWidth;
    this.state = {
      height:winHeight,
      width:winWidth,
      imgHeight:'',
      imgWidth:'',
      left:0,
    };
  }
  handleImg = () => {
    let image = new Image();
    image.src = this.props.url;
    image.onload = () => {
      let state = { ...this.state };
      state.imgHeight = parseInt(image.height / 2);
      state.imgWidth = parseInt(image.width / 2);
      this.setState(state);
    }
  }
  componentDidMount(){
    this.handleImg();
    draggable(this.refs.img, this.refs.img);
  }
  handleWheel =  (event) =>  {
    //判断鼠标滚轮的上下滑动
    let deta = event.deltaY;
    if(deta > 0){
      this.handleEnlarge('small');
    }
    if(deta < 0){
      this.handleEnlarge('large');
    }

  }
  handleClose = () => {
    if(this.props.handleClose){
      this.props.handleClose();
    }
  }
  handleEnlarge = (type) => {
    let state = { ...this.state };
    if(type === 'large'&& state.imgHeight <= 1000 ){
      state.imgHeight = state.imgHeight + 50;
      state.imgWidth = state.imgWidth + 50;
    }else if(type === 'small'&& state.imgHeight >= 100 ){
      state.imgHeight = state.imgHeight - 50;
      state.imgWidth = state.imgWidth - 50;
    }
    this.setState(state);
  }
  handleRotate = (type) => {
    let state = { ...this.state };
    if(type === 'left'){
      state.left = state.left + 90;
    }else{
      state.left = state.left - 90;
    }
    this.setState(state);
  }
  handleDelete = () => {
    console.log('guigui')
    if(this.props.handleClose){
      this.props.handleClose()
    }
  }
  handleImgStop =(e) => {
    e.stopPropagation();;
  }
  render(){
    return(
      <div id={style.Box}
           style = {{
             //height:this.state.height+'px',
            // width : this.state.width +'px'
           }}
           onWheel={this.handleWheel}
           onClick={this.handleDelete}
      >
        <div
          className={style.content}
          style = {{
        }}
        >
          <div className={style.content}>
            <img src={this.props.url} alt="" ref='img'
                 draggable={true}
                 onClick={(e) => this.handleImgStop(e)}
                 style = {{
                   transform:`rotate(${this.state.left}deg)`,
                   height: this.state.imgHeight * 2 + 'px',
                   width: this.state.imgWidth * 2 + 'px',
                   marginTop: -this.state.imgHeight + 'px',
                   marginLeft: -this.state.imgWidth + 'px'
                 }}
            />
          </div>
          <div className={style.buttons} onClick={(e) => {e.stopPropagation();}}>
            <div onClick={() =>this.handleEnlarge('large')}>
              <i className='iconfont icon-fangda'></i>
              <span>放大</span>
            </div>
            <div onClick={()=>this.handleEnlarge('small')}>
              <i className='iconfont icon-iconset0159'></i>
              <span>缩小</span>
            </div>
            <div onClick={this.handleRotate}>
              <i className='iconfont icon-llfilterrotate'></i>
              <span >旋转90度</span>
            </div>
          </div>
        </div>
      </div>
    )
  }
}

import React, {Component} from 'react';
import style from './style.scss';

class Tabs extends Component {

  state = {
    active: this.props.list && this.props.list[0] || {},
    current: 1,
    pages: 1,
    width: 0,
    distance: 0
  }

  componentWillReceiveProps(nextProps) {
    if(JSON.stringify(this.props.list) !== JSON.stringify(nextProps.list) && nextProps.list && nextProps.list.length)
    {
      this.setState({
        active: nextProps.list && nextProps.list[0] || {}
      });
    }
  }

  componentDidUpdate(prevProps, prevState) {
    if(JSON.stringify(this.state.active) !== JSON.stringify(prevState.active) && this.state.active)
    {
      if(this.props.onChange)
      {
        this.props.onChange(this.state.active);
      }
    }

    if(JSON.stringify(this.props.list) !== JSON.stringify(prevProps.list))
    {
      this.getPages();
    }
  }

  componentDidMount() {
    if(this.props.list && this.props.list[0])
    {
      if(this.props.onChange)
      {
        this.props.onChange(this.props.list[0]);
      }
    }
    this.getPages();
  }

  getPages = () => {
    const container = this.refs.container;
    const tabs = this.refs.tabs;
    let width = 0;
    for(let i = 0;i < tabs.children.length;i++)
    {
      width = width + tabs.children[i].clientWidth;
    }
    this.setState({
      width: container.clientWidth,
      pages: Math.ceil(width / container.clientWidth)
    });
  }

  onClick = (active, index) => {
    const { current } = this.state;
    const tabs = this.refs.tabs;
    let width = 0;
    let currentWidth = 0;
    for(let i = 0;i <= index;i++)
    {
      currentWidth = tabs.children[i].clientWidth;
      width = width + currentWidth;
    }
    if(width > (current - 1) * tabs.clientWidth && width - currentWidth < (current - 1) * tabs.clientWidth)
    {
      this.setState({
        distance: (width - currentWidth) - (current - 1) * tabs.clientWidth
      });
    }else if(width > current * tabs.clientWidth)
    {
      this.setState({
        distance: width - current * tabs.clientWidth
      });
    }else{
      this.setState({
        distance: 0
      });
    }
    this.setState({ active }, () => {
      if(this.props.onChange)
      {
        this.props.onChange(active);
      }
    });
  }

  checkActive = (item) => {
    const { active } = this.state;
    if(JSON.stringify(item) === JSON.stringify(active))
    {
      return {
        className: style.active
      }
    }

    return {};
  }

  checkDisabled = (type) => {
    const { current, pages } = this.state;
    if(type === 0)
    {
      if(current <= 1)
      {
        return {disabled: true}
      }
    }else{
      if(current >= pages)
      {
        return {disabled: true}
      }
    }
    return {};
  }

  getDistance = () => {
    this.setState({
      distance: 0
    });
    // const { current } = this.state;
    // const tabs = this.refs.tabs;
    // const containerWidth = tabs.clientWidth;
    // let width = 0;
    // let currentWidth = 0;
    // for(let i = 0;i < tabs.children.length;i++)
    // {
    //   currentWidth = tabs.children[i].clientWidth;
    //   width = width + currentWidth;
    //   if(width > (current - 1) * containerWidth)
    //   {
    //     break;
    //   }
    // }
    // if(width - (current - 1) * containerWidth > 0)
    // {
    //   this.setState({
    //     distance: (current - 1) * containerWidth - (width - currentWidth)
    //   })
    // }
  }

  scrollAction = (e, index) => {
    const { current, pages } = this.state;
    const disabled = e.target.getAttribute('disabled');
    if(disabled === '')
    {
      return;
    }
    this.setState({
      current: current + index
    }, () => {
      this.getDistance();
    });
  }

	render() {
    const { className, list } = this.props;
    const { current, pages, width, distance } = this.state;
		return (
      <div className={style.container + (className ? (' ' + className) : '')}>
        <span {...this.checkDisabled(0)} className="iconfont" onClick={e => {
            this.scrollAction(e, -1);
          }}>&#xe601;</span>
        <div ref='container'>
          <ul ref='tabs' style={{
              transform: `translateX(-${(current - 1) * width + distance}px)`
            }}>
            {
              list && list.length ? (
                list.map((item, index) => (
                  <li {...this.checkActive(item)} key={index} onClick={() => {
                      this.onClick(item, index)
                    }}>{item.text}</li>
                ))
              ) : ''
            }
          </ul>
        </div>
        <span {...this.checkDisabled(1)} className="iconfont" onClick={e => {
              this.scrollAction(e, 1);
            }}>&#xe600;</span>
      </div>
		)
	}
}

export default Tabs;

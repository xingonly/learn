import React, {Component} from "react";
import style from './style.scss';

export default class App extends Component {

    render() {
      const { className } = this.props;
        return (
            <div className={style.title + (className ? (' ' + className) : '')}>
                <div>{this.props.name}</div>
                <div className={style.img}><img src={require('./img/rect.png')} /></div>
            </div>
        )
    }
}

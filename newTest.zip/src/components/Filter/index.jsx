import React,{ Component } from 'react'
import { withRouter } from 'react-router-dom'
import { Tooltip, Select, Input, DatePicker } from 'antd'
import moment from 'moment'
import resource from 'resource'
import styles from './styles.scss'
const Option = Select.Option
const SearchItem = Input.Search
//西秀区
const XXID = '520402000000'

class Filter extends Component {
  constructor(props) {
    super(props)
    this.state = {
      startTime: null,
      endTime: null,
      defaultTown: '乡/镇',
      defaultVillage: '村/社区',
      townID: '',
      villageID: '',
      town: '',
      village: '',
      townOption: [{value: '',label: '乡/镇'}],
      villageOption: [{ value: '', label: '村/社区' }],
      inputV: ''
    }
  }

  componentDidMount() {
    this.getTown()
  }

  // 父组件需要清Filter时用,父组件reset=true 回调reset=false
  componentWillReceiveProps(nextProps) {
    if (nextProps.reset) {
      this.reset()
    }
  }

  reset = () => {
    this.setState({
      startTime: null,
      endTime: null,
      defaultTown: '乡/镇',
      defaultVillage: '村/社区',
      townID: '',
      villageID: '',
      town: '',
      village: '',
      townOption: [{value: '',label: '乡/镇'}],
      villageOption: [{ value: '', label: '村/社区' }],
      inputV: ''
    })
  }

  // 获取镇AJAX
  getTown = () => {
    resource.get(`/xixiu-server/region/getRegionByParentid/${XXID}`).then(res => {
      if (res.status == 200) {
        let arr = []
        for (let ite of res.data)
        {
          let data = {
            value: ite.id,
            label: ite.name
          }
          arr.push(data)
        }
        arr.unshift({ value: '', label: '乡/镇' })
        this.setState({
          townOption: arr
        })
      } else {
        console.log(res.message)
      }
    })
  }

  // 获取村AJAX
  getVillage = id => {
    if(!id) return
    resource.get(`/xixiu-server/region/getRegionByParentid/${id}`).then(res => {
      if (res.status == 200) {
        let arr = []
        for (let ite of res.data)
        {
          let data = {
            value: ite.id,
            label: ite.name
          }
          arr.push(data)
        }
        arr.unshift({ value: '', label: '村/社区' })
        this.setState({
          villageOption: arr
        })
      } else {
        console.log(res.message)
      }
    })
  }

  // 时间选择器相关
  onTimeChange = (field, value) => {
    this.setState({
      [field]: value,
    },() => {
      console.log(this.state);
    });
  }

  onStartChange = (value) => {
    this.onTimeChange('startTime', value);
  }

  onEndChange = (value) => {
    this.onTimeChange('endTime', value);
  }

  // 不允许选的起始时间
  disabledStartDate = (startTime) => {
    const endTime = this.state.endTime;
    if (!startTime || !endTime) {
      return false;
    }
    return startTime.valueOf() > endTime.valueOf();
  }

  // 不允许选的结束时间
  disabledEndDate = (endTime) => {
    const startTime = this.state.startTime;
    if (!endTime || !startTime) {
      return false;
    }
    return endTime.valueOf() <= startTime.valueOf();
  }


  //  select相关
  initCode = () => {
    this.setState({
      townID: '',
      town: '乡/镇',
      villageID: '',
      village: '村/社区',
      villageOption: [{value: '',label: '村/社区'}]
    })
  }
  townChange = (v, ite) => {
    this.setState({
      townID: v,
      town: ite.props.children,
      villageID: '',
      village: '村/社区',
      villageOption: [{value: '',label: '村/社区'}]
    }, () => {
      this.getVillage(v)
    })
  }
  villageChange = (v, ite) => {
    this.setState({
      villageID: v,
      village: ite.props.children
    });
  }

  //input 相关
  inputChange = e => {
      this.setState({
          inputV: e.target.value
      })
  }

  handleSearch = (allowDate, allowSelect) => {
    const date = {
      startTime: this.state.startTime && moment(this.state.startTime).format('X'),
      endTime: this.state.endTime && moment(this.state.endTime).format('X')
    }
    const code = { code: this.state.villageID ? this.state.villageID : this.state.townID }
    const value = { value: this.state.inputV }
    let data = {}
    Object.assign(data, (allowDate && date), (allowSelect && code), value)
    // console.log(data)
    this.props.onSubmit(data)
  }

  render() {
    const { title, placeholder, allowDate, allowSelect } = this.props
    const townOptions = this.state.townOption.map(ite =>
      <Option
        key={ite.value}
        value={ite.value}
        title={ite.label}
      >
        {ite.label}
      </Option>)
    const villageOptions = this.state.villageOption.map(ite =>
      <Option
        key={ite.value}
        value={ite.value}
        title={ite.label}
      >
        {ite.label}
      </Option>)
    return (
      <div className={styles.searchItem}>
        <span className={styles.title}>{title}</span>
        <div className={styles.searchBox}>
          {
            allowDate && <div className={styles.dateBox}>
            <span className={styles.dateLabel}>{this.props.operateName || '操作时间：'}</span>
            <DatePicker
              allowClear
              locale="zh_CN"
              placeholder="起始时间"
              value={this.state.startTime}
              onChange={this.onStartChange}
              disabledDate={this.disabledStartDate}
              style={{ width: '6rem' }}
              className={styles.startDate}
            />
            <span className={styles.mid} />
            <DatePicker
              allowClear
              locale="zh_CN"
              placeholder="结束时间"
              value={this.state.endTime}
              onChange={this.onEndChange}
              disabledDate={this.disabledEndDate}
              style={{width: '6rem'}}
              className={styles.endDate}
            />
          </div>
          }
          {
            allowSelect && <div className={styles.selectBox}>
              <span
                className={styles.xixiuTitle}
                onClick={this.initCode}
              >
                西秀区
              </span>
            <Select
              defaultValue={this.state.defaultTown}
              value={this.state.town}
              style={{ width: '6rem', marginLeft: 7, marginRight: 9 }}
              onChange={this.townChange}
            >
              {townOptions}
            </Select>
            <Select
              defaultValue={this.state.defaultVillage}
              value={this.state.village}
              style={{ width: '6rem' }}
              onChange={this.villageChange}
            >
              {villageOptions}
            </Select>
          </div>
          }
          <div className={styles.inputBox}>
            <SearchItem
              placeholder={placeholder || '请输入姓名或证件号'}
              value={this.state.inputV}
              onChange={this.inputChange}
              style={{width: '9rem'}}
              onSearch={() => {this.handleSearch(allowDate, allowSelect)}}
              enterButton
            />
          </div>
        </div>
      </div>
    )
  }
}

export default withRouter(Filter)

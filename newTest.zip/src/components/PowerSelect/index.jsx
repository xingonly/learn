// 上帝保佑,永无bug

import React, {Component} from "react"
import style from './style.scss'

export default class Select extends Component {

    state = {
        selecting: false,
        item: '',
        value: ''
    }

    topEvent = () => {
        var state = {...this.state};
        state.selecting = false;
        this.setState(state);
        document.removeEventListener('click',this.topEvent);
    }

    select = () => {
      if(this.props.disabled)
      {
        return;
      }
        var state = {...this.state};
        state.selecting = !state.selecting;
        if(state.selecting)
        {
            document.addEventListener('click',this.topEvent);
        }
        this.setState(state);
    }

    chose = (item) => {
        var state = {...this.state};
        state.item = item;
        this.setState(state);
    }

    getItem = () => {
        return this.state.item;
    }

    setItem = (item) => {
        this.setState({
            item: item
        });
    }

    valid = (item) => {
        if(typeof item === 'object')
        {
            var flag = false;
            for(let key in this.state.item)
            {
                if(this.state.item[key] !== item[key])
                {
                    flag = true;
                    break;
                }
            }

            for(let key in item)
            {
                if(this.state.item[key] !== item[key])
                {
                    flag = true;
                    break;
                }
            }

            return flag;
        }else{
            if(this.state.item === item)
            {
                return false;
            }else{
                return true;
            }
        }
    }

    getDefaultObj = () => {
        var obj = {};
        obj[this.props.map.value] = '';
        obj[this.props.map.text] = '全部';
        return obj;
    }

    getDefaultItem = () => {
        if(this.props.list && this.props.list.length)
        {
            if(this.props.default)
            {
                var obj = {};
                obj[this.props.map.value] = '';
                obj[this.props.map.text] = '全部';
                return obj;
            }else{
                return this.props.list[0];
            }
        }else{
            return '';
        }
    }

    compare = (v1,v2) => {
        if(typeof v1 != typeof v2)
        {
            return false;
        }else{
            if(v1 === null && v2 === null)
            {
                return true;
            }else if(v1 === null || v2 === null)
            {
                return false;
            }else if(typeof v1 === 'object')
            {
                let flag = true;
                for(let key in v1)
                {
                    flag = this.compare(v1[key],v2[key]);
                    if(!flag)
                    {
                        return flag;
                    }
                }

                for(let key in v2)
                {
                    flag = this.compare(v1[key],v2[key]);
                    if(!flag)
                    {
                        return flag;
                    }
                }

                return flag;
            }else if(typeof v1 === 'undefined')
            {
                return true;
            }else{
                if(v1 === v2)
                {
                    return true;
                }else{
                    return false;
                }
            }

        }

    }

    getWidth = (padding) => {
      var count = 0;
      for(let i = 0;i < this.props.list.length;i++)
      {
        let word = this.props.list[i][this.props.map.text] + '' || this.props.list[i][this.props.map.value] + '' || this.props.list[i] + '';
        if(word.length > count)
        {
          count = word.length;
        }
      }
      return (count * 16 + 16 + padding + 10) / 20 + 'rem';
    }

    getItemByValue = () => {
        for(let i = 0;i < this.props.list;i++)
        {
            if(this.props.list[i][this.props.map.value] === this.props.value)
            {
                return this.props.list[i];
            }
        }
    }

    componentDidMount () {
        var state = {...this.state};
        state.item = this.getDefaultItem();
        this.setState(state);
    }

    componentDidUpdate (prevProps,prevState) {
        if(!this.compare(prevProps.list,this.props.list) && this.props.value === undefined)
        {
            var state = {...this.state};
            state.item = this.getDefaultItem();
            this.setState(state);
        }
        if(this.props.value !== undefined && prevProps.value != this.props.value)
        {
            var state = {...this.state};
            state.item = this.getItemByValue();
            this.setState(state);
        }
        if(this.props.onChange && this.valid(prevState.item))
        {
            this.props.onChange(this.state.item);
        }
    }

    componentWillUnmount () {
        document.removeEventListener('click',this.topEvent);
    }

    render() {

        return (
            <div className={style.container} style={this.props.compact ? {padding: '0 0.2rem'} : {}}>
                <div className={style.show} style={this.props.autoWidth ? {width: this.getWidth(0), minWidth: this.props.minWidth ? this.props.minWidth : '0px'} : {}} onClick={this.select}>
                    <span title={this.state.item ? (this.state.item[this.props.map.text] ? this.state.item[this.props.map.text] : (this.state.item[this.props.map.value] ? this.state.item[this.props.map.value] : '')) : ''} style={
                        this.props.disabled ? {
                          color: 'gray',
                          whiteSpace: 'nowrap'
                        } : {
                            whiteSpace: 'nowrap'
                        }
                      }>
                        {
                            this.state.item ? (this.state.item[this.props.map.text] ? this.state.item[this.props.map.text] : (this.state.item[this.props.map.value] ? this.state.item[this.props.map.value] : '')) : ''
                        }
                    </span>
                    <img src={require('./images/select_arrow.png')}/>
                </div>
                {
                    this.state.selecting ? (
                        <ul className={style.selecting}>
                            {
                                this.props.default ? (
                                    <li onClick={this.chose.bind(this,this.getDefaultObj())}>
                                        <div>
                                            全部
                                        </div>
                                    </li>
                                ) : ''
                            }
                            {
                                this.props.list.map((item,index) => {
                                    var className = '';
                                    if(this.state.item)
                                    {
                                        if(this.state.item[this.props.map.value] && this.state.item[this.props.map.value] === item[this.props.map.value])
                                        {
                                            className = 'active';
                                        }

                                        if(!this.state.item[this.props.map.value] && this.state.item === item)
                                        {
                                            className = 'active';
                                        }
                                    }

                                    if(this.props.scope && this.props.scope.scope != 520000000000)
                                    {
                                      if(!this.props.scope.district || item[this.props.map.value] == this.props.scope.district || item == this.props.scopedistrict || (!item[this.props.map.value] || !item) )
                                      {
                                        return (
                                            <li title={item[this.props.map.text] ? item[this.props.map.text] : (item[this.props.map.value] ? item[this.props.map.value] : item)} key={index} className={className} onClick={this.chose.bind(this,item)}>
                                                <div>
                                                    {item[this.props.map.text] ? item[this.props.map.text] : (item[this.props.map.value] ? item[this.props.map.value] : item)}
                                                </div>
                                            </li>
                                        )
                                      }else{
                                        return (
                                            <li title={item[this.props.map.text] ? item[this.props.map.text] : (item[this.props.map.value] ? item[this.props.map.value] : item)} key={index} className={className}>
                                                <div style={{color: 'gray'}}>
                                                    {item[this.props.map.text] ? item[this.props.map.text] : (item[this.props.map.value] ? item[this.props.map.value] : item)}
                                                </div>
                                            </li>
                                        )
                                      }

                                    }else{
                                      return (
                                          <li title={item[this.props.map.text] ? item[this.props.map.text] : (item[this.props.map.value] ? item[this.props.map.value] : item)} key={index} className={className} onClick={this.chose.bind(this,item)}>
                                              <div>
                                                  {item[this.props.map.text] ? item[this.props.map.text] : (item[this.props.map.value] ? item[this.props.map.value] : item)}
                                              </div>
                                          </li>
                                      )
                                    }
                                })
                            }
                        </ul>
                    ) : ''
                }
            </div>
        )
    }
}

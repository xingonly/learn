// 上帝保佑,永无bug

import React, {Component} from "react"
import { TOKEN } from '../../constants/storage'
import createHashHistory from 'history/createHashHistory'
import { pUser } from '../../configs/endpoints.prod'
import resource from '../../util/resource'
import {NavLink, Link} from 'react-router-dom'
import { message } from 'antd'
import smallLogo from './images/smallLogo.gif'
import style from './style.scss'

export default class Nav extends Component {

    constructor(props){
        super(props);
        try {
          this.roles = JSON.parse(sessionStorage.getItem('roles'));
        }catch(e) {
          this.roles = [];
        }
        this.povertyAlleviation = '';
        if(this.roles && this.roles.indexOf('USE_MANAGER_CENTER') !== -1){
            this.povertyAlleviation =  <li><NavLink to="/main/controlCenter/povertyalleviation" activeClassName={style.active}>菜单扶贫</NavLink></li>;
        }
    }

    logout = () => {
        resource.delete(pUser.logout).then( (res) => {
            if(res.status !== 200) {
                message.error(res.message);
            }else {
                sessionStorage.removeItem(TOKEN);
                createHashHistory().push('/login')
            }
        })
    }

    render() {
        return (
            <div className={style.wrap}>
                <Link to="/main/controlCenter/dateAnalysis"><img src={smallLogo} alt='' /><span className={style.logo}>西秀区“菜单式”扶贫服务管理系统</span></Link>
                <nav className={style.navs}>
                    {/*<NavLink to="/main/keypoint" activeClassName={style.active}>重点指标</NavLink>*/}
                    {/*<NavLink to="/main/dataAnalysis" activeClassName={style.active}>数据分析</NavLink>*/}
                    {/*<NavLink to="/login" activeClassName={style.active}>对象查询</NavLink>*/}
                    {/*<NavLink to="/main/object_management" activeClassName={style.active}>对象管理</NavLink>*/}
                    {/*<NavLink to="/main/helpingCadres" activeClassName={style.active}>帮扶干部</NavLink>*/}
                    <NavLink className={style.showNextNav} to="/main/controlCenter" activeClassName={style.active}>
                        <span>调度中心</span>
                        <ul className={style.levelTwoNav}>
                            <li><NavLink to="/main/controlCenter/dateAnalysis" activeClassName={style.active}>数据分析</NavLink></li>
                            {this.povertyAlleviation}
                        </ul>
                    </NavLink>
                    <NavLink to="/main/greenfieldFarms" activeClassName={style.active}>绿野芳田</NavLink>
                    <NavLink className={style.showNextNav} to="/main/lilyTown" activeClassName={style.active}>
                        <span>百合花小镇</span>
                        <ul style={{padding: '12px 0'}} className={style.levelTwoNav}>
                            <li><NavLink to="/main/lilyTown/disableInfo" activeClassName={style.active}>残疾人信息</NavLink></li>
                            <li><NavLink to="/main/lilyTown/supportCenterAsso" activeClassName={style.active}>托养中心联合体</NavLink></li>
                        </ul>
                    </NavLink>
                    <NavLink className={style.showNextNav} to="/main/keypoint" activeClassName={style.active}>
                        <span>重点指标</span>
                        <ul className={style.levelTwoNav}>
                            <li><NavLink to="/main/keypoint/accurateidentification" activeClassName={style.active}>异常调度</NavLink></li>
                            <li><NavLink to="/main/keypoint/protection" activeClassName={style.active}>基本保障</NavLink></li>
                            <li><NavLink to="#" activeClassName={style.active} style={{color: 'gray',cursor: 'not-allowed',border:'none'}}>易地搬迁</NavLink></li>
                            <li><NavLink to="/main/keypoint/education" activeClassName={style.active}>教育扶贫</NavLink></li>
                            {/*<li><NavLink to="#" activeClassName={style.active}>企业帮扶</NavLink></li>*/}
                        </ul>
                    </NavLink>
                    <NavLink to="/main/object" activeClassName={style.active}>对象查询</NavLink>
                    <NavLink to="/main/object_management" activeClassName={style.active}>对象管理</NavLink>
                    <NavLink className={style.showNextNav} to="/main/cadre" activeClassName={style.active}>
                        <span>干部管理</span>
                        <ul className={style.levelTwoNav}>
                            <li><NavLink to="/main/cadre/log" activeClassName={style.active}>日志管理</NavLink></li>
                            <li><NavLink to="/main/cadre/signIn" activeClassName={style.active}>签到管理</NavLink></li>
                            <li><NavLink to="/main/cadre/DataManage" activeClassName={style.active}>数据管理</NavLink></li>
                            <li><NavLink to="/main/cadre/helpingCadres" activeClassName={style.active}>干部帮扶</NavLink></li>
                        </ul>
                    </NavLink>
                    <ul className={style.control}>
                        <li className={style.stair}>
                            <span style={{margin: '0 .5rem 0 0'}}>{sessionStorage.getItem('username') && sessionStorage.getItem('username') || '--'}</span>
                            <a href="javascript:void(0)"><i className="iconfont">&#xe6bd;</i></a>
                            <ul className={style.second}>
                                {
                                    sessionStorage.getItem('roles') && (sessionStorage.getItem('roles').indexOf('USE_RESPONSIBILITY_DEPARTMENT') !== -1?
                                        <li><NavLink to="/main/controlCenter/povertyalleviation" activeClassName={style.active}>需求办理</NavLink></li>: null)
                                    || null
                                }
                                <li><a href="javascript:void(0)" onClick={this.logout}>退出</a></li>
                            </ul>
                        </li>
                        {/*<li className={style.stair}>*/}
                            {/*<a href="javascript:void(0)">*/}
                                {/*<i className="iconfont">&#xe609;</i>*/}
                            {/*</a>*/}
                        {/*</li>*/}
                    </ul>
                </nav>
            </div>
        )
    }
}

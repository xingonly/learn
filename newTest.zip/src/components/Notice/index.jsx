// 上帝保佑,永无bug

import React, {Component} from "react";
import ReactDOM from 'react-dom';
import style from './style.scss';

class NoticeComponent extends Component {

    constructor (props) {
      super(props);
      this.state = {
        list: []
      }
    }

    closeNotice = (index) => {
      if(this.props.handleClose)
      {
        this.props.handleClose(index);
      }
    }

    render() {

        return (
          <div className={style.container}>
            {
              this.props.noticeList.map((item,index) => {
                let mainStyle = '';
                let img = '';
                switch(item.type) {
                  case 'success':
                    mainStyle = {
                      background: '#28fad0',
                      color: '#fff'
                    };
                    img = 'success.png';
                    break;
                  case 'warring':
                    mainStyle = {
                      background: '#fad328',
                      color: '#fff'
                    };
                    img = 'warring.png';
                    break;
                  case 'error':
                    mainStyle = {
                      background: '#fa285c',
                      color: '#fff'
                    };
                    img = 'error.png';
                }

                return (
                  <div className={style.notice + ' ' + item.className} key={index} style={mainStyle} onClick={this.closeNotice.bind(this,index)}>
                    <div className={style.icon}>
                      <img src={require('./images/' + img)}/>
                    </div>
                    <div className={style.main}>
                      <div className={style.title}>
                        {item.title}
                      </div>
                      <div className={style.content}>
                        {item.content}
                      </div>
                    </div>
                  </div>
                );
              })
            }
          </div>
        )
    }
}

class Notice {

  constructor () {

    var list = [];

    var interval = '';

    this.success = (title,content) => {
      list.unshift(
        {
          type: 'success',
          title: title,
          content: content
        }
      );
      render();
    }

    this.warning = (title,content) => {
      list.unshift(
        {
          type: 'warring',
          title: title,
          content: content
        }
      );
      render();
    }

    this.error = (title,content) => {
      list.unshift(
        {
          type: 'error',
          title: title,
          content: content
        }
      );
      render();
    }

    var handleClose = (index) => {
      list.splice(index,1)
      if(interval)
      {
        clearInterval(interval);
        interval = '';
      }
      render();
    }

    var subtract = () => {
      list.length = list.length - 1;
      render();
    }

    var render = () => {
      ReactDOM.render(<NoticeComponent noticeList={list} handleClose={handleClose}/>, document.getElementById('notice'));
      if(list.length && !interval)
      {
        let lists = list;
        interval = setInterval(() => {
          if(list.length > 0)
          {
            list[list.length - 1].className = style.fadeOut;
            render();
            setTimeout(subtract,1000);
          }else if(lists.length === 0){
            render();
          }else{
            clearInterval(interval);
            interval = '';
          }
        },5000);
      }
    }
  }
}

export default new Notice();

import React, { Component } from 'react'
import style from './style.scss'
import noData from './images/noData.png'

export default class NoData extends Component {
    render(){
        return(
            <div className={style.emptys}>
                <div style={{padding:'140px 0'}}>
                    <img src={noData} alt=""/>
                </div>
            </div>
        )
    }
}
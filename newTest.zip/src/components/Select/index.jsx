import React, {Component} from "react"
import style from "./style.scss";
// import { Tooltip } from "antd";

export default class Select extends Component {
  constructor(props) {
    super(props);
    this.options = this.props.options;
    this.state = {
      width: this.props.width || '100%',
      list: this.props.options,
      show:false,
      value:'',
      isTop:false
    }
  }

  componentDidMount () {
    if(this.props.value !== undefined)
    {
      this.setState({
        value: this.props.value
      });
    }

  }

  componentWillUnmount () {
    document.removeEventListener('click', this.handleShowOptions);
  }
  componentWillReceiveProps(newProps){
    this.options = newProps.options;
    this.setState({
      width: newProps.width || '100%',
      list: newProps.options
    });
    if(newProps.value !== this.props.value && newProps.value !== undefined)
    {
      this.setState({
        value: newProps.value
      });
    }
  }

  handleOption = (value)=> {
    if(this.props.value !== undefined)
    {
      this.props.onChangeOption(value);
    }else{
      this.setState({
        value: value.id
      },this.props.onChangeOption(value))
    }
  }
  //
  handleShowOptions = () => {
    if(this.input) {
     this.input = false;
     return;
    }
    this.setState({
      show:!this.state.show
    }, () => {
      if(this.state.show)
      {
        document.addEventListener('click', this.handleShowOptions);
        if(document.querySelector('body').scrollHeight > document.documentElement.clientHeight){
          this.setState({
            isTop:true
          })
        }else{
          this.setState({
            isTop:false
          })
        }
      }else{
        document.removeEventListener('click', this.handleShowOptions);
        if(this.props.showInput ){
          this.refs.input.value = '';
        }
        if(document.querySelector('body').scrollHeight > document.documentElement.clientHeight){
          this.setState({
            isTop:true,
            list:this.options
          })
        }else{
          this.setState({
            isTop:false,
            list:this.options
          })
        }
      }
    })
  }
  //输入框点击事件
  handleCilck = (e) => {
    e.nativeEvent.stopImmediatePropagation();
    this.input= true;
  }
  //输入框筛选事件
  inputChange = (e) => {
    let value = e.target.value;
    let reg = new RegExp(value,'g');
    let option = [];
    if(!value){
      option = this.options;
    }else{
      for(let i = 0; i < this.options.length; i++){
        if(reg.test(this.options[i].name)){
          option.push(this.options[i]);
        }
      }
    }
    this.setState({
      list:option
    })
  }
  //
  find = (array,id) => {
    for (let i = 0; i < array.length;i++){
      if(array[i].id === id){
        return array[i].name
      }
    }
  }

  render() {
    return (
      <section className={style.select + " " + (this.props.className ? this.props.className : '')}
               onClick={this.handleShowOptions} style={{width: this.state.width}}>
        <div className={style.wenzi}>
          {/*<Tooltip title={this.find(this.state.list, this.state.value)}>*/}
            <span className={style.test}>
            {(() => {
              if (!this.state.value) {
                return this.props.defaultValue;
              } else {
                return this.find(this.state.list, this.state.value)
              }
            })()}
            </span>
          {/*</Tooltip>*/}
          <span className={style.sanjiao}/>
        </div>
        <div className={style.options} style={{display:this.state.show?'block':'none',
          top:this.state.isTop ? '-6.25rem':'40px'}}>
          {
            this.props.showInput ? <input type="text" className={style.selectInput} ref="input"
            onClick={(event) =>{this.handleCilck(event)}} onChange={this.inputChange}/> : null
          }
          {
            this.state.list.map((item,index) => {
              return(
                <div key={index} className={style.option} onClick={() => {this.handleOption(item)}}>
                 {item.name}
                </div>
              )
            })
          }
        </div>
      </section>
    )
  }
}

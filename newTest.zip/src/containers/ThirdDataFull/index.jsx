import React,{Component} from 'react'
import style from './index.scss'
import Five from './images/Five.png'
import resource from '../../util/resource'
import MySelect from '../../components/MySelect';
import createHistory from 'history/createHashHistory';

const history = createHistory();
export default class ThirdData extends Component {
    constructor(props) {
        super(props)
        this.data = ''
        this.thirdData = ''
        this.diffsData = []
        this.diffsContent = []
        this.gongan = ''
        this.jiaoyu = ''
        this.renshe = ''
        this.jianshe = ''
        this.minzheng = ''
        this.guotu = ''
        this.gongshang = ''
        this.weiji = ''
        this.yimin = ''
        this.state = {
            active: 'ga',
            marginLeft: '0',
            idNumber: JSON.parse(sessionStorage.getItem('ID')).idnumber||'',
            fid: JSON.parse(sessionStorage.getItem('ID')).fid||'',
            data: '',
            thirdData: '',
            diffsData: [],
            getData: {},
        }
    }
    componentDidMount() {
        this.getRequire()
        this.getDiffsRequire('gongan')
    }
    getRequire = () => {
        resource.get(`/compare-server/compare/v0.1/status?fid=${this.state.fid}`).then((res) => {
            if(res.status !== 200) {
                console.log(res.message)
            }else {
                this.setState({
                    getData: res.data
                })
            }
        })
    }
    getThirdRequire = (type) => {
        resource.get(`/xixiu-server/dataComparison/getThiredDetail?department=${type}&idnumber=${this.state.idNumber}`).then((res) => {
            if(res.status !== 200) {
                console.log(res.message)
            }else {
                if(res.data) {
                    this.thirdData = res.data
                    this.setState({
                        thirdData: res.data,
                    })
                }else {
                    this.thirdData = ''
                    this.setState({
                        thirdData: '',
                    })
                }
            }
        })
    }
    getDataRequire = (type) => {
        resource.get(`/xixiu-server/dataComparison/getData?department=${type}&idnumber=${this.state.idNumber}`).then((res) => {
            if(res.status !== 200) {
                console.log(res.message)
            }else {
                if(res.data) {
                    this.data = res.data
                    this.setState({
                        data: res.data,
                    })
                }else {
                    this.data = ''
                    this.setState({
                        data: '',
                    })
                }
            }
        })
    }
    getDiffsRequire = (type) => {
        resource.get(`/compare-server/compare/v0.1/diffs?fid=${this.state.fid}&deptCode=${type}`).then((res) => {
            if(res.status !== 200) {
                console.log(res.message)
            }else {
                if(res.data.content.length !== 0) {
                    let diffsContent = []
                    for(let ite of res.data.content) {
                        let data = {
                            value: ite.idnumber,
                            label: ite.full_name,
                        }
                        diffsContent.push(data)
                    }
                    this.diffsContent = diffsContent
                    let idNumber = this.state.idNumber
                    let c = res.data.content
                    for(let i=0;i<c.length;i++) {
                        if(c[i].idnumber === idNumber) {
                            this.diffsData = c[i].diffs
                            this[type] = c[i].full_name
                            this.setState({
                                idNumber: c[i].idnumber,
                                diffsData: c[i].diffs,
                            },() => {
                                this.getDataRequire(type)
                                this.getThirdRequire(type)
                            })
                            return false
                        }else {
                            this.diffsData = c[0].diffs
                            this[type] = c[0].full_name
                            this.setState({
                                idNumber: c[0].idnumber,
                                diffsData: c[0].diffs,
                            },() => {
                                this.getDataRequire(type)
                                this.getThirdRequire(type)
                            })
                        }
                    }
                }else {
                    this.diffsContent = []
                    this.diffsData = []
                    this.setState({
                        diffsData: '',
                    })
                }
            }
        })
    }
    selectList = (name,department) => {
        let getData = this.state.getData
        if(getData[department] !== null) {
            this.getDiffsRequire(department)
            this.setState({
                active: name
            })
        }
    }
    scrollLeft = () => {
        this.setState({
            marginLeft: '0'
        })
    }
    translateGender = (num) => {
        switch(num) {
            case 1:return '男';break;
            case 2:return '女';break;
            case 9:return '未知';break;
            default:return '-';break;
        }
    }
    translateSchoolSituation = (str) => {
        switch(str) {
            case '01':return '非在读';break;
            case '99':return '在读';break;
            default:return '-';break;
        }
    }
    translateTrueOrFalse = (b) => {
        switch(b) {
            case true:return '是';break;
            case false:return '否';break;
            default:return '-';break;
        }
    }
    translateGongShang = (num) => {
        switch(num) {
            case 0:return '未参加农民专业合作社、未参加其他';break;
            case 1:return '参加农民专业合作社、未参加其他';break;
            case 2:return '未参加农民专业合作社、参加其他';break;
            case 3:return '参加农民专业合作社、参加其他';break;
            default:return '-';break;
        }
    }
    translateYouFu = (num) => {
        switch(num) {
            case 0:return '否';break;
            case 1:return '是';break;
            default:return '-';break;
        }
    }
    translateCanBaoStatus = (num) => {
        switch(num) {
            case 0:return '终止参保';break;
            case 1:return '正常参保';break;
            default:return '-';break;
        }
    }
    diffs = (type) => {
        let diffsData = this.state.diffsData
        if(diffsData.length !== 0) {
            for(let item of diffsData) {
                switch(item) {
                    case type:return true;break;
                    default:break;
                }
            }
            return false
        }else {
            return false
        }
    }
    handleClickName = (obj,name) => {
        let value = obj.value;
        let label = obj.label;
        this[name] = label,
            this.setState({
                idNumber: value
            },() => {
                this.getDataRequire(name)
                this.getThirdRequire(name)
            })
    }
    jumpFull = () => {
        history.push('/main/object/objectSearch')
    }
    render() {
        let ga = <div className={style['content-center']}>
            <div className={style['fpb']}>
                <header className={style['title']}>扶贫办数据
                    <div className={style['select']}>
                        <MySelect
                            value={this.gongan}
                            options={this.diffsContent}
                            handleClick={this.handleClickName}
                            name="gongan"
                        />
                    </div>
                </header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.data && this.data.full_name || '-'}>姓名：{this.data && this.data.full_name || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.data && this.data.idnumber || '-'} >身份证号：{this.data && this.data.idnumber || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('relationship')?style['bg']:null} text-overflow`} title={this.data && this.data.relationship || '-'} >与户主关系：{this.data && this.data.relationship || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('gender')?style['bg']:null} text-overflow`} title={this.data && this.data.gender || '-'} >性别：{this.data && this.data.gender || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('ethnic')?style['bg']:null} text-overflow`} title={this.data && this.data.ethnic || '-'} >民族：{this.data && this.data.ethnic || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('homeAddress')?style['bg']:null} text-overflow`} title={this.data && this.data.homeAddress || '-'} >家庭住址：{this.data && this.data.homeAddress || '-'}</span>
                    </li>
                </ul>
            </div>
            <div className={style['separated']}></div>
            <div className={style['fpb']} style={{marginTop: '2.5rem'}}>
                <header className={style['title']}>公安厅数据</header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.full_name || '-'} >姓名：{this.thirdData && this.thirdData.full_name || '-'}</span>
                        <span className={`${this.diffs('car_except')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.car_except || '-'} >车型统计：{this.thirdData && this.thirdData.car_except || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.idnumber || '-'} >身份证号：{this.thirdData && this.thirdData.idnumber || '-'}</span>
                        <span className={`${this.diffs('car_status')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.car_status || '-'} >登记状态：{this.thirdData && this.thirdData.car_status || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('relationship')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.relationship || '-'} >与户主关系：{this.thirdData && this.thirdData.relationship || '-'}</span>
                        <span className={`${this.diffs('valid_date')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.valid_date || '-'} >领证日期：{this.thirdData && this.thirdData.valid_date || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('gender')?style['bg']:null} text-overflow`} title={this.translateGender(this.thirdData && this.thirdData.gender || 3)} >性别：{this.translateGender(this.thirdData && this.thirdData.gender || 3)}</span>
                        <span className={`${this.diffs('licensed_class')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.licensed_class || '-'} >驾驶登记：{this.thirdData && this.thirdData.licensed_class || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('ethnic')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.ethnic || '-'} >民族：{this.thirdData && this.thirdData.ethnic || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('district_code')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.district_code || '-'} >家庭住址：{this.thirdData && this.thirdData.district_code || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('first_record_date')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.first_record_date || '-'}>登记日期：{this.thirdData && this.thirdData.first_record_date || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('car_type')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.car_type || '-'} >车型：{this.thirdData && this.thirdData.car_type || '-'}</span>
                    </li>
                </ul>
            </div>
        </div>
        let jy = <div className={style['content-center']}>
            <div className={style['fpb']}>
                <header className={style['title']}>扶贫办数据
                    <div className={style['select']}>
                        <MySelect
                            value={this.jiaoyu}
                            options={this.diffsContent}
                            handleClick={this.handleClickName}
                            name="jiaoyu"
                        />
                    </div>
                </header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.data && this.data.full_name || '-'} >姓名：{this.data && this.data.full_name || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.data && this.data.idnumber || '-'} >身份证号：{this.data && this.data.idnumber || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('schoolSituation')?style['bg']:null} text-overflow`} title={this.data && this.data.schoolSituation || '-'} >在校生情况：{this.data && this.data.schoolSituation || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('gender')?style['bg']:null} text-overflow`} title={this.data && this.data.gender || '-'} >性别：{this.data && this.data.gender || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('homeAddress')?style['bg']:null} text-overflow`} title={this.data && this.data.homeAddress || '-'} >家庭住址：{this.data && this.data.homeAddress || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('educationLevel')?style['bg']:null} text-overflow`} title={this.data && this.data.educationLevel || '-'} >文化程度：{this.data && this.data.educationLevel || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('dateOfBirth')?style['bg']:null} text-overflow`} title={this.data && this.data.dateOfBirth || '-'} >出生日期：{this.data && this.data.dateOfBirth || '-'}</span>
                    </li>
                </ul>
            </div>
            <div className={style['separated']}></div>
            <div className={style['fpb']} style={{marginTop: '2.5rem'}}>
                <header className={style['title']}>教育厅数据</header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.full_name || '-'} >姓名：{this.thirdData && this.thirdData.full_name || '-'}</span>
                        <span className={`${this.diffs('isLocalProvince')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.isLocalProvince || '-'} >省内或省外就读：{this.thirdData && this.thirdData.isLocalProvince || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.idnumber || '-'} >身份证号：{this.thirdData && this.thirdData.idnumber || '-'}</span>
                        <span className={`${this.diffs('school')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.school || '-'} >就读学校及专业：{this.thirdData && this.thirdData.school || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('school_situation')?style['bg']:null} text-overflow`} title={this.translateSchoolSituation(this.thirdData && this.thirdData.school_situation || '00')}>在校生情况：{this.translateSchoolSituation(this.thirdData && this.thirdData.school_situation || '00')}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('gender')?style['bg']:null} text-overflow`} title={this.translateGender(this.thirdData && this.thirdData.gender || 3)}>性别：{this.translateGender(this.thirdData && this.thirdData.gender || 3)}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('district_code')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.district_code || '-'}>家庭住址：{this.thirdData && this.thirdData.district_code || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('rollID')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.rollID || '-'}>学籍号：{this.thirdData && this.thirdData.rollID || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('grade')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.grade || '-'}>就读年级：{this.thirdData && this.thirdData.grade || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('category')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.category || '-'}>资助类别：{this.thirdData && this.thirdData.category || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('fupin_total')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.fupin_total || '-'}>资助金额合计：{this.thirdData && this.thirdData.fupin_total || '-'}</span>
                    </li>
                </ul>
            </div>
        </div>
        let ym = <div className={style['content-center']}>
            <div className={style['fpb']}>
                <header className={style['title']}>扶贫办数据
                    <div className={style['select']}>
                        <MySelect
                            value={this.yimin}
                            options={this.diffsContent}
                            handleClick={this.handleClickName}
                            name="yimin"
                        />
                    </div>
                </header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.data && this.data.full_name || '-'}>户主姓名：{this.data && this.data.full_name || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.data && this.data.idnumber || '-'}>身份证号：{this.data && this.data.idnumber || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('population')?style['bg']:null} text-overflow`} title={this.data && this.data.population || '-'}>户口人数：{this.data && this.data.population || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('original_location')?style['bg']:null} text-overflow`} title={this.data && this.data.original_location || '-'}>迁出地：{this.data && this.data.original_location || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('purpose_location')?style['bg']:null} text-overflow`} title={this.data && this.data.purpose_location || '-'}>迁入地：{this.data && this.data.purpose_location || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('place_location')?style['bg']:null} text-overflow`} title={this.data && this.data.place_location || '-'}>安置地：{this.data && this.data.place_location || '-'}</span>
                    </li>
                </ul>
            </div>
            <div className={style['separated']}></div>
            <div className={style['fpb']} style={{marginTop: '2.5rem'}}>
                <header className={style['title']}>移民局数据</header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.full_name || '-'}>易地扶贫搬迁户户主姓名：{this.thirdData && this.thirdData.full_name || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.idnumber || '-'}>身份证号：{this.thirdData && this.thirdData.idnumber || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('population')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.population || '-'}>家庭成员人数：{this.thirdData && this.thirdData.population || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('out_address')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.out_address || '-'}>迁出地名称：{this.thirdData && this.thirdData.out_address || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('in_address')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.in_address || '-'}>迁入地：{this.thirdData && this.thirdData.in_address || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('place_location')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.place_location || '-'}>安置点名称：{this.thirdData && this.thirdData.place_location || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('people_number')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.people_number}>迁出地搬迁总人口：{this.thirdData && this.thirdData.people_number}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('house_of_group')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.house_of_group || '-'}>全组户数：{this.thirdData && this.thirdData.house_of_group || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('people_of_group')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.people_of_group || '-'}>全组人口：{this.thirdData && this.thirdData.people_of_group || '-'}</span>
                    </li>
                </ul>
            </div>
        </div>
        let gs = <div className={style['content-center']}>
            <div className={style['fpb']}>
                <header className={style['title']}>扶贫办数据
                    <div className={style['select']}>
                        <MySelect
                            value={this.gongshang}
                            options={this.diffsContent}
                            handleClick={this.handleClickName}
                            name="gongshang"
                        />
                    </div>
                </header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.data && this.data.full_name || '-'}>姓名：{this.data && this.data.full_name || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.data && this.data.idnumber || '-'}>身份证号：{this.data && this.data.idnumber || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('farmersCooperative')?style['bg']:null} text-overflow`} title={this.translateTrueOrFalse(this.data && this.data.farmersCooperative || '-')}>是否加入农民专业合作社：{this.translateTrueOrFalse(this.data && this.data.farmersCooperative || '-')}</span>
                    </li>
                </ul>
            </div>
            <div className={style['separated']}></div>
            <div className={style['fpb']} style={{marginTop: '2.5rem'}}>
                <header className={style['title']}>工商局数据</header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.full_name || '-'}>法人代表姓名：{this.thirdData && this.thirdData.full_name || '-'}</span>
                        <span className={`${this.diffs('djjg')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.djjg || '-'}>发照机关：{this.thirdData && this.thirdData.djjg || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.idnumber || '-'}>法定代表人身份证号：{this.thirdData && this.thirdData.idnumber || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('farmers_cooperative')?style['bg']:null} text-overflow`} title={this.translateGongShang(this.thirdData && this.thirdData.farmers_cooperative || 4)}>工商概要信息：{this.translateGongShang(this.thirdData && this.thirdData.farmers_cooperative || 4)}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('qymc')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.qymc || '-'}>公司名称：{this.thirdData && this.thirdData.qymc || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('zczb')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.zczb || '-'}>注册资金：{this.thirdData && this.thirdData.zczb || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('ybjyfw')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.ybjyfw || '-'}>经营范围：{this.thirdData && this.thirdData.ybjyfw || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('clrq')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.clrq || '-'}>注册时间：{this.thirdData && this.thirdData.clrq || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('djjgmc')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.djjgmc || '-'}>发照机关名称：{this.thirdData && this.thirdData.djjgmc || '-'}</span>
                    </li>
                </ul>
            </div>
        </div>
        let mz = <div className={style['content-center']}>
            <div className={style['fpb']}>
                <header className={style['title']}>扶贫办数据
                    <div className={style['select']}>
                        <MySelect
                            value={this.minzheng}
                            options={this.diffsContent}
                            handleClick={this.handleClickName}
                            name="minzheng"
                        />
                    </div>
                </header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.data && this.data.full_name || '-'}>姓名：{this.data && this.data.full_name || '-'}</span>
                        <span className={`${this.diffs('doubleDaughter')?style['bg']:null} text-overflow`} title={this.translateTrueOrFalse(this.data && this.data.doubleDaughter || '-')}>是否双女户：{this.translateTrueOrFalse(this.data && this.data.doubleDaughter || '-')}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.data && this.data.idnumber || '-'}>身份证号：{this.data && this.data.idnumber || '-'}</span>
                        <span className={`${this.diffs('dateOfBirth')?style['bg']:null} text-overflow`} title={this.data && this.data.dateOfBirth || '-'}>出生日期：{this.data && this.data.dateOfBirth || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('povertyAttribute')?style['bg']:null} text-overflow`} title={this.translateTrueOrFalse(this.data && this.data.povertyAttribute || '-')}>贫困户属性：{this.translateTrueOrFalse(this.data && this.data.povertyAttribute || '-')}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('activeSoldier')?style['bg']:null} text-overflow`} title={this.translateTrueOrFalse(this.data && this.data.activeSoldier || '-')}>是否现役军人：{this.translateTrueOrFalse(this.data && this.data.activeSoldier || '-')}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('onlyChild')?style['bg']:null} text-overflow`} title={this.translateTrueOrFalse(this.data && this.data.onlyChild || '-')}>是否独生子女：{this.translateTrueOrFalse(this.data && this.data.onlyChild || '-')}</span>
                    </li>
                </ul>
            </div>
            <div className={style['separated']}></div>
            <div className={style['fpb']} style={{marginTop: '2.5rem'}}>
                <header className={style['title']}>民政厅数据</header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.full_name || '-'}>姓名：{this.thirdData && this.thirdData.full_name || '-'}</span>
                        <span className={`${this.diffs('living_subsidies')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.living_subsidies || '-'}>优抚补助金额：{this.thirdData && this.thirdData.living_subsidies || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.idnumber || '-'}>身份证号：{this.thirdData && this.thirdData.idnumber || '-'}</span>
                        <span className={`${this.diffs('service_length')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.service_length || '-'}>服役年限：{this.thirdData && this.thirdData.service_length || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('is_youfu')?style['bg']:null} text-overflow`} title={this.translateYouFu(this.thirdData && this.thirdData.is_youfu || 2)}>是否享受抚恤补助：{this.translateYouFu(this.thirdData && this.thirdData.is_youfu || 2)}</span>
                        <span className={`${this.diffs('is_orphan')?style['bg']:null} text-overflow`} title={this.translateYouFu(this.thirdData && this.thirdData.is_orphan || 2)}>是否孤儿：{this.translateYouFu(this.thirdData && this.thirdData.is_orphan || 2)}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('is_low_security')?style['bg']:null} text-overflow`} title={this.translateYouFu(this.thirdData && this.thirdData.is_low_security || 2)}>是否为低保户：{this.translateYouFu(this.thirdData && this.thirdData.is_low_security || 2)}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('low_security_type')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.low_security_type || '-'}>低保类型：{this.thirdData && this.thirdData.low_security_type || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('low_security_amount')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.low_security_amount || '-'}>保障金额：{this.thirdData && this.thirdData.low_security_amount || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('youfu_type')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.youfu_type || '-'}>优抚类别：{this.thirdData && this.thirdData.youfu_type || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('disability_level')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.disability_level || '-'}>伤残等级：{this.thirdData && this.thirdData.disability_level || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('nature_disability')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.nature_disability || '-'}>伤残性质：{this.thirdData && this.thirdData.nature_disability || '-'}</span>
                    </li>
                </ul>
            </div>
        </div>
        let rs = <div className={style['content-center']}>
            <div className={style['fpb']}>
                <header className={style['title']}>扶贫办数据
                    <div className={style['select']}>
                        <MySelect
                            value={this.renshe}
                            options={this.diffsContent}
                            handleClick={this.handleClickName}
                            name="renshe"
                        />
                    </div>
                </header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.data && this.data.full_name || '-'}>姓名：{this.data && this.data.full_name || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.data && this.data.idnumber || '-'}>身份证号：{this.data && this.data.idnumber || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('gender')?style['bg']:null} text-overflow`} title={this.data && this.data.gender || '-'}>性别：{this.data && this.data.gender || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('resident_pension')?style['bg']:null} text-overflow`} title={this.translateTrueOrFalse(this.data && this.data.resident_pension || '-')}>是否参加新型农村养老保险：{this.translateTrueOrFalse(this.data && this.data.resident_pension || '-')}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('laborAbility')?style['bg']:null} text-overflow`} title={this.data && this.data.laborAbility || '-'}>劳动技能：{this.data && this.data.laborAbility || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('workSituation')?style['bg']:null} text-overflow`} title={this.data && this.data.workSituation || '-'}>劳工情况：{this.data && this.data.workSituation || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('workTime')?style['bg']:null} text-overflow`} title={this.data && this.data.workTime || '-'}>务工时间：{this.data && this.data.workTime || '-'}</span>
                    </li>
                </ul>
            </div>
            <div className={style['separated']}></div>
            <div className={style['fpb']} style={{marginTop: '2.5rem'}}>
                <header className={style['title']}>人社厅数据</header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.full_name || '-'}>姓名：{this.thirdData && this.thirdData.full_name || '-'}</span>
                        <span className={`${this.diffs('job_date')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.job_date || '-'}>就业日期：{this.thirdData && this.thirdData.job_date || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.idnumber || '-'}>身份证号：{this.thirdData && this.thirdData.idnumber || '-'}</span>
                        <span className={`${this.diffs('office')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.office || '-'}>单位名称：{this.thirdData && this.thirdData.office || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('gender')?style['bg']:null} text-overflow`} title={this.translateGender(this.thirdData && this.thirdData.gender || 0)}>性别：{this.translateGender(this.thirdData && this.thirdData.gender || 0)}</span>
                        <span className={`${this.diffs('jiuye_source_type')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.jiuye_source_type || '-'}>就业类型：{this.thirdData && this.thirdData.jiuye_source_type || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('resident_pension')?style['bg']:null} text-overflow`} title={this.translateCanBaoStatus(this.thirdData && this.thirdData.resident_pension || 2)}>养老保险状态：{this.translateCanBaoStatus(this.thirdData && this.thirdData.resident_pension || 2)}</span>
                        <span className={`${this.diffs('yanglao_money')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.yanglao_money || '-'}>参保金额：{this.thirdData && this.thirdData.yanglao_money || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('jy_sy_djz')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.jy_sy_djz || '-'}>就失业登记证：{this.thirdData && this.thirdData.jy_sy_djz || '-'}</span>
                        <span className={`${this.diffs('jiaofei_time')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.jiaofei_time || '-'}>缴费时间：{this.thirdData && this.thirdData.jiaofei_time || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('jiaofei_years')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.jiaofei_years || '-'}>缴费年度：{this.thirdData && this.thirdData.jiaofei_years || '-'}</span>
                        <span className={`${this.diffs('training_content')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.training_content || '-'}>培训内容：{this.thirdData && this.thirdData.training_content || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('training_time')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.training_time || '-'}>培训时间：{this.thirdData && this.thirdData.training_time || '-'}</span>
                        <span className={`${this.diffs('benefit')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.benefit || '-'}>培训补贴金额：{this.thirdData && this.thirdData.benefit || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('yanglao_source_type')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.yanglao_source_type || '-'}>城镇/农村（养老）：{this.thirdData && this.thirdData.yanglao_source_type || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('yanglao_address')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.yanglao_address || '-'}>地址：{this.thirdData && this.thirdData.yanglao_address || '-'}</span>
                    </li>
                </ul>
            </div>
        </div>
        let wj = <div className={style['content-center']}>
            <div className={style['fpb']}>
                <header className={style['title']}>扶贫办数据
                    <div className={style['select']}>
                        <MySelect
                            value={this.weiji}
                            options={this.diffsContent}
                            handleClick={this.handleClickName}
                            name="weiji"
                        />
                    </div>
                </header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.data && this.data.full_name || '-'}>姓名：{this.data && this.data.full_name || '-'}</span>
                        <span className={`${this.diffs('otherCauses')?style['bg']:null} text-overflow`} title={this.data && this.data.otherCauses || '-'}>其他致贫原因：{this.data && this.data.otherCauses || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.data && this.data.idnumber || '-'}>身份证号：{this.data && this.data.idnumber || '-'}</span>
                        <span className={`${this.diffs('gender')?style['bg']:null} text-overflow`} title={this.data && this.data.gender || '-'}>性别：{this.data && this.data.gender || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('ncms')?style['bg']:null} text-overflow`} title={this.translateTrueOrFalse(this.data && this.data.ncms || '-')}>是否参加新型农村合作医疗：{this.translateTrueOrFalse(this.data && this.data.ncms || '-')}</span>
                        <span className={`${this.diffs('martyr')?style['bg']:null} text-overflow`} title={this.translateTrueOrFalse(this.data && this.data.martyr || '-')}>是否军烈属：{this.translateTrueOrFalse(this.data && this.data.martyr || '-')}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('onlyChild')?style['bg']:null} text-overflow`} title={this.translateTrueOrFalse(this.data && this.data.onlyChild || '-')}>是否独生子女：{this.translateTrueOrFalse(this.data && this.data.onlyChild || '-')}</span>
                        <span className={`${this.diffs('mainCauses')?style['bg']:null} text-overflow`} title={this.data && this.data.mainCauses || '-'}>主要致贫原因：{this.data && this.data.mainCauses || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('doubleDaughter')?style['bg']:null} text-overflow`} title={this.translateTrueOrFalse(this.data && this.data.doubleDaughter || '-')}>是否双女户：{this.translateTrueOrFalse(this.data && this.data.doubleDaughter || '-')}</span>
                        <span className={`${this.diffs('povertyAttribute')?style['bg']:null} text-overflow`} title={this.data && this.data.povertyAttribute || '-'}>贫困户属性：{this.data && this.data.povertyAttribute || '-'}</span>
                    </li>
                </ul>
            </div>
            <div className={style['separated']}></div>
            <div className={style['fpb']} style={{marginTop: '2.5rem'}}>
                <header className={style['title']}>卫计委数据</header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.full_name || '-'}>姓名：{this.thirdData && this.thirdData.full_name || '-'}</span>
                        <span className={`${this.diffs('within_costs')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.within_costs || '-'}>保内费用：{this.thirdData && this.thirdData.within_costs || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.idnumber || '-'}>身份证号：{this.thirdData && this.thirdData.idnumber || '-'}</span>
                        <span className={`${this.diffs('amount_personal_pay')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.amount_personal_pay || '-'}>自付费用：{this.thirdData && this.thirdData.amount_personal_pay || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('ncms')?style['bg']:null} text-overflow`} title={this.translateYouFu(this.thirdData && this.thirdData.ncms || 2)}>是否参加新型农村合作医疗：{this.translateYouFu(this.thirdData && this.thirdData.ncms || 2)}</span>
                        <span className={`${this.diffs('amount_fund_compensation')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.amount_fund_compensation || '-'}>基金补偿金额：{this.thirdData && this.thirdData.amount_fund_compensation || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('only_child')?style['bg']:null} text-overflow`} title={this.translateYouFu(this.thirdData && this.thirdData.only_child || 2)}>是否独生子女：{this.translateYouFu(this.thirdData && this.thirdData.only_child || 2)}</span>
                        <span className={`${this.diffs('amount_civil_compensation')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.amount_civil_compensation || '-'}>民政补偿金额：{this.thirdData && this.thirdData.amount_civil_compensation || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('gender')?style['bg']:null} text-overflow`} title={this.translateGender(this.thirdData && this.thirdData.gender || 0)}>性别：{this.translateGender(this.thirdData && this.thirdData.gender || 0)}</span>
                        <span className={`${this.diffs('serious_illness_compensation')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.serious_illness_compensation || '-'}>大病商保补偿：{this.thirdData && this.thirdData.serious_illness_compensation || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('precise_properties')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.precise_properties || '-'}>精确属性：{this.thirdData && this.thirdData.precise_properties || '-'}</span>
                        <span className={`${this.diffs('family_planning_reduction_amount')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.family_planning_reduction_amount || '-'}>计生两户减免金额：{this.thirdData && this.thirdData.family_planning_reduction_amount || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('in_hospital_diagnosis_name')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.in_hospital_diagnosis_name || '-'}>入院诊断：{this.thirdData && this.thirdData.in_hospital_diagnosis_name || '-'}</span>
                        <span className={`${this.diffs('fiscal_out_amount')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.fiscal_out_amount || '-'}>财政兜底金额：{this.thirdData && this.thirdData.fiscal_out_amount || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('out_hospital_diagnosis_name')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.out_hospital_diagnosis_name || '-'}>出院诊断：{this.thirdData && this.thirdData.out_hospital_diagnosis_name || '-'}</span>
                        <span className={`${this.diffs('other_security_amount')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.other_security_amount || '-'}>其他保障金额：{this.thirdData && this.thirdData.other_security_amount || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('total_cost')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.total_cost || '-'}>总费用：{this.thirdData && this.thirdData.total_cost || '-'}</span>
                        <span className={`${this.diffs('medical_institutions_amount')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.medical_institutions_amount || '-'}>医疗机构承担金额：{this.thirdData && this.thirdData.medical_institutions_amount || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('single_disease_amount')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.single_disease_amount || '-'}>单病种费用金额：{this.thirdData && this.thirdData.single_disease_amount || '-'}</span>
                        <span className={`${this.diffs('double_daughter')?style['bg']:null} text-overflow`} title={this.translateYouFu(this.thirdData && this.thirdData.double_daughter || 2)}>是否双女户：{this.translateYouFu(this.thirdData && this.thirdData.double_daughter || 2)}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('poverty_attribute')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.poverty_attribute || '-'}>贫困户属性：{this.thirdData && this.thirdData.poverty_attribute || '-'}</span>
                    </li>
                </ul>
            </div>
        </div>
        let js = <div className={style['content-center']}>
            <div className={style['fpb']}>
                <header className={style['title']}>扶贫办数据
                    <div className={style['select']}>
                        <MySelect
                            value={this.jianshe}
                            options={this.diffsContent}
                            handleClick={this.handleClickName}
                            name="jianshe"
                        />
                    </div>
                </header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.data && this.data.full_name || '-'}>户主姓名：{this.data && this.data.full_name || '-'}</span>
                        <span className={`${this.diffs('dangerous')?style['bg']:null} text-overflow`} title={this.translateTrueOrFalse(this.data && this.data.dangerous || '-')}>是否危房户：{this.translateTrueOrFalse(this.data && this.data.dangerous || '-')}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.data && this.data.idnumber || '-'}>身份证号：{this.data && this.data.idnumber || '-'}</span>
                        <span className={`${this.diffs('dangerType')?style['bg']:null} text-overflow`} title={this.data && this.data.dangerType || '-'}>危房级别：{this.data && this.data.dangerType || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('population')?style['bg']:null} text-overflow`} title={this.data && this.data.population || '-'}>户口总人数：{this.data && this.data.population || '-'}</span>
                        <span className={`${this.diffs('ethnic')?style['bg']:null} text-overflow`} title={this.data && this.data.ethnic || '-'}>民族：{this.data && this.data.ethnic || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('area')?style['bg']:null} text-overflow`} title={this.data && this.data.area || '-'}>住房面积：{this.data && this.data.area || '-'}</span>
                        <span className={`${this.diffs('povertyAttribute')?style['bg']:null} text-overflow`} title={this.data && this.data.povertyAttribute || '-'}>贫困户属性：{this.data && this.data.povertyAttribute || '-'}</span>
                    </li>
                </ul>
            </div>
            <div className={style['separated']}></div>
            <div className={style['fpb']} style={{marginTop: '2.5rem'}}>
                <header className={style['title']}>建设厅数据</header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.full_name || '-'}>户主姓名：{this.thirdData && this.thirdData.full_name || '-'}</span>
                        <span className={`${this.diffs('after_transforming_house_property')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.after_transforming_house_property || '-'}>改造后房屋产权：{this.thirdData && this.thirdData.after_transforming_house_property || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.idnumber || '-'}>身份证号：{this.thirdData && this.thirdData.idnumber || '-'}</span>
                        <span className={`${this.diffs('years_included_plan')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.years_included_plan || '-'}>列入计划年度：{this.thirdData && this.thirdData.years_included_plan || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('population')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.population || '-'}>家庭人数：{this.thirdData && this.thirdData.population || '-'}</span>
                        <span className={`${this.diffs('is_accepted')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.is_accepted || '-'}>旧住房建造结构: {this.thirdData && this.thirdData.is_accepted || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('area')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.area || '-'}>改造后住房面积：{this.thirdData && this.thirdData.area || '-'}</span>
                        <span className={`${this.diffs('date_approval')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.date_approval || '-'}>批准日期：{this.thirdData && this.thirdData.date_approval || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('dangerous')?style['bg']:null} text-overflow`} title={this.translateYouFu(this.thirdData && this.thirdData.dangerous || 2)}>是否危房户：{this.translateYouFu(this.thirdData && this.thirdData.dangerous || 2)}</span>
                        <span className={`${this.diffs('start_date')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.start_date || '-'}>开工日期：{this.thirdData && this.thirdData.start_date || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('transformation_reason')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.transformation_reason || '-'}>改造原因：{this.thirdData && this.thirdData.transformation_reason || '-'}</span>
                        <span className={`${this.diffs('completion_date')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.completion_date || '-'}>竣工日期：{this.thirdData && this.thirdData.completion_date || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('ethnic')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.ethnic || '-'}>民族：{this.thirdData && this.thirdData.ethnic || '-'}</span>
                        <span className={`${this.diffs('assistance_fund_type')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.assistance_fund_type || '-'}>享受补助资金类型：{this.thirdData && this.thirdData.assistance_fund_type || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('is_disabled_family')?style['bg']:null} text-overflow`} title={this.translateYouFu(this.thirdData && this.thirdData.is_disabled_family || 2)}>是否贫困残疾家庭：{this.translateYouFu(this.thirdData && this.thirdData.is_disabled_family || 2)}</span>
                        <span className={`${this.diffs('total_investment')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.total_investment || '-'}>总投资：{this.thirdData && this.thirdData.total_investment || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('transformation_way')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.transformation_way || '-'}>改造方式：{this.thirdData && this.thirdData.transformation_way || '-'}</span>
                        <span className={`${this.diffs('government_subsidy_funds')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.government_subsidy_funds || '-'}>各级政府补助资金：{this.thirdData && this.thirdData.government_subsidy_funds || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('construction_mode')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.construction_mode || '-'}>建设方式：{this.thirdData && this.thirdData.construction_mode || '-'}</span>
                        <span className={`${this.diffs('farmers_raised_funds')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.farmers_raised_funds || '-'}>农户其他自筹资金：{this.thirdData && this.thirdData.farmers_raised_funds || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('house_area_after_transforming')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.house_area_after_transforming || '-'}>旧住房建造面积：{this.thirdData && this.thirdData.house_area_after_transforming || '-'}</span>
                        <span className={`${this.diffs('is_commercial_housing')?style['bg']:null} text-overflow`} title={this.translateYouFu(this.thirdData && this.thirdData.is_commercial_housing || 2)}>是否有商品房登记信息：{this.translateYouFu(this.thirdData && this.thirdData.is_commercial_housing || 2)}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('structure_after_transforming')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.structure_after_transforming || '-'}>改造后房屋结构：{this.thirdData && this.thirdData.structure_after_transforming || '-'}</span>
                        <span className={`${this.diffs('buyer')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.buyer || '-'}>产权人姓名：{this.thirdData && this.thirdData.buyer || '-'}</span>
                    </li>
                </ul>
            </div>
        </div>
        let gt = <div className={style['content-center']}>
            <div className={style['fpb']}>
                <header className={style['title']}>扶贫办数据
                    <div className={style['select']}>
                        <MySelect
                            value={this.guotu}
                            options={this.diffsContent}
                            handleClick={this.handleClickName}
                            name="guotu"
                        />
                    </div>
                </header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.data && this.data.full_name || '-'}>姓名：{this.data && this.data.full_name || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.data && this.data.idnumber || '-'}>身份证号：{this.data && this.data.idnumber || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('gender')?style['bg']:null} text-overflow`} title={this.data && this.data.gender || '-'}>性别：{this.data && this.data.gender || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('ethnic')?style['bg']:null} text-overflow`} title={this.data && this.data.ethnic || '-'}>民族：{this.data && this.data.ethnic || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('homeAddress')?style['bg']:null} text-overflow`} title={this.data && this.data.homeAddress || '-'}>家庭住址：{this.data && this.data.homeAddress || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('relationship')?style['bg']:null} text-overflow`} title={this.data && this.data.relationship || '-'}>与户主关系：{this.data && this.data.relationship || '-'}</span>
                    </li>
                </ul>
            </div>
            <div className={style['separated']}></div>
            <div className={style['fpb']} style={{marginTop: '2.5rem'}}>
                <header className={style['title']}>国土厅数据</header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.full_name || '-'}>产权人姓名：{this.thirdData && this.thirdData.full_name || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.idnumber || '-'}>身份证号：{this.thirdData && this.thirdData.idnumber || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('is_registered')?style['bg']:null} text-overflow`} title={this.translateYouFu(this.thirdData && this.thirdData.is_registered || 2)}>是否有房屋类不动产登记信息：{this.translateYouFu(this.thirdData && this.thirdData.is_registered || 2)}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('place')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.place || '-'}>房屋类不动产登记地：{this.thirdData && this.thirdData.place || '-'}</span>
                    </li>
                </ul>
            </div>
        </div>
        return (
            <div className={style['third-data']} >
                <header className={style['header']}>
                    <i className="iconfont" onClick={this.jumpFull}>&#xe643;</i>
                </header>
                <div className={style['nav']}>
                    <ul className={style['nav-list']}>
                        <li style={{marginLeft: this.state.marginLeft,transition: 'margin-left 1s'}}><span className={style[this.state.getData.gongan !== null?(this.state.getData.gongan > 0?(this.state.active === 'ga'?'yellow':'yellowDefault'):(this.state.active === 'ga'?'active':'activeDefault')):'gray']} onClick={() => {this.selectList('ga','gongan')}}>公安</span></li>
                        <li><span className={`${style[this.state.getData.jiaoyu !== null?(this.state.getData.jiaoyu > 0?(this.state.active === 'jy'?'yellow':'yellowDefault'):(this.state.active === 'jy'?'active':'activeDefault')):'gray']} ${style['jy']}`} onClick={() => {this.selectList('jy','jiaoyu')}}>教育{this.state.getData.student !== ''?<img src={Five} alt="" />:''}</span></li>
                        <li><span className={style[this.state.getData.yimin !== null?(this.state.getData.yimin > 0?(this.state.active === 'ym'?'yellow':'yellowDefault'):(this.state.active === 'ym'?'active':'activeDefault')):'gray']} onClick={() => {this.selectList('ym','yimin')}}>移民</span></li>
                        <li><span className={style[this.state.getData.gongshang !== null?(this.state.getData.gongshang > 0?(this.state.active === 'gs'?'yellow':'yellowDefault'):(this.state.active === 'gs'?'active':'activeDefault')):'gray']} onClick={() => {this.selectList('gs','gongshang')}}>工商</span></li>
                        <li><span className={style[this.state.getData.minzheng !== null?(this.state.getData.minzheng > 0?(this.state.active === 'mz'?'yellow':'yellowDefault'):(this.state.active === 'mz'?'active':'activeDefault')):'gray']} onClick={() => {this.selectList('mz','minzheng')}}>民政</span></li>
                        <li><span className={style[this.state.getData.renshe !== null?(this.state.getData.renshe > 0?(this.state.active === 'rs'?'yellow':'yellowDefault'):(this.state.active === 'rs'?'active':'activeDefault')):'gray']} onClick={() => {this.selectList('rs','renshe')}}>人社</span></li>
                        <li><span className={style[this.state.getData.weiji !== null?(this.state.getData.weiji > 0?(this.state.active === 'wj'?'yellow':'yellowDefault'):(this.state.active === 'wj'?'active':'activeDefault')):'gray']} onClick={() => {this.selectList('wj','weiji')}}>卫计</span></li>
                        <li><span className={style[this.state.getData.jianshe !== null?(this.state.getData.jianshe > 0?(this.state.active === 'js'?'yellow':'yellowDefault'):(this.state.active === 'js'?'active':'activeDefault')):'gray']} onClick={() => {this.selectList('js','jianshe')}}>建设</span></li>
                        <li><span className={style[this.state.getData.guotu !== null?(this.state.getData.guotu > 0?(this.state.active === 'gt'?'yellow':'yellowDefault'):(this.state.active === 'gt'?'active':'activeDefault')):'gray']} onClick={() => {this.selectList('gt','guotu')}}>国土</span></li>
                    </ul>
                </div>
                {
                    (() => {
                        switch(this.state.active) {
                            case 'ga': return ga;break;
                            case 'jy': return jy;break;
                            case 'ym': return ym;break;
                            case 'gs': return gs;break;
                            case 'mz': return mz;break;
                            case 'rs': return rs;break;
                            case 'wj': return wj;break;
                            case 'js': return js;break;
                            case 'gt': return gt;break;
                            default: return ga;break;
                        }
                    })()
                }
            </div>
        )
    }
}

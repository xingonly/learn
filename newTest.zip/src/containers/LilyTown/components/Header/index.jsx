import React from "react";
import styles from './styles.scss';

const Header = ({ title }) => {
  return (
    <div className={styles.headerItem}>
      <img src={require('../../images/L.png')} />  
      <span className={styles.headerTitle}>{title}</span>
    </div>
  )
}

export default Header
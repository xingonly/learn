import React, {Component} from "react";
import styles from './styles.scss';
import { Tooltip, message, Modal } from 'antd';
import Select from 'components/MySelect';
import BigTitle from '../../../../components/BigTitle';
import Filter from '../../../../components/Filter';
import Title from '../../../../components/Title';
import Follow from '../../images/follow.png';
import UnFollow from '../../images/unFollow.png';
import Pagination from 'components/PaginationNoEnd';
import { convertQueryString } from 'utils';
import resource from '../../../../util/resource';
import Notice from '../../../../components/Notice';
import Man from '../../images/man.png';

const ths = [ 'one', 'two','姓名','残疾等级','残疾类型','是否就业','务工类型','监护人','薪酬情况(元)','贫困状态','three'];

export default class SupportCenterAsso extends Component {
    constructor(props) {
        super(props);
        this.state = {
            selectedPart: 'center',
            type: '贫困状态',
            typeCode: '',
            typeOption: [
                { value: '', label: '贫困状态' },
                { value: '0', label: '未脱贫' },
                { value: '1', label: '已脱贫' }
            ],
            work: '是否就业',
            workCode: '',
            workOption: [
                { value: '', label: '是否就业' },
                { value: '0', label: '未就业' },
                { value: '1', label: '已就业' }
            ],
            data: [],
            page: 1,
            pageSize: 7,
            total: 0,
            centerList: [],
            centerTotal: 0,
            //托养中心
            nursed_org: '',
            keyword: '',
            clear: false,
            visible: false
        }
    }
    componentDidMount() {
        this.requireTotalData();
        this.requireList();
    }

    requireTotalData = () => {
        resource.get(`/compare-server/disabled/v0.1/nursed_peoples/grouped_count?by=nursed_org`).then(res => {
            if(res.status !== 200) {
                Notice.error('', '网络异常');
            }else {
                let newRes = res.data.content;
                let centerList = [];
                let centerTotal = 0;
                for(let item of newRes) {
                    if(item.key !== '西秀区托养中心') {
                        centerTotal = centerTotal + item.count;
                        centerList.push(item);
                    }else {
                        centerTotal = centerTotal + item.count;
                    }
                }
                this.setState({
                    centerList: centerList,
                    centerTotal: centerTotal
                })
            }
        })
    }

    requireList = () => {
        let params = {
            nursed_org: this.state.nursed_org,
            nursed_is_employed: this.state.workCode,
            keyword: this.state.keyword,
            poor_status: this.state.typeCode,
            page: this.state.page,
            size: this.state.pageSize
        }
        resource.get(`/compare-server/disabled/v0.1/nursed_peoples${convertQueryString(params)}`).then(res => {
            if (res.status === 200) {
                this.setState({
                    data: res.data.content,
                    total: res.data.total
                })
            }else {
                Notice.error('', '网络异常');
            }
        })
    }

    handleLink = (num, status) => {
        if(status !== null) {
            let obj = {
                inputValue: num,
                region: {
                    shi: '',
                    xian: '',
                    xiang: '',
                    zheng: ''
                }
            }
            sessionStorage.setItem('keyWord', JSON.stringify(obj))
            this.props.history.push('/main/object/objectSearch');
        }else {
            this.showModal(num);
        }
    }
    renderAvatar = () => { }
    renderGender = gender => {
        switch (gender)
        {
            case 1: return '男'; break;
            case 2: return '女'; break;
            default: return '-'; break;
        }
    }
    renderStatus = status => {
        switch (status)
        {
            case 0: return <img src={require('../../images/poverty.png')} />;
            case 1: return <img src={require('../../images/outofpoverty.png')} />;
            default: return <img src={require('../../images/nopoverty.png')} />;
        }
    }
    // checkExit = (img) => {
    //   // ref={img => this.img = img} onError={() => this.img.src = '../../../images/man.png'}
    //   img.src = '../../../images/man.png';
    //   img.onerror = null;
    // }

    typeChange = (obj) => {
        let label = obj.label;
        let v = obj.value;
        this.setState({
            type: label,
            typeCode: v,
            page: 1
        }, () => {
            this.requireList();
        })
    };

    pageChange = page => {
        this.setState({
            page: page
        },() => {
            this.requireList()
        })
    };


    toggleFollow = (e, id) => {
        e.stopPropagation();
        console.log(e, id)
    };
    showFollow = t => {
        switch (t)
        {
            case t === 'FALSE': return Follow;
            default: return UnFollow
        }
    };
    onSubmit = data => {
        console.log('data', data);
        let v = data.value;
        this.setState({
            keyword: v,
            type: '贫困状态',
            typeCode: '',
            work: '是否就业',
            workCode: '',
        }, () => {
            this.requireList();
        })
    };
    changePart = (part, nursed_org) => {
        this.setState({
            selectedPart: part,
            nursed_org: nursed_org,
            type: '贫困状态',
            typeCode: '',
            work: '是否就业',
            workCode: '',
            page: 1,
            keyword: '',
            clear: true
        }, () => {
            this.setState({
               clear: false
            }, () => {
               this.requireList();
            });
        })
    };
    changeUrl = (e) =>{
        e.target.setAttribute('src',Man);
    };
    translateLevel = (level) => {
        if(level) {
            let levelArr = level.split(',');
            if(levelArr.length > 1) {
                let data = [];
                for(let item of levelArr) {
                    switch (item) {
                        case '1': data.push('一级'); break;
                        case '2': data.push('二级'); break;
                        case '3': data.push('三级'); break;
                        case '4': data.push('四级'); break;
                        default: data.push('-'); break;
                    }
                }
                return data.join(',');
            }else {
                switch (levelArr[0]) {
                    case '1': return '一级'; break;
                    case '2': return '二级'; break;
                    case '3': return '三级'; break;
                    case '4': return '四级'; break;
                    default: return '-'; break;
                }
            }
        }
    };
    translateEmployed = (employed) => {
        switch (employed) {
            case 0: return '未就业'; break;
            case 1: return '已就业'; break;
            default: return '-'; break;
        }
    };
    workChange = (obj) => {
        let label = obj.label;
        let v = obj.value;
        this.setState({
            work: label,
            workCode: v,
            page: 1
        }, () => {
            this.requireList();
        })
    };
    showModal = (num) => {
        this.getThirdRequire(num);
    };
    handleOk = (e) => {
        console.log(e);
        this.setState({
            visible: false,
        });
    };
    handleCancel = (e) => {
        console.log(e);
        this.setState({
            visible: false,
        });
    };
    getThirdRequire = (num) => {
        resource.get(`/xixiu-server/dataComparison/getThiredDetail?department=canlian&idnumber=${num}`).then((res) => {
            if(res.status !== 200) {
                console.log(res.message)
            }else {
                if(res.data) {
                    this.thirdData = res.data
                    this.setState({
                        thirdData: res.data,
                        visible: true,
                    })
                }else {
                    this.thirdData = ''
                    this.setState({
                        thirdData: '',
                        visible: true,
                    })
                }
            }
        })
    }
    translateGender = (num) => {
        switch(num) {
            case 1:return '男';break;
            case 2:return '女';break;
            case 9:return '未知';break;
            default:return '-';break;
        }
    }
    render() {
        return (
            <section className={styles['support-Center-Asso']}>
                <BigTitle title='托养中心联合体' />
                <div className={styles['content']}>
                    <div className={styles['left']}>
                        <header>
                            <Title name='联合机构' />
                        </header>
                        <div className={styles['svg-container']}>
                            <div className={styles['center-part']}>
                                <ul>
                                    <li>
                                        <span className={styles['font-black-color']}>{`${this.state.centerTotal}人`}</span>
                                    </li>
                                    <li style={{margin: '1rem 0 0 0'}}>
                                        <span onClick={() => this.changePart('center', '')} className={`${styles['center-span']} ${this.state.selectedPart === 'center'? styles['select-part-active']: null}`}>托养中心联合体</span>
                                    </li>
                                    <li>
                                        <span className={`${styles['line-one']} ${styles['line-common']}`}></span>
                                        <span className={`${styles['line-two']} ${styles['line-common']}`}></span>
                                        <span className={`${styles['line-three']} ${styles['line-common']}`}></span>
                                        <span className={`${styles['line-four']} ${styles['line-common']}`}></span>
                                        <span className={`${styles['line-five']} ${styles['line-common']}`}></span>
                                    </li>
                                    <li>
                                        <span onClick={() => this.changePart('partOne', this.state.centerList.length > 0? this.state.centerList[0].key: '')} className={`${styles['part-one']} ${styles['part-common']} ${this.state.selectedPart === 'partOne'? styles['select-part-active']: null}`}>
                                            <span>{this.state.centerList.length > 0? this.state.centerList[0].key: '--'}</span>
                                        </span>
                                        <span onClick={() => this.changePart('partTwo', this.state.centerList.length > 0? this.state.centerList[1].key: '')} className={`${styles['part-two']} ${styles['part-common']} ${this.state.selectedPart === 'partTwo'? styles['select-part-active']: null}`}>
                                            <span>{this.state.centerList.length > 0? this.state.centerList[1].key: '--'}</span>
                                        </span>
                                        <span onClick={() => this.changePart('partThree', this.state.centerList.length > 0? this.state.centerList[2].key: '')} className={`${styles['part-three']} ${styles['part-common']} ${this.state.selectedPart === 'partThree'? styles['select-part-active']: null}`}>
                                            <span>{this.state.centerList.length > 0? this.state.centerList[2].key: '--'}</span>
                                        </span>
                                        <span onClick={() => this.changePart('partFour', this.state.centerList.length > 0? this.state.centerList[3].key: '')} className={`${styles['part-four']} ${styles['part-common']} ${this.state.selectedPart === 'partFour'? styles['select-part-active']: null}`}>
                                            <span>{this.state.centerList.length > 0? this.state.centerList[3].key: '--'}</span>
                                        </span>
                                        <span onClick={() => this.changePart('partFive', this.state.centerList.length > 0? this.state.centerList[4].key: '')} className={`${styles['part-five']} ${styles['part-common']} ${this.state.selectedPart === 'partFive'? styles['select-part-active']: null}`}>
                                            <span>{this.state.centerList.length > 0? this.state.centerList[4].key: '--'}</span>
                                        </span>
                                    </li>
                                    <li>
                                        <span className={`${styles['part-num-one']} ${styles['part-num-common']}`}>{this.state.centerList.length > 0? this.state.centerList[0].count: '--'}</span>
                                        <span className={`${styles['part-num-two']} ${styles['part-num-common']}`}>{this.state.centerList.length > 0? this.state.centerList[1].count: '--'}</span>
                                        <span className={`${styles['part-num-three']} ${styles['part-num-common']}`}>{this.state.centerList.length > 0? this.state.centerList[2].count: '--'}</span>
                                        <span className={`${styles['part-num-four']} ${styles['part-num-common']}`}>{this.state.centerList.length > 0? this.state.centerList[3].count: '--'}</span>
                                        <span className={`${styles['part-num-five']} ${styles['part-num-common']}`}>{this.state.centerList.length > 0? this.state.centerList[4].count: '--'}</span>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div className={styles['right']}>
                        <Filter title='人员列表'
                                reset={this.state.clear}
                                onSubmit={this.onSubmit}
                        />
                        <div className={styles.tableBox}>
                            <div className={styles.thBox}>
                                {
                                    ths.map(ite => (
                                        ite !== '贫困状态'
                                            ?
                                            (
                                                ite !== '是否就业'
                                                    ?
                                                    <div className={styles.thItem} key={`ths_${ite}`}>{ite}</div>
                                                    :
                                                    <div className={styles.thItem} key={`ths_${ite}`} style={{textAlign: 'left'}}>
                                                        <Select
                                                            value={this.state.work}
                                                            options={this.state.workOption}
                                                            handleClick={this.workChange}
                                                            name="work"
                                                        />
                                                    </div>
                                            )
                                            : <div className={styles.thItem} key={`ths_${ite}`} style={{textAlign: 'left'}}>
                                                <Select
                                                    value={this.state.type}
                                                    options={this.state.typeOption}
                                                    handleClick={this.typeChange}
                                                    name="type"
                                                />
                                            </div>
                                    ))
                                }
                            </div>
                            <div className={styles.trBox}>
                                {
                                    this.state.data.map((ite, idx) => (
                                        <div key={ite.id} className={styles.trItem} onClick={() =>{this.handleLink(ite.idnumber, ite.poor_status)}}>
                                            <div className={styles.tdItem} />
                                            <div className={styles.tdItem}>
                                                <img
                                                    className={styles.avatar}
                                                    src={ite.portrait ? ite.portrait : require('../../images/man.png') }
                                                    onError={this.changeUrl}
                                                />
                                            </div>
                                            <div className={styles.tdItem}>{!!ite.full_name? ite.full_name: '--'}</div>
                                            <div className={styles.tdItem}>{this.translateLevel(ite.level)}</div>
                                            <div className={styles.tdItem}>{!!ite.type? ite.type: '--'}</div>
                                            <div className={styles.tdItem}>{this.translateEmployed(ite.nursed_is_employed)}</div>
                                            <div className={styles.tdItem}>{!!ite.nursed_employee_type? ite.nursed_employee_type: '--'}</div>
                                            <div className={styles.tdItem}>{!!ite.nursed_guardian? ite.nursed_guardian: '--'}</div>
                                            <div className={styles.tdItem}>{!!ite.nursed_salary? ite.nursed_salary: '--'}</div>
                                            <div className={styles.tdItem}>{this.renderStatus(ite.poor_status)}</div>
                                            {/*<div className={styles.tdItem}>*/}
                                                {/*<img*/}
                                                    {/*onClick={(e) => { this.toggleFollow(e, ite.id) }}*/}
                                                    {/*src={this.showFollow(ite.id)}*/}
                                                {/*/>*/}
                                            {/*</div>*/}
                                            <div className={styles.tdItem} />
                                        </div>
                                    ))
                                }
                            </div>
                        </div>
                        <div className={styles.footerBox}>
                            {
                                this.state.total > 10 && <Pagination
                                    start={1}
                                    size={this.state.pageSize}
                                    current={this.state.page}
                                    total={this.state.total}
                                    onChange={this.pageChange}
                                />
                            }
                        </div>
                    </div>
                </div>
                <Modal
                    title="残联信息"
                    visible={this.state.visible}
                    onOk={this.handleOk}
                    onCancel={this.handleCancel}
                    bodyStyle={{padding: '0 0 1rem 0'}}
                    footer={null}
                >
                    <div>
                        <div className={styles['fpb']} style={{marginTop: '1rem'}}>
                            <header className={styles['title']}>残联</header>
                            <ul className={styles['list-style']}>
                                <li>
                                    <span className={`text-overflow`} title={this.thirdData && this.thirdData.full_name || '-'}>姓名：{this.thirdData && this.thirdData.full_name || '-'}</span>
                                    <span className={`text-overflow`} title={this.thirdData && this.thirdData.type || '-'}>残疾类别：{this.thirdData && this.thirdData.type || '-'}</span>
                                </li>
                                <li>
                                    <span className={`text-overflow`} title={this.thirdData && this.thirdData.idnumber || '-'}>身份证号：{this.thirdData && this.thirdData.idnumber || '-'}</span>
                                    <span className={`text-overflow`} title={this.thirdData && this.translateLevel(this.thirdData.level) || '-'}>残疾等级：{this.thirdData && this.translateLevel(this.thirdData.level) || '-'}</span>
                                </li>
                                <li>
                                    <span className={`text-overflow`} title={this.thirdData && this.translateGender(this.thirdData.gender) || '-'} >性别：{this.thirdData && this.translateGender(this.thirdData.gender) || '-'}</span>
                                </li>
                                <li>
                                    <span className={`text-overflow`} title={this.thirdData && this.thirdData.address || '-'}>家庭住址：{this.thirdData && this.thirdData.address || '-'}</span>
                                </li>
                            </ul>
                        </div>
                        <div className={styles['fpb']}>
                            <header className={styles['title']} style={{width: '100%', textAlign: 'center'}}>就业培训信息</header>
                            <ul className={styles['list-style']}>
                                <li>
                                    <span className={`text-overflow`} title={this.thirdData && this.thirdData.work_status || '-'}>就业状况：{this.thirdData && this.thirdData.work_status || '-'}</span>
                                    <span className={`text-overflow`} title={this.thirdData && this.thirdData.work_address || '-'}>就业地区：{this.thirdData && this.thirdData.work_address || '-'}</span>
                                </li>
                                <li>
                                    <span className={`text-overflow`} title={this.thirdData && this.thirdData.work_begain_time || '-'}>起始时间：{this.thirdData && this.thirdData.work_begain_time || '-'}</span>
                                    <span className={`text-overflow`} title={this.thirdData && this.thirdData.work_end_time || '-'}>截止时间：{this.thirdData && this.thirdData.work_end_time || '-'}</span>
                                </li>
                            </ul>
                        </div>
                        <div className={styles['fpb']}>
                            <header className={styles['title']} style={{width: '100%', textAlign: 'center'}}>康复服务</header>
                            <ul className={styles['list-style']}>
                                <li>
                                    <span className={`text-overflow`} title={this.thirdData && this.thirdData.recovery_project || '-'}>康复项目：{this.thirdData && this.thirdData.recovery_project || '-'}</span>
                                    <span className={`text-overflow`} title={this.thirdData && this.thirdData.recovery_org || '-'}>康复机构：{this.thirdData && this.thirdData.recovery_org || '-'}</span>
                                </li>
                                <li>
                                    <span className={`text-overflow`} title={this.thirdData && this.thirdData.recovery_time || '-'}>康复时间：{this.thirdData && this.thirdData.recovery_time || '-'}</span>
                                </li>
                            </ul>
                        </div>
                        <div className={styles['fpb']}>
                            <header className={styles['title']} style={{width: '100%', textAlign: 'center'}}>托养中心联合体</header>
                            <ul className={styles['list-style']}>
                                <li>
                                    <span className={`text-overflow`} title={this.thirdData && this.thirdData.nursed_org || '-'}>托养中心名称：{this.thirdData && this.thirdData.nursed_org || '-'}</span>
                                    <span className={`text-overflow`} title={this.thirdData && this.thirdData.nursed_guardian || '-'}>监护人：{this.thirdData && this.thirdData.nursed_guardian || '-'}</span>
                                </li>
                                <li>
                                    <span className={`text-overflow`} title={this.thirdData && this.thirdData.nursed_subsidy || '-'}>补助情况：{this.thirdData && this.thirdData.nursed_subsidy || '-'}</span>
                                    <span className={`text-overflow`} title={this.thirdData && this.translateEmployed(this.thirdData.nursed_is_employed) || '-'}>是否就业：{this.thirdData && this.translateEmployed(this.thirdData.nursed_is_employed) || '-'}</span>
                                </li>
                                <li>
                                    <span className={`text-overflow`} title={this.thirdData && this.thirdData.nursed_employee_type || '-'}>务工类型：{this.thirdData && this.thirdData.nursed_employee_type || '-'}</span>
                                    <span className={`text-overflow`} title={this.thirdData && this.thirdData.nursed_salary || '-'}>薪酬情况：{this.thirdData && this.thirdData.nursed_salary || '-'}</span>
                                </li>
                            </ul>
                        </div>
                    </div>
                </Modal>
            </section>
        )
    }
}
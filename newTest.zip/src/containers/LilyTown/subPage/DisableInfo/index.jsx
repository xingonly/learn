import React, { Component } from "react"
import Header from '../../components/Header'
import LeftBox from './LeftBox'
import RightBox from './RightBox'
import styles from './styles.scss'

class DisableInfo extends Component {

    render() {
        return (
            <section id={styles['disableInfo']}>
                <div className={styles.container}>
                    <Header title="残疾人信息" />
                    <LeftBox />
                    <RightBox />
                </div>
            </section>
        )
    }
}

export default DisableInfo
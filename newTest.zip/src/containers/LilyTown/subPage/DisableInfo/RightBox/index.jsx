import React,{ Component } from 'react'
import { withRouter, Link } from 'react-router-dom'
import resource from 'resource'
import { Tooltip, Modal } from 'antd'
import Filter from 'components/Filter'
import Select from 'components/MySelect'
import Loading from 'components/Loading'
import NoData from 'components/noData'
import Pagination from 'components/PaginationNoEnd';
import { convertQueryString } from 'utils'
import Follow from '../../../images/follow.png'
import UnFollow from '../../../images/unFollow.png'
import Man from '../../../images/man.png'
import styles from './styles.scss'
import List from './list.json'

const ths = [ ' ', '姓名','性别','年龄','残疾类型','家庭住址','贫困状态']

class RightBox extends Component {
  constructor(props) {
    super(props)
    this.state = {
      loading: false,
      type: '贫困状态',
      typeOption: [
        { value: '', label: '贫困状态' },
        { value: '0', label: '未脱贫' },
        { value: '1', label: '已脱贫' }        
      ],
      data: [],
      page: 1,
      pageSize: 10,
      total: 0,
      code: '',
      keyword: '',
      status: '',
      clear: false // 需要重置Filter组件时用
    }
  }

  componentDidMount() {
    this.listRequire()
  }
  
  listRequire = () => {
    this.setState({
      loading: true
    })
    let params = {
      district_code: this.state.code,
      keyword: this.state.keyword,
      poor_status: this.state.status,
      page: this.state.page,
      size: 10
    }
    resource.get(`/compare-server/disabled/v0.1/peoples/${convertQueryString(params)}`).then(res => {
      if (res.status == 200) {
        this.setState({
          data: res.data.content,
          total: res.data.total,
          loading: false
        })
      } else {
        this.setState({
          loading: false
        })
      }
    }).catch(e => {
      this.setState({
        loading: false
      })
    })
  }

  handleLink = (num, status) => {
    if(status !== null) {
        let obj = {
            inputValue: num,
            region: {
                shi: '',
                xian: '',
                xiang: '',
                zheng: ''
            }
        }
        sessionStorage.setItem('keyWord', JSON.stringify(obj))
        this.props.history.push('/main/object/objectSearch');
    }else {
        this.showModal(num);
    }
  }
  showModal = (num) => {
      this.getThirdRequire(num);
  };
  getThirdRequire = (num) => {
      resource.get(`/xixiu-server/dataComparison/getThiredDetail?department=canlian&idnumber=${num}`).then((res) => {
          if(res.status !== 200) {
              console.log(res.message)
          }else {
              if(res.data) {
                  this.thirdData = res.data
                  this.setState({
                      thirdData: res.data,
                      visible: true,
                  })
              }else {
                  this.thirdData = ''
                  this.setState({
                      thirdData: '',
                      visible: true,
                  })
              }
          }
      })
  }
  renderAvatar = () => { }
  renderGender = gender => {
    switch (gender)
    {
      case 1: return '男'
      case 2: return '女'
      default: return '--'  
    }
   }
  renderStatus = status => {
    switch (status)
    {
      case 0: return <img src={require('../../../images/poverty.png')} />  
      case 1: return <img src={require('../../../images/outofpoverty.png')} />
      default: return <img src={require('../../../images/nopoverty.png')} />
    }
  }

  typeChange = v => {
    this.setState({
      status: v.value,
      type: v.label,
      page: 1,
      total: 0
    }, () => {
      this.listRequire()
    })
  }
  
  pageChange = page => {
    this.setState({
        page: page
    },() => {
        this.listRequire()
    })
}


  toggleFollow = (e, id) => {
    e.stopPropagation();
    console.log(e, id)
  }
  showFollow = t => {
    switch (t)
    {
      case t === 'FALSE': return Follow
      default: return UnFollow
    }
  }

  onSubmit = data => {
    this.setState({
      code: data.code,
      keyword: data.value,
      page: 1
    }, () => {
      this.listRequire()
    })
  }

  changeUrl = (e) =>{
		e.target.setAttribute('src',Man);
  }
  

  // 需要重置Filter组件时用
  clear = () => {
    this.setState({
      clear: true
    }, () => {
      this.setState({
        clear: false
      })
    })
  }

  translateGender = (num) => {
      switch(num) {
          case 1:return '男';break;
          case 2:return '女';break;
          case 9:return '未知';break;
          default:return '-';break;
      }
  }

  translateEmployed = (employed) => {
      switch (employed) {
          case 0: return '未就业'; break;
          case 1: return '已就业'; break;
          default: return '-'; break;
      }
  };

  translateLevel = (level) => {
      if(level) {
          let levelArr = level.split(',');
          if(levelArr.length > 1) {
              let data = [];
              for(let item of levelArr) {
                  switch (item) {
                      case '1': data.push('一级'); break;
                      case '2': data.push('二级'); break;
                      case '3': data.push('三级'); break;
                      case '4': data.push('四级'); break;
                      default: data.push('-'); break;
                  }
              }
              return data.join(',');
          }else {
              switch (levelArr[0]) {
                  case '1': return '一级'; break;
                  case '2': return '二级'; break;
                  case '3': return '三级'; break;
                  case '4': return '四级'; break;
                  default: return '-'; break;
              }
          }
      }
  };

  handleOk = (e) => {
      console.log(e);
      this.setState({
          visible: false,
      });
  };
  handleCancel = (e) => {
      console.log(e);
      this.setState({
          visible: false,
      });
  };

  render() {
    return (
      <div className={styles.rightContainer}>
        <Filter
          title='残疾人列表'
          // allowDate
          allowSelect
          onSubmit={this.onSubmit}
          // reset={this.state.clear}
        />
        {/* <span onClick={this.clear}>重置Filter值</span> */}
        <div className={styles.tableBox}>
          <div className={styles.thBox}>
            {
              ths.map(ite => (ite !== '贫困状态'
                ? <div className={styles.thItem} key={`ths_${ite}`}>{ite}</div>
                : <div className={styles.thItem} key={`ths_${ite}`} style={{textAlign: 'left'}}>
                  <Select
                    value={this.state.type}
                    options={this.state.typeOption}
                    handleClick={this.typeChange}
                    name="type"
                    />  
                </div>
              ))
            }
          </div>
          {
            this.state.loading ? <Loading /> : this.state.data.length
              ? <div className={styles.trBox}>
            {
                  this.state.data.map((ite, idx) => (
                <div key={ite.id} className={styles.trItem} onClick={() =>{this.handleLink(ite.idnumber, ite.poor_status)}}>
                  <div className={styles.tdItem} />
                  <div className={styles.tdItem}>
                    <img
                      className={styles.avatar}
                      src={ite.portrait ? ite.portrait : require('../../../images/man.png')}
                      onError={this.changeUrl}
                    />
                  </div>  
                  <div className={styles.tdItem}>{ite.full_name}</div>
                  <div className={styles.tdItem}>{this.renderGender(ite.gender)}</div>
                  <div className={styles.tdItem}>{ite.age}</div>
                  <div className={styles.tdItem +' '+ 'text-overflow'}>{ite.type}</div>
                  <Tooltip title={ite.address}>
                    <div className={styles.tdItem +' '+ 'text-overflow'}>{ite.address}</div>
                  </Tooltip>
                  <div className={styles.tdItem}>{this.renderStatus(ite.poor_status)}</div>
                  {/*<div className={styles.tdItem}>*/}
                    {/*<img*/}
                      {/*onClick={(e) => { this.toggleFollow(e, ite.id) }}*/}
                      {/*src={this.showFollow(ite.id)}*/}
                    {/*/>  */}
                  {/*</div>*/}
                   <div className={styles.tdItem} />
                  </div>  
                ))  
              }   
          </div> : <NoData />
          }
        </div>
        <div className={styles.footerBox}>
          {
            this.state.total > 10 && <Pagination
              start={1}
              size={this.state.pageSize}
              current={this.state.page}
              total={this.state.total}
              onChange={this.pageChange}
          />
          }
        </div>
        <Modal
            title="残联信息"
            visible={this.state.visible}
            onOk={this.handleOk}
            onCancel={this.handleCancel}
            bodyStyle={{padding: '0 0 1rem 0'}}
            footer={null}
        >
          <div>
            <div className={styles['fpb']} style={{marginTop: '1rem'}}>
              <header className={styles['title']}>残联</header>
              <ul className={styles['list-style']}>
                <li>
                  <span className={`text-overflow`} title={this.thirdData && this.thirdData.full_name || '-'}>姓名：{this.thirdData && this.thirdData.full_name || '-'}</span>
                  <span className={`text-overflow`} title={this.thirdData && this.thirdData.type || '-'}>残疾类别：{this.thirdData && this.thirdData.type || '-'}</span>
                </li>
                <li>
                  <span className={`text-overflow`} title={this.thirdData && this.thirdData.idnumber || '-'}>身份证号：{this.thirdData && this.thirdData.idnumber || '-'}</span>
                  <span className={`text-overflow`} title={this.thirdData && this.translateLevel(this.thirdData.level) || '-'}>残疾等级：{this.thirdData && this.translateLevel(this.thirdData.level) || '-'}</span>
                </li>
                <li>
                  <span className={`text-overflow`} title={this.thirdData && this.translateGender(this.thirdData.gender) || '-'} >性别：{this.thirdData && this.translateGender(this.thirdData.gender) || '-'}</span>
                </li>
                <li>
                  <span className={`text-overflow`} title={this.thirdData && this.thirdData.address || '-'}>家庭住址：{this.thirdData && this.thirdData.address || '-'}</span>
                </li>
              </ul>
            </div>
            <div className={styles['fpb']}>
              <header className={styles['title']} style={{width: '100%', textAlign: 'center'}}>就业培训信息</header>
              <ul className={styles['list-style']}>
                <li>
                  <span className={`text-overflow`} title={this.thirdData && this.thirdData.work_status || '-'}>就业状况：{this.thirdData && this.thirdData.work_status || '-'}</span>
                  <span className={`text-overflow`} title={this.thirdData && this.thirdData.work_address || '-'}>就业地区：{this.thirdData && this.thirdData.work_address || '-'}</span>
                </li>
                <li>
                  <span className={`text-overflow`} title={this.thirdData && this.thirdData.work_begain_time || '-'}>起始时间：{this.thirdData && this.thirdData.work_begain_time || '-'}</span>
                  <span className={`text-overflow`} title={this.thirdData && this.thirdData.work_end_time || '-'}>截止时间：{this.thirdData && this.thirdData.work_end_time || '-'}</span>
                </li>
              </ul>
            </div>
            <div className={styles['fpb']}>
              <header className={styles['title']} style={{width: '100%', textAlign: 'center'}}>康复服务</header>
              <ul className={styles['list-style']}>
                <li>
                  <span className={`text-overflow`} title={this.thirdData && this.thirdData.recovery_project || '-'}>康复项目：{this.thirdData && this.thirdData.recovery_project || '-'}</span>
                  <span className={`text-overflow`} title={this.thirdData && this.thirdData.recovery_org || '-'}>康复机构：{this.thirdData && this.thirdData.recovery_org || '-'}</span>
                </li>
                <li>
                  <span className={`text-overflow`} title={this.thirdData && this.thirdData.recovery_time || '-'}>康复时间：{this.thirdData && this.thirdData.recovery_time || '-'}</span>
                </li>
              </ul>
            </div>
            <div className={styles['fpb']}>
              <header className={styles['title']} style={{width: '100%', textAlign: 'center'}}>托养中心联合体</header>
              <ul className={styles['list-style']}>
                <li>
                  <span className={`text-overflow`} title={this.thirdData && this.thirdData.nursed_org || '-'}>托养中心名称：{this.thirdData && this.thirdData.nursed_org || '-'}</span>
                  <span className={`text-overflow`} title={this.thirdData && this.thirdData.nursed_guardian || '-'}>监护人：{this.thirdData && this.thirdData.nursed_guardian || '-'}</span>
                </li>
                <li>
                  <span className={`text-overflow`} title={this.thirdData && this.thirdData.nursed_subsidy || '-'}>补助情况：{this.thirdData && this.thirdData.nursed_subsidy || '-'}</span>
                  <span className={`text-overflow`} title={this.thirdData && this.translateEmployed(this.thirdData.nursed_is_employed) || '-'}>是否就业：{this.thirdData && this.translateEmployed(this.thirdData.nursed_is_employed) || '-'}</span>
                </li>
                <li>
                  <span className={`text-overflow`} title={this.thirdData && this.thirdData.nursed_employee_type || '-'}>务工类型：{this.thirdData && this.thirdData.nursed_employee_type || '-'}</span>
                  <span className={`text-overflow`} title={this.thirdData && this.thirdData.nursed_salary || '-'}>薪酬情况：{this.thirdData && this.thirdData.nursed_salary || '-'}</span>
                </li>
              </ul>
            </div>
          </div>
        </Modal>
      </div>
    )
  }
}

export default withRouter(RightBox)

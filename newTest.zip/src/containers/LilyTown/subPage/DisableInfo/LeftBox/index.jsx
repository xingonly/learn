import React,{ Component } from 'react'
import { withRouter } from 'react-router-dom'
import Title from 'components/Title'
import resource from 'resource'
import Pie from './subPage/Pie'
import Line from './subPage/Line'
import styles from './styles.scss'

class LeftBox extends Component {
  constructor(props) {
    super(props)
    this.state = {
      pieData: [],
      lineData: []
    }
  }
  componentDidMount() { 
    this.getPie()
    this.getLine()
  }
  
  getPie = () => {
    resource.get('/compare-server/disabled/v0.1/peoples/grouped_count?by=level').then(res => {
      if (res.status == 200)
      {
        this.setState({
          pieData: res.data.content
        })
      } else {
        console.log(res.message)
      }  
    })
   }
  getLine = () => {
    resource.get('/compare-server/disabled/v0.1/peoples/grouped_count?by=age').then(res => {
      if (res.status == 200)
      {
        this.setState({
          lineData: res.data.content
        })
      } else {
        console.log(res.message)
      }  
    })
  }
  render() {
    return (
      <div className={styles.leftContainer}>
        <Title name='情况统计' />
        <div className={styles.chartsBox}>
          <div className={styles.chartItem}>
          <Pie data={this.state.pieData} height="30rem" width="100%"/>  
          </div>
          <div className={styles.chartItem}>
          <Line data={this.state.lineData} height="30rem" width="100%"/>    
          </div>
        </div>
      </div>
    )
  }
}

export default withRouter(LeftBox)

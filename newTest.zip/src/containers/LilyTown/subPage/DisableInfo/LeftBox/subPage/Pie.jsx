import React, {Component} from 'react'
import echarts from 'echarts'

class Pie extends Component {
  constructor(props) {
    super(props);
    this.data = this.props.data || [];
    this.pieChart = null;
}

  componentDidMount() {
    this.drawPie();
    window.addEventListener('resize', this.pieChart.resize);
}
componentWillReceiveProps(props) {
    this.data = props.data;
    this.drawPie();
}
componentWillUpdate(){
    this.drawPie();
}

    transKey = key => {
        switch (key)
        {
            case '1': return '一'
            case '2': return '二'
            case '3': return '三'    
            case '4': return '四'
        }
    }

    drawPie = () => {
        let DATA = this.data
        let dataIn = []
        let dataOut = []
        for (let i = 0; i < DATA.length; i++)
        {
            let  ite = DATA[i]
            dataIn.push({ name: '', value: ite.count })
            dataOut.push({name: `${this.transKey(ite.key)}级`, value: ite.count})
        }    
        
    // let dataIn = [{ value: 30, name: '' }, { value: 70, name: '' }]
    // let dataOut = [{ value: 30, name: '一级' }, { value: 70, name: '二级' }]
    
    this.pieChart = echarts.init(this.refs.pie);
    // let colorOut = ["#63d9f2", "#dbecf8"];
    //     let colorIn = ["#54b8cd", "#bac8d3"];    
        let colorOut = ["#97e8f9" ,"#63d9f2", '#fddb3c', '#fcb700'];
        let colorIn = [ "#80c5d4", "#54b8cd", '#d7b933', '#d49c00'];       
    let option = {
      title: {
        "text": '残疾等级比例',
        "x": '39%',
        "y": '42%',
        textAlign: "center",
        "textStyle": {
            "fontWeight": 'normal',
            "fontSize": '1rem'
        }
    },
        tooltip: {
            trigger: 'item',
            formatter: "{a} <br/>{b}: {c} ({d}%)"
        },
        legend: {
            orient: 'vertical',
            right: '0',
            bottom: '20%',
            data: ['一级', '二级', '三级', '四级'],
            formatter:function(name){
                let oa = option.series[1].data;
                let colors = option.series[1].color;
                let num = 0;
                for(let i = 0; i < oa.length; i++){
                    num = num + oa[i].value;
                }
                for(let i = 0; i < oa.length; i++){
                    if(name === oa[i].name){
                        return name + '：' + (oa[i].value/num * 100).toFixed(2) + '%'
                    }
                }
            }
        },
        series: [
            { // 内环
                name:'',
                type:'pie',
                radius: ['20%', '30%'],
                center: ['40%', "45%"],
                hoverAnimation: false,
                legendHoverLink:false,
                avoidLabelOverlap: false,
                tooltip: {
                    show:false,
                },
                color: colorIn,
                label: {
                    normal: {
                        show: false,
                        position: 'center'
                    },
                    emphasis: {
                        show: false,
                    }
                },
                labelLine: {
                    normal: {
                        show: false
                    }
                },
                data: dataIn
            },
            {  // 外环
                name:'残疾等级比例',
                type:'pie',
                radius: ['30%', '40%'],
                center: [ '40%', "45%" ],
                avoidLabelOverlap: false,
                color: colorOut,
                label: {
                    normal: {
                        formatter: function(params, ticket, callback) {
                            var total = 0;
                            var percent = 0;

                            dataOut.forEach(function(value, index, array) {
                                total += value.value;
                            });
                            percent = ((params.value / total) * 100).toFixed(2);
                            return params.name + '：' + params.value;
                            // return `${params.name}`
                        },
                    },
                    // emphasis: {
                    //     show: false,
                    // }
                },
                labelLine: {
                    normal: {
                        show: true
                    }
                },
                data:dataOut
            }
        ]
    };
    this.pieChart.setOption( option );
}

render() {
  return (
      <div style={{width:this.props.width,height:this.props.height}} ref="pie"></div>
  )
}  
 }

export default Pie
import React, {Component} from 'react'
import echarts from 'echarts'

class Line extends Component {
  constructor(props) {
    super(props);
    this.data = this.props.data || []
    this.lineChart = null
}

  componentDidMount() {
    this.drawLine();
    window.addEventListener('resize', this.lineChart.resize);
}
componentWillReceiveProps(props) {
    this.data = props.data;
    this.drawLine();
}
componentWillUpdate(){
    this.drawLine();
}

    drawLine = () => {
        let DATA = this.data
        let X = []
        let arr = []
        for (let i = 0; i < DATA.length; i++)
        {
            let ite = DATA[i]
            X.push(ite.key)
            arr.push(ite.count)
        }    
    
    this.lineChart = echarts.init(this.refs.line);
    // let colorOut = ["#63d9f2", "#dbecf8"];
    // let colorIn = ["#54b8cd", "#bac8d3"];    
    let option = {
      backgroundColor:'#fff',
     title : {
         text: '年龄分布',
         x: 'center',
         y: '10'
     },
     tooltip : {
         trigger: 'axis'
     },
      grid: {
         // left: '3%',
         // right: '25%',
         top:'30%',
         // bottom: '30%',
         // containLabel: true
     },
     color:['rgba(216, 244, 247, 1)'],
     calculable : true,
     xAxis : [
         {
             type : 'category',
             boundaryGap : false,
             axisTick: {
                 show: false
             },
             axisLine: {
             lineStyle: {
                 color: '#ccc'
             }
         },
           data: X
         },
         
     ],
        yAxis: {
             name: '人数/个',
             type : 'value',
             splitLine: {
                 lineStyle: {
                     color: ['#d8d8d8']
                 }
             },
             axisTick: {
                 show: false
             },
             axisLine: {
             lineStyle: {
                 color: '#fff'
             }
         },
         axisLabel: {
             margin: 10,
             textStyle: {
                 fontSize: 14,
                 color: '#999'
             }
         },
         }
     ,
     series : [
         {
             name:'年龄分布',
             type:'line',
             areaStyle: {
                 normal: {type: 'default',
                     color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                         offset: 0,
                         color: 'rgba(216, 244, 247, 0.6)'
                     }, {
                         offset: 1,
                         color: 'rgba(216, 244, 247, 0.6)'
                     }], false)
                 }
             },
             lineStyle: {
                 normal: {
                     color: 'rgba(110, 186, 187, .8)'
                 }
             },
             smooth:true,
             itemStyle: {
                 normal: {areaStyle: {type: 'default'}}    
             },
            //  data:[210, 123, 312, 121,654, 500, 830, 710 ]
            data: arr 
         }
     ]
 };
    this.lineChart.setOption( option );
}

render() {
  return (
      <div style={{width:this.props.width,height:this.props.height}} ref="line"></div>
  )
}  
 }

export default Line
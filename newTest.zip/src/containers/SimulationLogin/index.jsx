// 上帝保佑,永无bug
import React, {Component} from "react"
import resource from '../../util/resource';

export default class Simulation extends Component {

    componentDidMount(){
        if(location.href.indexOf('from') !== -1){
            this.simulationLogin();
        }
    }


    //模拟登录
    simulationLogin = ()=>{
        let obj = this.resolveURL();
        let username=obj['principal'];
        let password =obj['credentials'] ;
        let from = obj['from'];
        resource.post('/welfare-user/security/tokenAuthen', {username,password,from}).then( (res) => {
            if (res.status === 200) {
                // 保存token
                sessionStorage.setItem('token', res.data.token);
                sessionStorage.setItem('username', res.data.user.username);
            }
        });
    }

    //URL解析
    resolveURL = ()=>{
        let data;
        let search = location.href.split('?')[1];
        if(!search) {
            return false;
        }
        let resData = {};
        if(search.indexOf('&') == -1) {
            data = search.split('=');
            resData[data[0].split('=')[0]] = data[0].split('=')[1]
        } else {
            data = search.split('&');
            for(let i = 0; i <data.length ; i++){
                resData[data[i].split('=')[0]] = data[i].split('=')[1]
            }
        }
        return resData;
    }

    render() {
        return (
            <div style={{height: '46rem', overflow: 'hidden'}}>

            </div>
        )
    }
}

import React,{Component} from 'react'
import style from './index.scss'
import Five from './images/Five.png'
import resource from '../../../../../util/resource'
import MySelect from '../../../../../components/MySelect';
import createHistory from 'history/createHashHistory';
import eventEmitter from '../../../../../util/eventEmitter';

const history = createHistory();
export default class ThirdData extends Component {
    constructor(props) {
        super(props);
        this.data = '';
        this.thirdData = '';
        this.diffsData = [];
        this.diffsContent = [];
        this.gongan = '';
        this.jiaoyu = '';
        this.canlian = '';
        this.renshe = '';
        this.jianshe = '';
        this.minzheng = '';
        this.guotu = '';
        this.gongshang = '';
        this.weiji = '';
        this.yimin = '';
        this.state = {
            active: this.translateNameReturn(this.props.name),
            marginLeft: '.6rem',
            idNumber: JSON.parse(sessionStorage.getItem('ID')).idnumber||'',
            fid: JSON.parse(sessionStorage.getItem('ID')).fid||'',
            data: '',
            thirdData: '',
            diffsData: [],
            getData: {},
            leftIcon: false,
            rightIcon: true,
        }
    }
    componentDidMount() {
        this.getRequire();
    }
    componentWillReceiveProps(props) {
        this.translateName(props.name)
    }
    translateName = (name) => {
        switch(name) {
            case 'gongan':this.setState({active: 'ga'});break;
            case 'jiaoyu':this.setState({active: 'jy'});break;
            case 'canlian': this.setState({active: 'cl'});break;
            case 'yimin':this.setState({active: 'ym'});break;
            case 'gongshang':this.setState({active: 'gs'});break;
            case 'minzheng':this.setState({active: 'mz'});break;
            case 'renshe':this.setState({active: 'rs'});break;
            case 'weiji':this.setState({active: 'wj'});break;
            case 'jianshe':this.setState({active: 'js'});break;
            case 'guotu':this.setState({active: 'gt'});break;
            default:this.setState({active: 'ga'});break;
        }
    }
    translateNameReturn = (name) => {
        switch(name) {
            case 'gongan':return 'ga';break;
            case 'jiaoyu':return 'jy';break;
            case 'canlian':return 'cl';break;
            case 'yimin':return 'ym';break;
            case 'gongshang':return 'gs';break;
            case 'minzheng':return 'mz';break;
            case 'renshe':return 'rs';break;
            case 'weiji':return 'wj';break;
            case 'jianshe':return 'js';break;
            case 'guotu':return 'gt';break;
            default:return 'ga';break;
        }
    }
    getRequire = () => {
        resource.get(`/compare-server/compare/v0.1/status?fid=${this.state.fid}`).then((res) => {
            if(res.status !== 200) {
                console.log(res.message)
            }else {
                let fpData = res.data;
                if(fpData.gongan !== null) {
                    this.setState({
                        active: 'ga',
                        getData: fpData
                    }, () => {
                        this.getDiffsRequire('gongan','first');
                    })
                }else if(fpData.jiaoyu !== null) {
                    this.setState({
                        active: 'jy',
                        getData: fpData
                    }, () => {
                        this.getDiffsRequire('jiaoyu','first');
                    })
                }else if(fpData.canlian !== null) {
                    this.setState({
                        active: 'cl',
                        getData: fpData
                    }, () => {
                        this.getDiffsRequire('canlian','first');
                    })
                }else if(fpData.yimin !== null) {
                    this.setState({
                        active: 'ym',
                        getData: fpData
                    }, () => {
                        this.getDiffsRequire('yimin','first');
                    })
                }else if(fpData.gongshang !== null) {
                    this.setState({
                        active: 'gs',
                        getData: fpData
                    }, () => {
                        this.getDiffsRequire('gongshang','first');
                    })
                }else if(fpData.minzheng !== null) {
                    this.setState({
                        active: 'mz',
                        getData: fpData
                    }, () => {
                        this.getDiffsRequire('minzheng','first');
                    })
                }else if(fpData.renshe !== null) {
                    this.setState({
                        active: 'rs',
                        getData: fpData
                    }, () => {
                        this.getDiffsRequire('renshe','first');
                    })
                }else if(fpData.weiji !== null) {
                    this.setState({
                        active: 'wj',
                        getData: fpData
                    }, () => {
                        this.getDiffsRequire('weiji','first');
                    })
                }else if(fpData.jianshe !== null) {
                    this.setState({
                        active: 'js',
                        getData: fpData
                    }, () => {
                        this.getDiffsRequire('jianshe','first');
                    })
                }else if(fpData.guotu !== null) {
                    this.setState({
                        active: 'gt',
                        getData: fpData
                    }, () => {
                        this.getDiffsRequire('guotu','first');
                    })
                }else {
                    this.setState({
                        active: 'ga',
                        getData: fpData
                    }, () => {
                        this.getDiffsRequire('gongan','first');
                    })
                }
            }
        })
    }
    getThirdRequire = (type) => {
        resource.get(`/xixiu-server/dataComparison/getThiredDetail?department=${type}&idnumber=${this.state.idNumber}`).then((res) => {
            if(res.status !== 200) {
                console.log(res.message)
            }else {
                if(res.data) {
                    this.thirdData = res.data
                    this.setState({
                        thirdData: res.data,
                    })
                }else {
                    this.thirdData = ''
                    this.setState({
                        thirdData: '',
                    })
                }
            }
        })
    }
    getDataRequire = (type) => {
        resource.get(`/xixiu-server/dataComparison/getData?department=${type}&idnumber=${this.state.idNumber}`).then((res) => {
            if(res.status !== 200) {
                console.log(res.message)
            }else {
                if(res.data) {
                    this.data = res.data
                    this.setState({
                        data: res.data,
                    })
                }else {
                    this.data = ''
                    this.setState({
                        data: '',
                    })
                }
            }
        })
    }
    getDiffsRequire = (type,first) => {
        resource.get(`/compare-server/compare/v0.1/diffs?fid=${this.state.fid}&deptCode=${type}`).then((res) => {
            if(res.status !== 200) {
                console.log(res.message)
            }else {
                if(res.data.content.length !== 0) {
                    let diffsContent = []
                    for(let ite of res.data.content) {
                        let data = {
                            value: ite.idnumber,
                            label: ite.full_name,
                        }
                        diffsContent.push(data)
                    }
                    this.diffsContent = diffsContent
                    let idNumber = this.state.idNumber
                    let c = res.data.content
                    for(let i=0;i<c.length;i++) {
                        if(c[i].idnumber === idNumber) {
                            this.diffsData = c[i].diffs
                            this[type] = c[i].full_name

                            if(!first) {
                                let obj = {
                                    fid: c[i].fid,
                                    id: c[i].peopleid,
                                    idnumber: c[i].idnumber
                                }
                                sessionStorage.setItem('ID',JSON.stringify(obj));
                                eventEmitter.emit('changeIdNumber', c[i].fid,c[i].peopleid,c[i].idnumber,'third');
                            }

                            this.setState({
                                idNumber: c[i].idnumber,
                                diffsData: c[i].diffs,
                            },() => {
                                this.getDataRequire(type)
                                this.getThirdRequire(type)
                            })
                            return false
                        }else if(i === c.length-1) {
                            this.diffsData = c[0].diffs
                            this[type] = c[0].full_name
                            this.setState({
                                diffsData: c[0].diffs,
                                idNumber: c[0].idnumber,
                            },() => {
                                this.getDataRequire(type)
                                this.getThirdRequire(type)
                            })
                        }
                    }
                }else {
                    this.diffsContent = []
                    this.diffsData = []
                    this.setState({
                        diffsData: '',
                    })
                }
            }
        })
    }
    selectList = (name,department) => {
        let getData = this.state.getData
        if(getData[department] !== null) {
            this.getDiffsRequire(department,'first')
            this.setState({
                active: name
            })
        }
    }
    scrollLeft = () => {
        this.setState({
            marginLeft: '.6rem',
            rightIcon: true,
            leftIcon: false
        })
    }
    scrollRight = () => {
        this.setState({
            marginLeft: '-12.6rem',
            rightIcon: false,
            leftIcon: true
        })
    }
    translateGender = (num) => {
        switch(num) {
            case 1:return '男';break;
            case 2:return '女';break;
            case 9:return '未知';break;
            default:return '-';break;
        }
    }
    translateSchoolSituation = (str) => {
        switch(str) {
            case '01':return '非在读';break;
            case '99':return '在读';break;
            default:return '-';break;
        }
    }
    translateTrueOrFalse = (b) => {
        switch(b) {
            case true:return '是';break;
            case false:return '否';break;
            default:return '-';break;
        }
    }
    translateGongShang = (num) => {
        switch(num) {
            case 0:return '未参加农民专业合作社、未参加其他';break;
            case 1:return '参加农民专业合作社、未参加其他';break;
            case 2:return '未参加农民专业合作社、参加其他';break;
            case 3:return '参加农民专业合作社、参加其他';break;
            default:return '-';break;
        }
    }
    translateYouFu = (num) => {
        switch(num) {
            case 0:return '否';break;
            case 1:return '是';break;
            default:return '-';break;
        }
    }
    translateCanBaoStatus = (num) => {
        switch(num) {
            case 0:return '终止参保';break;
            case 1:return '正常参保';break;
            default:return '-';break;
        }
    }
    translateLevel = (level) => {
        if(level) {
            let levelArr = level.split(',');
            if(levelArr.length > 1) {
                let data = [];
                for(let item of levelArr) {
                    switch (item) {
                        case '1': data.push('一级'); break;
                        case '2': data.push('二级'); break;
                        case '3': data.push('三级'); break;
                        case '4': data.push('四级'); break;
                        default: data.push('-'); break;
                    }
                }
                return data.join(',');
            }else {
                switch (levelArr[0]) {
                    case '1': return '一级'; break;
                    case '2': return '二级'; break;
                    case '3': return '三级'; break;
                    case '4': return '四级'; break;
                    default: return '-'; break;
                }
            }
        }
    };
    translateEmployed = (employed) => {
        switch (employed) {
            case 0: return '未就业'; break;
            case 1: return '已就业'; break;
            default: return '--'; break;
        }
    };
    diffs = (type) => {
        let diffsData = this.state.diffsData
        if(diffsData.length !== 0) {
            for(let item of diffsData) {
                switch(item) {
                    case type:return true;break;
                    default:break;
                }
            }
            return false
        }else {
            return false
        }
    }
    handleClickName = (obj,name) => {
        let value = obj.value;
        let label = obj.label;
        this[name] = label,
        this.setState({
            idNumber: value
        },() => {
            this.getDiffsRequire(name)
        })
    }
    jumpFull = () => {
        history.push('/main/thirdDataFull')
    }
    render() {
        let ga = <div>
            <div className={style['fpb']}>
                <header className={style['title']}>扶贫办
                    <div className={style['select']}>
                        <MySelect
                            value={this.gongan}
                            options={this.diffsContent}
                            handleClick={this.handleClickName}
                            name="gongan"
                        />
                    </div>
                </header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.data && this.data.full_name || '-'}>姓名：{this.data && this.data.full_name || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.data && this.data.idnumber || '-'} >身份证号：{this.data && this.data.idnumber || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('relationship')?style['bg']:null} text-overflow`} title={this.data && this.data.relationship || '-'} >与户主关系：{this.data && this.data.relationship || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('gender')?style['bg']:null} text-overflow`} title={this.data && this.data.gender || '-'} >性别：{this.data && this.data.gender || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('ethnic')?style['bg']:null} text-overflow`} title={this.data && this.data.ethnic || '-'} >民族：{this.data && this.data.ethnic || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('homeAddress')?style['bg']:null} text-overflow`} title={this.data && this.data.homeAddress || '-'} >家庭住址：{this.data && this.data.homeAddress || '-'}</span>
                    </li>
                </ul>
            </div>
            <div className={style['fpb']} style={{marginTop: '2.5rem'}}>
                <header className={style['title']}>公安厅</header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.full_name || '-'} >姓名：{this.thirdData && this.thirdData.full_name || '-'}</span>
                        <span className={`${this.diffs('car_except')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.car_except || '-'} >车型统计：{this.thirdData && this.thirdData.car_except || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.idnumber || '-'} >身份证号：{this.thirdData && this.thirdData.idnumber || '-'}</span>
                        <span className={`${this.diffs('car_status')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.car_status || '-'} >登记状态：{this.thirdData && this.thirdData.car_status || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('relationship')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.relationship || '-'} >与户主关系：{this.thirdData && this.thirdData.relationship || '-'}</span>
                        <span className={`${this.diffs('valid_date')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.valid_date || '-'} >领证日期：{this.thirdData && this.thirdData.valid_date || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('gender')?style['bg']:null} text-overflow`} title={this.translateGender(this.thirdData && this.thirdData.gender || 3)} >性别：{this.translateGender(this.thirdData && this.thirdData.gender || 3)}</span>
                        <span className={`${this.diffs('licensed_class')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.licensed_class || '-'} >驾驶登记：{this.thirdData && this.thirdData.licensed_class || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('ethnic')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.ethnic || '-'} >民族：{this.thirdData && this.thirdData.ethnic || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('district_code')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.district_code || '-'} >家庭住址：{this.thirdData && this.thirdData.district_code || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('first_record_date')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.first_record_date || '-'}>登记日期：{this.thirdData && this.thirdData.first_record_date || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('car_type')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.car_type || '-'} >车型：{this.thirdData && this.thirdData.car_type || '-'}</span>
                    </li>
                </ul>
            </div>
        </div>
        let jy = <div>
            <div className={style['fpb']}>
                <header className={style['title']}>扶贫办
                    <div className={style['select']}>
                        <MySelect
                            value={this.jiaoyu}
                            options={this.diffsContent}
                            handleClick={this.handleClickName}
                            name="jiaoyu"
                        />
                    </div>
                </header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.data && this.data.full_name || '-'} >姓名：{this.data && this.data.full_name || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.data && this.data.idnumber || '-'} >身份证号：{this.data && this.data.idnumber || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('schoolSituation')?style['bg']:null} text-overflow`} title={this.data && this.data.schoolSituation || '-'} >在校生情况：{this.data && this.data.schoolSituation || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('gender')?style['bg']:null} text-overflow`} title={this.data && this.data.gender || '-'} >性别：{this.data && this.data.gender || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('homeAddress')?style['bg']:null} text-overflow`} title={this.data && this.data.homeAddress || '-'} >家庭住址：{this.data && this.data.homeAddress || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('educationLevel')?style['bg']:null} text-overflow`} title={this.data && this.data.educationLevel || '-'} >文化程度：{this.data && this.data.educationLevel || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('dateOfBirth')?style['bg']:null} text-overflow`} title={this.data && this.data.dateOfBirth || '-'} >出生日期：{this.data && this.data.dateOfBirth || '-'}</span>
                    </li>
                </ul>
            </div>
            <div className={style['fpb']} style={{marginTop: '2.5rem'}}>
                <header className={style['title']}>教育厅</header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.full_name || '-'} >姓名：{this.thirdData && this.thirdData.full_name || '-'}</span>
                        <span className={`${this.diffs('isLocalProvince')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.isLocalProvince || '-'} >省内或省外就读：{this.thirdData && this.thirdData.isLocalProvince || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.idnumber || '-'} >身份证号：{this.thirdData && this.thirdData.idnumber || '-'}</span>
                        <span className={`${this.diffs('school')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.school || '-'} >就读学校及专业：{this.thirdData && this.thirdData.school || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('school_situation')?style['bg']:null} text-overflow`} title={this.translateSchoolSituation(this.thirdData && this.thirdData.school_situation || '00')}>在校生情况：{this.translateSchoolSituation(this.thirdData && this.thirdData.school_situation || '00')}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('gender')?style['bg']:null} text-overflow`} title={this.translateGender(this.thirdData && this.thirdData.gender || 3)}>性别：{this.translateGender(this.thirdData && this.thirdData.gender || 3)}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('district_code')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.district_code || '-'}>家庭住址：{this.thirdData && this.thirdData.district_code || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('rollID')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.rollID || '-'}>学籍号：{this.thirdData && this.thirdData.rollID || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('grade')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.grade || '-'}>就读年级：{this.thirdData && this.thirdData.grade || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('category')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.category || '-'}>资助类别：{this.thirdData && this.thirdData.category || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('fupin_total')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.fupin_total || '-'}>资助金额合计：{this.thirdData && this.thirdData.fupin_total || '-'}</span>
                    </li>
                </ul>
            </div>
        </div>
        let cl = <div>
            <div className={style['fpb']}>
                <header className={style['title']}>扶贫办
                    <div className={style['select']}>
                        <MySelect
                            value={this.canlian}
                            options={this.diffsContent}
                            handleClick={this.handleClickName}
                            name="canlian"
                        />
                    </div>
                </header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.data && this.data.full_name || '-'}>户主姓名：{this.data && this.data.full_name || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.data && this.data.idnumber || '-'}>身份证号：{this.data && this.data.idnumber || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('gender')?style['bg']:null} text-overflow`} title={this.data && this.data.gender || '-'} >性别：{this.data && this.data.gender || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('address')?style['bg']:null} text-overflow`} title={this.data && this.data.address || '-'}>家庭住址：{this.data && this.data.address || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('relationship')?style['bg']:null} text-overflow`} title={this.data && this.data.relationship || '-'} >与户主关系：{this.data && this.data.relationship || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('ethnic')?style['bg']:null} text-overflow`} title={this.data && this.data.ethnic || '-'} >民族：{this.data && this.data.ethnic || '-'}</span>
                    </li>
                </ul>
            </div>
            <div className={style['fpb']} style={{marginTop: '2.5rem'}}>
                <header className={style['title']}>残联</header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.full_name || '-'}>姓名：{this.thirdData && this.thirdData.full_name || '-'}</span>
                        <span className={`${this.diffs('type')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.type || '-'}>残疾类别：{this.thirdData && this.thirdData.type || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.idnumber || '-'}>身份证号：{this.thirdData && this.thirdData.idnumber || '-'}</span>
                        <span className={`${this.diffs('level')?style['bg']:null} text-overflow`} title={this.thirdData && this.translateLevel(this.thirdData.level) || '-'}>残疾等级：{this.thirdData && this.translateLevel(this.thirdData.level) || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('gender')?style['bg']:null} text-overflow`} title={this.thirdData && this.translateGender(this.thirdData.gender) || '-'} >性别：{this.thirdData && this.translateGender(this.thirdData.gender) || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('address')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.address || '-'}>家庭住址：{this.thirdData && this.thirdData.address || '-'}</span>
                    </li>
                </ul>
            </div>
            <div className={style['fpb']}>
                <header className={style['title']} style={{width: '100%', textAlign: 'center'}}>就业培训信息</header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('work_status')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.work_status || '-'}>就业状况：{this.thirdData && this.thirdData.work_status || '-'}</span>
                        <span className={`${this.diffs('work_address')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.work_address || '-'}>就业地区：{this.thirdData && this.thirdData.work_address || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('work_begain_time')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.work_begain_time || '-'}>起始时间：{this.thirdData && this.thirdData.work_begain_time || '-'}</span>
                        <span className={`${this.diffs('work_end_time')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.work_end_time || '-'}>截止时间：{this.thirdData && this.thirdData.work_end_time || '-'}</span>
                    </li>
                </ul>
            </div>
            <div className={style['fpb']}>
                <header className={style['title']} style={{width: '100%', textAlign: 'center'}}>康复服务</header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('recovery_project')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.recovery_project || '-'}>康复项目：{this.thirdData && this.thirdData.recovery_project || '-'}</span>
                        <span className={`${this.diffs('recovery_org')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.recovery_org || '-'}>康复机构：{this.thirdData && this.thirdData.recovery_org || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('recovery_time')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.recovery_time || '-'}>康复时间：{this.thirdData && this.thirdData.recovery_time || '-'}</span>
                    </li>
                </ul>
            </div>
            <div className={style['fpb']}>
                <header className={style['title']} style={{width: '100%', textAlign: 'center'}}>托养中心联合体</header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('nursed_org')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.nursed_org || '-'}>托养中心名称：{this.thirdData && this.thirdData.nursed_org || '-'}</span>
                        <span className={`${this.diffs('nursed_guardian')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.nursed_guardian || '-'}>监护人：{this.thirdData && this.thirdData.nursed_guardian || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('nursed_subsidy')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.nursed_subsidy || '-'}>补助情况：{this.thirdData && this.thirdData.nursed_subsidy || '-'}</span>
                        <span className={`${this.diffs('nursed_is_employed')?style['bg']:null} text-overflow`} title={this.thirdData && this.translateEmployed(this.thirdData.nursed_is_employed) || '-'}>是否就业：{this.thirdData && this.translateEmployed(this.thirdData.nursed_is_employed) || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('nursed_employee_type')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.nursed_employee_type || '-'}>务工类型：{this.thirdData && this.thirdData.nursed_employee_type || '-'}</span>
                        <span className={`${this.diffs('nursed_salary')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.nursed_salary || '-'}>薪酬情况：{this.thirdData && this.thirdData.nursed_salary || '-'}</span>
                    </li>
                </ul>
            </div>
        </div>
        let ym = <div>
            <div className={style['fpb']}>
                <header className={style['title']}>扶贫办
                    <div className={style['select']}>
                        <MySelect
                            value={this.yimin}
                            options={this.diffsContent}
                            handleClick={this.handleClickName}
                            name="yimin"
                        />
                    </div>
                </header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.data && this.data.full_name || '-'}>户主姓名：{this.data && this.data.full_name || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.data && this.data.idnumber || '-'}>身份证号：{this.data && this.data.idnumber || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('population')?style['bg']:null} text-overflow`} title={this.data && this.data.population || '-'}>户口人数：{this.data && this.data.population || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('original_location')?style['bg']:null} text-overflow`} title={this.data && this.data.original_location || '-'}>迁出地：{this.data && this.data.original_location || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('purpose_location')?style['bg']:null} text-overflow`} title={this.data && this.data.purpose_location || '-'}>迁入地：{this.data && this.data.purpose_location || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('place_location')?style['bg']:null} text-overflow`} title={this.data && this.data.place_location || '-'}>安置地：{this.data && this.data.place_location || '-'}</span>
                    </li>
                </ul>
            </div>
            <div className={style['fpb']} style={{marginTop: '2.5rem'}}>
                <header className={style['title']}>移民局</header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.full_name || '-'}>易地扶贫搬迁户户主姓名：{this.thirdData && this.thirdData.full_name || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.idnumber || '-'}>身份证号：{this.thirdData && this.thirdData.idnumber || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('population')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.population || '-'}>家庭成员人数：{this.thirdData && this.thirdData.population || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('out_address')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.out_address || '-'}>迁出地名称：{this.thirdData && this.thirdData.out_address || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('in_address')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.in_address || '-'}>迁入地：{this.thirdData && this.thirdData.in_address || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('place_location')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.place_location || '-'}>安置点名称：{this.thirdData && this.thirdData.place_location || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('people_number')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.people_number}>迁出地搬迁总人口：{this.thirdData && this.thirdData.people_number}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('house_of_group')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.house_of_group || '-'}>全组户数：{this.thirdData && this.thirdData.house_of_group || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('people_of_group')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.people_of_group || '-'}>全组人口：{this.thirdData && this.thirdData.people_of_group || '-'}</span>
                    </li>
                </ul>
            </div>
        </div>
        let gs = <div>
            <div className={style['fpb']}>
                <header className={style['title']}>扶贫办
                    <div className={style['select']}>
                        <MySelect
                            value={this.gongshang}
                            options={this.diffsContent}
                            handleClick={this.handleClickName}
                            name="gongshang"
                        />
                    </div>
                </header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.data && this.data.full_name || '-'}>姓名：{this.data && this.data.full_name || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.data && this.data.idnumber || '-'}>身份证号：{this.data && this.data.idnumber || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('farmersCooperative')?style['bg']:null} text-overflow`} title={this.translateTrueOrFalse(this.data && this.data.farmersCooperative || '-')}>是否加入农民专业合作社：{this.translateTrueOrFalse(this.data && this.data.farmersCooperative || '-')}</span>
                    </li>
                </ul>
            </div>
            <div className={style['fpb']} style={{marginTop: '2.5rem'}}>
                <header className={style['title']}>工商局</header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.full_name || '-'}>法人代表姓名：{this.thirdData && this.thirdData.full_name || '-'}</span>
                        <span className={`${this.diffs('djjg')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.djjg || '-'}>发照机关：{this.thirdData && this.thirdData.djjg || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.idnumber || '-'}>法定代表人身份证号：{this.thirdData && this.thirdData.idnumber || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('farmers_cooperative')?style['bg']:null} text-overflow`} title={this.translateGongShang(this.thirdData && this.thirdData.farmers_cooperative || 4)}>工商概要信息：{this.translateGongShang(this.thirdData && this.thirdData.farmers_cooperative || 4)}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('qymc')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.qymc || '-'}>公司名称：{this.thirdData && this.thirdData.qymc || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('zczb')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.zczb || '-'}>注册资金：{this.thirdData && this.thirdData.zczb || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('ybjyfw')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.ybjyfw || '-'}>经营范围：{this.thirdData && this.thirdData.ybjyfw || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('clrq')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.clrq || '-'}>注册时间：{this.thirdData && this.thirdData.clrq || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('djjgmc')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.djjgmc || '-'}>发照机关名称：{this.thirdData && this.thirdData.djjgmc || '-'}</span>
                    </li>
                </ul>
            </div>
        </div>
        let mz = <div>
            <div className={style['fpb']}>
                <header className={style['title']}>扶贫办
                    <div className={style['select']}>
                        <MySelect
                            value={this.minzheng}
                            options={this.diffsContent}
                            handleClick={this.handleClickName}
                            name="minzheng"
                        />
                    </div>
                </header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.data && this.data.full_name || '-'}>姓名：{this.data && this.data.full_name || '-'}</span>
                        <span className={`${this.diffs('doubleDaughter')?style['bg']:null} text-overflow`} title={this.translateTrueOrFalse(this.data && this.data.doubleDaughter || '-')}>是否双女户：{this.translateTrueOrFalse(this.data && this.data.doubleDaughter || '-')}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.data && this.data.idnumber || '-'}>身份证号：{this.data && this.data.idnumber || '-'}</span>
                        <span className={`${this.diffs('dateOfBirth')?style['bg']:null} text-overflow`} title={this.data && this.data.dateOfBirth || '-'}>出生日期：{this.data && this.data.dateOfBirth || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('povertyAttribute')?style['bg']:null} text-overflow`} title={this.translateTrueOrFalse(this.data && this.data.povertyAttribute || '-')}>贫困户属性：{this.translateTrueOrFalse(this.data && this.data.povertyAttribute || '-')}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('activeSoldier')?style['bg']:null} text-overflow`} title={this.translateTrueOrFalse(this.data && this.data.activeSoldier || '-')}>是否现役军人：{this.translateTrueOrFalse(this.data && this.data.activeSoldier || '-')}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('onlyChild')?style['bg']:null} text-overflow`} title={this.translateTrueOrFalse(this.data && this.data.onlyChild || '-')}>是否独生子女：{this.translateTrueOrFalse(this.data && this.data.onlyChild || '-')}</span>
                    </li>
                </ul>
            </div>
            <div className={style['fpb']} style={{marginTop: '2.5rem'}}>
                <header className={style['title']}>民政厅</header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.full_name || '-'}>姓名：{this.thirdData && this.thirdData.full_name || '-'}</span>
                        <span className={`${this.diffs('living_subsidies')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.living_subsidies || '-'}>优抚补助金额：{this.thirdData && this.thirdData.living_subsidies || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.idnumber || '-'}>身份证号：{this.thirdData && this.thirdData.idnumber || '-'}</span>
                        <span className={`${this.diffs('service_length')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.service_length || '-'}>服役年限：{this.thirdData && this.thirdData.service_length || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('is_youfu')?style['bg']:null} text-overflow`} title={this.translateYouFu(this.thirdData && this.thirdData.is_youfu || 2)}>是否享受抚恤补助：{this.translateYouFu(this.thirdData && this.thirdData.is_youfu || 2)}</span>
                        <span className={`${this.diffs('is_orphan')?style['bg']:null} text-overflow`} title={this.translateYouFu(this.thirdData && this.thirdData.is_orphan || 2)}>是否孤儿：{this.translateYouFu(this.thirdData && this.thirdData.is_orphan || 2)}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('is_low_security')?style['bg']:null} text-overflow`} title={this.translateYouFu(this.thirdData && this.thirdData.is_low_security || 2)}>是否为低保户：{this.translateYouFu(this.thirdData && this.thirdData.is_low_security || 2)}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('low_security_type')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.low_security_type || '-'}>低保类型：{this.thirdData && this.thirdData.low_security_type || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('low_security_amount')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.low_security_amount || '-'}>保障金额：{this.thirdData && this.thirdData.low_security_amount || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('youfu_type')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.youfu_type || '-'}>优抚类别：{this.thirdData && this.thirdData.youfu_type || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('disability_level')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.disability_level || '-'}>伤残等级：{this.thirdData && this.thirdData.disability_level || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('nature_disability')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.nature_disability || '-'}>伤残性质：{this.thirdData && this.thirdData.nature_disability || '-'}</span>
                    </li>
                </ul>
            </div>
        </div>
        let rs = <div>
            <div className={style['fpb']}>
                <header className={style['title']}>扶贫办
                    <div className={style['select']}>
                        <MySelect
                            value={this.renshe}
                            options={this.diffsContent}
                            handleClick={this.handleClickName}
                            name="renshe"
                        />
                    </div>
                </header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.data && this.data.full_name || '-'}>姓名：{this.data && this.data.full_name || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.data && this.data.idnumber || '-'}>身份证号：{this.data && this.data.idnumber || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('gender')?style['bg']:null} text-overflow`} title={this.data && this.data.gender || '-'}>性别：{this.data && this.data.gender || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('resident_pension')?style['bg']:null} text-overflow`} title={this.translateTrueOrFalse(this.data && this.data.resident_pension || '-')}>是否参加新型农村养老保险：{this.translateTrueOrFalse(this.data && this.data.resident_pension || '-')}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('laborAbility')?style['bg']:null} text-overflow`} title={this.data && this.data.laborAbility || '-'}>劳动技能：{this.data && this.data.laborAbility || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('workSituation')?style['bg']:null} text-overflow`} title={this.data && this.data.workSituation || '-'}>劳工情况：{this.data && this.data.workSituation || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('workTime')?style['bg']:null} text-overflow`} title={this.data && this.data.workTime || '-'}>务工时间：{this.data && this.data.workTime || '-'}</span>
                    </li>
                </ul>
            </div>
            <div className={style['fpb']} style={{marginTop: '2.5rem'}}>
                <header className={style['title']}>人社厅</header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.full_name || '-'}>姓名：{this.thirdData && this.thirdData.full_name || '-'}</span>
                        <span className={`${this.diffs('yb_start_stop_time')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.yb_start_stop_time || '-'}>医保缴费起止时间：{this.thirdData && this.thirdData.yb_start_stop_time || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.idnumber || '-'}>身份证号：{this.thirdData && this.thirdData.idnumber || '-'}</span>
                        <span className={`${this.diffs('yl_department')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.yl_department || '-'}>养老保险参保单位：{this.thirdData && this.thirdData.yl_department || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('ncms')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.ncms || '-'}>医保参保状态：{this.thirdData && this.thirdData.ncms || '-'}</span>
                        <span className={`${this.diffs('yl_place')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.yl_place || '-'}>养老保险参保地：{this.thirdData && this.thirdData.yl_place || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('resident_pension')?style['bg']:null} text-overflow`} title={this.translateCanBaoStatus(this.thirdData && this.thirdData.resident_pension || 2)}>养老保险状态：{this.translateCanBaoStatus(this.thirdData && this.thirdData.resident_pension || 2)}</span>
                        <span className={`${this.diffs('yl_insurance_type')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.yl_insurance_type || '-'}>养老保险险种类型：{this.thirdData && this.thirdData.yl_insurance_type || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('jiuye_certificate')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.jiuye_certificate || '-'}>就业创业证：{this.thirdData && this.thirdData.jiuye_certificate || '-'}</span>
                        <span className={`${this.diffs('yl_start_stop_time')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.yl_start_stop_time || '-'}>养老保险缴费起止时间：{this.thirdData && this.thirdData.yl_start_stop_time || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('office')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.office || '-'}>就业单位名称：{this.thirdData && this.thirdData.office || '-'}</span>
                        <span className={`${this.diffs('train_content')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.train_content || '-'}>培训内容：{this.thirdData && this.thirdData.train_content || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('yb_department')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.yb_department || '-'}>医保参保单位：{this.thirdData && this.thirdData.yb_department || '-'}</span>
                        <span className={`${this.diffs('train_school')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.train_school || '-'}>培训学校：{this.thirdData && this.thirdData.train_school || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('yb_place')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.yb_place || '-'}>医保参保地：{this.thirdData && this.thirdData.yb_place || '-'}</span>
                        <span className={`${this.diffs('graduation_mark')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.graduation_mark || '-'}>毕业标识：{this.thirdData && this.thirdData.graduation_mark || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('yb_insurance_type')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.yb_insurance_type || '-'}>医保险种类型：{this.thirdData && this.thirdData.yb_insurance_type || '-'}</span>
                    </li>
                </ul>
            </div>
        </div>
        let wj = <div>
            <div className={style['fpb']}>
                <header className={style['title']}>扶贫办
                    <div className={style['select']}>
                        <MySelect
                            value={this.weiji}
                            options={this.diffsContent}
                            handleClick={this.handleClickName}
                            name="weiji"
                        />
                    </div>
                </header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.data && this.data.full_name || '-'}>姓名：{this.data && this.data.full_name || '-'}</span>
                        <span className={`${this.diffs('otherCauses')?style['bg']:null} text-overflow`} title={this.data && this.data.otherCauses || '-'}>其他致贫原因：{this.data && this.data.otherCauses || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.data && this.data.idnumber || '-'}>身份证号：{this.data && this.data.idnumber || '-'}</span>
                        <span className={`${this.diffs('gender')?style['bg']:null} text-overflow`} title={this.data && this.data.gender || '-'}>性别：{this.data && this.data.gender || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('ncms')?style['bg']:null} text-overflow`} title={this.translateTrueOrFalse(this.data && this.data.ncms || '-')}>是否参加新型农村合作医疗：{this.translateTrueOrFalse(this.data && this.data.ncms || '-')}</span>
                        <span className={`${this.diffs('martyr')?style['bg']:null} text-overflow`} title={this.translateTrueOrFalse(this.data && this.data.martyr || '-')}>是否军烈属：{this.translateTrueOrFalse(this.data && this.data.martyr || '-')}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('onlyChild')?style['bg']:null} text-overflow`} title={this.translateTrueOrFalse(this.data && this.data.onlyChild || '-')}>是否独生子女：{this.translateTrueOrFalse(this.data && this.data.onlyChild || '-')}</span>
                        <span className={`${this.diffs('mainCauses')?style['bg']:null} text-overflow`} title={this.data && this.data.mainCauses || '-'}>主要致贫原因：{this.data && this.data.mainCauses || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('doubleDaughter')?style['bg']:null} text-overflow`} title={this.translateTrueOrFalse(this.data && this.data.doubleDaughter || '-')}>是否双女户：{this.translateTrueOrFalse(this.data && this.data.doubleDaughter || '-')}</span>
                        <span className={`${this.diffs('povertyAttribute')?style['bg']:null} text-overflow`} title={this.data && this.data.povertyAttribute || '-'}>贫困户属性：{this.data && this.data.povertyAttribute || '-'}</span>
                    </li>
                </ul>
            </div>
            <div className={style['fpb']} style={{marginTop: '2.5rem'}}>
                <header className={style['title']}>卫计委</header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.full_name || '-'}>姓名：{this.thirdData && this.thirdData.full_name || '-'}</span>
                        <span className={`${this.diffs('within_costs')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.within_costs || '-'}>保内费用：{this.thirdData && this.thirdData.within_costs || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.idnumber || '-'}>身份证号：{this.thirdData && this.thirdData.idnumber || '-'}</span>
                        <span className={`${this.diffs('amount_personal_pay')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.amount_personal_pay || '-'}>自付费用：{this.thirdData && this.thirdData.amount_personal_pay || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('ncms')?style['bg']:null} text-overflow`} title={this.translateYouFu(this.thirdData && this.thirdData.ncms || 2)}>是否参加新型农村合作医疗：{this.translateYouFu(this.thirdData && this.thirdData.ncms || 2)}</span>
                        <span className={`${this.diffs('amount_fund_compensation')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.amount_fund_compensation || '-'}>基金补偿金额：{this.thirdData && this.thirdData.amount_fund_compensation || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('only_child')?style['bg']:null} text-overflow`} title={this.translateYouFu(this.thirdData && this.thirdData.only_child || 2)}>是否独生子女：{this.translateYouFu(this.thirdData && this.thirdData.only_child || 2)}</span>
                        <span className={`${this.diffs('amount_civil_compensation')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.amount_civil_compensation || '-'}>民政补偿金额：{this.thirdData && this.thirdData.amount_civil_compensation || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('gender')?style['bg']:null} text-overflow`} title={this.translateGender(this.thirdData && this.thirdData.gender || 0)}>性别：{this.translateGender(this.thirdData && this.thirdData.gender || 0)}</span>
                        <span className={`${this.diffs('serious_illness_compensation')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.serious_illness_compensation || '-'}>大病商保补偿：{this.thirdData && this.thirdData.serious_illness_compensation || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('precise_properties')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.precise_properties || '-'}>精确属性：{this.thirdData && this.thirdData.precise_properties || '-'}</span>
                        <span className={`${this.diffs('family_planning_reduction_amount')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.family_planning_reduction_amount || '-'}>计生两户减免金额：{this.thirdData && this.thirdData.family_planning_reduction_amount || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('in_hospital_diagnosis_name')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.in_hospital_diagnosis_name || '-'}>入院诊断：{this.thirdData && this.thirdData.in_hospital_diagnosis_name || '-'}</span>
                        <span className={`${this.diffs('fiscal_out_amount')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.fiscal_out_amount || '-'}>财政兜底金额：{this.thirdData && this.thirdData.fiscal_out_amount || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('out_hospital_diagnosis_name')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.out_hospital_diagnosis_name || '-'}>出院诊断：{this.thirdData && this.thirdData.out_hospital_diagnosis_name || '-'}</span>
                        <span className={`${this.diffs('other_security_amount')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.other_security_amount || '-'}>其他保障金额：{this.thirdData && this.thirdData.other_security_amount || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('total_cost')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.total_cost || '-'}>总费用：{this.thirdData && this.thirdData.total_cost || '-'}</span>
                        <span className={`${this.diffs('medical_institutions_amount')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.medical_institutions_amount || '-'}>医疗机构承担金额：{this.thirdData && this.thirdData.medical_institutions_amount || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('single_disease_amount')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.single_disease_amount || '-'}>单病种费用金额：{this.thirdData && this.thirdData.single_disease_amount || '-'}</span>
                        <span className={`${this.diffs('double_daughter')?style['bg']:null} text-overflow`} title={this.translateYouFu(this.thirdData && this.thirdData.double_daughter || 2)}>是否双女户：{this.translateYouFu(this.thirdData && this.thirdData.double_daughter || 2)}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('poverty_attribute')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.poverty_attribute || '-'}>贫困户属性：{this.thirdData && this.thirdData.poverty_attribute || '-'}</span>
                    </li>
                </ul>
            </div>
        </div>
        let js = <div>
            <div className={style['fpb']}>
                <header className={style['title']}>扶贫办
                    <div className={style['select']}>
                        <MySelect
                            value={this.jianshe}
                            options={this.diffsContent}
                            handleClick={this.handleClickName}
                            name="jianshe"
                        />
                    </div>
                </header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.data && this.data.full_name || '-'}>户主姓名：{this.data && this.data.full_name || '-'}</span>
                        <span className={`${this.diffs('dangerous')?style['bg']:null} text-overflow`} title={this.translateTrueOrFalse(this.data && this.data.dangerous || '-')}>是否危房户：{this.translateTrueOrFalse(this.data && this.data.dangerous || '-')}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.data && this.data.idnumber || '-'}>身份证号：{this.data && this.data.idnumber || '-'}</span>
                        <span className={`${this.diffs('dangerType')?style['bg']:null} text-overflow`} title={this.data && this.data.dangerType || '-'}>危房级别：{this.data && this.data.dangerType || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('population')?style['bg']:null} text-overflow`} title={this.data && this.data.population || '-'}>户口总人数：{this.data && this.data.population || '-'}</span>
                        <span className={`${this.diffs('ethnic')?style['bg']:null} text-overflow`} title={this.data && this.data.ethnic || '-'}>民族：{this.data && this.data.ethnic || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('area')?style['bg']:null} text-overflow`} title={this.data && this.data.area || '-'}>住房面积：{this.data && this.data.area || '-'}</span>
                        <span className={`${this.diffs('povertyAttribute')?style['bg']:null} text-overflow`} title={this.data && this.data.povertyAttribute || '-'}>贫困户属性：{this.data && this.data.povertyAttribute || '-'}</span>
                    </li>
                </ul>
            </div>
            <div className={style['fpb']} style={{marginTop: '2.5rem'}}>
                <header className={style['title']}>建设厅</header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.full_name || '-'}>户主姓名：{this.thirdData && this.thirdData.full_name || '-'}</span>
                        <span className={`${this.diffs('after_transforming_house_property')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.after_transforming_house_property || '-'}>改造后房屋产权：{this.thirdData && this.thirdData.after_transforming_house_property || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.idnumber || '-'}>身份证号：{this.thirdData && this.thirdData.idnumber || '-'}</span>
                        <span className={`${this.diffs('years_included_plan')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.years_included_plan || '-'}>列入计划年度：{this.thirdData && this.thirdData.years_included_plan || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('population')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.population || '-'}>家庭人数：{this.thirdData && this.thirdData.population || '-'}</span>
                        <span className={`${this.diffs('is_accepted')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.is_accepted || '-'}>旧住房建造结构: {this.thirdData && this.thirdData.is_accepted || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('area')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.area || '-'}>改造后住房面积：{this.thirdData && this.thirdData.area || '-'}</span>
                        <span className={`${this.diffs('date_approval')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.date_approval || '-'}>批准日期：{this.thirdData && this.thirdData.date_approval || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('dangerous')?style['bg']:null} text-overflow`} title={this.translateYouFu(this.thirdData && this.thirdData.dangerous || 2)}>是否危房户：{this.translateYouFu(this.thirdData && this.thirdData.dangerous || 2)}</span>
                        <span className={`${this.diffs('start_date')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.start_date || '-'}>开工日期：{this.thirdData && this.thirdData.start_date || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('transformation_reason')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.transformation_reason || '-'}>改造原因：{this.thirdData && this.thirdData.transformation_reason || '-'}</span>
                        <span className={`${this.diffs('completion_date')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.completion_date || '-'}>竣工日期：{this.thirdData && this.thirdData.completion_date || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('ethnic')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.ethnic || '-'}>民族：{this.thirdData && this.thirdData.ethnic || '-'}</span>
                        <span className={`${this.diffs('assistance_fund_type')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.assistance_fund_type || '-'}>享受补助资金类型：{this.thirdData && this.thirdData.assistance_fund_type || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('is_disabled_family')?style['bg']:null} text-overflow`} title={this.translateYouFu(this.thirdData && this.thirdData.is_disabled_family || 2)}>是否贫困残疾家庭：{this.translateYouFu(this.thirdData && this.thirdData.is_disabled_family || 2)}</span>
                        <span className={`${this.diffs('total_investment')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.total_investment || '-'}>总投资：{this.thirdData && this.thirdData.total_investment || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('transformation_way')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.transformation_way || '-'}>改造方式：{this.thirdData && this.thirdData.transformation_way || '-'}</span>
                        <span className={`${this.diffs('government_subsidy_funds')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.government_subsidy_funds || '-'}>各级政府补助资金：{this.thirdData && this.thirdData.government_subsidy_funds || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('construction_mode')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.construction_mode || '-'}>建设方式：{this.thirdData && this.thirdData.construction_mode || '-'}</span>
                        <span className={`${this.diffs('farmers_raised_funds')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.farmers_raised_funds || '-'}>农户其他自筹资金：{this.thirdData && this.thirdData.farmers_raised_funds || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('house_area_after_transforming')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.house_area_after_transforming || '-'}>旧住房建造面积：{this.thirdData && this.thirdData.house_area_after_transforming || '-'}</span>
                        <span className={`${this.diffs('is_commercial_housing')?style['bg']:null} text-overflow`} title={this.translateYouFu(this.thirdData && this.thirdData.is_commercial_housing || 2)}>是否有商品房登记信息：{this.translateYouFu(this.thirdData && this.thirdData.is_commercial_housing || 2)}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('structure_after_transforming')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.structure_after_transforming || '-'}>改造后房屋结构：{this.thirdData && this.thirdData.structure_after_transforming || '-'}</span>
                        <span className={`${this.diffs('buyer')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.buyer || '-'}>产权人姓名：{this.thirdData && this.thirdData.buyer || '-'}</span>
                    </li>
                </ul>
            </div>
        </div>
        let gt = <div>
            <div className={style['fpb']}>
                <header className={style['title']}>扶贫办
                    <div className={style['select']}>
                        <MySelect
                            value={this.guotu}
                            options={this.diffsContent}
                            handleClick={this.handleClickName}
                            name="guotu"
                        />
                    </div>
                </header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.data && this.data.full_name || '-'}>姓名：{this.data && this.data.full_name || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.data && this.data.idnumber || '-'}>身份证号：{this.data && this.data.idnumber || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('gender')?style['bg']:null} text-overflow`} title={this.data && this.data.gender || '-'}>性别：{this.data && this.data.gender || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('ethnic')?style['bg']:null} text-overflow`} title={this.data && this.data.ethnic || '-'}>民族：{this.data && this.data.ethnic || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('homeAddress')?style['bg']:null} text-overflow`} title={this.data && this.data.homeAddress || '-'}>家庭住址：{this.data && this.data.homeAddress || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('relationship')?style['bg']:null} text-overflow`} title={this.data && this.data.relationship || '-'}>与户主关系：{this.data && this.data.relationship || '-'}</span>
                    </li>
                </ul>
            </div>
            <div className={style['fpb']} style={{marginTop: '2.5rem'}}>
                <header className={style['title']}>国土厅</header>
                <ul className={style['list-style']}>
                    <li>
                        <span className={`${this.diffs('full_name')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.full_name || '-'}>产权人姓名：{this.thirdData && this.thirdData.full_name || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('idnumber')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.idnumber || '-'}>身份证号：{this.thirdData && this.thirdData.idnumber || '-'}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('is_registered')?style['bg']:null} text-overflow`} title={this.translateYouFu(this.thirdData && this.thirdData.is_registered || 2)}>是否有房屋类不动产登记信息：{this.translateYouFu(this.thirdData && this.thirdData.is_registered || 2)}</span>
                    </li>
                    <li>
                        <span className={`${this.diffs('place')?style['bg']:null} text-overflow`} title={this.thirdData && this.thirdData.place || '-'}>房屋类不动产登记地：{this.thirdData && this.thirdData.place || '-'}</span>
                    </li>
                </ul>
            </div>
        </div>
        return (
            <div className={style['third-data']} >
                <header className={style['header']}>
                    <i></i>
                </header>
                <div className={style['nav']}>
                    <span className="iconfont" onClick={this.scrollLeft} style={{opacity: this.state.leftIcon?'1':'0'}}>&#xe601;</span>
                    <ul className={style['nav-list']}>
                        <li style={{marginLeft: this.state.marginLeft,transition: 'margin-left 1s'}}><span className={style[this.state.getData.gongan !== null?(this.state.getData.gongan > 0?(this.state.active === 'ga'?'yellow':'yellowDefault'):(this.state.active === 'ga'?'active':'activeDefault')):'gray']} onClick={() => {this.selectList('ga','gongan')}}>公安</span></li>
                        <li><span className={`${style[this.state.getData.jiaoyu !== null?(this.state.getData.jiaoyu > 0?(this.state.active === 'jy'?'yellow':'yellowDefault'):(this.state.active === 'jy'?'active':'activeDefault')):'gray']} ${style['jy']}`} onClick={() => {this.selectList('jy','jiaoyu')}}>教育{this.state.getData.student !== ''?<img src={Five} alt="" />:''}</span></li>
                        <li><span className={style[this.state.getData.canlian !== null?(this.state.getData.canlian > 0?(this.state.active === 'cl'?'yellow':'yellowDefault'):(this.state.active === 'cl'?'active':'activeDefault')):'gray']} onClick={() => {this.selectList('cl','canlian')}}>残联</span></li>
                        <li><span className={style[this.state.getData.yimin !== null?(this.state.getData.yimin > 0?(this.state.active === 'ym'?'yellow':'yellowDefault'):(this.state.active === 'ym'?'active':'activeDefault')):'gray']} onClick={() => {this.selectList('ym','yimin')}}>移民</span></li>
                        <li><span className={style[this.state.getData.gongshang !== null?(this.state.getData.gongshang > 0?(this.state.active === 'gs'?'yellow':'yellowDefault'):(this.state.active === 'gs'?'active':'activeDefault')):'gray']} onClick={() => {this.selectList('gs','gongshang')}}>工商</span></li>
                        <li><span className={style[this.state.getData.minzheng !== null?(this.state.getData.minzheng > 0?(this.state.active === 'mz'?'yellow':'yellowDefault'):(this.state.active === 'mz'?'active':'activeDefault')):'gray']} onClick={() => {this.selectList('mz','minzheng')}}>民政</span></li>
                        <li><span className={style[this.state.getData.renshe !== null?(this.state.getData.renshe > 0?(this.state.active === 'rs'?'yellow':'yellowDefault'):(this.state.active === 'rs'?'active':'activeDefault')):'gray']} onClick={() => {this.selectList('rs','renshe')}}>人社</span></li>
                        <li><span className={style[this.state.getData.weiji !== null?(this.state.getData.weiji > 0?(this.state.active === 'wj'?'yellow':'yellowDefault'):(this.state.active === 'wj'?'active':'activeDefault')):'gray']} onClick={() => {this.selectList('wj','weiji')}}>卫计</span></li>
                        <li><span className={style[this.state.getData.jianshe !== null?(this.state.getData.jianshe > 0?(this.state.active === 'js'?'yellow':'yellowDefault'):(this.state.active === 'js'?'active':'activeDefault')):'gray']} onClick={() => {this.selectList('js','jianshe')}}>建设</span></li>
                        <li><span className={style[this.state.getData.guotu !== null?(this.state.getData.guotu > 0?(this.state.active === 'gt'?'yellow':'yellowDefault'):(this.state.active === 'gt'?'active':'activeDefault')):'gray']} onClick={() => {this.selectList('gt','guotu')}}>国土</span></li>
                    </ul>
                    <span className="iconfont" onClick={this.scrollRight} style={{opacity: this.state.rightIcon?'1':'0'}}>&#xe600;</span>
                </div>
                {
                    (() => {
                       switch(this.state.active) {
                           case 'ga': return ga; break;
                           case 'jy': return jy; break;
                           case 'cl': return cl; break;
                           case 'ym': return ym; break;
                           case 'gs': return gs; break;
                           case 'mz': return mz; break;
                           case 'rs': return rs; break;
                           case 'wj': return wj; break;
                           case 'js': return js; break;
                           case 'gt': return gt; break;
                           default: return ga; break;
                       }
                    })()
                }
            </div>
        )
    }
}

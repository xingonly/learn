// 上帝保佑,永无bug
import React, {Component} from "react";
import eventEmitter from '../../../../util/eventEmitter'
import {Link,hashHistory} from 'react-router';
import style from './style.scss'
import Help from './Help/index';
import InfoDetail from './Detail/index';
import Product from './Product/index';
import FinancialCondition from './family/index';
import ThirdData from './ThirdData/index';

export default class InnerRight extends Component {
    constructor(props){
        super(props);
        this.open =false;
        this.name = '';
        this.state = {
            tab: 'xx'
        }
    }
    componentDidMount = () => {
        this.spreadWidth();
        let tab;
        eventEmitter.addListener('changeIdNumber', (a,b,c,d,e) => {
            tab = d == 'third'?'ds':'xx';
            if(e){
                this.name = e;
            }
            this.setState({
                tab: tab
            });
        });
        eventEmitter.addListener('changeDepartment', (name) => {
            this.name = name;
            this.setState({
                tab: 'ds'
            });
        });
    };

    setTabs = (data) =>{
        let tabState = this.state.tab;
        if(data !== tabState) {
            this.setState({
                tab: data
            }, () => {
                this.spreadWidth('SB');
            })
        }
    };

    spreadWidth = (data) => {
      const allowList = ['xx', 'sc', 'ds'];
      const tab = this.state.tab;
      let overflow = '';
      if(allowList.includes(tab))
      {
        overflow = 'overflow: auto;'
      }
        let cssText,sText;
        let width = this.refs.spreadWidth.clientWidth;
        if(data === 'SB'){
            cssText = ' border-right: none; border-left: 6px solid #fff;';
            sText = 'box-shadow:0 0 30px rgba(0, 0, 0, .3);width:33.1rem;padding-right: 2.15rem;opacity: 1;' + overflow;
            this.refs.spreadWidth.style.cssText = sText;
            this.refs.forEvent.style.right = '32.4rem';
            this.refs.trigger.style.cssText = cssText;
            this.open = true;
        }else{
            if(this.open) {
                cssText = ' border-right: 6px solid #fff; border-left: none;';
                sText = 'border: none;box-shadow: 0;width:0px;padding-right: 0px;opacity: 0;' + overflow;
                this.refs.spreadWidth.style.cssText = sText;
                this.refs.forEvent.style.right = '2.6rem';
                this.refs.trigger.style.cssText = cssText;
                this.open = false;
            }else{
                cssText = ' border-right: none; border-left: 6px solid #fff;';
                // sText = 'border: 1px solid  #0b5b6b;box-shadow: 0px 0px 25px 4px rgba(7, 169, 182, 0.2) inset; width: 33.1rem;padding-right: 2.15rem;opacity: 1;';
                sText = 'box-shadow:0 0 30px rgba(0, 0, 0, .3);; width: 33.1rem;padding-right: 2.15rem;opacity: 1;' + overflow;
                this.refs.spreadWidth.style.cssText = sText;
                this.refs.forEvent.style.right = '32.4rem';
                this.refs.trigger.style.cssText = cssText;
                this.open = true;
            }
        }
    }

    renderComponent = () => {
        switch (this.state.tab){
            case 'xx':
                return <InfoDetail />;
                break;
            case 'sc':
                return <Product />;
                break;
            case 'jt':
                return <FinancialCondition />;
                break;
            case 'bf':
                return <Help />;
                break;
            case 'ds':
                return <ThirdData name={this.name}/>;
                break;
            default :
                break;
        }
    };

    componentWillUnmount (){
        /*eventEmitter.removeListener('changeIdNumber', () => {
            this.setState({
                tab: 'xx'
            });
        });
        eventEmitter.removeListener('changeDepartment', () => {
            this.setState({
                tab: 'ds'
            });
        });*/
    }

    render() {
        return (
            <div className={style.innerRight}>
                <div className={style.newNavBox}>
                    <div className={style.newItem + ' ' + style[this.state.tab === 'xx'? 'active' : '']} onClick={()=>{this.setTabs('xx')}}>
                        <span>详细信息</span>
                    </div>
                    <div className={style.newItem + ' ' + style[this.state.tab === 'sc'? 'active' : '']}onClick={()=>{this.setTabs('sc')}}>
                        <span>生产生活条件</span>
                    </div>
                    <div className={style.newItem + ' ' + style[this.state.tab === 'jt'? 'active' : '']} onClick={()=>{this.setTabs('jt')}}>
                        <span>家庭经济状况</span>
                    </div>
                    <div className={style.newItem + ' ' + style[this.state.tab === 'bf'? 'active' : '']}onClick={()=>{this.setTabs('bf')}}>
                        <span>帮扶信息</span>
                    </div>
                    <div className={style.newItem + ' ' + style[this.state.tab === 'ds'? 'active' : '']} onClick={()=>{this.setTabs('ds')}}>
                        <span>第三方数据</span>
                    </div>
                </div>
                <div className={style.box}>
                    <div className={style.navBox}>
                        {/* <div className={this.state.tab === 'xx'? style.item + ' ' + style.one + ' '+ style.active:style.item + ' ' + style.one} onClick={()=>{this.setTabs('xx')}}>
                            <span>详细信息</span>
                        </div>
                        <div className={this.state.tab === 'sc'? style.item + ' ' + style.two + ' '+ style.active:style.item + ' ' + style.two} onClick={()=>{this.setTabs('sc')}}>
                            <span>生产生活条件</span>
                        </div>
                        <div className={this.state.tab === 'jt'? style.item + ' ' + style.thr + ' '+ style.active:style.item + ' ' + style.thr} onClick={()=>{this.setTabs('jt')}}>
                            <span>家庭经济状况</span>
                        </div>
                        <div className={this.state.tab === 'bf'? style.item + ' ' + style.four + ' '+ style.active:style.item + ' ' + style.four} onClick={()=>{this.setTabs('bf')}}>
                            <span>帮扶信息</span>
                        </div>
                        <div className={this.state.tab === 'ds'? style.item + ' ' + style.five + ' '+ style.active:style.item + ' ' + style.five} onClick={()=>{this.setTabs('ds')}}>
                            <span>第三方数据</span>
                        </div> */}
                        <div className={style.spread} ref="forEvent" onClick={this.spreadWidth}>
                            <span className={style.trigger} ref="trigger"></span>
                        </div>
                        <div className={style.containers} ref="spreadWidth">
                            {
                                this.renderComponent()
                            }
                            {/*<div className={style.bbs} style={{display: this.state.tab === 'xx' ? 'block':'none'}}>
                                <InfoDetail />
                            </div>
                            <div className={style.bbs} style={{display: this.state.tab === 'sc' ? 'block':'none'}}>
                                <Product />
                            </div>
                            <div className={style.bbds} style={{display: this.state.tab === 'jt' ? 'block':'none'}}>
                                <FinancialCondition />
                            </div>
                            <div className={style.bbs} style={{display: this.state.tab === 'bf' ? 'block':'none'}}>
                                <Help />
                            </div>
                            <div className={style.bbs} style={{display: this.state.tab === 'ds' ? 'block':'none'}}>
                                <ThirdData />
                            </div>*/}
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

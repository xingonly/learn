import React, {Component} from "react";
import resource from '../../../../../util/resource';
import d3 from 'd3';
import eventEmitter from '../../../../../util/eventEmitter';
import msk from '../images/msk.png'
import male from '../images/male.png'
import style from './style.scss'
import Export from '../images/export.gif'
import Title from 'components/Title'
import Tabs from 'components/Tabs'
import Table from 'components/Table'

const numMap = {
  0: '零',
  1: '一',
  2: '二',
  3: '三',
  4: '四',
  5: '五',
  6: '六',
  7: '七',
  8: '八',
  9: '九'
}

const formatDate = (d, type = 'second', split = ['-', ':']) => {
  if(!d)
  {
    return '--';
  }

  const date = new Date(d);
  const year = date.getFullYear();
  const month = date.getMonth() < 10 ? '0' + (date.getMonth() + 1) : (date.getMonth() + 1);
  const day = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
  const hour = date.getHours() < 10 ? '0' + date.getHours() : date.getHours();
  const minute = date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes();
  const second = date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds();

  switch (type) {
    case 'day':
      const splitStr = split[0] + '';
      return year + splitStr + month + splitStr + day;
    default:
    return year + split[0] + month + split[0] + day + ' ' + hour + split[1] + minute + split[1] + second;
  }
}

const translateNumToCN = (num) => {
  if(num < 10)
  {
    return numMap[num];
  }

  if(num === 10)
  {
    return '十';
  }

  if(num < 20)
  {
    num = (num + '');
    return '十' + (num[1] != '0' ? numMap[num[1]] : '');
  }

  if(num < 100)
  {
    num = (num + '');
    return numMap[num[0]] + '十' + (num[1] != '0' ? numMap[num[1]] : '');
  }
}

const columns = [
  {label: '操作情况', filter: (item) => {
    return item.operator + '：' + item.operation;
  }},
  {label: '说明情况', filter: (item) => {
    return item.remark || '--'
  }},
  {label: '操作时间', filter: (item) => {
    return formatDate(item.operateTime);
  }}
];

export default class InfoDetail extends Component {
    constructor(props){
        super(props);
        this.changeIdNumberFunc = null;
        this.state = {
            peopleInfo:{

            },
            poorReasons:{
                mainCauses: "",
                otherCauses: ""
            },
            peopleId: "",
            familyId: "",
            requireList: [],
            operateList: []
        }
    }

    initData = (idCard) => {
      resource.get(`/xixiu-server/require/listByFid/${idCard}`).then((res) => {
        this.setState({
          requireList: (res.data && res.data.content || []).map((item, index) => ({
            id: item.id,
            text: '需求' + translateNumToCN(index + 1)
          }))
        });
      });
    }

    initOperateData = (id) => {
      resource.get(`/xixiu-server/require/operates/${id}`).then((res) => {
        this.setState({
          operateList: res.data || []
        });
      });
    }

    onTabChange = (item) => {
      this.initOperateData(item.id);
    }

    /*componentWillUnmount(){
     //eventEmitter.removeListener(this.changeIdNumberFunc);

     }*/

    componentDidMount(){
        this.changeIdNumberFunc = eventEmitter.addListener('changeIdNumber', ( fid, id, idnumber ) => {
            if( fid && id ){
                this.loadPage( fid, id );
            }

            if(fid)
            {
              this.initData(fid);
            }
        });

        let ss = JSON.parse( sessionStorage.getItem( "ID" ) );

        if( ss && ss.fid && ss.id ){
            this.loadPage( ss.fid, ss.id );
        }

        if(ss && ss.fid)
        {
          this.initData(ss.fid);
        }
    }

    loadPage = ( fid, id )=>{
        this.setState({
            peopleId: id,
            familyId: fid
        },function(){
            this.getInfo();
            this.getPoorReasions();
            this.getGraphData();
        });
    }

    getGraphData = ()=> {
        let params = { fid: this.state.familyId }
        resource.get( `/xixiu-server/welfareshow/getPoorFamilyMemberApp/${params.fid}` ).then( ( res ) =>{
            if(res.data){
                let data = {};
                data.origin = {};
                data.relations = [];

                for( let i=0; i<res.data.length; i++ ){
                    if( res.data[i].relationship === "户主" ){
                        data.origin = res.data[i];
                    }else{
                        data.relations.push( res.data[i] );
                    }
                }

                this.drawGraph( data );
            }
        });
    }

    getInfo = () =>{
        let params = { fid: this.state.peopleId }
        resource.get( `/xixiu-server/welfare/getPoorFamilyAllInfo/${params.fid}` ).then( ( res ) =>{
            this.setState({
                peopleInfo: res.data
            });
        });
    }
    getPoorReasions = () =>{
        let params = { id: this.state.familyId }
        resource.get( `/xixiu-server/poorFamilyInfo/getPoorFamilyPoorCauses/${params.id}` ).then( ( res ) =>{
            this.setState({
                poorReasons: res.data
            });
        });
    }

    drawGraph = ( data )=>{
        let this_ = this;

        let container = document.getElementById( "graphChart" );
        let originPoint = { x: container.clientWidth/2, y: container.clientHeight/2 };
        let radius  = originPoint.x > originPoint.y ? originPoint.y : originPoint.x;
        let itemRadius = 20;
        let labelSize = 12;
        let radiusReduce = 20;

        d3.select("#graphChart").select("svg").remove();
        let svg = d3.select("#graphChart").append("svg")
            .attr( "width", container.clientWidth )
            .attr( "height", container.clientHeight );

        function drawLine() {
            let splitNum = 360 / data.relations.length;
            svg.selectAll( "line" )
                .data( data.relations )
                .enter()
                .append( "line" )
                .attr( "x1", originPoint.x )
                .attr( "y1", originPoint.y )
                .attr( "x2", function( d, i ){
                    return  radius + Math.sin( i*splitNum/180*Math.PI )*(radius-itemRadius-1 - radiusReduce)
                })
                .attr( "y2", function( d, i ){
                    return  radius + Math.cos( i*splitNum/180*Math.PI )*(radius-itemRadius-1 - radiusReduce)
                })
                .attr( "stroke-dasharray", "2,2" )
                .attr( "stroke-width", "2" )
                .attr( "stroke", "#027e80" );
        }

        function drawPartPoint(){
            let splitNum = 360 / data.relations.length;

            let react_g = svg.append('g').attr( "class", "image-g" );

            let itemsDefsImg = react_g.selectAll( "defs" )
                .data( data.relations )
                .enter()
                .append( "defs" )
                .append( "pattern" )
                .attr( "width", "100%" )
                .attr( "height", "100%" )
                .attr( "patternContentUnits", "objectBoundingBox" )
                .attr( "id", function( d, i ){  return "item_defs"+i })
                .append( 'image' )
                .attr( "preserveAspectRatio", "none" )
                .attr( "width", "1" )
                .attr( "height", "1" );


            let headImgs = react_g.selectAll('.head-img')
                .data( data.relations )
                .enter()
                .append( "circle" )
                .attr( "cx", originPoint.x )
                .attr( "cy", originPoint.y )
                .attr( "class", function( d, i ){
                    if( d.data_status == 1 ){
                        return "head-img indeterminacy"
                    }else{
                        return "head-img"
                    }
                })
                .attr( "r", 20 )
                .attr( "fill", function( d, i ){ return "url(#item_defs"+i+")"  } );

            headImgs.transition()
                .duration(750)
                .attr( "cx", function( d, i ){
                    return  (radius) + Math.sin( i*splitNum/180*Math.PI )*(radius-itemRadius-1 - radiusReduce )
                })
                .attr( "cy", function( d, i ){
                    return  (radius) + Math.cos( i*splitNum/180*Math.PI )*(radius-itemRadius-1 - radiusReduce)
                })

            //马赛克
            let mskImgs = react_g.selectAll( ".msk" )
                .data( data.relations )
                .enter()
                .append( "image" )
                .attr( "x", originPoint.x-itemRadius )
                .attr( "y", originPoint.y-itemRadius )
                /*.attr( "x", function( d, i ){
                    return  (radius-itemRadius) + Math.sin( i*splitNum/180*Math.PI )*(radius-itemRadius-1 - radiusReduce )
                 })
                 .attr( "y", function( d, i ){
                     return  (radius-itemRadius) + Math.cos( i*splitNum/180*Math.PI )*(radius-itemRadius-1 - radiusReduce)
                 })*/
                .attr( "class", "msk" )
                .attr( "width", 40 )
                .attr( "height", 40 )
                //.attr( "xlink:href", msk )
                .on( "click", function( d, i ){
                    eventEmitter.emit( 'changeIdNumber', null, null, d.idnumber )
                });

            mskImgs.transition()
                .duration(750)
                .attr( "x", function( d, i ){
                    return  (radius-itemRadius) + Math.sin( i*splitNum/180*Math.PI )*(radius-itemRadius-1 - radiusReduce )
                })
                .attr( "y", function( d, i ){
                    return  (radius-itemRadius) + Math.cos( i*splitNum/180*Math.PI )*(radius-itemRadius-1 - radiusReduce)
                })

            itemsDefsImg.attr( "xlink:href", function( d, i ){
                let image = new Image;
                let src ;
                image.src = d.headurl;
                image.onload = ()=>{
                    this.setAttribute( "href", image.src )
                }

                image.onerror = ()=>{
                    mskImgs[0][i].setAttribute( "opacity", 0 );
                    this.setAttribute( "href", male )
                }
            })

            let textBaseOffset = 14*3;
            let labels =  react_g.selectAll( "text" )
                .data( data.relations )
                .enter()
                .append( "text" )
                .text( function( d, i ){
                    return d.relationship + ' : ' + this_.formatterName ( d.fullName )
                })
                .attr( "x",function( d, i ) { return  originPoint.x - (textBaseOffset+d.fullName.length*labelSize)/2 })
                .attr( "y", originPoint.y + labelSize*4/3+itemRadius )
                /*.attr( "x", function( d, i ){
                 return  radius + Math.sin( i*splitNum/180*Math.PI )*(radius-itemRadius-1 - radiusReduce) - (textBaseOffset+d.fullName.length*labelSize)/2
                 })
                 .attr( "y", function( d, i ){
                 return  radius + Math.cos( i*splitNum/180*Math.PI )*(radius-itemRadius-1 - radiusReduce) + labelSize*4/3+itemRadius
                 })*/
                .attr( "fill", "#000" )
                .attr( "font-size", labelSize );

            labels.transition()
                .duration(750)
                .attr( "x", function( d, i ){
                    return  radius + Math.sin( i*splitNum/180*Math.PI )*(radius-itemRadius-1 - radiusReduce) - (textBaseOffset+d.fullName.length*labelSize)/2
                })
                .attr( "y", function( d, i ){
                    return  radius + Math.cos( i*splitNum/180*Math.PI )*(radius-itemRadius-1 - radiusReduce) + labelSize*4/3+itemRadius
                })
        }

        function drawOriginPoint() {
            let img_defs = svg.append("defs")
                .append( "pattern" )
                .attr( "width", "100%" )
                .attr( "height", "100%" )
                .attr( "patternContentUnits", "objectBoundingBox" )
                .attr( "id", "origin_img" );

            let origin_img = img_defs.append( 'image' )
            //.attr( "xlink:href", data.origin.headurl )
                .attr( "preserveAspectRatio", "none" )
                .attr( "width", "1" )
                .attr( "height", "1" );


            let img = new Image;
            img.src = data.origin.headurl;
            img.onload = ()=>{
                origin_img.attr( "href", img.src )
            }
            img.onerror = ()=>{
                origin_img.attr( "href", male );
                msk.attr( "opacity", 0 );
            };

            svg.append( 'circle' )
                .attr('data-pp','lf')
                .attr( "cx", originPoint.x )
                .attr( "cy", originPoint.y )
                .attr( "r", 20 )
                .attr( "class", function( d, i ){
                    if( data.origin.data_status == 1 ){
                        return "head-img indeterminacy"
                    }else{
                        return "head-img"
                    }
                })
                .attr( "fill", "url(#origin_img)")
                .on( "click", function(){
                    eventEmitter.emit( 'changeIdNumber', null, null, data.origin.idnumber )
                });

            let textBaseOffset = 14*3;
            svg.append( "text" )
                .text( data.origin.relationship + ' : ' + this_.formatterName( data.origin.fullName ) )
                .attr( "x", originPoint.x -labelSize - (textBaseOffset+data.origin.fullName.length)/2 )
                .attr( "y", originPoint.y +labelSize*4/3+itemRadius)
                .attr( "fill", "#000" )
                .attr( "font-size", labelSize );
        }

        drawLine();
        drawPartPoint();
        drawOriginPoint();
    }

    formatterName = (name)=>{
        if( name ){
            /*let str = name.split("");
            str[ str.length-1 ] = "*";
            return str.join( "" )*/
            return name;
        }else{
            return "-"
        }

    }

    formatterID = ( id )=>{
        if( id ){
            /*let str = id.split("");
            str.splice( str.length-8, 4, "****" )
            return str*/
            return id;
        }else{
            return "-"
        }
    }

    formatterAccount = ( account )=>{
        if( account ){
            /*let str = account.split("");
            str.splice( str.length-8, 8, "********" )
            return str*/
            return account;
        }else{
            return "-"
        }
    }

    formatterPhone = ( phone ) =>{
        if( phone ){
            /*let str = phone.split("");
             str.splice( str.length-4, 4, "****" )
             return str*/
            return phone;
        }else{
            return "-"
        }
    }

    formatterBirth = ( birth ) =>{
        if( birth ){
            /*let str = birth.split("");
            str.splice( str.length-4, 4, "****" )
            return str*/
            return birth;
        }else{
            return "-"
        }
    };

    download = () => {
        window.open(`https://42.123.99.59:13000/support-server/wordfile/downloadtmp?idnumber=${this.state.peopleInfo.idnumber}`);
    };

    render() {
      const { requireList, operateList } = this.state;
        return  (
            <div id={style['infoDetail']}>
                <div className={style['infoDetail-top']}>
                    <div className={style.attention}>
                        {/*<a href={`https://42.123.99.59:13000/support-server/wordfile/downloadtmp?idnumber=${this.state.peopleInfo.idnumber}`} download={this.state.peopleInfo.fullName}>
                            导出<img src={Export}/>
                        </a>*/}
                        {/*<i className={style.follow}></i>*/}
                        {/*<button onClick={this.download}>导出<img src={Export}/></button>*/}
                    </div>
                    <div className={style.panel}>
                        {/*
                          <div className={style['panel-title']}>
                              <div className={style['title-body']}>
                                  <span className={style.border + ' '+style['top-left']}></span>
                                  <span className={style.border + ' '+style['bottom-right']}></span>
                                  <span className={style.border + ' '+style.left}></span>
                                  <span className={style.border + ' '+style.right}></span>
                                  <span className={style.content}>基本信息</span>
                              </div>
                          </div>
                        */}
                       <Title name="基本信息" />
                        <div className={style['panel-content']}>
                            <div className={style['info-box']}>
                                <div className={style['info-content']}>
                                    <ul>
                                        <li className={style['line-two']}>
                                            <span className={style['info-label']}>姓&emsp;&emsp;名 : </span>
                                            <span className={style['info-value']}>&nbsp;{ this.formatterName( this.state.peopleInfo.fullName ) }</span>
                                            <span className={style['info-space']}></span>
                                            <span className={style['info-label']}>性&emsp;&emsp;别 : </span>
                                            <span className={style['info-value']}>&nbsp;{ this.state.peopleInfo.gender || '-' }</span>
                                        </li>
                                        <li className={style['line-two']}>
                                            <span className={style['info-label']}>民&emsp;&emsp;族 : </span>
                                            <span className={style['info-value']}>&nbsp;{ this.state.peopleInfo.ethnic || '-' }</span>
                                            <span className={style['info-space']}></span>
                                            <span className={style['info-label']}>出&emsp;&emsp;生 : </span>
                                            <span className={style['info-value']}>&nbsp;{ this.formatterBirth( this.state.peopleInfo.dateOfBirth ) }</span>
                                        </li>
                                        <li className={style['line-two']}>
                                            <span className={style['info-label']}>帮扶类型 : </span>
                                            <span className={style['info-value']}>&nbsp;{ this.state.peopleInfo.supportPlanType || '-' }</span>
                                            <span className={style['info-space']}></span>
                                            <span className={style['info-label']}>识别标注 : </span>
                                            <span className={style['info-value']}>&nbsp;{ this.state.peopleInfo.identificationStandard || '-' }</span>
                                        </li>
                                        <li className={style['line-two']}>
                                            <span className={style['info-label']}>联系电话 : </span>
                                            <span className={style['info-value']}>&nbsp;{ this.formatterPhone( this.state.peopleInfo.linePhone ) }</span>
                                            <span className={style['info-space']}></span>
                                            <span className={style['info-label']}>贫困户属性 : </span>
                                            <span className={style['info-value']}>&nbsp;{ this.state.peopleInfo.povertyAttribute || '-' }</span>
                                        </li>
                                        <li className={style['line-two']}>
                                            <span className={style['info-label']}>建档立卡时间 : </span>
                                            <span className={style['info-value']} style={{width: '15%'}}>&nbsp;{this.state.peopleInfo.firstYear || '-'}</span>
                                            <span className={style['info-space']}></span>
                                            <span className={style['info-label']}>脱贫时间 : </span>
                                            <span className={style['info-value']}>&nbsp;{this.state.peopleInfo.statusTime || '-'}</span>
                                        </li>
                                        <li className={style['line-one']}>
                                            <span className={style['info-label']}>住址 :  </span>
                                            <span className={style['info-value']}>&nbsp;{ this.state.peopleInfo.homeAddress || '-' }</span>
                                        </li>
                                        <li className={style['line-one']}>
                                            <span className={style['info-label']}>公民身份证号 :  </span>
                                            <span className={style['info-value']}>&nbsp;{ this.formatterID( this.state.peopleInfo.idnumber ) }</span>
                                        </li>
                                        <li className={style['line-one']}>
                                            <span className={style['info-label']}>开户银行 :  </span>
                                            <span className={style['info-value']}>&nbsp;{ this.state.peopleInfo.accountBankname || '-' }</span>
                                        </li><li className={style['line-one']}>
                                        <span className={style['info-label']}>银行账号 :  </span>
                                        <span className={style['info-value']}>&nbsp;{  this.formatterAccount( this.state.peopleInfo.accountNumber ) }</span>
                                    </li>
                                    </ul>
                                </div>
                                <div className={style['info-icon']}>
                                    <ul>
                                        <li className={ this.state.peopleInfo.drinkingWaterSafe? style['icon-active'] : "" }> <i className="iconfont">&#xe612;</i></li>
                                        <li className={ this.state.peopleInfo.clothes? style['icon-active'] : "" }> <i className="iconfont">&#xe635;</i></li>
                                        <li className={ this.state.peopleInfo.ncms? style['icon-active'] : "" }> <i className="iconfont">&#xe60a;</i></li>
                                        <li className={ this.state.peopleInfo.house? style['icon-active'] : "" }> <i className="iconfont">&#xe657;</i></li>
                                        <li className={ this.state.peopleInfo.education? style['icon-active'] : "" }> <i className="iconfont">&#xe62f;</i></li>
                                        <li className={ this.state.peopleInfo.money? style['icon-active'] : "" }> <i className="iconfont">&#xe611;</i></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div className={style['infoDetail-bottom']}>
                    <div className={style['infoDetail-bottom-left']}>
                        <div className={style.panel}>
                            <Title className={style.title} name="致贫原因"/>
                            <div className={style['panel-content']}>
                                <div className={style['hex-row']}>
                                    <div className={ this.state.poorReasons.mainCauses.match( "病" )? style['hexBin']+ ' '+style['hexBin-active-strong'] : this.state.poorReasons.otherCauses.match( "病" )? style['hexBin']+ ' '+style['hexBin-active-normal'] : style['hexBin'] }>
                                        <div className={style['hexBin-left']}></div>
                                        <div className={style['hexBin-body']}><span className={style['hexBin-content']}>因病</span><span className={style['middle']}></span></div>
                                        <div className={style['hexBin-right']}></div>
                                    </div>
                                    <div className={ this.state.poorReasons.mainCauses.match( "残" )? style['hexBin']+' '+style['odd']+' '+style['hexBin-active-strong'] : this.state.poorReasons.otherCauses.match( "残" )? style['hexBin']+' '+style['odd']+' '+style['hexBin-active-normal'] : style['hexBin']+' '+style['odd'] }>
                                        <div className={style['hexBin-left']}></div>
                                        <div className={style['hexBin-body']}><span className={style['hexBin-content']}>因残</span><span className={style['middle']}></span></div>
                                        <div className={style['hexBin-right']}></div>
                                    </div>
                                    <div className={ this.state.poorReasons.mainCauses.match( "其他" )? style['hexBin']+ ' '+style['hexBin-active-strong'] : this.state.poorReasons.otherCauses.match( "其他" )? style['hexBin']+ ' '+style['hexBin-active-normal'] : style.hexBin  }>
                                        <div className={style['hexBin-left']}></div>
                                        <div className={style['hexBin-body']}><span className={style['hexBin-content']}>其他</span><span className={style['middle']}></span></div>
                                        <div className={style['hexBin-right']}></div>
                                    </div>
                                    <div className={ this.state.poorReasons.mainCauses.match( "技术" )? style['hexBin']+' '+style['odd']+' '+style['hexBin-active-strong'] : this.state.poorReasons.otherCauses.match( "技术" )? style['hexBin']+' '+style['odd']+' '+style['hexBin-active-normal'] : style['hexBin']+' '+style['odd']  }>
                                        <div className={style['hexBin-left']}></div>
                                        <div className={style['hexBin-body']}><span className={style['hexBin-content']}>缺技术</span><span className={style['middle']}></span></div>
                                        <div className={style['hexBin-right']}></div>
                                    </div>
                                </div>
                                <div className="hex-row">
                                    <div className={ this.state.poorReasons.mainCauses.match( "动力" )? style['hexBin']+ ' '+style['hexBin-active-strong']  : this.state.poorReasons.otherCauses.match( "动力" )? style['hexBin']+ ' '+style['hexBin-active-normal']  : style['hexBin'] }>
                                        <div className={style['hexBin-left']}></div>
                                        <div className={style['hexBin-body']}><span className={style['hexBin-content']}>自身劳动力不足</span><span className={style['middle']}></span></div>
                                        <div className={style['hexBin-right']}></div>
                                    </div>
                                    <div className={ this.state.poorReasons.mainCauses.match( "水" )? style['hexBin']+' '+style['odd']+' '+style['hexBin-active-strong'] : this.state.poorReasons.otherCauses.match( "水" )? style['hexBin']+' '+style['odd']+' '+style['hexBin-active-normal'] : style['hexBin']+' '+style['odd'] }>
                                        <div className={style['hexBin-left']}></div>
                                        <div className={style['hexBin-body']}><span className={style['hexBin-content']}>缺水</span><span className={style['middle']}></span></div>
                                        <div className={style['hexBin-right']}></div>
                                    </div>
                                    <div className={ this.state.poorReasons.mainCauses.match( "学" )? style['hexBin']+ ' '+style['hexBin-active-strong']  : this.state.poorReasons.otherCauses.match( "学" )? style['hexBin']+ ' '+style['hexBin-active-normal'] : style['hexBin']  }>
                                        <div className={style['hexBin-left']}></div>
                                        <div className={style['hexBin-body']}><span className={style['hexBin-content']}>因学</span><span className={style['middle']}></span></div>
                                        <div className={style['hexBin-right']}></div>
                                    </div>
                                    <div className={ this.state.poorReasons.mainCauses.match( "交通" )? style['hexBin']+' '+style['odd']+' '+style['hexBin-active-strong']  : this.state.poorReasons.otherCauses.match( "交通" )? style['hexBin']+' '+style['odd']+' '+style['hexBin-active-normal'] : style['hexBin']+' '+style['odd'] }>
                                        <div className={style['hexBin-left']}></div>
                                        <div className={style['hexBin-body']}><span className={style['hexBin-content']} style={{ fontSize: "0.7rem" }}>交通条件落后</span><span className={style['middle']}></span></div>
                                        <div className={style['hexBin-right']}></div>
                                    </div>
                                </div>
                                <div className="hex-row">
                                    <div className={ this.state.poorReasons.mainCauses.match( "土地" )? style['hexBin']+ ' '+style['hexBin-active-strong'] : this.state.poorReasons.otherCauses.match( "土地" )? style['hexBin']+ ' '+style['hexBin-active-normal'] : style['hexBin']  }>
                                        <div className={style['hexBin-left']}></div>
                                        <div className={style['hexBin-body']}><span className={style['hexBin-content']}>缺土地</span><span className={style['middle']}></span></div>
                                        <div className={style['hexBin-right']}></div>
                                    </div>
                                    <div className={ this.state.poorReasons.mainCauses.match( "缺劳" )? style['hexBin']+' '+style['odd']+' '+style['hexBin-active-strong']  : this.state.poorReasons.otherCauses.match( "缺劳" )? style['hexBin']+' '+style['odd']+' '+style['hexBin-active-normal'] : style['hexBin']+' '+style['odd'] }>
                                        <div className={style['hexBin-left']}></div>
                                        <div className={style['hexBin-body']}><span className={style['hexBin-content']}>缺劳动</span><span className={style['middle']}></span></div>
                                        <div className={style['hexBin-right']}></div>
                                    </div>
                                    <div className={ this.state.poorReasons.mainCauses.match( "资金" )? style['hexBin']+ ' '+style['hexBin-active-strong']  : this.state.poorReasons.otherCauses.match( "资金" )?  style['hexBin']+ ' '+style['hexBin-active-normal'] : style['hexBin']  }>
                                        <div className={style['hexBin-left']}></div>
                                        <div className={style['hexBin-body']}><span className={style['hexBin-content']}>缺资金</span><span className={style['middle']}></span></div>
                                        <div className={style['hexBin-right']}></div>
                                    </div>
                                    <div className={ this.state.poorReasons.mainCauses.match( "灾" )? style['hexBin']+' '+style['odd']+' '+style['hexBin-active-strong']  : this.state.poorReasons.otherCauses.match( "灾" )? style['hexBin']+' '+style['odd']+' '+style['hexBin-active-normal']: style['hexBin']+' '+style['odd'] }>
                                        <div className={style['hexBin-left']}></div>
                                        <div className={style['hexBin-body']}><span className={style['hexBin-content']}>因灾</span><span className={style.middle}></span></div>
                                        <div className={style['hexBin-right']}></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div className={style['infoDetail-bottom-right']}>
                        <div className={style.panel}>
                            <Title className={style.title} name="家庭成员"/>
                            <div className={style['panel-content']}>
                                <div className={style['graph-chart']} id="graphChart"></div>
                            </div>
                        </div>
                    </div>
                    <div style={{ clear: "both" }}></div>
                </div>
                <div className={style.requireList}>
                  <Title name="需求帮扶进展"/>
                  {
                    requireList.length ? (
                      <div className={style.helpList}>
                        <Tabs className={style.tabs} onChange={this.onTabChange} list={requireList}/>
                        <div className={style.help_tab}>
                          <img src={require('./images/rect.png')}/>
                          <span>历史记录</span>
                        </div>
                        <div>
                          <Table className={style.operateTable} columns={columns} dataSource={operateList}/>
                        </div>
                      </div>
                    ) : (
                      <div style={{height: '200px', lineHeight: '200px', color: '#000', textAlign: 'center'}}>
                        暂无需求
                      </div>
                    )
                  }
                </div>
            </div>
        )
    }
}

// 上帝保佑,永无bug
import React, {Component} from "react";
import resource from '../../../../../util/resource';
import Selection from '../../../../../components/Selection/selection';
import Unix from '../../../../../util/Unix';
import style from './style.scss';
import {immutableRenderDecorator} from 'react-immutable-render-mixin';

@immutableRenderDecorator
export default class Help extends Component {
    constructor(props){
        super(props);
        this.Unix = new Unix();
        this.state = {
            peopleList: [],
            bfjh: null,
            bfxm: null,
            bfzrr: {},
            detail: null,
            bfTab: 'jh',
            hundred: '',
            selectPeople: [],
            selectHunderd: [{name:'企业1',id:''},{name:'企业2',id:''}],
            tip1: '加载中...',
            tip2: '加载中...',
            selectType: [{name: '帮扶计划', id: 'jh'}, {name: '帮扶项目', id: 'xm'}],
            hundredContainer: ''
        }
    }
    componentDidMount = () => {
        let fid = JSON.parse( sessionStorage.getItem( "ID"||{} )).fid;
        this.getBFJHData(fid);
        this.getBFXMData(fid);
        this.getBFZRRData(fid);
        this.getHundred(fid);
        document.addEventListener('click',this.setDisplay)
    };

    setDisplay = () =>{
        this.refs.xmd.style.display = 'none';
    }

    preventDaf = (e) =>{
        e.nativeEvent.stopImmediatePropagation()
    }

    //帮扶计划
    getBFJHData = (id) =>{
        resource.get('/xixiu-server/supportInfo/getPoorFamilySupportPrograms/'+id).then((res)=>{
            if(res.status === 200 && res.data.length > 0){
                this.setState({
                    bfjh: res.data
                })
            }else{
                this.setState({
                    tip1: '暂无数据'
                })
            }
        })
    };

    //帮扶项目
    getBFXMData = (id) =>{
        resource.get('/xixiu-server/supportInfo/getPoorFamilySupportProjects/'+id).then((res)=>{
            if(res.status === 200 && res.data.length > 0){
                this.setState({
                    bfxm: res.data
                })
            }else{
                this.setState({
                    tip2: '暂无数据'
                })
            }
        })
    };

    //帮扶责任人
    getBFZRRData = (id) =>{
        resource.get('/xixiu-server/supportInfo/getPoorFamilySupportResponsible/'+id).then((res)=>{
            if(res.status === 200){
                let name, id;
                for(let i = 0; i < res.data.length; i++){
                    name = res.data[i].fullname;
                    id = res.data[i].id;
                    this.state.selectPeople.push({name,id});
                }
                this.setState({
                    selectPeople: this.state.selectPeople,
                    peopleList: res.data,
                    bfzrr: res.data[0] || {}
                })
            }
        })
    };

    getHundred = (id) =>{
        let fid = id;
        resource.post('/zm/company/v0.1/bangfu_list',{fid}).then((res)=>{
            if(res.data && res.data.length>0){
                let arr = [];
                for(let i = 0; i<res.data.length; i++){
                    let k = i + 1;
                    let name = '企业'+k;
                    let id = res.data[i].companyName;
                    arr.push({name, id});
                }
                this.setState({
                    selectHunderd: arr,
                    hundred: res.data[0],
                    hundredContainer: res.data
                })
            }else{
                this.setState({
                    selectHunderd: [{name:'企业1',id:''},{name:'企业2',id:''}]
                })
            }
        })
    };

    //获取详情
    getDetail = (data,e,type) =>{
        e.nativeEvent.stopImmediatePropagation();
        let url;
        if(type === 'jh'){
            url = '/xixiu-server/supportInfo/getPoorFamilySupportProgramDetail/'+data
        }else{
            url = '/xixiu-server/supportInfo/getPoorFamilySupportProjectDetail/'+data
        }
        resource.get(url).then((res)=>{
            if(res.status === 200){
                this.refs.xmd.style.display = 'block';
                this.setState({
                    detail: res.data
                })
            }
        })
    };

    setFPTab = (n,item) =>{
        this.setState({
            bfTab: item.id
        })
    };

    setHundred =(n, item) =>{
        if(item.id){
            for(let i=0; i<this.state.hundredContainer.length; i++){
                if(this.state.hundredContainer[i].companyName === item.id){
                    this.setState({
                        hundred: this.state.hundredContainer[i]
                    })
                }
            }
        }
    }

    setPeople = (n, item) => {
        if(item.id){
            for(let i=0; i<this.state.peopleList.length; i++){
                if(this.state.peopleList[i].id === item.id){
                    this.setState({
                        bfzrr: this.state.peopleList[i]
                    })
                }
            }
        }
    }

    componentWillUnmount = () =>{
        document.removeEventListener('click',this.setDisplay);
    }

    render() {
        return (
            <div className={style['container-box-help']}>
                <div className={style['common-title']}>扶贫帮扶</div>
                <div className={style['select-up']}>
                    <div className={style.areaOptions}>
                        <Selection ref="help" tipData="帮扶计划" name="" data={this.state.selectType} onChange={this.setFPTab}/>
                    </div>
                </div>
                <div className={style.container} style={{display: this.state.bfTab == 'jh' ? 'block':'none'}}>
                    {
                        (this.state.bfjh && this.state.bfjh.length > 0) ? <div className={style['common-vertical']} style={{height: (this.state.bfjh.length - 1)*5 + 'rem'}}>
                            {
                                this.state.bfjh.map((value,index) =>{
                                    return <div className={style['common-box']} key={index} >
                                        <span className={style.circle} style={{top: (index*5 - 0.6) + 'rem'}}></span>
                                        <div className={index%2 === 0 ? style.common+' '+style.right:style.common+' '+style.left} style={{top: (index*5 - 2.5) + 'rem'}} onClick={(e) =>{this.getDetail(value.id,e,'jh')}}>
                                            <p><span>项目类别：</span>{value.projectType}</p>
                                            <p><span>项目名称：</span>{value.projectName}</p>
                                            <p><span>计划资金总额：</span>{value.planTotalCapital}</p>
                                        </div>
                                        <span className={index%2 === 0 ? style.time+' '+style.left:style.time+' '+style.right} style={{top: (index*5 - 0.4) + 'rem'}}>{value.year}</span>
                                    </div>
                                })
                            }
                        </div>:<div className={style.empty}>
                            <p>{this.state.tip1}</p>
                            <div className={style.linear}></div>
                        </div>
                    }
                </div>
                <div className={style.container} style={{display: this.state.bfTab == 'xm' ? 'block':'none'}}>
                    {
                        (this.state.bfxm && this.state.bfxm.length > 0) ? <div className={style['common-vertical']} style={{height: (this.state.bfxm.length - 1)*5 + 'rem'}}>
                            {
                                this.state.bfxm.map((value,index) =>{
                                    return <div className={style['common-box']} key={index}>
                                        <span className={style.circle} style={{top: (index*5 - 0.6) + 'rem'}}></span>
                                        <div className={index%2 === 0 ? style.common+' '+style.right:style.common+' '+style.left} style={{top: (index*5 - 2.5) + 'rem'}} onClick={(e) =>{this.getDetail(value.id,e,'xm')}}>
                                            <p><span>项目类别：</span>{value.projectType}</p>
                                            <p><span>项目名称：</span>{value.projectName}</p>
                                            <p><span>计划资金总额：</span>{value.planTotalCapital}</p>
                                        </div>
                                        <span className={index%2 === 0 ? style.time+' '+style.left:style.time+' '+style.right} style={{top: (index*5 - 0.4) + 'rem'}}>{value.year}</span>
                                    </div>
                                })
                            }
                        </div>:<div className={style.empty}>
                            <p>{this.state.tip2}</p>
                            <div className={style.linear}></div>
                        </div>
                    }
                </div>
                <div className={style['common-title']}>帮扶责任人</div>
                <div className={style.detailPerson}>
                    <div className={style['select-down']}>
                        <div className={style.areaOptions}>
                            <Selection ref="people" tipData={JSON.stringify(this.state.bfzrr) === '{}' ? '无' : this.state.bfzrr.fullname} name="" data={this.state.selectPeople} onChange={this.setPeople}/>
                        </div>
                    </div>
                    {
                        this.state.bfzrr ? <div className={style.dpBox}>
                            <div className={style.up}>
                                <span className={style['col-1']}>姓名：</span>
                                <span className={style['col-2']}>{ this.state.bfzrr.fullname || '-'}</span>
                                <span className={style['col-6']}>联系电话：</span>
                                <span className={style['col-7']}>{ this.state.bfzrr.linkPhone || '-'}</span>
                            </div>
                            <div className={style.down}>
                                <span className={style['col-8']}>职位：</span>
                                <span className={style['col-9']}>{this.state.bfzrr.post || '-'}</span>
                                <span className={style['col-3']}>帮扶单位名称：</span>
                                <span>{this.state.bfzrr.supportDepartment || '-'}</span>
                            </div>
                            <div className={style.bt}>
                                <span className={style['col-4']}>单位隶属关系：</span>
                                <span className={style['col-5']}>{this.state.bfzrr.unitAffiliation || '-'}</span>
                            </div>
                        </div>:null
                    }
                </div>
                {/*<div className={style['common-title']}>百企帮百村</div>*/}
                {/*<div className={style.hundredBox}>*/}
                    {/*<div className={style['select-down']}>*/}
                        {/*<div className={style.areaOptions}>*/}
                            {/*<Selection ref="type" tipData="企业1" name="" data={this.state.selectHunderd} onChange={this.setHundred}/>*/}
                        {/*</div>*/}
                    {/*</div>*/}
                    {/*<div className={style.content}>*/}
                        {/*<div className={style.common}>*/}
                            {/*<div className={style.left}>*/}
                                {/*<span>企业名称：</span>*/}
                                {/*<span>{this.state.hundred.companyName || '-'}</span>*/}
                            {/*</div>*/}
                            {/*<div className={style.right}>*/}
                                {/*<span>分类：</span>*/}
                                {/*<span>{this.state.hundred.classification || '-'}</span>*/}
                            {/*</div>*/}
                        {/*</div>*/}
                        {/*<div className={style.common}>*/}
                            {/*<div className={style.left}>*/}
                                {/*<span>企业（商会）代码类型：</span>*/}
                                {/*<span>{this.state.hundred.companyCodeType || '-'}</span>*/}
                            {/*</div>*/}
                            {/*<div className={style.right}>*/}
                                {/*<span>联系人：</span>*/}
                                {/*<span>{this.state.hundred.contacts || '-'}</span>*/}
                            {/*</div>*/}
                        {/*</div>*/}
                        {/*<div className={style.common}>*/}
                            {/*<div className={style.left}>*/}
                                {/*<span>企业（商会）代码号：</span>*/}
                                {/*<span>{this.state.hundred.companyCode || '-'}</span>*/}
                            {/*</div>*/}
                            {/*<div className={style.right}>*/}
                                {/*<span>联系电话：</span>*/}
                                {/*<span>{this.state.hundred.phoneNumber || '-'}</span>*/}
                            {/*</div>*/}
                        {/*</div>*/}
                        {/*<div className={style.common}>*/}
                            {/*<div className={style.left}>*/}
                                {/*<span>成立时间：</span>*/}
                                {/*<span>{this.state.hundred.foundingTime || '-'}</span>*/}
                            {/*</div>*/}
                            {/*<div className={style.right}>*/}
                                {/*<span>注册资金(万元)：</span>*/}
                                {/*<span>{this.state.hundred.registerdFund || '-'}</span>*/}
                            {/*</div>*/}
                        {/*</div>*/}
                        {/*<div className={style.common}>*/}
                            {/*<div className={style.left} style={{width: '100%'}}>*/}
                                {/*<span>注册所在地：</span>*/}
                                {/*<span>{this.state.hundred.registerLocation || '-'}</span>*/}
                            {/*</div>*/}
                        {/*</div>*/}
                    {/*</div>*/}
                {/*</div>*/}
                <div className={style['common-title']}>绿野芳田</div>
              <div className={style.greencenter}>
                <div   className={style.green}>
                      <div >
                           <span>参加合作社名称：</span>
                          <span>-</span>
                         </div>
                        <div>
                           <span>进入合作社时间：</span>
                             <span>-</span>
                         </div>
                     </div>
                     <div className={style.green}>
                         <div>
                             <span>分红模式：</span>
                             <span>-</span>
                         </div>
                         <div>
                             <span>收益情况（年）：</span>
                             <span>-</span>
                        </div>
                     </div>

                </div>
                <div className={style.dtBox} ref="xmd">
                    <div className={style.preventBox} onClick={this.preventDaf}>
                        {
                            this.state.detail && this.state.detail !== null ?<div className={style.dBox}>
                                <h3>项目详情</h3>
                                <p><span>项目类别：</span>{this.state.detail.projectType || '-'}</p>
                                <p><span>年度：</span>{this.state.detail.year || '-'}</p>
                                <p><span>项目名称：</span>{this.state.detail.projectName || '-'}</p>
                                <p><span>项目内容：</span>{this.state.detail.projectContent || '-'}</p>
                                <p><span>计量单位：</span>{this.state.detail.measurementUnit || '-'}</p>
                                <p><span>数量：</span>{this.state.detail.quantity || '-'}</p>
                                <p><span>资金总额(万元)：</span>{this.state.detail.planTotalCapital || '-'}</p>
                                <p><span>财政资金(万元)：</span>{this.state.detail.financeCapital || '-'}</p>
                                <p><span>行业部门资金(万元)：</span>{this.state.detail.industrySectorCapital || '-'}</p>
                                <p><span>社会扶持资金(万元)：</span>{this.state.detail.socialAssistanceCapital || '-'}</p>
                                <p><span>信贷资金(万元)：</span>{this.state.detail.creditCapital || '-'}</p>
                                <p><span>帮扶单位资金(万元)：</span>{this.state.detail.supportDepartmentCapital || '-'}</p>
                                <p><span>群众自筹资金(万元)：</span>{this.state.detail.peopleRaisedCapital || '-'}</p>
                                <p><span>其它资金(万元)：</span>{this.state.detail.otherCapital || '-'}</p>
                                <p><span>参与类型(万元)：暂无数据</span></p>
                            </div> :<div className={style.empty}>
                                <p>暂无数据</p>
                                <div className={style.linear}></div>
                            </div>
                        }
                    </div>
                </div>
            </div>
        );
    }
}


import React, {Component} from "react";
import resource from '../../../../../util/resource';
import style from './style.scss';
import AllPip from './chart/pip1';
import PurePip from './chart/pip2';
import OtherPip from './chart/pip3';
import Title from 'components/Title'

export default class FinancialCondition extends Component {
    constructor(props){
        super(props);
        this.state = {
            peopleId: "",
            familyId: "",
            wageSumData: {},
            pureIncomeData: {},
            otherIncomeData: {}
        };
        this.attr = {
            familyId: "",
            peopleId: ""
        }
    }

    componentDidUpdate(){
        /*setTimeout( function(){

         }.bind(this), 300 );*/

        this.family = JSON.parse( sessionStorage.getItem( "ID" ) );

        let ss = {
            fid:this.family.fid,
            id:this.family.id
        };
        if( ss.fid == this.attr.familyId ){
            return;
        }else{

            this.attr.familyId = ss.fid;
            this.attr.peopleId = ss.id;
            this.setState({
                familyId: ss.fid,
                peopleId: ss.id
            },function(){
                this.getFamilyIncomeSum();
                this.getPureIncome();
                this.getOtherIncome();
            });
        }
    }

    getFamilyIncomeSum = () =>{
        let params = { fid: this.state.familyId };
        resource.get( `/xixiu-server/poorFamilyInfo/getPoorFamilyIncome/${params.fid}` ).then( ( res ) =>{
            if(res.status === 200 && res.data){
                this.setState({
                    wageSumData: res.data
                });
            }else{
                this.setState({
                    wageSumData: {}
                });
            }
        });
    };

    getPureIncome = () =>{
        let params = { fid: this.state.familyId };
        resource.get( `/xixiu-server/poorFamilyInfo/getPoorFamilyNetIncome/${params.fid}` ).then( ( res ) =>{
            if(res.status === 200 && res.data){
                this.setState({
                    pureIncomeData: res.data
                });
            }else{
                this.setState({
                    pureIncomeData: {}
                });
            }
        });
    };

    getOtherIncome = () =>{
        let params = { fid: this.state.familyId };
        resource.get( `/xixiu-server/poorFamilyInfo/getPoorFamilyExpenditure/${params.fid}` ).then( ( res ) =>{
            if(res.status === 200 && res.data){
                this.setState({
                    otherIncomeData: res.data
                });
            }else{
                this.setState({
                    otherIncomeData: {}
                });
            }
        });
    };

    componentDidMount(){

        this.family = JSON.parse( sessionStorage.getItem( "ID" ) );

        let ss = {
            fid:this.family.fid,
            id:this.family.id
        };
        this.attr.familyId = ss.fid;
        this.attr.peopleId = ss.id;
        this.setState({
            familyId: ss.fid,
            peopleId: ss.id
        },function(){
            this.getFamilyIncomeSum();
            this.getPureIncome();
            this.getOtherIncome();
        });
    }

    render() {
        return  (
            <div id={style['financial']}>
            <div className={style.wage_sum}>
            <Title name="总收入" />
                    {/* <div className={style.panel_title}>总收入</div> */}
                    <div className={style.panel_content}>
                        <AllPip data={this.state.wageSumData} height="11.171rem" width="32.75rem"/>
                    </div>
                </div>
            <div className={style.pure_income}>
            <Title name="纯收入" />
                    {/* <div className={style.panel_title}>纯收入</div> */}
                    <div className={style.panel_content}>
                        <PurePip data={this.state.pureIncomeData} height="11.171rem" width="32.75rem"/>
                    </div>
                </div>
            <div className={style.other_income}>
            <Title name="其他资金" />
                    {/* <div className={style.panel_title}>其他资金</div> */}
                    <div className={style.panel_content}>
                        <OtherPip data={this.state.otherIncomeData} height="11.171rem" width="32.75rem"/>
                    </div>
                </div>
            </div>
        )
    }
}
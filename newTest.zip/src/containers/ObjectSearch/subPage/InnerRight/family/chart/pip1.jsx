import React, {Component} from 'react';
import echarts from 'echarts';

export default class Pip1 extends Component {

    constructor(props) {
        super(props);
        this.data = this.props.data;
        this.wageSumChart = null;
    }

    componentDidMount() {
        this.drawWageSum(this.data);
        window.addEventListener('resize', this.wageSumChart.resize);
    }
    componentWillReceiveProps(props) {
        this.data = props.data;
        this.drawWageSum(this.data);
    }
    componentWillUpdate(){
        this.drawWageSum(this.data);
    }


    drawWageSum = (data) => {
        let allData = parseInt(data.productionOperationIncome) + parseInt(data.transterIncome) + parseInt(data.wageIncome) +parseInt(data.propertyIncome) +parseInt(data.otherTransterIncome);
        if(!allData){
            allData = 0;
        }
        this.wageSumChart = echarts.init(this.refs.wageSumChart);
        let colorOut = ["#63d9f2", "#dbecf8", "#65f5da", "#54e0c5", "#fce98f"];
        let colorIn = ["#54b8cd", "#bac8d3", "#55d0b9", "#47bea7", "#d6c679"];    
        let option = {
            tooltip: {
                trigger: 'item',
                formatter: "{a} <br/>{b}: {c} ({d}%)"
            },
            legend: {
                orient: 'vertical',
                right: '20%',
                top: 'center',
                data: [
                    { name: '生产经营性收入', icon: 'circle' },
                    { name: '转移性收入', icon: 'circle' },
                    { name: '工资收入', icon: 'circle' },
                    { name: '财产性收入', icon: 'circle' },
                    { name: '其他转移性收入', icon: 'circle' }
                ],
                formatter:function(name){
                    let oa = option.series[1].data;
                    let colors = option.series[1].color;
                    let num = 0;
                    for(let i = 0; i < oa.length; i++){
                        num = num + oa[i].value;
                    }
                    for(let i = 0; i < oa.length; i++){
                        if(name === oa[i].name){
                            return name + '   ' + oa[i].value;
                        }
                    }
                }
            },
            series: [
                { // 内环
                    name:'',
                    type:'pie',
                    radius: ['45%', '65%'],
                    center: ['25%', "50%"],
                    hoverAnimation: false,
                    legendHoverLink:false,
                    avoidLabelOverlap: false,
                    tooltip: {
                        show:false,
                    },
                    color: colorIn,
                    label: {
                        normal: {
                            show: false,
                            position: 'center'
                        },
                        emphasis: {
                            show: false,
                        }
                    },
                    labelLine: {
                        normal: {
                            show: false
                        }
                    },
                    data:[
                        {value:data.productionOperationIncome || 0, name:''},
                        {value:data.transterIncome || 0, name:''},
                        {value:data.wageIncome || 0, name:''},
                        {value:data.propertyIncome || 0, name:''},
                        {value:data.otherTransterIncome || 0, name:''}
                    ]
                },
                {  // 外环
                    name:'总收入',
                    type:'pie',
                    radius: ['65%', '85%'],
                    center: [ '25%', "50%" ],
                    avoidLabelOverlap: false,
                    color: colorOut,
                    label: {
                        normal: {
                            show: false,
                            position: 'center'
                        },
                        emphasis: {
                            show: false,
                        }
                    },
                    labelLine: {
                        normal: {
                            show: false
                        }
                    },
                    data:[
                        {value:data.productionOperationIncome || 0, name:'生产经营性收入'},
                        {value:data.transterIncome || 0, name:'转移性收入'},
                        {value:data.wageIncome || 0, name:'工资收入'},
                        {value:data.propertyIncome || 0, name:'财产性收入'},
                        {value:data.otherTransterIncome || 0, name:'其他转移性收入'}
                    ]
                },
                {
                    tooltip:{ show: false },
                    name:'',
                    type:'pie',
                    radius: '40%',
                    center: [ '25%', "50%" ],
                    avoidLabelOverlap: false,
                    label: {
                        normal: {
                            show: true,
                            position: 'center',
                            textStyle: {
                                fontSize: '14',
                                color: "#7f8893"
                            },
                            formatter: " "+allData+ " "
                        },
                        emphasis: {
                            show: true,
                            textStyle: {
                                fontSize: '18',
                                color: "#7f8893"
                            },
                            formatter: " "+allData+ " "
                        }
                    },
                    labelLine: {
                        normal: {
                            show: false
                        }
                    },
                    itemStyle: {
                        normal:{
                            color: "transparent"
                        }
                    },
                    data:[
                        {value: (data.productionOperationIncome+data.transterIncome+data.wageIncome+data.propertyIncome+data.otherTransterIncome).toFixed(0), name:''},
                    ]
                },
            ]
        };
        this.wageSumChart.setOption( option );
    };

    render() {
        return (
            <div style={{width:this.props.width,height:this.props.height}} ref="wageSumChart"></div>
        )
    }
}
import React, {Component} from 'react';
import echarts from 'echarts';

export default class App extends Component {

    constructor(props) {
        super(props);
        this.pureIncomeChart = null;
    }
    componentDidMount(){
        this.drawPureIncome(this.props.data);
        window.addEventListener('resize', this.pureIncomeChart.resize);
    }
    componentWillReceiveProps(props) {
        this.drawPureIncome(props.data);
    }

    drawPureIncome = (data)=>{
        console.log(data)
        this.pureIncomeChart = echarts.init(this.refs.pureIncomeChart);
        let option = {
            color:[ "#bfc0f0" ],
            tooltip: {
                trigger: 'item'
            },
            legend: {
                orient: 'vertical',
                left: '20%',
                top: 'center',
                data: ['纯收入', '人均纯收入'],
                // formatter:function(name){
                //     let oa = option.series[1].data;
                //     let colors = option.series[1].color;
                //     let num = 0;
                //     for(let i = 0; i < oa.length; i++){
                //         num = num + oa[i].value;
                //     }
                //     for(let i = 0; i < oa.length; i++){
                //         if(name === oa[i].name){
                //             return name + '   ' + oa[i].value;
                //         }
                //     }
                // }
            },
            series: [
                {  // 外圈的内环
                    name:'',
                    type:'pie',
                    radius: ['55%', '70%'],
                    center: [ '75%', "50%" ],
                    hoverAnimation: false,
                    legendHoverLink:false,
                    avoidLabelOverlap: false,
                    tooltip: { show:false },
                    label: {
                        normal: {
                            show: false,
                            position: 'center'
                        },
                        emphasis: {
                            show: false,
                        }
                    },
                    labelLine: {
                        normal: {
                            show: false
                        }
                    },
                    itemStyle: {
                        normal:{
                            color: "#41b7a3"
                        }
                    },
                    data:[
                        {value:data.netIncome || 0, name:''},
                    ]
                },
                {  // 外圈的外环
                    name:'',
                    type:'pie',
                    radius: ['70%', '85%'],
                    center: [ '75%', "50%" ],
                    avoidLabelOverlap: false,
                    label: {
                        normal: {
                            show: false,
                            position: 'center',
                        },
                        emphasis: {
                            show: true,
                            position: 'center',
                            textStyle: {
                                fontSize: '12',
                                color: "#7f8893"
                            },
                            formatter: '{c}'
                        }
                    },
                    labelLine: {
                        normal: {
                            show: false
                        }
                    },
                    itemStyle: {
                        normal:{
                            color: "#49ccb6"
                        }
                    },
                    data:[
                        {value:data.netIncome || 0, name:'纯收入'},
                    ]
                },
                { // 内圈的内环
                    name:'',
                    type:'pie',
                    radius: [ '25%', "35%" ],
                    center: [ '75%', "50%" ],
                    hoverAnimation: false,
                    legendHoverLink:false,
                    avoidLabelOverlap: false,
                    tooltip: { show:false },
                    label: {
                        normal: {
                            show: false,
                            position: 'center',
                            textStyle: {
                                fontSize: '20',
                                color: "#7f8893"
                            },
                            // formatter: '{c}'
                        },
                        emphasis: {
                            show: false,
                            textStyle: {
                                fontSize: '25',
                                color: "#7f8893"
                            }
                        }
                    },
                    labelLine: {
                        normal: {
                            show: false
                        }
                    },
                    itemStyle: {
                        normal:{
                            color: "#e2d180"
                        }
                    },
                    data:[
                        {value:data.percapitaNetIncome || 0, name:''},
                    ]
                },
                {  // 内圈的外环
                    name:'',
                    type:'pie',
                    radius: ['35%', '45%'],
                    center: [ '75%', "50%" ],
                    avoidLabelOverlap: false,
                    label: {
                        normal: {
                            show: false,
                            position: 'center',
                            textStyle: {
                                fontSize: '12',
                                color: "#7f8893"
                            },
                            // formatter: '{c}'
                        },
                        emphasis: {
                            show: true,
                            textStyle: {
                                fontSize: '12',
                                color: "#7f8893"
                            },
                            formatter: '{c}'
                        }
                    },
                    labelLine: {
                        normal: {
                            show: false
                        }
                    },
                    itemStyle: {
                        normal:{
                            color: "#fce98f"
                        }
                    },
                    data:[
                        {value:data.percapitaNetIncome || 0, name:'人均纯收入'},
                    ]
                }
            ]
        };
        this.pureIncomeChart.setOption( option );
    };

    render() {
        return (
            <div style={{width:this.props.width,height:this.props.height}} ref="pureIncomeChart"></div>
        )
    }
}
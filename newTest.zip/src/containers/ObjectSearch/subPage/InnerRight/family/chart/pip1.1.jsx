import React, {Component} from 'react';
import echarts from 'echarts';

export default class Pip1 extends Component {

    constructor(props) {
        super(props);
        this.data = this.props.data;
        this.wageSumChart = null;
    }

    componentDidMount() {
        this.drawWageSum(this.data);
        window.addEventListener('resize', this.wageSumChart.resize);
    }
    componentWillReceiveProps(props) {
        this.data = props.data;
        this.drawWageSum(this.data);
    }
    componentWillUpdate(){
        this.drawWageSum(this.data);
    }


    drawWageSum = ( data )=>{
        let allData = parseInt(data.productionOperationIncome) + parseInt(data.transterIncome) + parseInt(data.wageIncome) +parseInt(data.propertyIncome) +parseInt(data.otherTransterIncome);
        if(!allData){
            allData = 0;
        }
        this.wageSumChart = echarts.init(this.refs.wageSumChart);
        let option = {
            color:[ "#11d1e0", "#fedd69", "#f38c09", "#f0b0fc", "#a8f7fc" ],
            tooltip: {
                trigger: 'item',
                formatter: "{a} <br/>{b}: {c} ({d}%)"
            },
            series: [
                {
                    name:'',
                    type:'pie',
                    radius: ['50%', '85%'],
                    center: [ '25%', "50%" ],
                    avoidLabelOverlap: false,
                    label: {
                        normal: {
                            show: false,
                            position: 'center'
                        },
                        emphasis: {
                            show: false,
                        }
                    },
                    labelLine: {
                        normal: {
                            show: false
                        }
                    },
                    data:[
                        {value:data.productionOperationIncome || 0, name:'生产经营性收入'},
                        {value:data.transterIncome || 0, name:'转移性收入'},
                        {value:data.wageIncome || 0, name:'工资收入'},
                        {value:data.propertyIncome || 0, name:'财产性收入'},
                        {value:data.otherTransterIncome || 0, name:'其他转移性收入'}
                    ]
                },
                {
                    tooltip:{ show: false },
                    name:'',
                    type:'pie',
                    radius: '40%',
                    center: [ '25%', "50%" ],
                    avoidLabelOverlap: false,
                    label: {
                        normal: {
                            show: true,
                            position: 'center',
                            textStyle: {
                                fontSize: '20',
                                color: "#fff"
                            },
                            formatter: " "+allData+ " "
                        },
                        emphasis: {
                            show: true,
                            textStyle: {
                                fontSize: '25',
                                color: "#fff"
                            },
                            formatter: " "+allData+ " "
                        }
                    },
                    labelLine: {
                        normal: {
                            show: false
                        }
                    },
                    itemStyle: {
                        normal:{
                            color: "transparent"
                        }
                    },
                    data:[
                        {value: (data.productionOperationIncome+data.transterIncome+data.wageIncome+data.propertyIncome+data.otherTransterIncome).toFixed(0), name:''},
                    ]
                },
            ]
        };
        this.wageSumChart.setOption( option );
    };

    render() {
        return (
            <div style={{width:this.props.width,height:this.props.height}} ref="wageSumChart"></div>
        )
    }
}
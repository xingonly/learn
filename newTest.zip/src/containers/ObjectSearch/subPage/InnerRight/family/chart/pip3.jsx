import React, {Component} from 'react';
import echarts from 'echarts';

export default class App extends Component {

    constructor(props) {
        super(props);
        this.otherIncome = null;
    }

    componentDidMount() {
        this.drawOtherIncome(this.props.data);
        window.addEventListener('resize', this.otherIncome.resize);
    }

    componentWillReceiveProps(props) {
        this.drawOtherIncome(props.data);
    }

    drawOtherIncome = (data)=>{
        this.otherIncome = echarts.init(this.refs.otherIncome);
        let colorOut = ["#63d9f2", "#dbecf8", "#65f5da", "#54e0c5", "#fce98f", "#ffbb2c"];
        let colorIn = ["#54b8cd", "#bac8d3", "#55d0b9", "#47bea7", "#d6c679", 'd99f25'];   
        let option = {
            color:[ "#abf6fc", "#fedd69", "#f0b0fc", "#bebef0", "#f380c9", "#11cee1" ],
            tooltip: {
                trigger: 'item',
                formatter: "{a} <br/>{b}: {c} ({d}%)"
            },
            legend: {
                orient: 'vertical',
                right: '20%',
                top: 'center',
                textStyle: {
                    fontSize: 10
                },
                itemWidth: 10,
                data: [
                    { name: '生产经营性支出', icon: 'circle' },
                    { name: '养老保险金', icon: 'circle' },
                    { name: '低保金', icon: 'circle' },
                    { name: '计划生育金', icon: 'circle' },
                    { name: '五险金', icon: 'circle' },
                    { name: '生态保障金', icon: 'circle' }
                ],
                formatter:function(name){
                    let oa = option.series[1].data;
                    let colors = option.series[1].color;
                    let num = 0;
                    for(let i = 0; i < oa.length; i++){
                        num = num + oa[i].value;
                    }
                    for(let i = 0; i < oa.length; i++){
                        if(name === oa[i].name){
                            return name + '   ' + oa[i].value;
                        }
                    }
                }
            },
            series: [
                {  // 内环
                    name:'',
                    type:'pie',
                    radius: ['45%', '65%'],
                    center: [ '25%', "50%" ],
                    hoverAnimation: false,
                    legendHoverLink:false,
                    avoidLabelOverlap: false,
                    color: colorIn,
                    label: {
                        normal: {
                            show: false,
                            position: 'center'
                        },
                        emphasis: {
                            show: false,
                        }
                    },
                    labelLine: {
                        normal: {
                            show: false
                        }
                    },
                    data:[
                        {value:data.productiveExpenditure || 0, name:''},
                        {value:data.pension || 0, name:''},
                        {value:data.incomeSecurity || 0, name:''},
                        {value:data.birthControlExpenditure || 0, name:''},
                        {value:data.fiveIncomeSecurity || 0, name:''},
                        {value:data.ecologicalSecurityFund || 0, name:''},
                    ]
                },
                {  // 外环
                    name:'',
                    type:'pie',
                    radius: ['65%', '85%'],
                    center: [ '25%', "50%" ],
                    avoidLabelOverlap: false,
                    color: colorOut,
                    label: {
                        normal: {
                            show: false,
                            position: 'center'
                        },
                        emphasis: {
                            show: false,
                        }
                    },
                    labelLine: {
                        normal: {
                            show: false
                        }
                    },
                    data:[
                        {value:data.productiveExpenditure || 0, name:'生产经营性支出'},
                        {value:data.pension || 0, name:'养老保险金'},
                        {value:data.incomeSecurity || 0, name:'低保金'},
                        {value:data.birthControlExpenditure || 0, name:'计划生育金'},
                        {value:data.fiveIncomeSecurity || 0, name:'五险金'},
                        {value:data.ecologicalSecurityFund || 0, name:'生态保障金'},
                    ]
                },
                {
                    tooltip:{
                        show: false
                    },
                    name:'',
                    type:'pie',
                    radius: '40%',
                    center: [ '25%', "50%" ],
                    avoidLabelOverlap: false,
                    label: {
                        normal: {
                            show: true,
                            position: 'center',
                            textStyle: {
                                fontSize: '14',
                                color: "#7f8893"
                            },
                            formatter: '{c}'
                        },
                        emphasis: {
                            show: true,
                            textStyle: {
                                fontSize: '18',
                                color: "#7f8893"
                            }
                        }
                    },
                    labelLine: {
                        normal: {
                            show: false
                        }
                    },
                    itemStyle: {
                        normal:{
                            color: "transparent"
                        }
                    },
                    data:[
                        {value:data.productiveExpenditure + data.pension + data.incomeSecurity + data.birthControlExpenditure + data.fiveIncomeSecurity + data.ecologicalSecurityFund, name:''},
                    ]
                },
            ]
        };
        this.otherIncome.setOption( option );
    };

    render() {
        return (
            <div style={{width:this.props.width,height:this.props.height}} ref="otherIncome"></div>
        )
    }
}
import React, {Component} from 'react';
import echarts from 'echarts';

export default class App extends Component {

    constructor(props) {
        super(props);
        this.pureIncomeChart = null;
    }
    componentDidMount(){
        this.drawPureIncome(this.props.data);
        window.addEventListener('resize', this.pureIncomeChart.resize);
    }
    componentWillReceiveProps(props) {
        this.drawPureIncome(props.data);
    }

    drawPureIncome = (data)=>{
        console.log(data)
        this.pureIncomeChart = echarts.init(this.refs.pureIncomeChart);
        let option = {
            color:[ "#bfc0f0" ],
            tooltip: {
                trigger: 'item'
            },
            series: [
                {
                    name:'',
                    type:'pie',
                    radius: ['60%', '85%'],
                    center: [ '75%', "50%" ],
                    avoidLabelOverlap: false,
                    label: {
                        normal: {
                            show: false,
                            position: 'center'
                        },
                        emphasis: {
                            show: false,
                        }
                    },
                    labelLine: {
                        normal: {
                            show: false
                        }
                    },
                    data:[
                        {value:data.netIncome || 0, name:'纯收入'},
                    ]
                },
                {
                    name:'',
                    type:'pie',
                    radius: '48%',
                    center: [ '75%', "50%" ],
                    avoidLabelOverlap: false,
                    label: {
                        normal: {
                            show: true,
                            position: 'center',
                            textStyle: {
                                fontSize: '20',
                                color: "#fff"
                            },
                            formatter: '{c}'
                        },
                        emphasis: {
                            show: true,
                            textStyle: {
                                fontSize: '25',
                                color: "#fff"
                            }
                        }
                    },
                    labelLine: {
                        normal: {
                            show: false
                        }
                    },
                    itemStyle: {
                        normal:{
                            color: "#fedd69"
                        }
                    },
                    data:[
                        {value:data.percapitaNetIncome || 0, name:'人均纯收入'},
                    ]
                },
            ]
        };
        this.pureIncomeChart.setOption( option );
    };

    render() {
        return (
            <div style={{width:this.props.width,height:this.props.height}} ref="pureIncomeChart"></div>
        )
    }
}
import React, {Component} from 'react';
import echarts from 'echarts';

export default class App extends Component {

    constructor(props) {
        super(props);
        this.otherIncome = null;
    }

    componentDidMount() {
        this.drawOtherIncome(this.props.data);
        window.addEventListener('resize', this.otherIncome.resize);
    }

    componentWillReceiveProps(props) {
        this.drawOtherIncome(props.data);
    }

    drawOtherIncome = (data)=>{
        this.otherIncome = echarts.init(this.refs.otherIncome);
        let option = {
            color:[ "#abf6fc", "#fedd69", "#f0b0fc", "#bebef0", "#f380c9", "#11cee1" ],
            tooltip: {
                trigger: 'item',
                formatter: "{a} <br/>{b}: {c} ({d}%)"
            },
            series: [
                {
                    name:'',
                    type:'pie',
                    radius: ['50%', '85%'],
                    center: [ '25%', "50%" ],
                    avoidLabelOverlap: false,
                    label: {
                        normal: {
                            show: false,
                            position: 'center'
                        },
                        emphasis: {
                            show: false,
                        }
                    },
                    labelLine: {
                        normal: {
                            show: false
                        }
                    },
                    data:[
                        {value:data.productiveExpenditure || 0, name:'生产经营性支出'},
                        {value:data.pension || 0, name:'养老保险金'},
                        {value:data.incomeSecurity || 0, name:'低保金'},
                        {value:data.birthControlExpenditure || 0, name:'计划生育金'},
                        {value:data.fiveIncomeSecurity || 0, name:'五险金'},
                        {value:data.ecologicalSecurityFund || 0, name:'生态保障金'},
                    ]
                },
                {
                    tooltip:{
                        show: false
                    },
                    name:'',
                    type:'pie',
                    radius: '40%',
                    center: [ '25%', "50%" ],
                    avoidLabelOverlap: false,
                    label: {
                        normal: {
                            show: true,
                            position: 'center',
                            textStyle: {
                                fontSize: '20',
                                color: "#fff"
                            },
                            formatter: '{c}'
                        },
                        emphasis: {
                            show: true,
                            textStyle: {
                                fontSize: '25',
                                color: "#fff"
                            }
                        }
                    },
                    labelLine: {
                        normal: {
                            show: false
                        }
                    },
                    itemStyle: {
                        normal:{
                            color: "transparent"
                        }
                    },
                    data:[
                        {value:data.productiveExpenditure + data.pension + data.incomeSecurity + data.birthControlExpenditure + data.fiveIncomeSecurity + data.ecologicalSecurityFund, name:''},
                    ]
                },
            ]
        };
        this.otherIncome.setOption( option );
    };

    render() {
        return (
            <div style={{width:this.props.width,height:this.props.height}} ref="otherIncome"></div>
        )
    }
}
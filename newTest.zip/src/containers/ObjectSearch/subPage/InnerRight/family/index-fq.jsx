import React, {Component} from "react";
import resource from '../../../../../util/resource';
import style from './style.scss';
import AllPip from './chart/pip1';
import PurePip from './chart/pip2';
import OtherPip from './chart/pip3';

export default class FinancialCondition extends Component {
    constructor(props){
        super(props);
        this.state = {
            peopleId: "",
            familyId: "",
            wageSumData: {},
            pureIncomeData: {},
            otherIncomeData: {}
        };
        this.attr = {
            familyId: "",
            peopleId: ""
        }
    }

    componentDidUpdate(){
        /*setTimeout( function(){

         }.bind(this), 300 );*/

        this.family = JSON.parse( sessionStorage.getItem( "ID" ) );

        let ss = {
            fid:this.family.fid,
            id:this.family.id
        };
        if( ss.fid == this.attr.familyId ){
            return;
        }else{

            this.attr.familyId = ss.fid;
            this.attr.peopleId = ss.id;
            this.setState({
                familyId: ss.fid,
                peopleId: ss.id
            },function(){
                this.getFamilyIncomeSum();
                this.getPureIncome();
                this.getOtherIncome();
            });
        }
    }

    getFamilyIncomeSum = () =>{
        let params = { fid: this.state.familyId };
        resource.get( `/xixiu-server/poorFamilyInfo/getPoorFamilyIncome/${params.fid}` ).then( ( res ) =>{
            if(res.status === 200 && res.data){
                this.setState({
                    wageSumData: res.data
                });
            }else{
                this.setState({
                    wageSumData: {}
                });
            }
        });
    };

    getPureIncome = () =>{
        let params = { fid: this.state.familyId };
        resource.get( `/xixiu-server/poorFamilyInfo/getPoorFamilyNetIncome/${params.fid}` ).then( ( res ) =>{
            if(res.status === 200 && res.data){
                this.setState({
                    pureIncomeData: res.data
                });
            }else{
                this.setState({
                    pureIncomeData: {}
                });
            }
        });
    };

    getOtherIncome = () =>{
        let params = { fid: this.state.familyId };
        resource.get( `/xixiu-server/poorFamilyInfo/getPoorFamilyExpenditure/${params.fid}` ).then( ( res ) =>{
            if(res.status === 200 && res.data){
                this.setState({
                    otherIncomeData: res.data
                });
            }else{
                this.setState({
                    otherIncomeData: {}
                });
            }
        });
    };

    componentDidMount(){

        this.family = JSON.parse( sessionStorage.getItem( "ID" ) );

        let ss = {
            fid:this.family.fid,
            id:this.family.id
        };
        this.attr.familyId = ss.fid;
        this.attr.peopleId = ss.id;
        this.setState({
            familyId: ss.fid,
            peopleId: ss.id
        },function(){
            this.getFamilyIncomeSum();
            this.getPureIncome();
            this.getOtherIncome();
        });
    }

    render() {
        return  (
            <div id={style['financial']}>
                <div className={style.wage_sum}>
                    <div className={style.panel_title}>总收入</div>
                    <div className={style.panel_content}>
                        <AllPip data={this.state.wageSumData} height="11.171rem" width="32.75rem"/>
                        <div className={style.legend_panel}>
                            <div className={style.legend_panel_content}>
                                <div className={ !this.state.wageSumData.productionOperationIncome||this.state.wageSumData.productionOperationIncome == 0 ?  style.production_income+" "+ style.income_item : style.production_income+" "+style.income_item }>
                                    <span className={style.legend_icon}/>
                                    <span className={style.legend_label}>生产经营性收入</span>
                                    <span className={style.legend_value}>￥{ this.state.wageSumData.productionOperationIncome }</span>
                                </div>
                                <div className={ !this.state.wageSumData.transterIncome||this.state.wageSumData.transterIncome == 0 ? style.non_active+" "+style.transference_income+" "+style.income_item : style.transference_income+" "+style.income_item }>
                                    <span className={style.legend_icon}/>
                                    <span className={style.legend_label}>转移性收入</span>
                                    <span className={style.legend_value}>￥{ this.state.wageSumData.transterIncome }</span>
                                </div>
                                <div className={ !this.state.wageSumData.wageIncome||this.state.wageSumData.wageIncome == 0 ? style.non_active+" "+style.salary_income+" "+style.income_item  : style.salary_income+" "+style.income_item }>
                                    <span className={style.legend_icon}/>
                                    <span className={style.legend_label}>工资收入</span>
                                    <span className={style.legend_value}>￥{ this.state.wageSumData.wageIncome }</span>
                                </div>
                                <div className={ !this.state.wageSumData.propertyIncome||this.state.wageSumData.propertyIncome == 0 ? style.non_active+" "+style.property_income+" "+style.income_item : style.property_income+" "+style.income_item }>
                                    <span className={style.legend_icon}/>
                                    <span className={style.legend_label}>财产性收入</span>
                                    <span className={style.legend_value}>￥{ this.state.wageSumData.propertyIncome }</span>
                                </div>
                                <div className={ !this.state.wageSumData.otherTransterIncome||this.state.wageSumData.otherTransterIncome == 0 ? style.non_active+" "+style.other_transference_income+" "+style.income_item : style.property_income+" "+style.income_item }>
                                    <span className={style.legend_icon}/>
                                    <span className={style.legend_label}>其他转移性收入</span>
                                    <span className={style.legend_value}>￥{ this.state.wageSumData.otherTransterIncome }</span>
                                </div>
                            </div>
                            <span className={style.middle}/>
                        </div>
                    </div>
                </div>
                <div className={style.pure_income}>
                    <div className={style.panel_title}>纯收入</div>
                    <div className={style.panel_content}>
                        <div className={style.legend_panel}>
                            <div className={style.legend_panel_content}>
                                <div className={ !this.state.pureIncomeData.percapitaNetIncome||this.state.pureIncomeData.percapitaNetIncome == 0 ? style.non_active+" "+style.personal_income+" "+style.income_item : style.personal_income+" "+style.income_item }>
                                    <span className={style.legend_icon}/>
                                    <span className={style.legend_label}>纯收入</span>
                                    <span className={style.legend_value}>￥{ this.state.pureIncomeData.netIncome }</span>
                                </div>
                                <div className={ !this.state.pureIncomeData.netIncome||this.state.pureIncomeData.netIncome == 0 ? style.non_active+" "+style.family_income+" "+style.income_item : style.family_income+" "+style.income_item }>
                                    <span className={style.legend_icon}/>
                                    <span className={style.legend_label}>人均纯收入</span>
                                    <span className={style.legend_value}>￥{ this.state.pureIncomeData.percapitaNetIncome }</span>
                                </div>
                            </div>
                            <span className={style.middle}/>
                        </div>
                        <PurePip data={this.state.pureIncomeData} height="11.171rem" width="32.75rem"/>
                    </div>
                </div>
                <div className={style.other_income}>
                    <div className={style.panel_title}>其他资金</div>
                    <div className={style.panel_content}>
                        <OtherPip data={this.state.otherIncomeData} height="11.171rem" width="32.75rem"/>
                        <div className={style.legend_panel}>
                            <div className={style.legend_panel_content}>
                                <div className={ !this.state.otherIncomeData.productiveExpenditure||this.state.otherIncomeData.productiveExpenditure == 0 ? style.non_active+" "+style.production_pay+" "+style.income_item : style.production_pay+" "+style.income_item }>
                                    <span className={style.legend_icon}/>
                                    <span className={style.legend_label}>生产经营性支出</span>
                                    <span className={style.legend_value}>￥{ this.state.otherIncomeData.productiveExpenditure }</span>
                                </div>
                                <div className={ !this.state.otherIncomeData.pension||this.state.otherIncomeData.pension == 0 ? style.non_active+" "+style.retirement_fund+" "+style.income_item : style.retirement_fund+" "+style.income_item }>
                                    <span className={style.legend_icon}/>
                                    <span className={style.legend_label}>养老保险金</span>
                                    <span className={style.legend_value}>￥{ this.state.otherIncomeData.pension }</span>
                                </div>
                                <div className={ !this.state.otherIncomeData.incomeSecurity||this.state.otherIncomeData.incomeSecurity == 0 ? style.non_active+" "+style.basic_living+" "+style.income_item : style.basic_living+" "+style.income_item }>
                                    <span className={style.legend_icon}/>
                                    <span className={style.legend_label}>低保金</span>
                                    <span className={style.legend_value}>￥{ this.state.otherIncomeData.incomeSecurity }</span>
                                </div>
                                <div className={ !this.state.otherIncomeData.birthControlExpenditure||this.state.otherIncomeData.birthControlExpenditure == 0 ? style.non_active+" "+style.birth_control+" "+style.income_item : style.birth_control+" "+style.income_item }>
                                    <span className={style.legend_icon}/>
                                    <span className={style.legend_label}>计划生育金</span>
                                    <span className={style.legend_value}>￥{ this.state.otherIncomeData.birthControlExpenditure }</span>
                                </div>
                                <div className={ !this.state.otherIncomeData.fiveIncomeSecurity||this.state.otherIncomeData.fiveIncomeSecurity == 0 ? style.non_active+" "+style.insurance_fund+" "+style.income_item : style.insurance_fund+" "+style.income-item }>
                                    <span className={style.legend_icon}/>
                                    <span className={style.legend_label}>五保金</span>
                                    <span className={style.legend_value}>￥{ this.state.otherIncomeData.fiveIncomeSecurity }</span>
                                </div>
                                <div className={ !this.state.otherIncomeData.ecologicalSecurityFund||this.state.otherIncomeData.ecologicalSecurityFund == 0 ? style.non_active+" "+style.ecological_ensurence+" "+style.income_item : style.ecological_ensurence+" "+style.income_item }>
                                    <span className={style.legend_icon}/>
                                    <span className={style.legend_label}>生态保障金</span>
                                    <span className={style.legend_value}>￥{ this.state.otherIncomeData.ecologicalSecurityFund }</span>
                                </div>
                            </div>
                            <span className={style.middle}/>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}
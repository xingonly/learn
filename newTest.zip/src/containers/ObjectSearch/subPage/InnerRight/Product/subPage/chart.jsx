// 上帝保佑,永无bug
import React, {Component} from "react";
import echarts from 'echarts';
/*import {immutableRenderDecorator} from 'react-immutable-render-mixin';

@immutableRenderDecorator*/
export default class Line extends Component {

    constructor(props){
        super(props);
        this.state = {
            colorData: ['#3c96a1','#d3a905','#5f4d7f','#b0704d','#e13d25','#56946f','#b59471','#155ca3','#bcceb8'],
            nameData: ['耕地面积','有效灌溉面积','田','土','林地面积','退耕还林面积','林果面积','牧草地面积','水面面积']
        }
    }

    componentDidMount = () =>{
        let  myChart = echarts.init(document.getElementById('line'));
        myChart.setOption(this.setOption(this.props.data));
    };

    componentDidUpdate = () =>{
        console.log(213);
    };

    setOption = (data, zoom) => {
        let arrName = [],
            arrValue = [];
        for(let item of data){
            arrName.push(item.name);
            arrValue.push(item.value);
        }
        let option = {
            tooltip : {
                trigger: 'axis',
                axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                    type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                },
                formatter: '{b0}: {c0}亩'
            },
            grid: {
                left: '10%',
                right: '6%',
                bottom: 10
            },
            xAxis : [
                {
                    type : 'category',
                    data: arrName,
                    axisTick: {
                        show: false
                    },
                    axisLabel: {
                        show:false
                    },
                    axisLine: {
                        lineStyle: {
                            color: '#07a9b6'
                        }
                    }
                }
            ],
            yAxis : [
                {
                    // type : 'category',
                    // data : ['10','20','30','40'],
                    name: '单位(亩)',
                    axisTick: {
                        show: false
                    },
                    splitLine: {
                        show: false
                    },
                    axisLine: {
                        lineStyle: {
                            color: '#07a9b6'
                        }
                    }
                }
            ],
            series : [
                {
                    name:'',
                    type:'bar',
                    barWidth: 15,
                    data:arrValue,
                    itemStyle: {
                        barBorderRadius:40,
                        normal: {
                            color: function(params) {
                                var colorList = ['#3c96a1','#d3a905','#5f4d7f','#b0704d','#e13d25','#56946f','#b59471','#155ca3','#bcceb8'];
                                return colorList[params.dataIndex]
                            }
                        }
                    }
                }
            ],
            label: {
                normal: {
                    show: true,
                    position: 'top',
                    formatter: '{c}'
                },
                emphasis: {
                    show: true,
                    position: 'top',
                    formatter: '{c}'
                }
            }
        };
        return option;
    }

    render() {
        return (
            <div className="chart-box">
                <div className="charts" id="line" ></div>
                <div className="labelBox">
                    {
                        this.state.nameData.map((value,index)=>{
                            return <p key={index}><i style={{background: this.state.colorData[index]}}></i><span>{value}</span></p>
                        })
                    }
                </div>
            </div>
        )
    }
}

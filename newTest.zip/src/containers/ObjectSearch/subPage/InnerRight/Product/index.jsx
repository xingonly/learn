// 上帝保佑,永无bug
import React, {Component} from "react";
import {Link} from 'react-router';
import echarts from 'echarts';
import resource from '../../../../../util/resource';
import style from './style.scss';
import {immutableRenderDecorator} from 'react-immutable-render-mixin';
import Title from 'components/Title'
import have from '../images/have.png'
import noImage from '../images/noImage.png'
import ShowImage from 'components/showImage'
import RenderInBody from './subPage/alert'

@immutableRenderDecorator
export default class Life extends Component {
    constructor(props){
        super(props);
        this.state = {
            zf: null,
            jd: null,
            sh: null,
            grayData: null,
            colorData: ['#3c96a1','#d3a905','#5f4d7f','#b0704d','#e13d25','#56946f','#b59471','#155ca3','#bcceb8'],
            nameData: ['耕地面积','有效灌溉面积','田','土','林地面积','退耕还林面积','林果面积','牧草地面积','水面面积'],
            showAlert:''
        }
    }
    componentDidMount = () => {
        let fid = JSON.parse( sessionStorage.getItem( "ID" )).fid;
        this.getZFData(fid);
        this.getJDData(fid);
        this.getSHData(fid);
        this.getSCData(fid);
        //document.addEventListener('click',this.setDisplay)
    };


    setDisplay = () =>{
        this.refs.fjImg.style.display = 'none';
    }

    changeImg = (e) =>{
        e.nativeEvent.stopImmediatePropagation();
        this.refs.fjImg.style.display = 'block';
    };

    preventDf = (e) =>{
        e.nativeEvent.stopImmediatePropagation();
    }

    //住房条件
    getZFData = (id) =>{
        resource.get('/xixiu-server/poorFamilyInfo/getPoorFamilyHousing/'+id).then((res)=>{
            if(res.status === 200){
                this.setState({
                    zf: res.data
                })
            }
        })
    };

    //家电
    getJDData = (id) =>{
        resource.get('/xixiu-server/poorFamilyInfo/getPoorFamilyHouseholdAppliances/'+id).then((res)=>{
            if(res.status === 200){
                this.setState({
                    jd: res.data
                })
            }
        })
    };

    //生活
    getSHData = (id) =>{
        resource.get('/xixiu-server/poorFamilyInfo/getPoorFamilyLivingCondition/'+id).then((res)=>{
            if(res.status === 200){
                this.setState({
                    sh: res.data
                })
            }
        })
    };

    //生产
    getSCData = (id) =>{
        resource.get('/xixiu-server/dataStatistics/getPoorFamilyProductionCondition/'+id).then((res)=>{
            if(res.status === 200){
                let  myChart = echarts.init(document.getElementById('line'));
                myChart.setOption(this.setOption(res.data));
            }
        })
    };

    setOption = (data) => {
        let arrName = [],
            arrValue = [];
        for(let item of data){
            arrName.push(item.name);
            arrValue.push(item.value ? item.value :0);
        }
        this.setState({
            grayData : arrValue
        })
        let option = {
            tooltip : {
                trigger: 'axis',
                axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                    type : 'line'        // 默认为直线，可选为：'line' | 'shadow'
                },
                formatter: '{b0}: {c0}亩'
            },
            grid: {
                left: '10%',
                right: '6%',
                bottom: 30,
                top: 30,
            },
            xAxis : [
                {
                    type : 'category',
                    data: arrName,
                    axisTick: {
                        show: false
                    },
                    axisLabel: {
                        show:true
                    },
                    axisLine: {
                        lineStyle: {
                            color: '#939394'
                        }
                    }
                }
            ],
            yAxis : [
                {
                    // type : 'category',
                    // data : ['10','20','30','40'],
                    name: '单位(亩)',
                    axisTick: {
                        show: false
                    },
                    splitLine: {
                        show: false
                    },
                    axisLine: {
                        lineStyle: {
                            color: '#939394'
                        }
                    }
                }
            ],
            series : [
                {
                    name:'',
                    type:'bar',
                    barWidth: 15,
                    data:arrValue,
                    itemStyle: {
                        normal: {
                            barBorderRadius:40,
                            color: function(params) {
                                var colorList = ['#3c96a1','#d3a905','#5f4d7f','#b0704d','#e13d25','#56946f','#b59471','#155ca3','#bcceb8'];
                                return colorList[params.dataIndex]
                            }
                        },
                        emphasis:{
                            shadowColor: '#07a9b6',
                            shadowBlur: 10,
                            shadowOffsetX: 0,
                            shadowOffsetY: 0
                        }
                    }
                }
            ],
            label: {
                normal: {
                    show: true,
                    position: 'top',
                    formatter: '{c}'
                },
                emphasis: {
                    show: true,
                    position: 'top',
                    formatter: '{c}'
                }
            }
        };
        return option;
    }

    componentWillUnmount = () =>{
        document.removeEventListener('click',this.setDisplay);
    }

    handleShow = (url) => {
        let state = { ...this.state };
        state.showAlert  = <RenderInBody><ShowImage handleClose = { () => this.handleCancel() } url={url}/></RenderInBody>;
         this.setState(state);
    }

    handleCancel = () => {
        let state = this.state;
        state.showAlert = '';
        this.setState(state);
    }

    handleError = (str) => {
        let state = this.state;
        state[str] = true;
        this.setState(state);
    }

    render() {
        let {showAlert} = this.state;
        return (
            <div className={style.containerLife}>
                <Title name="住房条件" />{/*
                <p className={style.commonTitle} style={{marginTop: '0.5rem'}}>住房</p>*/}
                {
                    this.state.zf ? <div className={style.container}>
                        <div className={this.state.zf.area > 0  ? style.common :style.common}>
                            <b>{this.state.zf.area}</b>
                            <p>住房面积(平方米)</p>
                            {
                                this.state.zf && this.state.zf.areaPic && !this.state.areaPic ?
                                    <img
                                        src={have}
                                        alt=""
                                        onClick={() => this.handleShow(this.state.zf.areaPic)}
                                        style={{cursor:'pointer'}}
                                    />:
                                    <img
                                        src={noImage}
                                        alt=""
                                    />

                            }
                            <img src={this.state.zf.areaPic} onError={() => this.handleError('areaPic')} style={{display:'none'}}/>
                        </div>
                        <div className={this.state.zf.dangerous ? style.common :style.common}>
                            <b>{this.state.zf.dangerous ? '是':'否'}</b>
                            <p>主要住房是否危房</p>
                            {
                                this.state.zf && this.state.zf.dangerousPic && !this.state.dangerousPic ?
                                <img
                                src={have}
                                alt=""
                                onClick={() => this.handleShow(this.state.zf.dangerousPic)}
                                style={{cursor:'pointer'}}
                                />:
                                    <img
                                        src={noImage}
                                        alt=""
                                    />

                            }
                            <img src={this.state.zf.dangerousPic} onError={() => this.handleError('dangerousPic')} style={{display:'none'}}/>
                        </div>
                        <div className={this.state.zf.sanitaryToilet ? style.common :style.common}>
                            <b>{this.state.zf.sanitaryToilet ? '是':'否'}</b>
                            <p>有无卫生厕所</p>
                            {
                            this.state.zf && this.state.zf.sanitaryToiletPic && !this.state.sanitaryToiletPic ?
                                <img
                                    src={have}
                                    alt=""
                                    onClick={() => this.handleShow(this.state.zf.sanitaryToiletPic)}
                                    style={{cursor:'pointer'}}
                                />:
                                <img
                                    src={noImage}
                                    alt=""
                                />

                        }
                            <img src={this.state.zf.sanitaryToiletPic} onError={() => this.handleError('sanitaryToiletPic')} style={{display:'none'}}/>
                        </div>
                        <div className={this.state.zf.fuelTtype ? style.common + ' ' :style.common}>
                            <b>{this.state.zf.fuelType ? this.state.zf.fuelType:'其它'}</b>
                            <p>主要燃料类型</p>
                            {
                                this.state.zf && this.state.zf.fuelTypePic && !this.state.fuelTypePic ?
                                    <img
                                        src={have}
                                        alt=""
                                        onClick={() => this.handleShow(this.state.zf.fuelTypePic)}
                                        style={{cursor:'pointer'}}
                                    />:
                                    <img
                                        src={noImage}
                                        alt=""
                                    />

                            }
                            <img src={this.state.zf.fuelTypePic} onError={() => this.handleError('fuelTypePic')} style={{display:'none'}}/>
                        </div>
                        <div className={this.state.zf.buildingTime ? style.common + ' ':style.common}>
                            <b>{this.state.zf.buildingTime || '---'}</b>
                            <p>建房时间</p>
                        </div>
                        <div className={this.state.zf.mainBuildingStructure ? style.common + ' ':style.common}>
                            <b>{this.state.zf.mainBuildingStructure ? this.state.zf.mainBuildingStructure:'其它'}</b>
                            <p>房屋主要结构</p>
                            {
                                this.state.zf && this.state.zf.mainBuildingStructurePic && !this.state.mainBuildingStructurePic ?
                                    <img
                                        src={have}
                                        alt=""
                                        onClick={() => this.handleShow(this.state.zf.mainBuildingStructurePic)}
                                        style={{cursor:'pointer'}}
                                    />:
                                    <img
                                        src={noImage}
                                        alt=""
                                    />

                            }
                            <img src={this.state.zf.mainBuildingStructurePic} onError={() => this.handleError('mainBuildingStructurePic')} style={{display:'none'}}/>
                        </div>
                        <div className={this.state.zf.relocationPovertyRelief ? style.common + ' ':style.common}>
                            <b>{this.state.zf.relocationPovertyRelief ? '有':'无'}</b>
                            <p>易地扶贫搬迁情况</p>
                            {/*{
                                this.state.zf && this.state.zf.relocationPovertyReliefPic && !this.state.relocationPovertyReliefPic ?
                                    <img
                                        src={have}
                                        alt=""
                                        onClick={() => this.handleShow(this.state.zf.relocationPovertyReliefPic)}
                                        style={{cursor:'pointer'}}
                                    />:
                                    <img
                                        src={noImage}
                                        alt=""
                                    />

                            }
                            <img src={this.state.zf.relocationPovertyReliefPic} onError={() => this.handleError('relocationPovertyReliefPic')} style={{display:'none'}}/>*/}
                        </div>
                    </div>:null
                }
                <Title name="家电条件" />
                {
                    this.state.jd ? <div className={style.container}>
                        <div className={this.state.jd.washingMachine > 0  ? style.common :style.common}>
                            <b>{this.state.jd.washingMachine ? '有':'无'}</b>
                            <p>洗衣机</p>
                            {
                                this.state.jd && this.state.jd.washingMachinePic && !this.state.washingMachinePic ?
                                    <img
                                        src={have}
                                        alt=""
                                        onClick={() => this.handleShow(this.state.jd.washingMachinePic)}
                                        style={{cursor:'pointer'}}
                                    />:
                                    <img
                                        src={noImage}
                                        alt=""
                                    />

                            }
                            <img src={this.state.jd.washingMachinePic ? this.state.jd.washingMachinePic  :''} onError={() => this.handleError('washingMachinePic')} style={{display:'none'}}/>
                        </div>
                        <div className={this.state.jd.refrigerator > 0  ? style.common :style.common}>
                            <b>{this.state.jd.refrigerator ? '有':'无'}</b>
                            <p>电冰箱</p>
                            {
                                this.state.jd && this.state.jd.refrigeratorPic && !this.state.refrigeratorPic ?
                                    <img
                                        src={have}
                                        alt=""
                                        onClick={() => this.handleShow(this.state.jd.refrigeratorPic)}
                                        style={{cursor:'pointer'}}
                                    />:
                                    <img
                                        src={noImage}
                                        alt=""
                                    />

                            }
                            <img src={this.state.jd.refrigeratorPic} onError={() => this.handleError('refrigeratorPic')} style={{display:'none'}}/>
                        </div>
                        <div className={this.state.jd.colorTv > 0  ? style.common :style.common}>
                            <b>{this.state.jd.colorTv ? '有':'无'}</b>
                            <p>彩色电视机</p>
                            {
                                this.state.jd && this.state.jd.colorTvPic && !this.state.colorTvPic ?
                                    <img
                                        src={have}
                                        alt=""
                                        onClick={() => this.handleShow(this.state.jd.colorTvPic)}
                                        style={{cursor:'pointer'}}
                                    />:
                                    <img
                                        src={noImage}
                                        alt=""
                                    />

                            }
                            <img src={this.state.jd.colorTvPic} onError={() => this.handleError('colorTvPic')} style={{display:'none'}}/>
                        </div>
                        <div className={this.state.jd.airconditioning > 0  ? style.common :style.common}>
                            <b>{this.state.jd.airconditioning ? '有':'无'}</b>
                            <p>空调</p>
                            {
                                this.state.jd && this.state.jd.airconditioningPic && !this.state.airconditioningPic ?
                                    <img
                                        src={have}
                                        alt=""
                                        onClick={() => this.handleShow(this.state.jd.airconditioningPic)}
                                        style={{cursor:'pointer'}}
                                    />:
                                    <img
                                        src={noImage}
                                        alt=""
                                    />

                            }
                            <img src={this.state.jd.airconditioningPic} onError={() => this.handleError('airconditioningPic')} style={{display:'none'}}/>
                        </div>
                        <div className={this.state.jd.waterHeater > 0  ? style.common :style.common}>
                            <b>{this.state.jd.waterHeater ? '有':'无'}</b>
                            <p>热水器</p>
                            {
                                this.state.jd && this.state.jd.waterHeaterPic && !this.state.waterHeaterPic ?
                                    <img
                                        src={have}
                                        alt=""
                                        onClick={() => this.handleShow(this.state.jd.waterHeaterPic)}
                                        style={{cursor:'pointer'}}
                                    />:
                                    <img
                                        src={noImage}
                                        alt=""
                                    />

                            }
                            <img src={this.state.jd.waterHeaterPic} onError={() => this.handleError('waterHeaterPic')} style={{display:'none'}}/>
                        </div>
                        <div className={this.state.jd.fixedTelephone > 0  ? style.common:style.common}>
                            <b>{this.state.jd.fixedTelephone ? '有':'无'}</b>
                            <p>固定电话</p>
                            {
                                this.state.jd && this.state.jd.fixedTelephonePic && !this.state.fixedTelephonePic ?
                                    <img
                                        src={have}
                                        alt=""
                                        onClick={() => this.handleShow(this.state.jd.fixedTelephonePic)}
                                        style={{cursor:'pointer'}}
                                    />:
                                    <img
                                        src={noImage}
                                        alt=""
                                    />

                            }
                            <img src={this.state.jd.fixedTelephonePic} onError={() => this.handleError('fixedTelephonePic')} style={{display:'none'}}/>
                        </div>
                        <div className={this.state.jd.mobileTelephone > 0  ? style.common :style.common}>
                            <b>{this.state.jd.mobileTelephone ? '有':'无'}</b>
                            <p>移动电话</p>
                            {
                                this.state.jd && this.state.jd.mobileTelephonePic && !this.state.mobileTelephonePic ?
                                    <img
                                        src={have}
                                        alt=""
                                        onClick={() => this.handleShow(this.state.jd.mobileTelephonePic)}
                                        style={{cursor:'pointer'}}
                                    />:
                                    <img
                                        src={noImage}
                                        alt=""
                                    />

                            }
                            <img src={this.state.jd.mobileTelephonePic} onError={() => this.handleError('mobileTelephonePic')} style={{display:'none'}}/>
                        </div>
                        <div className={this.state.jd.agriculturalMachineryPic > 0  ? style.common :style.common}>
                            <b>{this.state.jd.agriculturalMachineryPic ? '有':'无'}</b>
                            <p>农业机器</p>
                            {
                                this.state.jd && this.state.jd.agriculturalMachineryPic && !this.state.agriculturalMachineryPic ?
                                    <img
                                        src={have}
                                        alt=""
                                        onClick={() => this.handleShow(this.state.jd.agriculturalMachineryPic)}
                                        style={{cursor:'pointer'}}
                                    />:
                                    <img
                                        src={noImage}
                                        alt=""
                                    />

                            }
                            <img src={this.state.jd.agriculturalMachineryPic} onError={() => this.handleError('agriculturalMachineryPic')} style={{display:'none'}}/>
                        </div>
                    </div>:null
                }
                <Title name="生活条件" />
                {
                    this.state.sh ? <div className={style.container}>
                        <div className={this.state.sh.drinkingWaterDifficult? style.common :style.common}>
                            <b>{this.state.sh.drinkingWaterDifficult ? '是':'无'}</b>
                            <p>饮水是否困难</p>
                            {
                                this.state.sh && this.state.sh.drinkingWaterDifficultPic && !this.state.drinkingWaterDifficultPic ?
                                    <img
                                        src={have}
                                        alt=""
                                        onClick={() => this.handleShow(this.state.sh.drinkingWaterDifficultPic)}
                                        style={{cursor:'pointer'}}
                                    />:
                                    <img
                                        src={noImage}
                                        alt=""
                                    />

                            }
                            <img src={this.state.sh.drinkingWaterDifficultPic} onError={() => this.handleError('drinkingWaterDifficultPic')} style={{display:'none'}}/>
                        </div>
                        <div className={this.state.sh.drinkingWaterSafe? style.common :style.common}>
                            <b>{this.state.sh.drinkingWaterSafe ? '是':'无'}</b>
                            <p>饮水是否安全</p>
                            {
                                this.state.sh && this.state.sh.drinkingWaterSafePic && !this.state.drinkingWaterSafePic ?
                                    <img
                                        src={have}
                                        alt=""
                                        onClick={() => this.handleShow(this.state.sh.drinkingWaterSafePic)}
                                        style={{cursor:'pointer'}}
                                    />:
                                    <img
                                        src={noImage}
                                        alt=""
                                    />

                            }
                            <img src={this.state.sh.drinkingWaterSafePic} onError={() => this.handleError('drinkingWaterSafePic')} style={{display:'none'}}/>
                        </div>
                        <div className={this.state.sh.drinkingSituation ? style.common :style.common}>
                            <b>{this.state.sh.drinkingSituation || '-'}</b>
                            <p>饮水情况</p>
                            {
                                this.state.sh && this.state.sh.drinkingSituationPic && !this.state.drinkingSituationPic ?
                                    <img
                                        src={have}
                                        alt=""
                                        onClick={() => this.handleShow(this.state.sh.drinkingSituationPic)}
                                        style={{cursor:'pointer'}}
                                    />:
                                    <img
                                        src={noImage}
                                        alt=""
                                    />

                            }
                            <img src={this.state.sh.drinkingSituationPic} onError={() => this.handleError('drinkingSituationPic')} style={{display:'none'}}/>
                        </div>
                        <div className={this.state.sh.lifeElectricity? style.common :style.common}>
                            <b>{this.state.sh.lifeElectricity ? '是':'无'}</b>
                            <p>是否通生活用电</p>
                            {
                                this.state.sh && this.state.sh.lifeElectricityPic && !this.state.lifeElectricityPic ?
                                    <img
                                        src={have}
                                        alt=""
                                        onClick={() => this.handleShow(this.state.sh.lifeElectricityPic)}
                                        style={{cursor:'pointer'}}
                                    />:
                                    <img
                                        src={noImage}
                                        alt=""
                                    />

                            }
                            <img src={this.state.sh.lifeElectricityPic} onError={() => this.handleError('lifeElectricityPic')} style={{display:'none'}}/>
                        </div>
                        <div className={this.state.sh.broadcastTelevision? style.common :style.common}>
                            <b>{this.state.sh.broadcastTelevision ? '是':'无'}</b>
                            <p>是否通广播电视</p>
                            {
                                this.state.sh && this.state.sh.broadcastTelevisionPic && !this.state.broadcastTelevisionPic ?
                                    <img
                                        src={have}
                                        alt=""
                                        onClick={() => this.handleShow(this.state.sh.broadcastTelevisionPic)}
                                        style={{cursor:'pointer'}}
                                    />:
                                    <img
                                        src={noImage}
                                        alt=""
                                    />

                            }
                            <img src={this.state.sh.broadcastTelevisionPic} onError={() => this.handleError('broadcastTelevisionPic')} style={{display:'none'}}/>
                        </div>
                        <div className={this.state.sh.distanceMainRoad > 0  ? style.common:style.common}>
                            <b>{this.state.sh.distanceMainRoad>0 ? this.state.sh.distanceMainRoad : '暂无'}</b>
                            <p>距离村主干路(公里)</p>
                            {
                                this.state.sh && this.state.sh.distanceMainRoadPic && !this.state.distanceMainRoadPic ?
                                    <img
                                        src={have}
                                        alt=""
                                        onClick={() => this.handleShow(this.state.sh.distanceMainRoadPic)}
                                        style={{cursor:'pointer'}}
                                    />:
                                    <img
                                        src={noImage}
                                        alt=""
                                    />

                            }
                            <img src={this.state.sh.distanceMainRoadPic} onError={() => this.handleError('distanceMainRoadPic')} style={{display:'none'}}/>
                        </div>
                        <div className={this.state.sh.homeRoadType? style.common :style.common}>
                            <b>{this.state.sh.homeRoadType || '-'}</b>
                            <p>入户路类型</p>
                            {
                                this.state.sh && this.state.sh.homeRoadTypePic && !this.state.homeRoadTypePic ?
                                    <img
                                        src={have}
                                        alt=""
                                        onClick={() => this.handleShow(this.state.sh.homeRoadTypePic)}
                                        style={{cursor:'pointer'}}
                                    />:
                                    <img
                                        src={noImage}
                                        alt=""
                                    />

                            }
                            <img src={this.state.sh.homeRoadTypePic} onError={() => this.handleError('homeRoadTypePic')} style={{display:'none'}}/>
                        </div>
                        <div className={this.state.sh.farmersCooperative? style.common :style.common}>
                            <b>{this.state.sh.farmersCooperative ? '是':'否'}</b>
                            <p>是否加入农合作社</p>
                            {
                                this.state.sh && this.state.sh.farmersCooperativePic && !this.state.farmersCooperativePic ?
                                    <img
                                        src={have}
                                        alt=""
                                        onClick={() => this.handleShow(this.state.sh.farmersCooperativePic)}
                                        style={{cursor:'pointer'}}
                                    />:
                                    <img
                                        src={noImage}
                                        alt=""
                                    />

                            }
                            <img src={this.state.sh.farmersCooperativePic} onError={() => this.handleError('farmersCooperativePic')} style={{display:'none'}}/>
                        </div>
                        <div className={this.state.sh.toilet	? style.common :style.common}>
                            <b>{this.state.sh.toilet ? '是':'否'}</b>
                            <p>厕所改造完成</p>
                            {
                                this.state.sh && this.state.sh.toiletPic && !this.state.toiletPic ?
                                    <img
                                        src={have}
                                        alt=""
                                        onClick={() => this.handleShow(this.state.sh.toiletPic)}
                                        style={{cursor:'pointer'}}
                                    />:
                                    <img
                                        src={noImage}
                                        alt=""
                                    />

                            }
                            <img src={this.state.sh.toiletPic} onError={() => this.handleError('toiletPic')} style={{display:'none'}}/>
                        </div>
                        <div className={this.state.sh.sty? style.common :style.common}>
                            <b>{this.state.sh.sty ? '是':'否'}</b>
                            <p>圈社改造情况</p>
                            {
                                this.state.sh && this.state.sh.styPic && !this.state.styPic ?
                                    <img
                                        src={have}
                                        alt=""
                                        onClick={() => this.handleShow(this.state.sh.styPic)}
                                        style={{cursor:'pointer'}}
                                    />:
                                    <img
                                        src={noImage}
                                        alt=""
                                    />

                            }
                            <img src={this.state.sh.styPic} onError={() => this.handleError('styPic')} style={{display:'none'}}/>
                        </div>
                        <div className={this.state.sh.kitchen? style.common :style.common}>
                            <b>{this.state.sh.kitchen ? '是':'否'}</b>
                            <p>厨房改造完成</p>
                            {
                                this.state.sh && this.state.sh.kitchenPic && !this.state.kitchenPic ?
                                    <img
                                        src={have}
                                        alt=""
                                        onClick={() => this.handleShow(this.state.sh.kitchenPic)}
                                        style={{cursor:'pointer'}}
                                    />:
                                    <img
                                        src={noImage}
                                        alt=""
                                    />

                            }
                            <img src={this.state.sh.kitchenPic} onError={() => this.handleError('kitchenPic')} style={{display:'none'}}/>
                        </div>
                       {/* <div className={this.state.sh.net? style.common :style.common}>
                            <b>{this.state.sh.net ? '是':'否'}</b>
                            <p>广电网络完成</p>
                            {
                                this.state.sh && this.state.sh.netPic && !this.state.netPic ?
                                    <img
                                        src={have}
                                        alt=""
                                        onClick={() => this.handleShow(this.state.sh.netPic)}
                                        style={{cursor:'pointer'}}
                                    />:
                                    <img
                                        src={noImage}
                                        alt=""
                                    />

                            }
                            <img src={this.state.sh.netPic} onError={() => this.handleError('netPic')} style={{display:'none'}}/>
                        </div>*/}
                    </div>:null
                }
                <Title name="生产条件" />
                <div className={style.chartBox}>
                    <div className={style.charts} id="line" ></div>
                    {/*<div className={style.labelBox}>
                        {
                            this.state.grayData && this.state.nameData.map((value,index)=>{
                                return <p key={index} className={this.state.grayData[index] > 0 ? '':style.gray}><i style={{background: this.state.grayData[index]>0 ? this.state.colorData[index]:'#474955'}}></i><span>{value}</span></p>
                            })
                        }
                    </div>*/}
                </div>{/*
                <div className={style.fjBox} ref="fjImg">
                    <div className={style.imgBox} onClick={this.preventDf}>
                        <img src={this.state.zf ? this.state.zf.houseImg:null} alt=""/>
                    </div>
                </div>*/}
                {showAlert}
            </div>
        );
    }
}
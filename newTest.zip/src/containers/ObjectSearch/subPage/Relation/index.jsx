// 上帝保佑,永无bug

import React, {Component} from "react"
import { immutableRenderDecorator } from 'react-immutable-render-mixin'
import d3 from 'd3'
import eventEmitter from '../../../../util/eventEmitter'
import resource from '../../../../util/resource'
import male from '../../images/male.png'

import style from './style.scss'


@immutableRenderDecorator
export default class Relation extends Component {

    constructor(props) {
        super(props);
        this.svg = null      // svg标签
        this.wrap = null    // 最外层g
        this.gNodes = null
        this.gTexts = null
        this.gLines = null
        this.ghead = null
        this.removes = null
        this.preTarget = null   // 上一次点中的部门
        this.departments = [{name: '公安云', className: 'gongan cloud'}, {name: '移民云', className: 'yimin cloud'}, {name: '卫计云', className: 'weiji cloud'},
            {name: '民政云', className: 'minzheng cloud'}, {name: '教育云', className: 'jiaoyu cloud'},{name: '扶贫云', className: 'fpb lightfpb'}, {name: '人社云', className: 'renshe cloud'},
            {name: '建设云', className: 'jianshe cloud'}, {name: '工商云', className: 'gongshang cloud'}, {name: '水利云', className: 'shuili cloud'}, {name: '国土云', className: 'guotu cloud'}]
        // this.

        this.state = {
            id: ''
        };
    }

    componentWillUnmount() {
        document.removeEventListener('click', this.clickDocument)
    }

    componentDidMount() {


        this.svg = d3.select('#svg')
        // 最外层g
        this.wrap = d3.select('.gwrap')
        // 节点最外层g
        this.gNodes = d3.select('.gnodes')
        // 文字最外层g
        this.gTexts = d3.select('.gtexts')
        // 连线最外层g
        this.gLines = d3.select('.glines')

        // 拖拽事件
        this.drag()

        eventEmitter.addListener('changeIdNumber', (fid, id, idnumber) => {
            d3.select('#msk').attr({'opacity': 0});
            this.gNodes.selectAll('.remove').remove();
            this.gTexts.selectAll('.remove').remove();
            this.gLines.selectAll('.remove').remove();
            d3.select('#ghead').remove();
            this.setState({
                id: idnumber
            });
            this.queryList(idnumber);
        });

        document.addEventListener('click', this.clickDocument)

    };


    queryList = (id) => {

        resource.get('/xixiu-server/welfareshow/getDepartmentDiferent?idnumber=' + id).then(res => {
            if(res.data){
                let windowRect = document.body.getBoundingClientRect()
                // 画中间头像
                this.drawTitle(windowRect)
                document.querySelector('#imgNotFound').src = res.data.fpb.dataDetail.headurl
                d3.select('#gheadImage').attr('xlink:href', res.data.fpb.dataDetail.headurl)
                // 画节点
                this.drawNodes(windowRect, res.data)
            }
        })
    }


    drag = () => {
        let mouseDown = {left: 0, top: 0}
        let zoom = d3.behavior.zoom()
            .scaleExtent([0.3, 3])
            .on('zoom', () => {
                this.wrap.attr('transform', 'translate(' + d3.event.translate + ')scale(' + d3.event.scale + ')');
            })
        let drag = d3.behavior.drag()
            .on('drag', () => {
                this.wrap.attr('style', 'left: ' + event.pageX  + 'px; top' + event.pageY + 'px');
            })
        this.svg.call(drag).call(zoom)
    }

    /*
     *   画头像
     */
    drawTitle = (windowRect) => {
        this.ghead  = d3.select('.ghead').append('circle').attr({id: 'ghead', cx: windowRect.width / 2, cy: windowRect.height / 2, r: 53, fill: 'url(#raduisImage)'})
        d3.select('#msk').attr({x: windowRect.width / 2 - 45, y: windowRect.height / 2 - 30, 'opacity': 1})
    }

    drawNodes = (windowRect, data) => {
        // 循环的临时部门的类名
        let className = ''
        // 循环的临时部门
        let department = null

        let fpb = data.fpb.dataDetail

        let idnumber = fpb.idnumber
        idnumber = idnumber.substr(0,10) + '****' + idnumber.substr(14)
        // let nodes = [{name: '姓名: -', className: 'guotu'}, {name: '是无有房屋类不动产登记信息: -', className: 'guotu'}, {name: '姓名: -', className: 'guotu'}, {name: '姓名: -', className: 'guotu'}];
        let nodes = [{name: `姓名: ${fpb.full_name.substr(0, fpb.full_name.length - 1) + '*' || '-'}`, className: 'fpb'}, {name: `身份证号: ${idnumber || '-'}`, className: 'fpb'},
            {name: `性别: ${fpb.gender || '-'}`, className: 'fpb'}, {name: `家庭住址: ${fpb.homeAddress || '-'}`, className: 'fpb'}]

        // 画第一圈各种云
        for (let i = 0, len = this.departments.length; i < len; i++) {
            let color = ''
            className = this.departments[i].className
            className = className.slice(0, className.indexOf(' '))

            // 遇到扶贫云退出该次循环
            if (className === 'fpb') {
                this.drawNode(this.departments[i], (Math.PI * 2) / len, 28, i, 42, 230, '#f28c08', 0, windowRect, this.ghead)
                continue
            }

            department = data[className]           // 当前部门

            // 第一圈的颜色
            switch (department.dataStatus['data_status']) {
                case -1:                                   // 无数据
                    color = '#bfbfbf'
                    break
                case 0:                                   // 正常
                    color = '#9de0c1'
                    break
                case  1:                                  // 异常
                    color = '#c52824'
                    break
            }

            // 填充数据
            if (department.dataStatus['data_status'] !== -1) {
                let dataDetail = department.dataDetail
                switch (className) {
                    case 'renshe':
                        dataDetail.full_name ? nodes.push({name: `姓名: ${dataDetail.full_name.substr(0, dataDetail.full_name.length - 1) + '*'}`, className: 'renshe full_name'}) : nodes.push({name: '姓名: -', className: 'renshe full_name'});
                        dataDetail.gender ? nodes.push({name: `性别: ${dataDetail.gender === 1 ? '男' : dataDetail.gender === 2 ? '女' : '未知'}`, className: 'renshe gender'}) : nodes.push({name: '性别: -', className: 'renshe gender'});
                        dataDetail.resident_pension !== null ? nodes.push({name: `参保状态: ${dataDetail.resident_pension === 1 ? '正常参保' : '终止参保'}`, className: 'renshe resident_pension'}) : nodes.push({name: '参保状态: -', className: 'renshe resident_pension'});
                        dataDetail.job_date ? nodes.push({name: `就业日期: ${dataDetail.job_date}`, className: 'renshe job_date'}) : nodes.push({name: '就业日期: -', className: 'renshe job_date'});
                        dataDetail.jiuye_source_type ? nodes.push({name: `就业类型: ${dataDetail.jiuye_source_type}`, className: 'renshe jiuye_source_type'}) : nodes.push({name: '就业类型: -', className: 'renshe jiuye_source_type'});
                        dataDetail.isactive ? nodes.push({name: `当前就业是否有效: ${dataDetail.isactive}`, className: 'renshe isactive'}) : nodes.push({name: '当前就业是否有效: -', className: 'renshe isactive'});
                        dataDetail.jy_sy_djz ? nodes.push({name: `就业失业登记证: ${dataDetail.jy_sy_djz}`, className: 'renshe jy_sy_djz'}) : nodes.push({name: '就业失业登记证: -', className: 'renshe jy_sy_djz'});
                        dataDetail.yanglao_address ? nodes.push({name: `参保人地址: ${dataDetail.yanglao_address}`, className: 'renshe yanglao_address'}) : nodes.push({name: '参保人地址: -', className: 'renshe yanglao_address'});
                        dataDetail.yanglao_source_type ? nodes.push({name: `养老类型: ${dataDetail.yanglao_source_type}`, className: 'renshe yanglao_source_type'}) : nodes.push({name: '养老类型: -', className: 'renshe yanglao_source_type'});
                        dataDetail.yanglao_money ? nodes.push({name: `参保金额: ${dataDetail.yanglao_money}`, className: 'renshe yanglao_money'}) : nodes.push({name: '参保金额: -', className: 'renshe yanglao_money'});
                        dataDetail.jiaofei_years ? nodes.push({name: `参保年度: ${dataDetail.jiaofei_years}`, className: 'renshe jiaofei_years'}) : nodes.push({name: '参保年度: -', className: 'renshe jiaofei_years'});
                        dataDetail.jiaofei_time ? nodes.push({name: `缴费时间: ${dataDetail.jiaofei_time}`, className: 'renshe jiaofei_time'}) : nodes.push({name: '缴费时间: -', className: 'renshe jiaofei_time'});
                        dataDetail.office ? nodes.push({name: `单位名称: ${dataDetail.office}`, className: 'renshe office'}) : nodes.push({name: '单位名称: -', className: 'renshe office'});
                        dataDetail.training_time ? nodes.push({name: `培训时间: ${dataDetail.training_time}`, className: 'renshe training_time'}) : nodes.push({name: '培训时间: -', className: 'renshe training_time'});
                        dataDetail.training_content ? nodes.push({name: `培训内容: ${dataDetail.training_content}`, className: 'renshe training_content'}) : nodes.push({name: '培训内容: -', className: 'renshe training_content'});
                        dataDetail.benefit ? nodes.push({name: `培训补贴金额: ${dataDetail.benefit}`, className: 'renshe benefit'}) : nodes.push({name: '培训补贴金额: -', className: 'renshe benefit'});
                        break
                    case 'jianshe':
                        dataDetail.full_name ? nodes.push({name: `户主姓名: ${dataDetail.full_name.substr(0, dataDetail.full_name.length - 1) + '*'}`, className: 'jianshe full_name'}) : nodes.push({name: '户主姓名: -', className: 'jianshe full_name'});
                        dataDetail.ethnic ? nodes.push({name: `民族: ${dataDetail.ethnic}`, className: 'jianshe ethnic'}) : nodes.push({name: '民族: -', className: 'jianshe ethnic'});
                        dataDetail.population ? nodes.push({name: `家庭人数: ${dataDetail.population}`, className: 'jianshe population'}) : nodes.push({name: '家庭人数: -', className: 'jianshe population'});
                        dataDetail.area ? nodes.push({name: `改造后住房面积: ${dataDetail.area}`, className: 'jianshe area'}) : nodes.push({name: '改造后住房面积: -', className: 'jianshe area'});
                        dataDetail.dangerous ? nodes.push({name: `是否危房: ${dataDetail.dangerous === 1 ? '是' : '否'}`, className: 'jianshe dangerous'}) : nodes.push({name: '是否危房: -', className: 'jianshe dangerous'});
                        dataDetail.danger_type ? nodes.push({name: `改造原因: ${dataDetail.danger_type}`, className: 'jianshe danger_type'}) : nodes.push({name: '改造原因: -', className: 'jianshe danger_type'});
                        dataDetail.transformation_way ? nodes.push({name: `是否贫困残疾家庭: ${dataDetail.transformation_way === 1 ? '是' : '否'}`, className: 'jianshe transformation_way'}) : nodes.push({name: '是否贫困残疾家庭: -', className: 'jianshe transformation_way'});
                        dataDetail.construction_mode ? nodes.push({name: `建设方式: ${dataDetail.construction_mode}`, className: 'jianshe construction_mode'}) : nodes.push({name: '建设方式: -', className: 'jianshe construction_mode'});
                        dataDetail.old_building_area ? nodes.push({name: `旧住房建造面积: ${dataDetail.old_building_area }`, className: 'jianshe old_building_area'}) : nodes.push({name: '旧住房建造面积: -', className: 'jianshe old_building_area'});
                        dataDetail.structure_after_transforming ? nodes.push({name: `改造后房屋结构: ${dataDetail.structure_after_transforming}`, className: 'jianshe structure_after_transforming'}) : nodes.push({name: '改造后房屋结构: -', className: 'jianshe structure_after_transforming'});
                        dataDetail.after_transforming_house_property ? nodes.push({name: `改造后房屋产权: ${dataDetail.after_transforming_house_property}`, className: 'jianshe after_transforming_house_property'}) : nodes.push({name: '改造后房屋产权: -', className: 'jianshe after_transforming_house_property'});
                        dataDetail.years_included_plan ? nodes.push({name: `列入计划年度: ${dataDetail.years_included_plan}`, className: 'jianshe years_included_plan'}) : nodes.push({name: '列入计划年度: -', className: 'jianshe years_included_plan'});
                        dataDetail.old_building_structure ? nodes.push({name: `旧住房建造结构: ${dataDetail.old_building_structure}`, className: 'jianshe old_building_structure'}) : nodes.push({name: '旧住房建造结构: -', className: 'jianshe old_building_structure'});
                        dataDetail.date_approval ? nodes.push({name: `批准日期: ${dataDetail.date_approval}`, className: 'jianshe date_approval'}) : nodes.push({name: '批准日期: -', className: 'jianshe date_approval'});
                        dataDetail.start_date ? nodes.push({name: `开工日期: ${dataDetail.start_date}`, className: 'jianshe start_date'}) : nodes.push({name: '开工日期: -', className: 'jianshe start_date'});
                        dataDetail.completion_date ? nodes.push({name: `竣工日期: ${dataDetail.completion_date}`, className: 'jianshe completion_date'}) : nodes.push({name: '竣工日期: -', className: 'jianshe completion_date'});
                        dataDetail.assistance_fund_type ? nodes.push({name: `享受补助资金类型: ${dataDetail.assistance_fund_type}`, className: 'jianshe assistance_fund_type'}) : nodes.push({name: '享受补助资金类型: -', className: 'jianshe assistance_fund_type'});
                        dataDetail.total_investment ? nodes.push({name: `总投资: ${dataDetail.total_investment}`, className: 'jianshe total_investment'}) : nodes.push({name: '总投资: -', className: 'jianshe total_investment'});
                        dataDetail.government_subsidy_funds ? nodes.push({name: `各级政府补助资金: ${dataDetail.government_subsidy_funds}`, className: 'jianshe government_subsidy_funds'}) : nodes.push({name: '各级政府补助资金: -', className: 'jianshe government_subsidy_funds'});
                        dataDetail.farmers_raised_funds ? nodes.push({name: `农户其他自筹资金: ${dataDetail.farmers_raised_funds}`, className: 'jianshe farmers_raised_funds'}) : nodes.push({name: '农户其他自筹资金: -', className: 'jianshe farmers_raised_funds'});
                        dataDetail.is_commercial_housing ? nodes.push({name: `是否有商品房登记信息: ${dataDetail.is_commercial_housing === 1 ? '是' : '否'}`, className: 'jianshe is_commercial_housing'}) : nodes.push({name: '是否有商品房登记信息: -', className: 'jianshe is_commercial_housing'});
                        dataDetail.buyer ? nodes.push({name: `产权人姓名: ${dataDetail.buyer}`, className: 'jianshe buyer'}) : nodes.push({name: '产权人姓名: -', className: 'jianshe buyer'});
                        break
                    case 'minzheng':
                        dataDetail.full_name ? nodes.push({name: `姓名: ${dataDetail.full_name.substr(0, dataDetail.full_name.length - 1) + '*'}`, className: 'minzheng full_name'}) : nodes.push({name: '姓名: -', className: 'minzheng full_name'});
                        dataDetail.poverty_attribute ? nodes.push({name: `贫困户属性: ${dataDetail.poverty_attribute}`, className: 'minzheng poverty_attribute'}) : nodes.push({name: '贫困户属性 -', className: 'minzheng poverty_attribute'});
                        dataDetail.martyr ? nodes.push({name: `是否军烈属: 是`, className: 'minzheng martyr'}) : nodes.push({name: '是否军烈属: 否', className: 'minzheng martyr'});
                        dataDetail.low_security_amount ? nodes.push({name: `低保金额: ${dataDetail.low_security_amount}`, className: 'minzheng low_security_amount'}) : nodes.push({name: '低保金额 -', className: 'minzheng low_security_amount'});
                        dataDetail.service_length ? nodes.push({name: `服役年限: ${dataDetail.service_length}`, className: 'minzheng service_length'}) : nodes.push({name: '服役年限 -', className: 'minzheng service_length'});
                        dataDetail.living_subsidies ? nodes.push({name: `优抚对象补助金额: ${dataDetail.living_subsidies}`, className: 'minzheng living_subsidies'}) : nodes.push({name: '优抚对象补助金额 -', className: 'minzheng living_subsidies'});
                        dataDetail.youfu_type ? nodes.push({name: `优抚类别: ${dataDetail.youfu_type}`, className: 'minzheng youfu_type'}) : nodes.push({name: '优抚类别 -', className: 'minzheng youfu_type'});
                        dataDetail.low_security_type ? nodes.push({name: `低保类型: ${dataDetail.low_security_type}`, className: 'minzheng low_security_type'}) : nodes.push({name: '低保类型 -', className: 'minzheng low_security_type'});
                        dataDetail.disability_level ? nodes.push({name: `伤残等级: ${dataDetail.disability_level}`, className: 'minzheng disability_level'}) : nodes.push({name: '伤残等级 -', className: 'minzheng disability_level'});
                        dataDetail.is_orphan ? nodes.push({name: `是否为孤儿: ${dataDetail.is_orphan === 1 ?  '是' : '否'}`, className: 'minzheng is_orphan'}) : nodes.push({name: '是否为孤儿 -', className: 'minzheng is_orphan'});
                        dataDetail.nature_disability ? nodes.push({name: `伤残性质: ${dataDetail.nature_disability}`, className: 'minzheng nature_disability'}) : nodes.push({name: '伤残性质 -', className: 'minzheng nature_disability'});
                        break
                    case 'guotu':
                        dataDetail.full_name ? nodes.push({name: `产权人姓名: ${dataDetail.full_name.substr(0, dataDetail.full_name.length - 1) + '*'}`, className: 'guotu full_name'}) : nodes.push({name: '姓名: -', className: 'guotu full_name'});
                        dataDetail.is_registered ? nodes.push({name: `是无有房屋类不动产登记信息: ${dataDetail.is_registered === 1 ? '有': '无'  }`, className: 'guotu is_registered'}) : nodes.push({name: '是无有房屋类不动产登记信息: -', className: 'guotu is_registered'});
                        dataDetail.place ? nodes.push({name: `房屋类不动产登记地: ${dataDetail.place}`, className: 'guotu place'}) : nodes.push({name: '房屋类不动产登记地: -', className: 'guotu place'});
                        break
                    case 'gongshang':
                        dataDetail.holder_full_name ? nodes.push({name: `户主姓名: ${dataDetail.holder_full_name.substr(0, dataDetail.holder_full_name.length - 1) + '*'}`, className: 'gongshang holder_full_name'}) : nodes.push({name: '户主姓名: -', className: 'gongshang holder_full_name'});
                        dataDetail.farmers_cooperative ? nodes.push( {name: `工商概要信息: ${dataDetail.farmers_cooperative === 0 ? '未参加农民专业合作社、未参加其他' : dataDetail.farmers_cooperative === 1 ? '未参加农民专业合作社、参加其他' : dataDetail.farmers_cooperative === 2 ? '参加农民专业合作社、未参加其他' : '参加农民专业合作社、参加其他'}`, className: 'gongshang farmers_cooperative'} ) : nodes.push({name: '工商概要信息: -', className: 'gongshang farmers_cooperative'});
                        dataDetail.clrq ? nodes.push({name: `注册日期: ${dataDetail.clrq}`, className: 'gongshang clrq'}) : nodes.push({name: '注册日期: -', className: 'gongshang clrq'});
                        dataDetail.full_name ? nodes.push({name: `法定代表人: ${dataDetail.full_name.substr(0, dataDetail.full_name.length - 1) + '*'}`, className: 'gongshang full_name'}) : nodes.push({name: '法定代表人: -', className: 'gongshang full_name'});
                        dataDetail.djjg ? nodes.push({name: `登记机关: ${dataDetail.djjg}`, className: 'gongshang djjg'}) : nodes.push({name: '登记机关: -', className: 'gongshang djjg'});
                        dataDetail.zczb ? nodes.push({name: `注册资本: ${dataDetail.zczb + '万'}`, className: 'gongshang zczb'}) : nodes.push({name: '注册资本: -', className: 'gongshang zczb'});
                        dataDetail.qymc ? nodes.push({name: `企业名称: ${dataDetail.qymc}`, className: 'gongshang qymc'}) : nodes.push({name: '企业名称: -', className: 'gongshang qymc'});
                        dataDetail.relationship ? nodes.push({name: `与户主关系: ${dataDetail.relationship}`, className: 'gongshang relationship'}) : nodes.push({name: '与户主关系: -', className: 'gongshang relationship'});
                        break
                    case 'gongan':
                        dataDetail.full_name ? nodes.push({name: `姓名: ${dataDetail.full_name.substr(0, dataDetail.full_name.length - 1) + '*'}`, className: 'gongan full_name'}) : nodes.push({name: '姓名: -', className: 'gongan full_name'});
                        dataDetail.name_used ? nodes.push({name: `曾用名: ${dataDetail.name_used}`, className: 'gongan name_used'}) : nodes.push({name: '曾用名: -', className: 'gongan name_used'});
                        dataDetail.gender ? nodes.push({name: `性别: ${dataDetail.gender === 1 ? '男' : dataDetail.gender === 2 ? '女' : '未知'}`, className: 'gongan gender'}) : nodes.push({name: '性别: -', className: 'gongan gender'});
                        dataDetail.ethnic ? nodes.push({name: `民族: ${dataDetail.ethnic}`, className: 'gongan ethnic'}) : nodes.push({name: '民族: -', className: 'gongan ethnic'});
                        dataDetail.district_code ? nodes.push({name: `家庭住址: ${dataDetail.district_code}`, className: 'gongan district_code'}) : nodes.push({name: '家庭住址: -', className: 'gongan district_code'});
                        dataDetail.relationship ? nodes.push({name: `与户主关系: ${dataDetail.relationship}`, className: 'gongan relationship'}) : nodes.push({name: '与户主关系: -', className: 'gongan relationship'});
                        dataDetail.first_record_date ? nodes.push({name: `车辆第一次登记日期: ${dataDetail.first_record_date}`, className: 'gongan first_record_date'}) : nodes.push({name: '车辆第一次登记日期: -', className: 'gongan first_record_date'});
                        dataDetail.model ? nodes.push({name: `车辆型号: ${dataDetail.model}`, className: 'gongan car_type'}) : nodes.push({name: '车辆型号: -', className: 'gongan model'});
                        dataDetail.car_status ? nodes.push({name: `车辆状态: ${dataDetail.car_status}`, className: 'gongan car_status'}) : nodes.push({name: '车辆状态: -', className: 'gongan car_status'});
                        dataDetail.licensed_class ? nodes.push({name: `驾驶证类型: ${dataDetail.licensed_class}`, className: 'gongan licensed_class'}) : nodes.push({name: '驾驶证类型: -', className: 'gongan licensed_class'});
                        dataDetail.valid_date ? nodes.push({name: `领证日期: ${dataDetail.valid_date}`, className: 'gongan valid_date'}) : nodes.push({name: '领证日期: -', className: 'gongan valid_date'});
                        break
                    case 'weiji':
                        dataDetail.full_name ? nodes.push({name: `姓名: ${dataDetail.full_name.substr(0, dataDetail.full_name.length - 1) + '*'}`, className: 'weiji full_name'}) : nodes.push({name: '姓名: -', className: 'weiji full_name'});
                        dataDetail.gender ? nodes.push({name: `性别: ${dataDetail.gender === 1 ? '男' : dataDetail.gender === 2 ? '女' : '未知'}`, className: 'weiji gender'}) : nodes.push({name: '性别: -', className: 'weiji gender'});
                        dataDetail.ncms ? nodes.push({name: `是否参加新型农村合作医疗: ${dataDetail.ncms === 0 ? '否' : '是'}`, className: 'weiji ncms'}) : nodes.push({name: '是否参加新型农村合作医疗: -', className: 'weiji ncms'});
                        dataDetail.only_child ? nodes.push({name: `是否独生子女: ${dataDetail.only_child === 0 ? '否' : '是'}`, className: 'weiji only_child'}) : nodes.push({name: '是否独生子女: -', className: 'weiji only_child'});
                        dataDetail.double_daughter ? nodes.push({name: `是否双女户: ${dataDetail.double_daughter === 0 ? '否' : '是'}`, className: 'weiji double_daughter'}) : nodes.push({name: '是否双女户: -', className: 'weiji double_daughter'});
                        dataDetail.poverty_attribute ? nodes.push({name: `贫困户属性: ${dataDetail.poverty_attribute}`, className: 'weiji poverty_attribute'}) : nodes.push({name: '贫困户属性: -', className: 'weiji poverty_attribute'});
                        dataDetail.precise_properties ? nodes.push({name: `精确属性: ${dataDetail.precise_properties}`, className: 'weiji precise_properties'}) : nodes.push({name: '精确属性: -', className: 'weiji precise_properties'});
                        dataDetail.in_hospital_diagnosis_name ? nodes.push({name: `入院诊断: ${dataDetail.in_hospital_diagnosis_name}`, className: 'weiji in_hospital_diagnosis_name'}) : nodes.push({name: '入院诊断: -', className: 'weiji in_hospital_diagnosis_name'});
                        dataDetail.out_hospital_diagnosis_name ? nodes.push({name: `出院诊断: ${dataDetail.out_hospital_diagnosis_name}`, className: 'weiji out_hospital_diagnosis_name'}) : nodes.push({name: '出院诊断: -', className: 'weiji out_hospital_diagnosis_name'});
                        dataDetail.total_cost ? nodes.push({name: `总费用: ${dataDetail.total_cost}`, className: 'weiji total_cost'}) : nodes.push({name: '总费用: -', className: 'weiji total_cost'});
                        dataDetail.within_costs ? nodes.push({name: `保内费用: ${dataDetail.within_costs}`, className: 'weiji within_costs'}) : nodes.push({name: '保内费用: -', className: 'weiji within_costs'});
                        dataDetail.amount_personal_pay ? nodes.push({name: `自付费用: ${dataDetail.amount_personal_pay}`, className: 'weiji amount_personal_pay'}) : nodes.push({name: '自付费用: -', className: 'weiji amount_personal_pay'});
                        dataDetail.amount_fund_compensation ? nodes.push({name: `基金补偿金额: ${dataDetail.amount_fund_compensation}`, className: 'weiji amount_fund_compensation'}) : nodes.push({name: '基金补偿金额: -', className: 'weiji amount_fund_compensation'});
                        dataDetail.amount_civil_compensation ? nodes.push({name: `民政补偿金额: ${dataDetail.amount_civil_compensation}`, className: 'weiji amount_civil_compensation'}) : nodes.push({name: '民政补偿金额: -', className: 'weiji amount_civil_compensation'});
                        dataDetail.serious_illness_compensation ? nodes.push({name: `大病商保补偿: ${dataDetail.serious_illness_compensation}`, className: 'weiji serious_illness_compensation'}) : nodes.push({name: '大病商保补偿: -', className: 'weiji serious_illness_compensation'});
                        dataDetail.family_planning_reduction_amount ? nodes.push({name: `计生两户减免金额: ${dataDetail.family_planning_reduction_amount}`, className: 'weiji family_planning_reduction_amount'}) : nodes.push({name: '计生两户减免金额: -', className: 'weiji family_planning_reduction_amount'});
                        dataDetail.fiscal_out_amount ? nodes.push({name: `财政兜底金额: ${dataDetail.fiscal_out_amount}`, className: 'weiji fiscal_out_amount'}) : nodes.push({name: '财政兜底金额: -', className: 'weiji fiscal_out_amount'});
                        dataDetail.other_security_amount ? nodes.push({name: `其他保障金额: ${dataDetail.other_security_amount}`, className: 'weiji other_security_amount'}) : nodes.push({name: '其他保障金额: -', className: 'weiji other_security_amount'});
                        dataDetail.medical_institutions_amount ? nodes.push({name: `医疗机构承担金额: ${dataDetail.medical_institutions_amount}`, className: 'weiji medical_institutions_amount'}) : nodes.push({name: '医疗机构承担金额: -', className: 'weiji medical_institutions_amount'});
                        dataDetail.single_disease_amount ? nodes.push({name: `单病种费用定额: ${dataDetail.single_disease_amount}`, className: 'weiji single_disease_amount'}) : nodes.push({name: '单病种费用定额: -', className: 'weiji single_disease_amount'});
                        break

                    case 'yimin':
                        dataDetail.full_name ? nodes.push({name: `产权人姓名: ${dataDetail.full_name.substr(0, dataDetail.full_name.length - 1) + '*'}`, className: 'yimin full_name'}) : nodes.push({name: '产权人姓名: -', className: 'yimin full_name'});
                        dataDetail.population ? nodes.push({name: `户口人数: ${dataDetail.population  }`, className: 'yimin population'}) : nodes.push({name: '户口人数: -', className: 'yimin population'});
                        dataDetail.out_place ? nodes.push({name: `迁出地: ${dataDetail.out_place}`, className: 'yimin out_place'}) : nodes.push({name: '迁出地: -', className: 'yimin out_place'});
                        dataDetail.in_place ? nodes.push({name: `迁入地: ${dataDetail.in_place}`, className: 'yimin in_place'}) : nodes.push({name: '迁入地: -', className: 'yimin in_place'});
                        dataDetail.settlement_site ? nodes.push({name: `安置地: ${dataDetail.settlement_site}`, className: 'yimin settlement_site'}) : nodes.push({name: '安置地: -', className: 'yimin settlement_site'});
                        dataDetail.people_number ? nodes.push({name: `迁出地搬迁总人口: ${dataDetail.people_number}`, className: 'yimin people_number'}) : nodes.push({name: '迁出地搬迁总人口: -', className: 'yimin people_number'});
                        dataDetail.house_of_group ? nodes.push({name: `全组户数: ${dataDetail.house_of_group}`, className: 'yimin house_of_group'}) : nodes.push({name: '全组户数: -', className: 'yimin house_of_group'});
                        dataDetail.people_of_group ? nodes.push({name: `全组人口: ${dataDetail.people_of_group}`, className: 'yimin people_of_group'}) : nodes.push({name: '全组人口: -', className: 'yimin people_of_group'});
                        break

                    case 'jiaoyu':
                        dataDetail.full_name ? nodes.push({name: `姓名: ${dataDetail.full_name.substr(0, dataDetail.full_name.length - 1) + '*'}`, className: 'jiaoyu full_name'}) : nodes.push({name: '姓名: -', className: 'jiaoyu full_name'});
                        dataDetail.district_code ? nodes.push({name: `家庭住址: ${dataDetail.district_code}`, className: 'jiaoyu district_code'}) : nodes.push({name: '家庭住址: -', className: 'jiaoyu district_code'});
                        dataDetail.gender ? nodes.push({name: `性别: ${dataDetail.gender === 1 ? '男' : dataDetail.gender === 2 ? '女' : '未知'}`, className: 'jiaoyu gender'}) : nodes.push({name: '性别: -', className: 'jiaoyu gender'});
                        dataDetail.school_situation ? nodes.push({name: `在校生情况: ${dataDetail.school_situation === '99' ? '在读' : '非在读'}`, className: 'jiaoyu school_situation'}) : nodes.push({name: '在校生情况: -', className: 'jiaoyu school_situation'});
                        dataDetail.rollID ? nodes.push({name: `学籍号: ${dataDetail.rollID}`, className: 'jiaoyu rollID'}) : nodes.push({name: '学籍号: -', className: 'jiaoyu rollID'});
                        dataDetail.grade ? nodes.push({name: `就读年级: ${dataDetail.grade}`, className: 'jiaoyu grade'}) : nodes.push({name: '就读年级: -', className: 'jiaoyu grade'});
                        dataDetail.category ? nodes.push({name: `资助类别: ${dataDetail.category}`, className: 'jiaoyu category'}) : nodes.push({name: '资助类别: -', className: 'jiaoyu category'});
                        dataDetail.fupin_total ? nodes.push({name: `资助金额合计: ${dataDetail.fupin_total}`, className: 'jiaoyu fupin_total'}) : nodes.push({name: '资助金额合计: -', className: 'jiaoyu fupin_total'});
                        dataDetail.isLocalProvince ? nodes.push({name: `省内或省外就读: ${dataDetail.isLocalProvince}`, className: 'jiaoyu isLocalProvince'}) : nodes.push({name: '省内或省外就读: -', className: 'jiaoyu isLocalProvince'});
                        dataDetail.school ? nodes.push({name: `就读学校: ${dataDetail.school}`, className: 'jiaoyu school'}) : nodes.push({name: '就读学校: -', className: 'jiaoyu school'});
                        break
                }
            }

            this.drawNode(this.departments[i], (Math.PI * 2) / len, 23, i, 42, 230, color, 0, windowRect, this.ghead, 0)
        }

        d3.selectAll('.cloud').on('click',  this.highLight)


        // 画第二圈
        setTimeout( () => {
            let className = ''
            let nodes_1 = nodes.slice(0, 20)
            let nodes_2 = nodes.slice(20, 56)
            let nodes_3 = nodes.slice(56, nodes.length)
            let length = nodes_1.length === 20 ? nodes_1.length : 20


            this.drawSecond( nodes_1, length, windowRect, 320)
            length = nodes_2.length > 36 ? nodes_1.length : 36
            this.drawSecond( nodes_2, length, windowRect, 440)

            length = nodes_3.length >= 52 ? nodes_1.length : 52
            this.drawSecond( nodes_3, length, windowRect, 560)

        }, 100)

    }

    // 画第二圈节点
    drawSecond  = (nodes, length, windowRect, radius) => {
        for (let i = 0; i < length; i++) {
            if (!nodes[i]) {
                continue
            }
            let className = nodes[i].className
            if (className.indexOf(' ') !== -1) {
                className = className.slice(0, className.indexOf(' '))
            } else {
                className = 'fpb'
            }
            this.drawNode(nodes[i], (Math.PI * 2) / length, 17, i, 35, radius, '#69dfff', -80, windowRect, this.gNodes.select('.' + className), 300)
        }
    }


    highLight = () => {
        let self = d3.select(event.target)
        let className = self.attr('class')
        let lightNodes = []
        // 没数据点击无效
        if (self.attr('fill') === '#bfbfbf' ||  this.preTarget === className) {
            return
        }


        this.preTarget = className

        this.gNodes.selectAll('circle').transition().duration(200).ease('linear').attr('opacity', 0.3)
        this.gLines.selectAll('line').transition().duration(200).ease('linear').attr('opacity', 0.1)
        this.gTexts.selectAll('text').transition().duration(200).ease('linear').attr('opacity', 0.3)

        className = className.slice(0, className.indexOf(' '))
        lightNodes = this.gNodes.selectAll('.' + className)
        lightNodes.transition().duration(200).ease('linear').attr('opacity', 1)
        this.gLines.selectAll('.' + className).transition().duration(200).ease('linear').attr('opacity', 1)
        this.gTexts.selectAll('.' + className).transition().duration(200).ease('linear').attr('opacity', 1)

        this.gNodes.selectAll('.fpb').transition().duration(200).ease('linear').attr('opacity', 0)
        this.gNodes.select('.lightfpb').transition().duration(200).ease('linear').attr('opacity', 1)
        this.gLines.selectAll('.fpb').transition().duration(200).ease('linear').attr('opacity', 0)
        this.gLines.selectAll('.lightfpb').transition().duration(200).ease('linear').attr('opacity', 1)
        this.gTexts.selectAll('.fpb').transition().duration(200).ease('linear').attr('opacity', 0)
        this.gTexts.select('.fpb').transition().duration(200).ease('linear').attr('opacity', 1)



        // 删除所有临时节点
        d3.selectAll('.temp').remove()

        let nodes = []

        eventEmitter.emit('changeDepartment', className)

        resource.get(`/xixiu-server/dataComparison/getData?department=${className}&idnumber=${this.state.id}`).then(resInfo => {
            let data = resInfo.data
            let windowRect = document.body.getBoundingClientRect()
            let idnumber = data.idnumber
            idnumber = idnumber.substr(0,10) + '****' + idnumber.substr(14)

            data.idnumber ? nodes.push({name: `身份证号: ${idnumber}`, className: 'gongan idnumber temp'}) : nodes.push({name: '身份证号: -', className: 'gongan idnumber temp'})
            switch (className) {
                case 'renshe':
                    data.full_name ? nodes.push({name: `姓名: ${data.full_name.substr(0, data.full_name.length - 1) + '*'}`, className: 'renshe full_name temp'}) : nodes.push({name: '姓名: -', className: 'renshe full_name temp'});
                    data.gender ? nodes.push({name: `性别: ${data.gender}`, className: 'renshe gender temp'}) : nodes.push({name: '性别: -', className: 'renshe gender temp'});
                    data.resident_pension ? nodes.push({name: `参保状态: '正常参保' `, className: 'renshe resident_pension temp'}) : nodes.push({name: '参保状态: 终止参保', className: 'renshe resident_pension temp'});
                    break
                case 'jianshe':
                    data.full_name ? nodes.push({name: `姓名: ${data.full_name.substr(0, data.full_name.length - 1) + '*'}`, className: 'jianshe full_name temp'}) : nodes.push({name: '姓名: -', className: 'jianshe full_name temp'});
                    data.ethnic ? nodes.push({name: `民族: ${data.ethnic}`, className: 'jianshe ethnic temp'}) : nodes.push({name: '民族: -', className: 'jianshe ethnic temp'});
                    data.population ? nodes.push({name: `家庭人数: ${data.population}`, className: 'jianshe population temp'}) : nodes.push({name: '家庭人数: -', className: 'jianshe population temp'});
                    data.area ? nodes.push({name: `改造后住房面积: ${data.area}`, className: 'jianshe area temp'}) : nodes.push({name: '改造后住房面积: -', className: 'jianshe area temp'});
                    data.dangerous ? nodes.push({name: `是否危房: ${data.dangerous === 1 ? '是' : '否'}`, className: 'jianshe dangerous temp'}) : nodes.push({name: '是否危房: -', className: 'jianshe dangerous temp'});
                    data.danger_type ? nodes.push({name: `改造原因: ${data.danger_type}`, className: 'jianshe danger_type temp'}) : nodes.push({name: '改造原因: -', className: 'jianshe danger_type temp'});
                    data.is_commercial_housing ? nodes.push({name: `是否有商品房登记信息: ${data.is_commercial_housing === 1 ? '是' : '否'}`, className: 'jianshe is_commercial_housing temp'}) : nodes.push({name: '是否有商品房登记信息: -', className: 'jianshe is_commercial_housing temp'});
                    break
                case 'minzheng':
                    data.full_name ? nodes.push({name: `姓名: ${data.full_name.substr(0, data.full_name.length - 1) + '*'}`, className: 'minzheng full_name temp'}) : nodes.push({name: '姓名: -', className: 'minzheng full_name temp'});
                    data.povertyAttribute ? nodes.push({name: `贫困户属性: ${data.povertyAttribute}`, className: 'minzheng poverty_attribute temp'}) : nodes.push({name: '贫困户属性 -', className: 'minzheng poverty_attribute temp'});
                    data.martyr ? nodes.push({name: `是否军烈属: 是`, className: 'minzheng martyr temp'}) : nodes.push({name: '是否军烈属: 否', className: 'minzheng martyr temp'});
                    break
                case 'guotu':
                    data.is_registered ? nodes.push({name: `是无有房屋类不动产登记信息: ${data.is_registered === 1 ? '有': '无'  }`, className: 'guotu is_registered temp'}) : nodes.push({name: '是无有房屋类不动产登记信息: -', className: 'guotu is_registered temp'});
                    break
                case 'gongshang':
                    data.holder_full_name ? nodes.push({name: `户主姓名: ${data.holder_full_name.substr(0, data.holder_full_name.length - 1) + '*'}`, className: 'gongshang holder_full_name temp'}) : nodes.push({name: '户主姓名: -', className: 'gongshang holder_full_name temp'});
                    data.farmers_cooperative ? nodes.push( {name: `工商概要信息: ${data.farmers_cooperative === 0 ? '未参加农民专业合作社、未参加其他' : data.farmers_cooperative === 1 ? '未参加农民专业合作社、参加其他' : data.farmers_cooperative === 2 ? '参加农民专业合作社、未参加其他' : '参加农民专业合作社、参加其他'}`, className: 'gongshang farmers_cooperative temp'} ) : nodes.push({name: '工商概要信息: -', className: 'gongshang farmers_cooperative temp'});
                    break
                case 'gongan':
                    data.full_name ? nodes.push({name: `姓名: ${data.full_name.substr(0, data.full_name.length - 1) + '*'}`, className: 'gongan full_name temp'}) : nodes.push({name: '姓名: -', className: 'gongan full_name temp'});
                    data.name_used ? nodes.push({name: `曾用名: ${data.name_used}`, className: 'gongan name_used temp'}) : nodes.push({name: '曾用名: -', className: 'gongan name_used temp'});
                    data.gender ? nodes.push({name: `性别: ${data.gender}`, className: 'gongan ender temp'}) : nodes.push({name: '性别: -', className: 'gongan gender temp'});
                    data.ethnic ? nodes.push({name: `民族: ${data.ethnic}`, className: 'gongan ethnic temp'}) : nodes.push({name: '民族: -', className: 'gongan ethnic temp'});
                    data.homeAddress ? nodes.push({name: `家庭住址: ${data.homeAddress}`, className: 'gongan district_code temp'}) : nodes.push({name: '家庭住址: -', className: 'gongan district_code temp'});
                    data.relationship ? nodes.push({name: `与户主关系: ${data.relationship}`, className: 'gongan relationship temp'}) : nodes.push({name: '与户主关系: -', className: 'gongan relationship temp'});
                    break

                case 'weiji':
                    data.full_name ? nodes.push({name: `姓名: ${data.full_name.substr(0, data.full_name.length - 1) + '*'}`, className: 'weiji full_name temp'}) : nodes.push({name: '姓名: -', className: 'weiji full_name temp'});
                    data.gender ? nodes.push({name: `性别: ${ data.gender}`, className: 'weiji gender temp'}) : nodes.push({name: '性别: -', className: 'weiji gender temp'});
                    data.ncms ? nodes.push({name: `是否参加新型农村合作医疗: ${data.ncms === 0 ? '否' : '是'}`, className: 'weiji ncms temp'}) : nodes.push({name: '是否参加新型农村合作医疗: -', className: 'weiji ncms temp'});
                    data.onlyChild ? nodes.push({name: `是否独生子女: ${data.onlyChild === 0 ? '否' : '是'}`, className: 'weiji only_child temp'}) : nodes.push({name: '是否独生子女: -', className: 'weiji only_child temp'});
                    data.doubleDaughter ? nodes.push({name: `是否双女户: ${data.doubleDaughter === 0 ? '否' : '是'}`, className: 'weiji double_daughter temp'}) : nodes.push({name: '是否双女户: -', className: 'weiji double_daughter temp'});
                    data.povertyAttribute ? nodes.push({name: `贫困户属性: ${data.povertyAttribute}`, className: 'weiji poverty_attribute temp'}) : nodes.push({name: '贫困户属性: -', className: 'weiji poverty_attribute temp'});
                    break

                case 'yimin':
                    data.full_name ? nodes.push({name: `产权人姓名: ${data.full_name.substr(0, data.full_name.length - 1) + '*'}`, className: 'yimin full_name temp'}) : nodes.push({name: '产权人姓名: -', className: 'yimin full_name temp'});
                    data.population ? nodes.push({name: `户口人数: ${data.population  }`, className: 'yimin population temp'}) : nodes.push({name: '户口人数: -', className: 'yimin population temp'});
                    data.out_place ? nodes.push({name: `迁出地: ${data.out_place}`, className: 'yimin out_place temp'}) : nodes.push({name: '迁出地: -', className: 'yimin out_place temp'});
                    data.in_place ? nodes.push({name: `迁入地: ${data.in_place}`, className: 'yimin in_place temp'}) : nodes.push({name: '迁入地: -', className: 'yimin in_place temp'});
                    data.settlement_site ? nodes.push({name: `安置地: ${data.settlement_site}`, className: 'yimin settlement_site temp'}) : nodes.push({name: '安置地: -', className: 'yimin settlement_site temp'});
                    break

                case 'jiaoyu':
                    data.full_name ? nodes.push({name: `姓名: ${data.full_name.substr(0, data.full_name.length - 1) + '*'}`, className: 'jiaoyu full_name temp'}) : nodes.push({name: '姓名: -', className: 'jiaoyu full_name temp'});
                    data.district_code ? nodes.push({name: `家庭住址: ${data.district_code}`, className: 'jiaoyu district_code temp'}) : nodes.push({name: '家庭住址: -', className: 'jiaoyu district_code temp'});
                    data.gender ? nodes.push({name: `性别: ${data.gender}`, className: 'jiaoyu gender temp'}) : nodes.push({name: '性别: -', className: 'jiaoyu gender temp'});
                    data.school_situation ? nodes.push({name: `在校生情况: ${data.school_situation === '99' ? '在读' : '非在读'}`, className: 'jiaoyu school_situation temp'}) : nodes.push({name: '在校生情况: -', className: 'jiaoyu school_situation temp'});
                    break
            }

            for (let i = 0, len = nodes.length; i < len; i++) {
                this.drawNode(nodes[i], Math.PI * 2 / 36, 17, i, 35, 495, '#69dfff', 40, windowRect, this.gNodes.select('.fpb'), 300)
            }
            resource.get( `/xixiu-server/dataComparison/getThiredDiferentFields?department=${className}&idnumber=${this.state.id}`).then(res => {

                res.data.diffs.forEach( (diff) => {
                    if (diff) {
                        let diffNodes = d3.selectAll('.' + className + '' + diff)
                        diffNodes.attr({'stroke': '#c52824', 'stroke-width': 4})
                        let first = diffNodes.filter( (item, i) => {
                            return i === 0
                        });
                        let second = diffNodes.filter( (item, i) => {
                            return i === 1
                        });
                        setTimeout(() => {
                            this.gLines.append('line').attr({x1: first.attr('cx'), y1: first.attr('cy'), x2: second.attr('cx'), y2: second.attr('cy'), stroke: '#c52824', 'stroke-width': 2, class: 'temp'});
                        }, 320)
                    }
                })

            })
        })
        event.stopPropagation()
    }

    /*
     *   绘制节点
     *   nodeTemp: 节点
     *   radians: 弧度基数
     *   i: 当前绘制节点数
     *   length: 节点间距离
     *   color: 节点颜色
     *   initRadians: 初始角度, 扩展节点用
     */
    drawNode = (node, radians, radius, i, dy, length, color, initRadians, windowRect, target, timer = 0) => {
        // this.gTexts.append('')
        let cx = windowRect.width / 2 - ( length * Math.cos(radians * i + initRadians) ),
            cy = windowRect.height / 2 - ( length * Math.sin(radians * i + initRadians) );

        this.gTexts.append('text').attr({x: cx, y: cy, dy: dy, fill: '#000', 'text-anchor': 'middle', 'font-size': 16, class: node.className + ' remove'}).text(node.name);

        this.gLines.append('line').attr({x1: cx, y1: cy, x2: target.attr('cx'), y2: target.attr('cy'), stroke: '#ccc', 'stroke-dasharray': '3 2', class: node.className + ' remove'});
        let classNames = node.className.split(' ');

        let className = classNames[0] + classNames[1];


        this.gNodes.append('circle').attr({ cx: windowRect.width / 2 - radius, cy: windowRect.height / 2 - radius, r: radius, fill: color, class: node.className + ' ' + className  + ' remove'})
            .transition()
            .duration(timer)
            .ease('linear')
            .attr('cx', cx)
            .attr('cy', cy)
    };

    clickDocument = () => {
        // 点击了当前展开元素
        if (event.target.getAttribute('class') === this.preTarget) {
            return;
        }
        setTimeout( () => {
            d3.selectAll('.temp').remove();
            this.preTarget = null;
            this.gNodes.selectAll('circle').attr('stroke', 'none').transition().duration(200).ease('linear').attr('opacity', 1);
            this.gLines.selectAll('line').transition().duration(200).ease('linear').attr('opacity', 1);
            this.gTexts.selectAll('text').transition().duration(200).ease('linear').attr('opacity', 1);
        }, 150);

    };

    notFound = () => {
        document.querySelector('#imgNotFound').src = male;
        d3.select('#msk').attr('opacity', 0);
        d3.select('#gheadImage').attr('xlink:href', male);
    };

    render() {
        return (
            <div  className={style.wrap}>
                <img src={male} id="imgNotFound" onError={this.notFound} style={{position: 'absolute', left: '-9999px'}}/>

                <svg id="svg" width="100%" height="100%">
                    <defs>
                        <pattern id="raduisImage" width="100%" height="100%" patternContentUnits="userSpaceOnUse">
                            <image width="106" height="106"  preserveAspectRatio="none" id="gheadImage"/>
                        </pattern>
                    </defs>
                    <g className="gwrap">
                        <g className="glines"></g>
                        <g className="gnodes"></g>
                        <g className="gtexts"></g>
                        <g className="ghead">
                        </g>
                        {/*<image width="90" height="48" xlinkHref={msk} id="msk" opacity='0'/>*/}
                    </g>

                </svg>
                <div className={style.tips}>
                    <div className={style.area}>
                        <span className={style.circle + ' ' + style.error}></span>
                        <span>异常第三方数据</span>
                    </div>
                    <div className={style.area}>
                        <span className={style.circle + ' ' + style.normal}></span>
                        <span>正常第三方数据</span>
                    </div>
                    <div className={style.area}>
                        <span className={style.circle + ' ' + style.compare}></span>
                        <span>对比关联字段</span>
                    </div>
                    <div className={style.area}>
                        <span className={style.circle + ' ' + style.errorCompare}></span>
                        <span>异常对比字段</span>
                    </div>
                    <div className={style.area}>
                        <span className={style.circle + ' ' + style.none}></span>
                        <span>暂无数据</span>
                    </div>
                </div>
            </div>
        )
    }
}

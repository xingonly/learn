import React,{Component} from 'react';
import redux from 'redux';
// import Pagination from 'rc-pagination';
import Pagination from '../../../../../components/PaginationNoEnd';
import MySelect from '../../../../../components/MySelect';
import outofpoverty from './images/outofpoverty.png';
import poverty from './images/poverty.png';
import choice from './images/choice.png';
import prepoverty from './images/prepoverty.png';
import backpoverty from './images/backpoverty.png';
import male from './images/nanren.png';
import msk from './images/msk.png';
import close from './images/close.png';
import open from './images/open.png';
import follow from './images/follow.png';
import unFollow from './images/unFollow.png';
import Notice from '../../../../../components/Notice'
// import 'rc-pagination/assets/index.css';
import style from './index.scss';
import resource from '../../../../../util/resource';
import eventEmitter from '../../../../../util/eventEmitter';
import {changeId} from '../../../../../actions/userinfo';
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import * as userActions from '../../../../../actions/userinfo'
@connect(state => ({
    users: state,
}), dispatch => ({
    userActions: bindActionCreators(userActions, dispatch)
}))
export default class Search extends Component{
    constructor() {
        super()
        this.params = {

        };
        this.state = {
            idObj: sessionStorage.getItem('keyWord')||'',
            inputValue:  sessionStorage.getItem('keyWord') ? JSON.parse(sessionStorage.getItem('keyWord')).inputValue : '' ,
            power: JSON.parse(sessionStorage.getItem('manager')),
            zhou: '乡/镇',
            xian: '村/社区',
            zhen: '请选择',
            cun: '请选择',
            pKType: '贫困类型',
            cunId: '',
            content: [],
            optionsZhou: [],
            optionsXian: [],
            optionsZhen: [],
            optionsCun: [],
            optionsPKType: [
                {label: '贫困类型', value: ''},
                {label: '未脱贫', value: '0'},
                {label: '脱贫', value: '1'},
                {label: '预脱贫', value: '2'},
                {label: '返贫', value: '3'}
            ],
            pKTypeId: '',
            pageSize: 7,
            page: 0,
            total: 7,
            i: 0,
            index: null,
            regions: '',
            //西秀区
            provinceId: '520402000000',
            fid: '',
            id: '',
            idnumber: '',
            open: true,
            //西秀id
            guizhouId: '520402000000'
        }
    }
    componentWillMount() {
        sessionStorage.setItem('Page','0');
        let sessionInputValue = null;
        if(this.state.idObj !== '') {
            let idObj = JSON.parse(this.state.idObj);
            sessionInputValue = idObj.inputValue?idObj.inputValue:'';
        }
        this.setState({
            inputValue: sessionInputValue
        },() => {
            this.searchRequire(1)
        })
    }
    componentDidMount() {
        let searchInput = document.getElementById('searchInput');
        searchInput.addEventListener('keydown', this.keyDownListener);
        if(this.state.idObj === '') {
            this.searchRequire('520000000000')
        }
        this.getProvinceId()
    }
    keyDownListener = event => {
        let code = event.keyCode || event.which || event.charCode;
        if (code == 13) {
            this.submit();
        }
    };
    getProvinceId = () => {
        resource.get(`/xixiu-server/region/getRegionByParentid/${this.state.provinceId}`).then((res) => {
                if(res.status !== 200) {
                    console.log(res.message)
                }else {
                    let optionsZhou = []
                    for(let item of res.data) {
                        let data = {
                            value: item.id,
                            label: item.name
                        }
                        optionsZhou.push(data)
                    }
                    // optionsZhou.unshift({value: '',label: '乡/镇'});
                    let powerShi = this.state.power.shi
                    for(let ite of optionsZhou) {
                        if(powerShi !== null&&ite.value === powerShi) {
                            optionsZhou = [{
                                value: ite.value,
                                label: ite.label,
                            }]
                        }
                    }
                    this.setState({
                        optionsZhou: optionsZhou
                    },() => {
                        let sessionRegion = null;
                        if(this.state.idObj !== '') {
                            let idObj = JSON.parse(this.state.idObj);
                            sessionRegion = idObj.region?idObj.region:'';
                            let optionsZhou = this.state.optionsZhou
                            for(let item of optionsZhou) {
                                if(item.value === sessionRegion.shi){
                                    this.setState({
                                        zhou: item.label
                                    })
                                }
                            }
                            this.setState({
                                provinceId: sessionRegion.shi
                            },() => {
                                if(this.state.provinceId) {
                                    this.xianRequire()
                                }
                                this.setState({
                                    provinceId: sessionRegion.xian
                                },() => {
                                    if(this.state.provinceId) {
                                        this.zhenRequire()
                                    }
                                    this.setState({
                                        provinceId: sessionRegion.xiang
                                    },() => {
                                        if(this.state.provinceId) {
                                            this.cunRequire()
                                        }
                                    })
                                })
                            })
                        }
                    })
                }
            })
    }
    xianRequire = () => {
        resource.get(`/xixiu-server/region/getRegionByParentid/${this.state.provinceId}`).then((res) => {
            if(res.status !== 200) {
                console.log(res.message)
            }else {
                let optionsXian = []
                for(let item of res.data) {
                    let data = {
                        value: item.id,
                        label: item.name
                    }
                    optionsXian.push(data)
                }
                // optionsXian.unshift({value: '',label: '请选择'})
                let powerXian = this.state.power.xian
                for(let ite of optionsXian) {
                    if(powerXian !== null&&ite.value === powerXian) {
                        optionsXian = [{
                            value: ite.value,
                            label: ite.label,
                        }]
                    }
                }
                this.setState({
                    optionsXian: optionsXian
                },() => {
                    let sessionRegion = null;
                    if(this.state.idObj !== '') {
                        let idObj = JSON.parse(this.state.idObj);
                        sessionRegion = idObj.region?idObj.region:'';
                        let optionsXian = this.state.optionsXian
                        for(let i=0;i<optionsXian.length;i++) {
                            if(optionsXian[i].value === sessionRegion.xian) {
                                this.setState({
                                    xian: optionsXian[i].label
                                })
                            }
                        }
                    }
                })
            }
        })
    }
    zhenRequire = () => {
        resource.get(`/xixiu-server/region/getRegionByParentid/${this.state.provinceId}`).then((res) => {
            if(res.status !== 200) {
                console.log(res.message)
            }else {
                let optionsZhen = []
                for(let item of res.data) {
                    let data = {
                        value: item.id,
                        label: item.name
                    }
                    optionsZhen.push(data)
                }
                // optionsZhen.unshift({value: '',label: '请选择'})
                let powerXiang = this.state.power.xiang
                for(let ite of optionsZhen) {
                    if(powerXiang !== null&&ite.value === powerXiang) {
                        optionsZhen = [{
                            value: ite.value,
                            label: ite.label,
                        }]
                    }
                }
                this.setState({
                    optionsZhen: optionsZhen
                },() => {
                    let sessionRegion = null;
                    if(this.state.idObj !== '') {
                        let idObj = JSON.parse(this.state.idObj);
                        sessionRegion = idObj.region?idObj.region:'';
                        let optionsZhen = this.state.optionsZhen
                        for(let item of optionsZhen) {
                            if(item.value === sessionRegion.xiang) {
                                this.setState({
                                    zhen: item.label
                                })
                            }
                        }
                    }
                })
            }
        })
    }
    cunRequire = () => {
        resource.get(`/xixiu-server/region/getRegionByParentid/${this.state.provinceId}`).then((res) => {
            if(res.status !== 200) {
                console.log(res.message)
            }else {
                let optionsCun = []
                for(let item of res.data) {
                    let data = {
                        value: item.id,
                        label: item.name
                    }
                    optionsCun.push(data)
                }
                // optionsCun.unshift({value: '',label: '请选择'})
                let powerCun = this.state.power.cun
                for(let ite of optionsCun) {
                    if(powerCun !== null&&ite.value === powerCun) {
                        optionsCun = [{
                            value: ite.value,
                            label: ite.label,
                        }]
                    }
                }
                this.setState({
                    optionsCun: optionsCun
                },() => {
                    let sessionRegion = null;
                    if(this.state.idObj !== '') {
                        let idObj = JSON.parse(this.state.idObj);
                        sessionRegion = idObj.region?idObj.region:'';
                        let optionsCun = this.state.optionsCun
                        for(let item of optionsCun) {
                            if(item.value === sessionRegion.zheng) {
                                this.setState({
                                    cun: item.label
                                })
                            }
                        }
                    }
                })
            }
        })
    }
    handleClickZhou = (value,name) => {
        let label = value.label
        let v = value.value
        this.setState({
            provinceId: v
        },() => {
            if(label !== '贵州省') {
                this.xianRequire()
            }
        })
        if(label === '贵州省') {
            v = this.state.guizhouId
        }
        this.setState({
            [name]: label,
            xian: '村/社区',
            zhen: '请选择',
            cun: '请选择',
            cunId: v,
            idObj: '',
            inputValue: '',
            page: 0,
            inputV: '',
            content: [],
            optionsXian: [],
            optionsZhen: [],
            optionsCun: [],
        },() => {
            if(v !== '') {
                sessionStorage.setItem('keyWord','');
                this.searchRequire(1)
            }
        })
    }
    handleClickXian = (value,name) => {
        let label = value.label;
        let v = value.value;
        this.setState({
            provinceId: v
        },() => {
            if(v !== '') {
                this.zhenRequire()
            }
        })
        this.setState({
            [name]: label,
            zhen: '请选择',
            cun: '请选择',
            cunId: v,
            idObj: '',
            inputValue: '',
            page: 0,
            content: [],
            optionsZhen: [],
            optionsCun: [],
        },() => {
            if(v !== '') {
                sessionStorage.setItem('keyWord','');
                this.searchRequire(1)
            }
        })
    }
    handleClickZhen = (value,name) => {
        let label = value.label;
        let v = value.value;
        this.setState({
            provinceId: v
        },() => {
            if(v !== '') {
                this.cunRequire()
            }
        })
        this.setState({
            [name]: label,
            cun: '请选择',
            cunId: v,
            idObj: '',
            inputValue: '',
            page: 0,
            content: [],
            optionsCun: [],
        },() => {
            if(v !== '') {
                sessionStorage.setItem('keyWord','');
                this.searchRequire(1)
            }
        })
    }
    handleClickCun = (value,name) => {
        let label = value.label;
        let v = value.value;
        this.setState({
            [name]: label,
            cunId: v,
            idObj: '',
            inputValue: '',
            page: 0,
            content: []
        },() => {
            if(v !== '') {
                sessionStorage.setItem('keyWord','');
                this.searchRequire(1)
            }
        })
    }
    handleClickPKType = (value, name) => {
        let label = value.label;
        let v = value.value;
        this.setState({
            [name]: label,
            pKTypeId: v,
            idObj: '',
            inputValue: '',
            page: 0,
            content: []
        }, () => {
            this.searchRequire(1)
        })
    }
    pageChange = page => {
        this.setState({
            page: page-1
        },() => {
            this.searchRequire()
        })
    }

    onClick = (i,fid,id,idnumber) => {
        let obj = {
            fid: fid,
            id: id,
            idnumber: idnumber
        }
        sessionStorage.setItem('ID',JSON.stringify(obj));
        sessionStorage.setItem('Page',`${this.state.page}`);
        eventEmitter.emit('changeIdNumber', fid,id,idnumber);
        this.setState({
            i: i,
        })
    }

    // onBlur = () => {
    //     this.setState({
    //         i: null
    //     })
    // }
    onMouseOver = index => {
        this.setState({
            index: index
        })
    }

    onMouseOut = () => {
        this.setState({
            index: null
        })
    }

    inputChange = e => {
        let inputValue = e.target.value;
        this.setState({
            inputValue: inputValue
        })
    }

    submit = () => {
        this.setState({
            page: 0
        },() => {
            sessionStorage.setItem('keyWord','');
            this.searchRequire(1)
        })
    }

    showImg = status => {
        if(status === '0') {
            return poverty
        }else if(status === '1') {
            return outofpoverty
        }else if(status === '2') {
            return prepoverty
        }else if(status === '3') {
            return backpoverty
        }
    }

    showFollowOrUnfollow = type => {
        if(type) {
            return follow
        }else {
            return unFollow
        }
    }

    followOrUnfollowRequire = (e, type, id) => {
        e.stopPropagation();
        if(type) {
            resource.get(`/xixiu-server/people/attentionPeople/cancel/${id}`).then( (res) => {
                if(res.status === 200)
                {
                    Notice.success('','取消关注成功');
                    this.searchRequire();
                }
            })
        }else {
            resource.get(`/xixiu-server/people/attentionPeople/${id}`).then( (res) => {
                if(res.status === 200)
                {
                    Notice.success('','关注成功');
                    this.searchRequire();
                }
            })
        }
    }
    // regionRequire = () => {
    //     resource.get().then(res => {
    //         console.log(res);
    //     })
    // }

    searchRequire = (source) => {
        let sessionRegion = null;
        if(this.state.idObj !== '') {
            let idObj = JSON.parse(this.state.idObj);
            let shi = idObj.region.shi;
            let xian = idObj.region.xian;
            let xiang = idObj.region.xiang;
            let zheng = idObj.region.zheng;
            if(zheng) {
                sessionRegion = zheng
            }else if(xiang) {
                sessionRegion = xiang
            }else if(xian) {
                sessionRegion = xian
            }else if(shi) {
                sessionRegion = shi
            }else {
                sessionRegion = ''
            }
        }
        if(source === '520000000000') {
            sessionRegion = '520000000000'
        }
        let validIdNumber = /(^\d{15}$)|(^\d{18}$)|(^\d{17}(\d|X|x)$)/.test(this.state.inputValue);
        let regions = sessionRegion?`&region=${sessionRegion}`:(this.state.cunId?`&region=${this.state.cunId}`:'');
        let name = validIdNumber?'':`&name=${this.state.inputValue !== null? this.state.inputValue: ''}`;
        let searchUrl = validIdNumber?`/xixiu-server/welfare/searchPoorPeopleByIdnumber/`:`/xixiu-server/welfare/searchPoorPeopleByName?`
        resource.get(`${searchUrl}${validIdNumber?``:`status=${this.state.pKTypeId}`}${validIdNumber?``:`&size=${this.state.pageSize}`}${validIdNumber?`${this.state.inputValue !== null? this.state.inputValue: ''}`: `${name}${regions}&page=${this.state.page}`}`).then(res => {
            if(res.status === 200) {
                this.setState({
                    content: res.data.content
                })
                if(res.data.content.length !== 0) {
                    for( let i=0; i<res.data.content.length; i++ ){
                        let image = new Image;
                        image.src =  res.data.content[i].headurl;
                        image.onerror = ()=>{
                            res.data.content[i].headurl = male;
                            this.setState({
                                content: res.data.content,
                                total: res.data.totalElements,
                                fid: res.data.content[0].fid,
                                id: res.data.content[0].id,
                                idnumber: res.data.content[0].idnumber
                            })
                        }
                        if( i === res.data.content.length - 1 ){
                            this.setState({
                                content: res.data.content,
                                total: res.data.totalElements,
                                fid: res.data.content[0].fid,
                                id: res.data.content[0].id,
                                idnumber: res.data.content[0].idnumber
                            },() => {
                                if (source) {
                                    let obj = {
                                        fid: this.state.fid,
                                        id: this.state.id,
                                        idnumber: this.state.idnumber
                                    }
                                    sessionStorage.setItem('ID',JSON.stringify(obj));
                                    if(!!sessionStorage.getItem('fromTo')) {
                                        //来自于百企帮百村
                                        if(sessionStorage.getItem('fromTo') === 'EnterpriseVillages'){
                                            eventEmitter.emit('changeIdNumber', this.state.fid,this.state.id,this.state.idnumber,'third');
                                            sessionStorage.removeItem('fromTo')
                                        }else{
                                            //来自于数据监控
                                            eventEmitter.emit('changeIdNumber', this.state.fid,this.state.id,this.state.idnumber,'third',sessionStorage.getItem('fromTo').split('-')[1]);
                                            sessionStorage.removeItem('fromTo')
                                        }
                                    }else {
                                        eventEmitter.emit('changeIdNumber', this.state.fid,this.state.id,this.state.idnumber);
                                    }
                                }
                            })
                        }
                    }
                }
                // else {
                //     this.setState({
                //         content: res.data.content,
                //         total: res.data.totalElements,
                //         fid: '',
                //         id: '',
                //         idnumber: ''
                //     },() => {
                //         if (source) {
                //             let obj = {
                //                 fid: this.state.fid,
                //                 id: this.state.id,
                //                 idnumber: this.state.idnumber
                //             }
                //             sessionStorage.setItem('ID',JSON.stringify(obj));
                //             eventEmitter.emit('changeIdNumber', this.state.fid,this.state.id,this.state.idnumber);
                //         }
                //     })
                // }
            }else {
                alert(res.message);
            }
        })
    }

    open = () => {

        let search = document.querySelector('.' + style.search);

        if(this.state.open) {
            this.setState({
                open: false
            });
            search.style.left = '-25rem';
        }else {
            this.setState({
                open: true
            });
            search.style.left = '1.1rem';
        }
    }

    searchXiXiu = () => {
        this.setState({
            zhou: '乡/镇',
            xian: '村/社区',
            zhen: '请选择',
            cun: '请选择',
            cunId: '520402000000',
            idObj: '',
            inputValue: '',
            page: 0,
            inputV: '',
            content: [],
            // optionsZhou: [],
            optionsXian: [],
            optionsZhen: [],
            optionsCun: [],
        },() => {
            sessionStorage.setItem('keyWord','');
            this.searchRequire(1)
        })
    }

    componentWillUnmount() {
        let searchInput = document.getElementById('searchInput');
        searchInput.removeEventListener('keydown', this.keyDownListener);
    }

    render() {
        // console.log(sessionStorage.getItem('keyWord'));
        return (
                <div className={style['search']} ref="search">
                    {/*<img src={this.state.open?close:open} alt="" onClick={this.open} className={style['open']} />*/}
                    <header className={style.header}>
                        <ul>
                            <li style={{verticalAlign: 'top'}}>
                                <span onClick={this.searchXiXiu} className={style['type-select']}>
                                    西秀区
                                </span>
                            </li>
                            <li>
                                <MySelect
                                    value={this.state.zhou}
                                    options={this.state.optionsZhou}
                                    handleClick={this.handleClickZhou}
                                    name="zhou"
                                />
                            </li>
                            <li>
                                <MySelect
                                    value={this.state.xian}
                                    options={this.state.optionsXian}
                                    handleClick={this.handleClickXian}
                                    name="xian"
                                />
                            </li>
                            <li>
                                <MySelect
                                    value={this.state.pKType}
                                    options={this.state.optionsPKType}
                                    handleClick={this.handleClickPKType}
                                    name="pKType"
                                />
                            </li>
                            {/*<li>*/}
                                {/*<MySelect*/}
                                    {/*value={this.state.zhen}*/}
                                    {/*options={this.state.optionsZhen}*/}
                                    {/*handleClick={this.handleClickZhen}*/}
                                    {/*name="zhen"*/}
                                {/*/>*/}
                            {/*</li>*/}
                            {/*<li>*/}
                                {/*<MySelect*/}
                                    {/*value={this.state.cun}*/}
                                    {/*options={this.state.optionsCun}*/}
                                    {/*handleClick={this.handleClickCun}*/}
                                    {/*name="cun"*/}
                                {/*/>*/}
                            {/*</li>*/}
                        </ul>
                        <input id='searchInput' type="search" className={style['input']} placeholder="身份证号或姓名全称" onChange={this.inputChange} value={this.state.inputValue?this.state.inputValue:''}/>
                        {/*<input type="button" className={style['submit-btn']} value="搜索" onClick={this.submit}/>*/}
                        <i onClick={this.submit} className={`iconfont ${style['searchIcon']}`}>&#xe6d1;</i>
                    </header>
                    <section className={style['content']}>
                        <ul id="lists">
                            {
                                this.state.content.map((obj,index) => (
                                    <li className={`${style[sessionStorage.getItem('Page') === `${this.state.page}`?(this.state.i === index?'background':''):'']} ${style[sessionStorage.getItem('Page') === `${this.state.page}`?(this.state.i-1 === index?'border':''):'']} ${style[sessionStorage.getItem('Page') === `${this.state.page}`?(this.state.index === index?'background':''):'']} ${style[sessionStorage.getItem('Page') === `${this.state.page}`?(this.state.index-1 === index?'border':''):'']}`}
                                        key={index}
                                        onClick={() => {this.onClick(index,obj.fid,obj.id,obj.idnumber)}}
                                        onMouseOver={() => {this.onMouseOver(index)}}
                                        onMouseOut={() => {this.onMouseOut()}}
                                    >
                                        <ul className={style['list']}>
                                            <li className={style['left']}>
                                                <img src={ obj.headurl } alt="" />
                                                {/*{obj.headurl === male?'': <img src={msk} alt="" className={style['msk']} />}*/}
                                            </li>
                                            <li className={style['middle']}>
                                                <p>{obj.fullName}</p>
                                                <p>{`证件号：${obj.idnumber}`}</p>
                                            </li>
                                            <li className={style['right']}>
                                                <img src={this.showImg(obj.status)} alt="" />
                                            </li>
                                            <li className={style['newFollow']}>
                                                <img onClick={event => {this.followOrUnfollowRequire(event, obj.attention, obj.id)}} src={this.showFollowOrUnfollow(obj.attention)} alt="" />
                                            </li>
                                        </ul>
                                    </li>
                                ))
                            }
                        </ul>
                        {
                            this.state.content.length?
                        <footer className={style['footer']}>
                            <div className={style['footer-content']}>
                                <Pagination
                                    start={1}
                                    size={this.state.pageSize}
                                    current={this.state.page+1}
                                    total={this.state.total}
                                    onChange={this.pageChange}
                                />
                            </div>
                        </footer>: <div className={style["empty"]}>
                                        <p>暂无数据</p>
                                        <div className={style["linear"]}></div>
                                    </div>
                        }
                    </section>
                </div>
            )
    }
}

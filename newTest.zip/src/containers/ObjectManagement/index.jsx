import React, {Component} from "react"
import createHashHistory from 'history/createHashHistory'
import style from './style.scss'
import { KEYWORD } from '../../constants/storage'
import SubObject from './subObject/index.jsx'
import resource from '../../util/resource'

export default class ObjectManagement extends Component {

    constructor(props){
        super(props)
        this.state = {
            follow: true,
            attentionObject: [],
            supportObject: [],
            currentActive: 0,
            pageable1: {
                start: 0,
                size:7
            },
            pageable2: {
                start: 0,
                size:7
            }
        }
        this.param = {
            page: 0,
            size: 10
        }
    }

    componentDidMount(){
        this.queryAttentionObject(this.param)
        this.querySupportObject(this.param)
    }

    queryAttentionObject = (param) => {
        resource.get('/xixiu-server/people/getPageAttentionPeople?page=' + param.page + '&size=' + param.size).then( res => {
            let state = {...this.state}
            state.attentionObject = res.data.content
            state.pageable1.size = res.data.size
            state.pageable1.total = res.data.totalElements
            state.pageable1.current = res.data.number
            this.setState(state)
        })
    }

    querySupportObject = (param) => {
        resource.get('/xixiu-server/people/getPageSupportResponsible?page=' + param.page + '&size=' + param.size).then( res => {
            let state = {...this.state}
            state.supportObject = res.data.content
            state.pageable2.size = res.data.size
            state.pageable2.total = res.data.totalElements
            state.pageable2.current = res.data.number
            this.setState(state)
        })
    }

    toggleFollow = (id, index) => {
        let state = {...this.state}
        state.follow = !state.follow
        state.follow ? (
            resource.post('/xixiu-server/people/attentionPeople', id).then( () => {
                state.attentionObject[index].attention = true
                this.setState(state)
            })
        ) : (
            resource.post('/xixiu-server/people/attentionPeople/cancel', id).then( () => {
                state.attentionObject[index].attention = false
                this.setState(state)
            })
        )
    }

    active = (item,index) => {

        let obj = {
            inputValue: item.idnumber,
            region: {
                shi: '',
                xian: '',
                xiang: '',
                zheng: ''
            }
        }

        sessionStorage.setItem(KEYWORD, JSON.stringify(obj))

        createHashHistory().push('/main/object/objectSearch')

        this.setState({
            currentActive: index
        })
    }

    change1 = (page, size) => {
        this.param.page = page
        this.param.size = size
        this.queryAttentionObject(this.param)
    }

    change2 = (page, size) => {
        this.param.page = page
        this.param.size = size
        this.querySupportObject(this.param)
    }

    render() {
      var attentionObject = (
        <ul>
            {
                this.state.attentionObject.length > 0 ? (
                    this.state.attentionObject.map( (item,index) => {
                        return (
                            <li key={index} className={this.state.currentActive === index ? (style.active) : ''} onClick={() => {this.active(item,index)}}>
                                <div><img src={item.headurl ? item.headurl : require('../EducationX/images/nanren.png')}/></div>
                                <div>
                                    <span>{item.fullName ? item.fullName : '-'}</span>
                                    <span>{item.gender ? item.gender : '-'}</span>
                                    <span>{item.idnumber ? item.idnumber : '-'}</span>
                                    <span>{item.homeAddress ? item.homeAddress : '-'}</span>
                                    <span>{item.povertyAttribute ? item.povertyAttribute : '-'}</span>
                                    <i className={item.attention ? style.follow : style.unFollow} onClick={ (e) => {e.stopPropagation();this.toggleFollow(item.id, index) }}></i>
                                </div>
                            </li>
                        )
                    })
                ) : <div className={style.emptyData}><span style={{display: 'block'}}>暂无数据</span><div className={style.gradientLine}></div></div>
            }
        </ul>
      )

      var supportObject  = (
          <ul>
              {
                  this.state.supportObject.length > 0 ? (
                      this.state.supportObject.map( (item,index) => {
                          return (
                              <li key={index} className={this.state.currentActive === index ? (style.active) : ''} onClick={() => {this.active(item,index)}}>
                                  <div><img src={item.headurl ? item.headurl : ''}/></div>
                                  <div>
                                      <span>{item.fullName ? item.fullName : '-'}</span>
                                      <span>{item.gender ? item.gender : '-'}</span>
                                      <span>{item.idnumber ? item.idnumber : '-'}</span>
                                      <span>{item.homeAddress ? item.homeAddress : '-'}</span>
                                      <span>{item.povertyAttribute ? item.povertyAttribute : '-'}</span>
                                  </div>
                              </li>
                          )
                      })
                  ) : <div className={style.emptyData}><span style={{display: 'block'}}>暂无数据</span><div className={style.gradientLine}></div></div>
              }
          </ul>
      )
        return (
            <div className={style.container}>
                <div className={style.left}>
                    <SubObject title="关注对象" content={attentionObject} pageable={this.state.pageable1} onChange={this.change1} />
                </div>
                <div className={style.right}>
                    <SubObject title="帮扶对象" content={supportObject} pageable={this.state.pageable2} onChange={this.change2}/>
                </div>
            </div>
        )
    }
}

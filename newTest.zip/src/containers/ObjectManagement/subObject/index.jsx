import React, {Component} from "react"
import style from './style.scss'
import Pagination from '../../../components/Pagination'
import title_border_left from '../../../components/Card/images/title_border_left.png'
import title_border_right from '../../../components/Card/images/title_border_right.png'

export default class SubObject extends Component {
    constructor(props){
        super(props)
        this.state = {
            page: this.props.pageable
        }
    }

    render() {
        let pageStyle = {
            position: 'absolute',
            top: '50%',
            right: 0,
            transform: 'translateY(-50%)'
        }
        return (
            <div className={style.wrapper}>
                <h1>
                    <img className={style.title_border_left} src={title_border_left}/>
                        <span>{this.props.title}</span>
                    <img className={style.title_border_right} src={title_border_right}/>
                </h1>
                {this.props.content ? this.props.content : null}
                <footer>
                    <Pagination {...this.state.page} style={pageStyle} onChange={this.props.onChange}/>
                </footer>
            </div>
        )
    }
}

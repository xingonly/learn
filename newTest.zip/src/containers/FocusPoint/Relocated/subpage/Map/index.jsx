import React, {Component} from "react";
import { immutableRenderDecorator } from 'react-immutable-render-mixin'
import style from './style.scss'
import IC from '../../../images/c.png'
import TC from '../../../images/t.png'

@immutableRenderDecorator
class Map extends Component {

    constructor(props) {
        super(props);
        this.fn = null;
        this.state = {
            show: false
        }
    }

    componentWillReceiveProps(props){
        if(props.data.line !== this.line || props.data.point !== this.point){
            this.line = props.data.line;
            this.point = props.data.point;
            this.setShow(false)
            this.setMap(props.data);
            setTimeout(()=>{
                this.setShow(true)
            },1500)
        }
    }

    mapFinished = (fun) =>{
        this.fn = fun;
        fun.drawPoint();
        fun.drawBorder();
    }

    setMap=(d)=>{
        let self =this;
        let map = new AMap.Map('money',{
            resizeEnable: true,
            zoom: 7,
            center: [106.669533,26.59615]
        });

        AMapUI.loadUI(['control/BasicControl'], function(BasicControl) {
            let layerCtrl = new BasicControl.LayerSwitcher({
                position: {
                    top:'20px',
                    right:'80px',
                },
                //自定义基础图层
                baseLayers: [{
                    id: 'tile',
                    name: '标准图',
                    layer: new AMap.TileLayer()
                }, {
                    enable: true,
                    id: 'satellite',
                    name: '卫星图',
                    layer: new AMap.TileLayer.Satellite()
                }],
                //自定义覆盖图层
                overlayLayers: [{
                    id: 'traffic',
                    name: '路况图',
                    layer: new AMap.TileLayer.Traffic()
                }, {
                    enable: true,
                    id: 'roadNet',
                    name: '路网图',
                    layer: new AMap.TileLayer.RoadNet()
                }]
            });
            map.addControl(new BasicControl.Zoom({
                position: 'lt', //left top，左上角
                showZoomNum: false //显示zoom值
            }));
            map.addControl(layerCtrl);
        });


        //加载行政区划插件
        AMap.service('AMap.DistrictSearch', function() {
            let opts = {
                subdistrict: 1,   //返回下一级行政区
                extensions: 'all',  //返回行政区边界坐标组等具体信息
                level: 'city'  //查询行政级别为 市
            };
            //实例化DistrictSearch
            district = new AMap.DistrictSearch(opts);
            district.setLevel('district');
            //行政区查询
            district.search('贵州省', function(status, result) {
                let bounds = result.districtList[0].boundaries;
                let polygons = [];
                if (bounds) {
                    for (let i = 0, l = bounds.length; i < l; i++) {
                        //生成行政区划polygon
                        let polygon = new AMap.Polygon({
                            map: map,
                            bubble: true,
                            strokeWeight: 2,
                            path: bounds[i],
                            fillOpacity: 0.1,
                            strokeStyle: "dashed",
                            fillColor: '#3b7ab5',
                            strokeColor: '#0a9ffd'
                        });
                        polygons.push(polygon);
                    }
                }
            });
        });


        let district;
        let tool = {
            drawBorder: function () {
                let data = d.line;
                if(data && data.length > 0){
                    //绘制航空线
                    AMapUI.load(['ui/misc/PathSimplifier', 'lib/$', 'lib/utils'], function(PathSimplifier, $, utils) {
                        if (!PathSimplifier.supportCanvas) {
                            alert('当前环境不支持 Canvas！');
                            return;
                        }
                        let colors = ["#fb8555"];

                        let pathSimplifierIns = new PathSimplifier({
                            map: map,
                            getPath: function (pathData, pathIndex) {
                                return pathData.path;
                            },
                            getHoverTitle: function (pathData, pathIndex, pointIndex) {
                                return pathData.name;
                            },
                            renderOptions: {
                                getPathStyle: function(pathItem, zoom) {
                                    let color = colors[pathItem.pathIndex % colors.length];
                                    return {
                                        pathLineStyle: {
                                            strokeStyle: color
                                        },
                                        startPointStyle:{
                                            radius: 2,
                                            fillStyle: '#f36462',
                                            strokeStyle: '#f39b88',
                                            lineWidth: 1,
                                        },
                                        pathNavigatorStyle: {
                                            fillStyle: 'yellow',
                                            lineWidth: 1,
                                            strokeStyle: "yellow",
                                            pathLinePassedStyle: {
                                                lineWidth: 1,
                                                strokeStyle: '#fff'
                                            }
                                        }
                                    };
                                }
                            }
                        });

                        window.pathSimplifierIns = pathSimplifierIns;

                        let arrLine = [],
                            earr = [];


                        for(var k = 0; k < data.length; k++){
                            let  obj = {};
                            if(k == 0){
                                earr.push(data[0].place_location_zb.split(',')[0],data[0].place_location_zb.split(',')[1])
                            }
                            let sarr =[];
                            sarr.push(data[k].out_address_zb.split(',')[0],data[k].out_address_zb.split(',')[1])
                            obj.name = data[k].out_address + '->' + data[k].place_location;
                            obj.path = PathSimplifier.getGeodesicPath(sarr, earr, 10);
                            arrLine.push(obj)
                        }


                        pathSimplifierIns.setData(arrLine);

                        for(let i = 0; i<data.length;i++){
                            (function (j) {
                                let navg = pathSimplifierIns.createPathNavigator(j, {
                                    loop: true,
                                    speed: 4000
                                });
                                navg.start();
                            }(i))
                        }

                    });
                }
            },


            drawPoint: function () {
                let _d = d.point,
                    _l = d.line,
                    icon,
                    cicon;
                icon = new AMap.Icon({
                    image : TC
                });
                cicon = new AMap.Icon({
                    image : IC
                });
                if(_l.length  < 1){
                    for(let i = 0; i < _d.length; i++){
                        let arr = [];
                        arr.push(_d[i].place_location_zb.split(',')[0], _d[i].place_location_zb.split(',')[1]);
                        let marker = new AMap.Marker({
                            icon: icon,
                            position: arr,
                            title: _d[i].place_location,
                            map : map
                        });
                        marker.on('click', function (e) {
                            self.props.click(e.target.Qi.title)
                        })
                    }
                }
                if(_l.length > 0){
                    for(let i = 0; i < _l.length; i++){
                        let arr = [];
                        arr.push(_l[i].out_address_zb.split(',')[0], _l[i].out_address_zb.split(',')[1]);
                        new AMap.Marker({
                            icon: icon,
                            position: arr,
                            title: _l[i].place_location,
                            map : map
                        });

                        if(i == 0){
                            let carr = [];
                            carr.push(_l[i].place_location_zb.split(',')[0], _l[i].place_location_zb.split(',')[1]);
                            new AMap.Marker({
                                icon: cicon,
                                position: carr,
                                title: _l[i].place_location,
                                map : map
                            });
                        }
                    }
                }
            }
        }

        map.on('complete', function() {
            //eventEmitter.emit('finished',tool);
            self.mapFinished(tool);
        });
    }

    setShow = (flag) => {
        this.setState({
            show: flag
        })
    }

    render() {
        return (
            <div className={style.contanier}>
                <div className={style.loading} style={{display: this.state.show ? 'none':'block'}}>
                    <img src={require('../../../images/loading.svg')}/>
                </div>
                <div style={{ width:"100%", height:"100%", position: "relative",display: this.state.show ? 'block':'none'}} id="money"></div>
            </div>
        )
    }
}

export default Map
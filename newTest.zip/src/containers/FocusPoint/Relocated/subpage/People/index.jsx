import React, {Component} from "react"
import createHistory from 'history/createHashHistory';
import resource from 'resource'
import PageList from 'components/Pagination'
import Notice from 'components/Notice'
import style from './style.scss'
import Att from 'static/images/follow.png'
import UnAtt from 'static/images/unFollow.png'
import DefaultImg from '../../../images/nanren.png';

const history = createHistory();

class People extends Component {

    state = {
        peopleData: [],
        total: 0,
        current: 0,
        size: 7
    }


    componentDidMount(){
        /*if(this.props.data){

        }*/
        this.initPeopleData()
    }

    initPeopleData = () =>{
        resource.post('/welfare-accurateidentification/app/relocation_people_list', {
            district_code: this.props.code || 520000000000,
            page: this.state.current,
            place_location: this.props.place,
            size: this.state.size
        }).then((res)=>{
            let data = [];
            if(res.status == 200){
                data = res.data.data
            }
            this.setState({
                peopleData: data,
                total: res.data.count
            })
        }).catch((err)=>{
            throw new Error(err);
        })
    }


    setPage =(data)=>{
        this.setState({
            current: data
        },()=>{
            this.initPeopleData();
        })
    };


    attentinFn = (flag, id, e) =>{
        e.stopPropagation()
        let url = '/xixiu-server/people/attentionPeople/';
        if(!flag){
            url = '/xixiu-server/people/attentionPeople/cancel/'
        }
        resource.get(url + id).then((res)=>{
            if(res.status == 200){
                Notice.success('', flag ? '取消关注成功' : '关注成功');
                this.initPeopleData();
            }else{
                Notice.error('', flag ? '取消关注失败' : '关注失败');
            }
        }).catch(err =>{
            throw new Error(err)
        })
    }

    linkPeopleAttention = (item) =>{
        console.log(item)
        let obj = {
            inputValue: item.idnumber,
            region: {
                shi: '',
                xian: '',
                xiang: '',
                zheng: ''
            }
        };
        sessionStorage.setItem('keyWord',JSON.stringify(obj));
        history.push('/main/object/objectSearch');
    }

    setDefaultImg =(event) =>{
        event.target.setAttribute('src',DefaultImg);
    };

    render() {
        return (
            <div className={style.areaBox}>
                <div className={style.loading} style={{display: this.state.peopleData.length > 0 ? 'none':'block'}}>
                    <img src={require('../../../images/loading.svg')}/>
                </div>
                <div className={style.pointBox}>
                    <p className={style.back} onClick={()=>{this.props.click(1)}}></p>
                    <table style={{display: this.state.peopleData.length > 0 ? 'block':'none'}}>
                        <thead>
                        <tr>
                            <th>头像</th>
                            <th>姓名</th>
                            <th>迁出地</th>
                            <th>家庭总收入（元）</th>
                            <th>关注状态</th>
                        </tr>
                        </thead>
                        <tbody>
                        {
                            this.state.peopleData.map((item,index)=>{
                                return <tr key={index} onClick={()=>{this.linkPeopleAttention(item)}}>
                                    <td>
                                        <img className={style.headImg} src={item.pic || DefaultImg} onError={this.setDefaultImg} alt=""/>
                                    </td>
                                    <td>{item.full_name || '-'}</td>
                                    <td>{item.out_address || '-'}</td>
                                    <td>{item.family_income || '-'}</td>
                                    <td>
                                        <img className={style.attention} onClick={(e)=>{this.attentinFn(item.attention, item.peopleid,e)}} src={item.attention ? Att : UnAtt} alt="-" title={item.attention ? '取消关注' : '关注'}/>
                                    </td>
                                </tr>
                            })
                        }
                        </tbody>
                    </table>
                    <div className={style.pageBox}>
                        {
                            this.state.total > 7 ? <PageList total={this.state.total} current={this.state.current} start={0} size={this.state.size} onChange={this.setPage} />:null
                        }
                    </div>
                </div>
            </div>
        )
    }
}

export default People

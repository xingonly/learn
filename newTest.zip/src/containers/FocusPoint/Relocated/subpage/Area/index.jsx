import React, {Component} from "react"
import style from './style.scss'

const list = [
    {
        name: '安置点（个）',
        key: 'location_count'
    },
    {
        name: '户数（户）',
        key: 'family_count'
    },
    {
        name: '人数',
        key: 'move_count'
    },
    {
        name: '安置率（%）',
        key: 'place_rate'
    },
    {
        name: '入住率（%）',
        key: 'check_in_rate'
    },
    {
        name: '就业率（%）',
        key: 'employment_rate'
    },
    {
        name: '当年户累积收入（元）',
        key: 'family_income'
    }
]

const Item  = ({item, props}) =>{
    return  <li onClick={()=>{props.click(1, item.district_code, item.region)}}>
        <h5>{item.region || '-'}</h5>
        <div className={style.details}>
            {
                list.map((v, i)=>{
                    return <div className={style.common} style={{color: item[v.key] ? '#fff':'#5d5b5b'}} key={v.key + i}>
                        <span>{v.name || '-'}</span>
                        <b>{item[v.key] || '-'}</b>
                    </div>
                })
            }
        </div>
    </li>
}

class Area extends Component {

    render() {
        return (
            <div className={style.areaBox}>
                <div className={style.loading} style={{display: this.props.data.length > 0 ? 'none':'block'}}>
                    <img src={require('../../../images/loading.svg')}/>
                </div>
                <ul style={{display: this.props.data.length > 0 ? 'block':'none'}}>
                    {
                        this.props.data.map((item,index)=>{
                            return <Item item={item} props={this.props} key={index} />
                        })
                    }
                </ul>
            </div>
        )
    }
}

export default Area

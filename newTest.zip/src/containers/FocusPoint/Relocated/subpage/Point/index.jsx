import React, {Component} from "react"
import style from './style.scss'

const list = [
    {
        name: '户数（户）',
        key: 'family_count'
    },
    {
        name: '人数',
        key: 'move_count'
    },
    {
        name: '入住率（%）',
        key: 'check_in_rate'
    },
    {
        name: '安置率（%）',
        key: 'place_rate'
    },
    {
        name: '当年户累积收入（元）',
        key: 'family_income'
    },
    {
        name: '就业率（%）',
        key: 'employment_rate'
    }
]

const Item  = ({item, props, show}) =>{
    return <div className={style.details} style={{display: show ? 'block':'none'}}>
        {
            list.map((v, i)=>{
            return <div className={style.common} style={{color: item[v.key] ? '#fff':'#5d5b5b'}} key={v.key + i}>
                <span>{v.name || '-'}</span>
                <b>{item[v.key] || '-'}</b>
            </div>
        })
        }
        <p className={style.lookD} onClick={()=>{props.click(2, item.place_location)}}>查看详情</p>
        </div>
}

class Point extends Component {

    state = {
        name: ''
    }

    changeShow = (name) => {
        let _name = '';
        if(name !== this.state.name){
            _name = name;
        }
        this.setState({
            name: _name
        })
    }

    render() {
        return (
            <div className={style.areaBox}>
                <div className={style.loading} style={{display: this.props.data.length > 0 ? 'none':'block'}}>
                    <img src={require('../../../images/loading.svg')}/>
                </div>
                <div className={style.pointBox}>
                    <p className={style.back} onClick={()=>{this.props.clickBack(0)}}></p>
                    <ul style={{display: this.props.data.length > 0 ? 'block':'none'}}>
                        {
                            this.props.data.map((item,index)=>{
                                return <li className={this.state.name === item.place_location ? style.active : ''} onClick={()=>{this.changeShow(item.place_location)}} key={item.place_location + index}>
                                    <h5>{item.place_location || '-'}</h5>
                                    <Item item={item} props={this.props} show={this.state.name === item.place_location ? true : false} key={index} />
                                </li>
                            })
                        }
                    </ul>
                </div>
            </div>
        )
    }
}

export default Point

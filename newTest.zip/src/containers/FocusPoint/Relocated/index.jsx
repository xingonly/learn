/*
* author: kn
* */
/*
import React, {Component} from "react"
import {bindActionCreators} from 'redux'
import actions from '../../../actions/relocated'
import { connect } from 'react-redux'
import Relocated from './content'


const mapStateToProps = (state) => {
    return {
        step: state.relocated.step || 0,
        district_code: state.relocated.district_code
    }
};


const mapDispatchToProps = (dispatch) => ({
    actions: bindActionCreators(actions, dispatch)
})


export default connect(  // 产生一个新的组件
    mapStateToProps,
    mapDispatchToProps,
)(Relocated);*/

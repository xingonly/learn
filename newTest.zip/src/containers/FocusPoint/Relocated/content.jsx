import React, {Component} from "react"
import Area from './subpage/Area'
import Point from './subpage/Point'
import People from './subpage/People'
import Map from './subpage/Map'
import Filter from 'containers/BasicProtection/subpage/Filter/index.jsx'
import resource from 'resource'
import style from './style.scss'

class Relocated extends Component {

    state = {
        step: 0,
        district_code: 520000000000,
        areaData: [],
        pointData: [],
        line: [],
        point: [],
        place_location: '',
        selectValues:[]
    }


    componentDidMount(){
        this.initAreaData()
    }

    //获取安置信息
    initAreaData = () =>{
        if(!this.state.district_code){
            return;
        }
        resource.post('/welfare-accurateidentification/app/relocation_area_list', {
            "district_code": this.state.district_code
        }).then((res)=>{
            let data = [];
            if(res.status == 200){
                data = res.data
            }
            this.setState({
                areaData: data
            })
        }).catch((err)=>{
            throw new Error(err);
        })
    }

    //安置点
    initPointData = (id) =>{
        return new Promise((resolve, reject)=>{
            resource.post('/welfare-accurateidentification/app/relocation_county_list', {
                "district_code": id
            }).then((res)=>{
                let data = [];
                if(res.status == 200){
                    data = res.data
                }
                resolve(data)
            }).catch((err)=>{
                resolve([])
                throw new Error(err);
            })
        })
    }


    //地图
    getMapData = (place) =>{
        resource.post('/welfare-accurateidentification/app/relocation_coordinate', {
            "place_location": place
        }).then((res)=>{
            let data = [];
            if(res.status == 200){
                data = res.data
            }
            let state = {...this.state};
            state.line = data;
            this.setState(state)
        }).catch((err)=>{
            throw new Error(err);
        })
    }

    setView = () => {
        switch(this.state.step) {
            case  0:
                return <Area click={this.clickArea} data={this.state.areaData} />;
            case 1:
                return <Point click={this.clickPoint} clickBack={this.goStep} data={this.state.pointData} />;
            case 2:
                return <People click={this.goStep} code={this.state.district_code} place={this.state.place_location} />;
        }
    }

    //太多异步操作 真想不想改！
    clickArea = (step, id, name) => {
        let _id = (id + '').substring(5,7);
        let arr = JSON.parse(JSON.stringify(this.state.selectValues));
        let spliceIndex = _id.indexOf('00') !== -1 ? 0 : 1;
        arr.splice(spliceIndex, 4 - spliceIndex, {id:id, name: name});
        this.setState({
            selectValues: arr
        },()=>{
            if(_id.indexOf('00') !== -1){
                this.setState({
                    district_code: id
                },()=>{
                    this.initAreaData()
                })
            }else{
                this.goStep(step, this.initPointData(id));
            }
        })
    }


    clickPoint = (step,params) =>{
        let state = {...this.state};
        state.place_location = params;
        state.step = step;
        this.setState(state,()=>{
            this.getMapData(params)
        })
    }

    goStep = (step, fun) => {
        let line = this.state.line;
        let point =this.state.point;
        switch (step){
            case 0:
               line = [];
               point = [];
                break;
            case 1:
                line = [];
                break;
            case 2:
                break;
        }


        if(fun){
            (async () => {
                let data = await fun;
                let state = {...this.state};
                state.pointData = data || [];
                state.point = data;
                state.step = step;
                state.line = line;
                this.setState(state)
            })();
        }else{
            let arr = JSON.parse(JSON.stringify(this.state.selectValues));
            if(step == 0){
                arr.splice(1, 3);
            }
            this.setState({
                step: step,
                line: line,
                point: point,
                selectValues: arr
            })
        }
    }

    onFilter = ({district_code, name, index}) => {
        if(index !== 0 && index !== 1){
            return;
        }
        let arr = JSON.parse(JSON.stringify(this.state.selectValues));
        arr.splice(index, 4 - index , {id: district_code, name: name});
        this.setState({
            step: index == 0 ? 0 : 1,
            district_code: district_code || 520000000000,
            line: [],
            point: [],
            selectValues: arr
        },()=>{
            if(index == 0){
                this.initAreaData()
            }
            if(index == 1){
                (async () => {
                    let data = await this.initPointData(district_code);
                    let state = {...this.state};
                    state.pointData = data || [];
                    state.point = data;
                    this.setState(state)
                })();
            }
        })
    }

    clickMap = (place) => {
        this.clickPoint(2,place)
    }

    render() {
        let data = {};
        data.line = this.state.line;
        data.point = this.state.point;
        return (
            <div className={style.wrap}>
                <div className={style.left}>
                    <div className={style.filter}>
                        <Filter onChange={this.onFilter} level values={this.state.selectValues} />
                    </div>
                    <div className={style.contentBox}>
                        {
                            this.setView()
                        }
                    </div>
                </div>
                <div className={style.right}>
                    <Map data={data} click={this.clickMap} />
                </div>
            </div>
        )
    }
}

export default Relocated

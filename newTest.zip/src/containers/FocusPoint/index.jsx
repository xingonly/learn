// 上帝保佑,永无bug

import React, {Component} from "react"
import { NavLink } from 'react-router-dom'

import style from './style.scss'

export default class KeyPoint extends Component {

    render() {
        return (
            <div className={style.wrap}>
                {/*<nav className={style.navs}>*/}
                    {/*<NavLink to="/main/keypoint/accurateidentification" activeClassName={style.active}><span>精准识别</span></NavLink>*/}
                    {/*<NavLink to="/main/keypoint/protection" activeClassName={style.active}><span>基本保障</span></NavLink>*/}
                    {/*<NavLink to="/main/keypoint/relocated" activeClassName={style.active}><span>易地搬迁</span></NavLink>*/}
                    {/*<NavLink to="/main/keypoint/education" activeClassName={style.active}><span>教育数据</span></NavLink>*/}
                    {/*<NavLink to="/main/keypoint/enterpriseAndVillages" activeClassName={style.active}><span>万企万村</span></NavLink>*/}
                {/*</nav>*/}
                {this.props.children}
            </div>
        )
    }
}

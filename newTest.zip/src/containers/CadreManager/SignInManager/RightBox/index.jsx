import React,{ Component } from 'react'
import { withRouter, Link } from 'react-router-dom'
import resource from 'resource'
import { Tooltip, Modal, Calendar, Badge } from 'antd'
import moment from  'moment'
import Filter from 'components/Filter'
import Loading from 'components/Loading'
import NoData from 'components/noData'
import Pagination from 'components/PaginationNoEnd'
import { workApi } from 'configs/endpoints.prod'
import { convertQueryString } from 'utils'
import ShowImage from 'components/showImage'
import List from './list.json'
import styles from './styles.scss'
import pic from './images/pic.png'
import calculate from './images/calculate.png'
import back from './images/back.png'

const ths = ['干部名称', '所属单位', '最近签到时间', '签到地点', '帮扶区域', ' ']

class RightBox extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: false,
      data: [],
      page: 0,
      pageSize: 10,
      total: 0,
      code: '',
      keyword: '',
      startTime: null,
      endTime: null,
      visible: false,
      signInList: [],
      // 单条签到数据
      signInListOne: [],
      // 签到日期列表
      signDateList: [],
      userId: null,
      img: null
    }
  }

  componentDidMount() {
    this.listRequire()
  }
  
  listRequire = () => {
    this.setState({
      loading: true
    });
    let params = {
      scope: this.state.code,
      nameOrPhoneNum: this.state.keyword,
      startTimestamp: this.state.startTime,
      endTimestamp: this.state.endTime,
      page: this.state.page,
      size: this.state.pageSize
    };
    resource.get(`${workApi.getSignLog}${convertQueryString(params)}`).then(res => {
      if (res.status === 200) {
        this.setState({
          data: res.data.content,
          total: res.data.totalElements,
          loading: false
        })
      } else {
        this.setState({
          loading: false
        })
      }
    }).catch(e => {
      this.setState({
        loading: false
      })
    })
  };

  pageChange = page => {
    this.setState({
        page: page - 1
    },() => {
        this.listRequire()
    })
  };

  formatTime = x => {
    return x ? moment(parseInt(x, 10)).format('YYYY-MM-DD HH:mm:ss') : '--'
  };

  showDetail = ite => {
    this.requireSignDate(ite.userId);
    let signInList = [ite];
    this.setState({
        signInList: signInList,
        signInListOne: signInList,
        userId: ite.userId
    }, () => {
        this.showModal();
    });
  };

  onSubmit = data => {
    this.setState({
      code: data.code,
      keyword: data.value,
      startTime: data.startTime,
      endTime: data.endTime,
      page: 0
    }, () => {
      this.listRequire()
    })
  };

  showModal = () => {
      this.setState({
          visible: true
      })
  };
  handleCancel = (e) => {
      this.setState({
          visible: false,
          userId: null,
          signInList: [],
          // 单条签到数据
          signInListOne: [],
          // 签到日期列表
          signDateList: []
      }, () => {
          this.hiddenCal();
      });
  };

  onSelect = (value) => {
      this.requireSignDateDetail(moment(value).format('YYYY-MM-DD'))
  };

  requireSignDate = (id) => {
      resource.get(`${workApi.getSignDate}?signerId=${id}`).then(res => {
        if(res.status !== 200) {
          message.error(res.message);
        }else {
          this.setState({
              signDateList: res.data
          })
        }
      })
  };

  requireSignDateDetail = (date) => {
    resource.get(`${workApi.getSignInDetail}?signerId=${this.state.userId}&signInDate=${date}`).then(res => {
      if(res.status !== 200) {
        message.error(res.message);
      }else {
        this.setState({
            signInList: res.data
        })
      }
    })
  };

  getListData = (value) => {
      let listData;
      let date = moment(value).format('YYYY-MM-DD');
      let signDateList = this.state.signDateList;
      if(signDateList.length > 0) {
          for(let item of signDateList) {
            if(item === date) {
                listData = [{ type: 'success', content: '' }]
            }
          }
      }
      return listData || [];
  };

  dateCellRender = (value) => {
      const listData = this.getListData(value);
      return (
          <ul className="events">
              {
                  listData.map(item => (
                      <li key={item.content}>
                        <Badge status={item.type} text={item.content} />
                      </li>
                  ))
              }
          </ul>
      );
  };

  showImg = (path) => {
    this.setState({
        img: <ShowImage handleClose = { () => this.imgCancel() } url={path}/>
    })
  };

  imgCancel = () => {
      this.setState({
          img: ''
      })
  };

  hiddenCal = () => {
      let calculate = document.getElementById('calculate');
      let backArrow = document.getElementById('backArrow');
      let full = document.getElementById('full');
      let fullArrow = document.getElementById('fullArrow');
      backArrow.style.display = 'none';
      calculate.style.height = '0';
      calculate.style.overflow = 'hidden';
      calculate.style.transition = '1s height';
      full.style.height = '319px';
      full.style.transition = '1s height';
      fullArrow.style.display = 'block';
      this.setState({
          signInList: this.state.signInListOne
      })
  };

  showCal = () => {
      let calculate = document.getElementById('calculate');
      let backArrow = document.getElementById('backArrow');
      let full = document.getElementById('full');
      let fullArrow = document.getElementById('fullArrow');
    if(backArrow.style.display === 'none') {
        backArrow.style.display = 'block';
        calculate.style.height = '319px';
        calculate.style.overflow = 'hidden';
        calculate.style.transition = '1s height';
        full.style.height = '0';
        full.style.transition = '1s height';
        fullArrow.style.display = 'none';
    }else {
        backArrow.style.display = 'none';
        calculate.style.height = '0';
        calculate.style.overflow = 'hidden';
        calculate.style.transition = '1s height';
        full.style.height = '319px';
        full.style.transition = '1s height';
        fullArrow.style.display = 'block';
        this.setState({
            signInList: this.state.signInListOne
        })
    }
  };

  render() {
    return (
      <div className={styles.rightContainer}>
        <Filter
          title='签到查询'
          placeholder="请输入干部姓名或电话号码"
          allowDate
          allowSelect
          onSubmit={this.onSubmit}
        />
        <div className={styles.tableBox}>
          <div className={styles.thBox}>
            {
              ths.map(ite =>
                <div className={styles.thItem} key={`ths_${ite}`}>{ite}</div>
              )
            }
          </div>
          {
            this.state.loading ? <Loading /> : this.state.data.length
              ? <div className={styles.trBox}>
            {
                  this.state.data.map((ite, idx) => (
                <div key={ite.id} className={styles.trItem}>
                  <div className={styles.tdItem} />
                  <div className={styles.tdItem}>{!!ite.userName? ite.userName: '--'}</div>
                  <div className={styles.tdItem + ' ' + 'text-overflow'} title={!!ite.department? ite.department: '--'}>{!!ite.department? ite.department: '--'}</div>
                  <div className={styles.tdItem}>{this.formatTime(ite.signInTime)}</div>
                  <Tooltip title={!!ite.signAdress? ite.signAdress: '--'}>
                    <div className={styles.tdItem + ' ' + 'text-overflow'}>{!!ite.signAdress? ite.signAdress: '--'}</div>
                  </Tooltip>
                  <Tooltip title={!!ite.scopeName? ite.scopeName: '--'}>
                      <div className={styles.tdItem + ' ' + 'text-overflow'}>{!!ite.scopeName? ite.scopeName: '--'}</div>
                  </Tooltip>
                  <div className={styles.tdItem}>
                        <span
                          className={styles.detail}
                          onClick={() => { this.showDetail(ite) }}
                        >详情</span> 
                  </div>
                   <div className={styles.tdItem} />
                  </div>  
                ))  
              }   
          </div> : <NoData />
          }
        </div>
        <div className={styles.footerBox}>
          {
            this.state.total > 10 && <Pagination
              start={1}
              size={this.state.pageSize}
              current={this.state.page + 1}
              total={this.state.total}
              onChange={this.pageChange}
          />
          }
          </div>
          <Modal visible={this.state.visible}
                 onCancel={this.handleCancel}
                 bodyStyle={{padding: '24px 0'}}
                 header={null}
                 footer={null}
          >
            <div>
              <div id='calculate' style={{margin: '0 auto', width: '300px', height: '0', padding: '0 24px', overflow: 'hidden'}}>
                <Calendar mode='month' fullscreen={false}
                          dateCellRender={this.dateCellRender}
                          onSelect={this.onSelect}
                />
              </div>
              <div id='backArrow' style={{margin: '0 0 20px 0', display: 'none', borderBottom: '3px solid #ececec', textAlign: 'center'}}><img onClick={this.hiddenCal} style={{width: '40px', cursor: 'pointer'}} src={back} alt='' /></div>
              <div className={styles['table-list']} style={{padding: '0 24px'}}>
                <header>签到详情</header>
                <div>
                    {
                      this.state.signInList.length > 0?this.state.signInList.map((obj, index) => (
                          <ul key={index}>
                            <li>
                              <span style={{color: '#59b8b5'}}>{!!obj.userName? obj.userName: '--'}</span>
                              <span style={{float: 'right'}}>{this.formatTime(obj.signInTime)}</span>
                            </li>
                            <li>
                              <span>签到位置：</span>
                              <span>{!!obj.signAdress? obj.signAdress: '--'}</span>
                            </li>
                            <li>
                              <span>工作记录：</span>
                              <span>{!!obj.workRecord? obj.workRecord: '--'}</span>
                            </li>
                            <li>
                              <a href="javascript:void(0);" style={{color: 'blue'}} onClick={() => {this.showImg(obj.imgpath)}}>查看图片</a>
                            </li>
                          </ul>
                      )): <div style={{height: '84px'}}>暂无数据</div>
                    }
                </div>
              </div>
              <div style={{height: '319px'}} id='full'>
              </div>
              <div style={{height: '43px', margin: '0 0 20px 0'}} id='fullArrow'>
              </div>
              <footer style={{textAlign: 'right'}}>
                <img onClick={this.showCal} style={{margin: '0 24px 0 0', cursor: 'pointer'}} src={calculate} alt='' />
              </footer>
            </div>
          </Modal>
          {
            this.state.img
          }
      </div>
    )
  }
}

export default withRouter(RightBox)

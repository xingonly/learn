import React, { Component } from "react"
import Header from 'components/BigTitle'
import LeftBox from './LeftBox'
import RightBox from './RightBox'
import styles from './styles.scss'

class SignInManager extends Component {

    render() {
        return (
            <section id={styles['signInManager']}>
                <div className={styles.container}>
                    <Header title="签到管理" />
                    <LeftBox />
                    <RightBox />
                </div>
            </section>
        )
    }
}

export default SignInManager
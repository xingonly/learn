import React,{ Component } from 'react'
import { withRouter } from 'react-router-dom'
import echarts from 'echarts'
import Title from 'components/Title'
import { message, Modal } from 'antd'
import resource from 'resource'
// import Pie from './subPage/Pie'
import Bar from './subPage/Bar/bar'
import styles from './styles.scss'
import { workApi } from 'configs/endpoints.prod'
import NoData from '../../../../components/noData'

class LeftBox extends Component {
  constructor(props) {
    super(props);
    this.state = {
        signList: [],
        page: 0,
        size: 10,
    }
  }
  componentDidMount() {
    this.requireRegionSign();
  }

  requireRegionSign = () => {
      resource.get(`${workApi.getRegionSignTown}`).then(res => {
        if(res.status !== 200) {
          message.error(res.message);
        }else {
          let newRes = res.data;
          let newArr = [];
          let newArrLevelTwo = [];
          for(let i = 0; i < newRes.length; i++) {
            if(i%4 === 0 && i !== 0) {
              newArr.push(newArrLevelTwo);
              newArrLevelTwo = [];
              newArrLevelTwo.push(newRes[i])
            }else {
              newArrLevelTwo.push(newRes[i])
            }
            if(i === newRes.length - 1) {
              newArr.push(newArrLevelTwo);
              newArrLevelTwo = [];
            }
          }
          this.setState({
              signList: newArr
          })
        }
      })
  };

  render() {
    return (
      <div className={styles.leftContainer}>
        <Title name='签到统计' />
        <div className={styles['region-sign']}>
            {
              this.state.signList &&
              (
                  this.state.signList.length > 0?
                      this.state.signList.map((obj, index) => (
                          <ul key={index}>
                            <li>
                                {
                                  obj.map((ob, index) => (
                                      <span style={{color: '#59afba'}} key={index} className='text-overflow' title={!!ob.total? ob.total: 0}>{!!ob.total? ob.total: 0}</span>
                                  ))
                                }
                            </li>
                            <li>
                                {
                                  obj.map((ob, index) => (
                                      <span key={index} className='text-overflow' title={!!ob.town? ob.town: '--'}>{!!ob.town? ob.town: '--'}</span>
                                  ))
                                }
                            </li>
                          </ul>
                      )): <NoData />
              )
              ||
              <NoData />
            }
        </div>
        <div className={styles.chartsBox}>
          <div className={styles.chartItem}>
            <div style={{height: "30rem",  width: "100%"}}>
              <Bar />
            </div>
          </div>
        </div>
      </div>
    )
  }
}

export default withRouter(LeftBox)

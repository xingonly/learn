import React, { Component } from 'react'
import { withRouter } from 'react-router-dom'
import { workApi } from 'configs/endpoints.prod'
import { message } from 'antd'
import echarts from 'echarts'
import resource from 'util/resource'
import Title from 'components/Title'

class chart extends Component{
    constructor(props){
        super(props);
        this.chart = null;
        this.paramas = {
            "district_code": 520402000000,
            "year": "2017"
        };
        this.state = {
            header: [],
            optionData:[],
        };
    }

    componentWillMount(){
        this.getInitData();
    }

    componentDidMount(){
        this.myChart = echarts.init(this.refs.barTest);
        this.getOption();
        let _this = this;
        window.addEventListener("resize",function(){
            _this.myChart.resize();
        });
    }

    getInitData = () => {
        resource.get(`${workApi.getRegionSign}`).then((res) => {
            if(res.status === 200){
                let newRes = res.data ? res.data.slice(0, 9) : [];
                let header = [];
                let realData = [];
                if(newRes.length > 0) {
                    for(let item of newRes) {
                        header.push(item.village);
                        realData.push({
                            name: !!item.village? item.village: '--',
                            value: !!item.total? item.total: 0
                        })
                    }
                }
                this.setState({
                    header: header,
                    optionData: realData
                },() => {
                    this.getOption();
                });
            }else {
                message.error(res.message);
            }
        })
    }

    getOption  = () => {
        let option={
            tooltip:{
                trigger: 'axis',
                axisPointer : {
                    type : 'shadow'
                }
            },
            grid: {
                bottom: '25%'
            },
            xAxis:{
                data: this.state.header,
                axisLine: {
                    lineStyle: {
                        color: '#eaeaea',
                        width: 1
                    }
                },
                splitLine: {
                    lineStyle: {
                        color: '#eaeaea',
                        width: 2
                    }
                },
                axisTick:{
                    show: false
                },
                axisLabel: {
                    rotate: -45,
                    interval: 0,
                    margin: 15,
                    textStyle: {
                        color:'#717171'
                    }
                }
            },
            yAxis:{
                name: '',
                nameTextStyle: {
                    color: '#717171',
                    fontSize: 14
                },
                axisLine: {
                    show: false
                },
                axisTick: {
                    show: false
                },
                splitLine: {
                    lineStyle: {
                        color: '#f7f7f7'
                    }
                },
                axisLabel: {
                    textStyle: {
                        color:'#717171'
                    }
                }
            },
            series:[{
                name:'',
                type:'bar',
                barMaxWidth: 20,
                data: this.state.optionData,
                itemStyle:{
                    normal:{
                        barBorderRadius:40,
                        color:'#0fb2c3',
                        borderWidth:2,
                        shadowColor:'rgba(168,225,226,0.5)'
                    }
                }

            }]
        };
        this.myChart.setOption(option);
    };

    render(){
        return(
                <div ref="barTest" style={{height:'100%',width:'100%'}}></div>
        )
    }
}

export default withRouter(chart)
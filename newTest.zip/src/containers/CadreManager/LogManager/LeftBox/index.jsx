import React,{ Component } from 'react'
import { withRouter } from 'react-router-dom'
import echarts from 'echarts'
import Title from 'components/Title'
import resource from 'resource'
// import Pie from './subPage/Pie'
// import Line from './subPage/Line'
import styles from './styles.scss'

class LeftBox extends Component {
  constructor(props) {
    super(props)
    this.state = {
      lineData: []
    }
  }
  componentDidMount() {
    this.getLine()
  }

  getLine = () => {
    resource.get('/xixiu-work/workLog/pagebyscope').then(res => {
      if (res.status == 200)
      {
        this.setState({
          lineData: res.data || []
        }, () => {
          this.initEcharts();
        })
      }
    })
  }

  initEcharts = () => {
    this.myChart = echarts.init(this.refs.container);
    const option = {
      // grid: {
      //   left: 50,
      //   right: 0
      // },
      xAxis: {
        type: 'value',
        axisTick: {
          show: false
        },
        axisLine: {
          show: false
        },
        axisLabel: {
          show: false
        },
        splitLine: {
          show: false
        },
        z: 10
      },
      yAxis: {
        type: 'category',
        // offset: 50,
        data: this.state.lineData.map(item => {
          return item.name;
        }),
        // axisLine: {
        //   show: false
        // },
        axisTick: {
          show: false
        },
        axisLabel: {
          textStyle: {
            color: '#000'
          }
        }
      },
      series: [
        { // For shadow
          type: 'bar',
          itemStyle: {
            normal: {color: 'rgba(0,0,0,0)'}
          },
          barGap:'-100%',
          barCategoryGap:'40%',
          data: (() => {
            let max = 0;
            this.state.lineData.forEach((item) => {
              if(item.count > max)
              {
                max = item.count;
              }
            });
            return this.state.lineData.map(item => {
              return max;
            })
          })(),
          animation: false
        },
        {
          type: 'bar',
          label: {
            normal: {
              position: 'right',
              textStyle: {
                color: '#78bcc8'
              },
              show: true
            }
          },
          itemStyle: {
            normal: {
              barBorderRadius: 10,
              color: new echarts.graphic.LinearGradient(
                1, 0, 0, 0,
                [
                  {offset: 0, color: '#adfced'},
                  {offset: 0.5, color: '#81d3d3'},
                  {offset: 1, color: '#57aab7'}
                ]
              )
            },
            emphasis: {
              barBorderRadius: 10,
              color: new echarts.graphic.LinearGradient(
                1, 0, 0, 0,
                [
                  {offset: 0, color: '#adfced'},
                  {offset: 0.5, color: '#81d3d3'},
                  {offset: 1, color: '#57aab7'}
                ]
              )
            }
          },
          data: this.state.lineData.map(item => {
            return item.count
          })
        }
      ]
    };
    this.myChart.setOption(option)
  }

  render() {
    return (
      <div className={styles.leftContainer}>
        <Title name='日志统计' />
        <div className={styles.chartsBox}>
          <div className={styles.chartItem}>
            <div ref='container'/>
          </div>
        </div>
      </div>
    )
  }
}

export default withRouter(LeftBox)

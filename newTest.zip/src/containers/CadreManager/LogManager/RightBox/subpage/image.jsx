import React, {Component} from 'react';
import style from './image.scss';

let timer = null;

class Image extends Component {

  state = {
    show: this.props.show
  }

  onClose = () => {
    this.setState({
      show: false
    }, () => {
      if(timer)
      {
        return;
      }
      timer = setTimeout(() => {
        if(this.props.onClose)
        {
          timer = null;
          this.props.onClose();
        }
      }, 300);
    });
  }

  componentWillReceiveProps(nextProps) {
    if(this.props.show !== nextProps.show)
    {
      this.setState({
        show: nextProps.show
      });
    }
  }

	render() {
    const { show } = this.state;
    if(!this.props.show)
    {
      return <div></div>
    }
		return (
			<div onClick={this.onClose} className={style.container + ' ' + (show ? style.containerEnter : style.containerLeave)}>
        <div className={style.content + ' ' + (show ? style.contentEnter : style.contentLeave)}>
          <img src={this.props.url} />
        </div>
			</div>
		)
	}
}

export default Image;

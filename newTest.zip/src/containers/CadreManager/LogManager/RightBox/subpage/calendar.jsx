import React, {Component} from 'react';
import style from './calendar.scss';
import { Calendar } from 'antd';
import moment from 'moment';
import { isDeepEmpty } from 'utils';

class CalendarComponent extends Component {

  state = {
    current: moment().valueOf()
  }

  onSelect = (date) => {
    this.setState({
      current: date.valueOf()
    }, () => {
      if(this.props.onChange)
      {
        this.props.onChange(date);
      }
    });
  }

  componentDidMount() {
    if(this.props.currentInfo)
    {
      this.setState({
        current: this.props.currentInfo.createTime
      });
    }
  }

  componentWillReceiveProps(nextProps) {
    if(JSON.stringify(this.props.currentInfo) !== JSON.stringify(nextProps.currentInfo) && !isDeepEmpty(nextProps.currentInfo))
    {
      this.setState({
        current: nextProps.currentInfo.createTime
      })
    }
  }

  renderCalender = (date) => {
    const d = date.get('date');
    const { current } = this.state;
    const currentMoment = moment(current);
    const { info } = this.props;
    if(this.isHaveLog(date))
    {
      return (
        <div className="ant-fullcalendar-date haveLog">
          <div className="ant-fullcalendar-value">{d < 10 ? '0' + d : d}</div>
          <div className="ant-fullcalendar-content"></div>
        </div>
      )
    }else{
      return (
        <div className="ant-fullcalendar-date">
          <div className="ant-fullcalendar-value">{d < 10 ? '0' + d : d}</div>
          <div className="ant-fullcalendar-content"></div>
        </div>
      )
    }
  }

  onClose = () => {
    if(this.props.onClose)
    {
      this.props.onClose();
    }
  }

  isHaveLog = (date) => {
    const { info = [] } = this.props;
    return info.find(item => date.isSame(item.createTime, 'day'));
  }

	render() {
    const { show } = this.props;
    const { current } = this.state;
		return (
			<div className={style.container} style={{height: show ? '350px' : '0'}}>
        <div>
          <Calendar
            fullscreen={false}
            onPanelChange={this.onSelect}
            onSelect={this.onSelect}
            dateFullCellRender={this.renderCalender}
            value={moment(current)}
          />
        </div>
        <i className="iconfont" onClick={this.onClose}>&#xe65a;</i>
			</div>
		)
	}
}

export default CalendarComponent;

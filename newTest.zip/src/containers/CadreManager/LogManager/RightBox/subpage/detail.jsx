import React, {Component} from 'react';
import style from './detail.scss';
import { formatDateT } from 'utils';
import Calendar from './calendar'
import moment from 'moment'
import { isDeepEmpty } from 'utils'
import Image from './image'
import { message } from 'antd'

class Detail extends Component {

  state = {
    currentInfo: {},
    showCalendar: false,
    showImage: false
  }

  showCalender = () => {
    this.setState({
      showCalendar: !this.state.showCalendar
    })
  }

  onCalenderChange = (date) => {
    const { info = [] } = this.props;
    const match = info.find(item => date.isSame(item.createTime, 'day'));
    if(match)
    {
      this.setState({
        currentInfo: match
      });
    }else{
      this.setState({
        currentInfo: {}
      })
    }
  }

  showImage = () => {
    const { currentInfo } = this.state;
    if(!(currentInfo.imgurls && currentInfo.imgurls[0]))
    {
      message.warning('当日没有日志图片')
      return;
    }
    this.setState({
      showImage: true
    });
  }

  componentDidMount() {
    this.setState({
      currentInfo: this.props.info && this.props.info[0] || {}
    });
  }

  componentWillReceiveProps(nextProps) {
    if(JSON.stringify(this.props.info) !== JSON.stringify(nextProps.info))
    {
      this.setState({
        currentInfo: nextProps.info[0] || {}
      });
    }
  }

	render() {
    const { currentInfo, showCalendar, showImage } = this.state;
		return (
			<div className={style.container}>
        <Calendar show={showCalendar} onClose={this.showCalender} info={this.props.info} currentInfo={currentInfo} onChange={this.onCalenderChange}/>
        <Image show={showImage} url={currentInfo.imgurls && currentInfo.imgurls[0]} onClose={() => {
            this.setState({
              showImage: false
            });
          }}/>
        <div className={style.contentContainer}>
          <h1>日志详情</h1>
          <div className={style.info}>
            <div>
              {currentInfo.realName}
            </div>
            <div>
              {formatDateT(currentInfo.createTime, 'second', ['/', ':'])}
            </div>
          </div>
          {
            isDeepEmpty(currentInfo) ? (
              <div className={style.content}>
                <div className={style.noLog}>
                  <span>当日没有日志记录</span>
                </div>
              </div>
            ) : (
              <div className={style.content}>
                <div className={style.row}>
                  <label>今日完成工作：</label>
                  <div className={style.span}>
                    {currentInfo.done || '-'}
                  </div>
                </div>
                <div className={style.row}>
                  <label>今日未完成工作：</label>
                  <div className={style.span}>
                    {currentInfo.undos || '-'}
                  </div>
                </div>
                <div className={style.row}>
                  <label>需协调工作：</label>
                  <div className={style.span}>
                    {currentInfo.needHelp || '-'}
                  </div>
                </div>
                <div className={style.row}>
                  <label>备注：</label>
                  <div className={style.span}>
                    {currentInfo.remark || '-'}
                  </div>
                </div>
              </div>
            )
          }
          <div className={style.footer}>
            <i className="iconfont" onClick={this.showImage}>&#xe691;</i>
            <i className="iconfont" onClick={this.showCalender}>&#xe603;</i>
          </div>
        </div>
			</div>
		)
	}
}

export default Detail;

import React,{ Component } from 'react'
import { withRouter, Link } from 'react-router-dom'
import resource from 'resource'
import { Tooltip } from 'antd'
import moment from  'moment'
import Filter from 'components/Filter'
import Loading from 'components/Loading'
import NoData from 'components/noData'
import Pagination from 'components/PaginationNoEnd'
import { convertQueryString } from 'utils'
import List from './list.json'
import styles from './styles.scss'
import { Modal } from 'antd'
import Detail from './subpage/detail'

const ths = ['干部名称', '所属单位', '最近提交时间', '提交内容', '帮扶区域', ' ']

class RightBox extends Component {
  constructor(props) {
    super(props)
    this.state = {
      loading: false,
      data: [],
      page: 0,
      pageSize: 10,
      total: 0,
      code: '',
      keyword: '',
      startTime: null,
      endTime: null,
      visiable: false,
      detailInfo: [],
      showCalendar: false
    }
  }

  componentDidMount() {
    this.listRequire()
  }

  listRequire = () => {
    this.setState({
      loading: true
    })
    let params = {
      keyword: this.state.keyword,
      beginTime: this.state.startTime,
      endTime: this.state.endTime,
      page: this.state.page,
      size: 10
    }
    if(this.state.keyword)
    {
      if(!(/^1[3|4|5|7|8|9][0-9]\d{4,8}$/.test(this.state.keyword)))
      {
        params.realName = this.state.keyword;
      }else{
        params.phone = this.state.keyword;
      }
    }
    if(this.state.code)
    {
      if((/000$/).test(this.state.code + ''))
      {
        params.xiang = this.state.code;
      }else{
        params.cun = this.state.code;
      }
    }
    resource.get(`/xixiu-work/workLog/page${convertQueryString(params)}`).then(res => {
    // resource.get(`/xixiu-work/workLog/page/${convertQueryString(params)}`).then(res => {
      if (res.status == 200) {
        this.setState({
          data: res.data && res.data.content,
          total: res.data && res.data.totalElements,
          loading: false
        })
      } else {
        this.setState({
          loading: false
        })
      }
    }).catch(e => {
      this.setState({
        loading: false
      })
    })
  }

  pageChange = page => {
    this.setState({
        page: page
    },() => {
        this.listRequire()
    })
  }

  formatTime = x => {
    return x ? moment(parseInt(x, 10)).format('YYYY-MM-DD hh:mm:ss') : '--'
  }

  showDetail = ite => {
    resource.get(`/xixiu-work/workLog/monthrecord/${ite.id}`).then(res => {
      this.setState({
        detailInfo: res.data || [],
        visiable: true
      });
    });
  }

  onSubmit = data => {
    this.setState({
      code: data.code,
      keyword: data.value,
      startTime: data.startTime,
      endTime: data.endTime,
      page: 0
    }, () => {
      this.listRequire()
    })
  }

  handleModalOk = () => {
    this.hideModal();
  }

  hideModal = () => {
    this.setState({
      visiable: false
    });
  }

  render() {
    const { visiable, detailInfo } = this.state;
    return (
      <div className={styles.rightContainer}>
        <Modal
          title="Modal"
          visible={visiable}
          onOk={this.handleModalOk}
          onCancel={this.hideModal}
          footer={null}
          title={null}
          width={600}
          destroyOnClose
          className={styles.modal}
        >
          <Detail info={detailInfo}/>
        </Modal>
        <Filter
          title='日志查询'
          placeholder="请输入干部姓名或电话号码"
          allowDate
          allowSelect
          operateName="提交时间："
          onSubmit={this.onSubmit}
        />
        <div className={styles.tableBox}>
          <div className={styles.thBox}>
            {
              ths.map(ite =>
                <div className={styles.thItem} key={`ths_${ite}`}>{ite}</div>
              )
            }
          </div>
          {
            this.state.loading ? <Loading /> : this.state.data.length
              ? <div className={styles.trBox}>
            {
                  this.state.data.map((ite, idx) => (
                <div key={ite.id} className={styles.trItem}>
                  <div className={styles.tdItem} />
                  <div className={styles.tdItem}>{ite.realName}</div>
                  <div className={styles.tdItem + ' ' + 'text-overflow'}>{ite.department}</div>
                  <div className={styles.tdItem}>{this.formatTime(ite.createTime)}</div>
                  <Tooltip title={ite.done}>
                    <div className={styles.tdItem + ' ' + 'text-overflow'}>{ite.done}</div>
                  </Tooltip>
                  <div className={styles.tdItem + ' ' + 'text-overflow'}>{ite.helpXiang + ite.helpCun}</div>
                  <div className={styles.tdItem}>
                        <span
                          className={styles.detail}
                          onClick={() => { this.showDetail(ite) }}
                        >详情</span>
                  </div>
                   <div className={styles.tdItem} />
                  </div>
                ))
              }
          </div> : <NoData />
          }
        </div>
        <div className={styles.footerBox}>
          {
            this.state.total > 10 && <Pagination
              start={1}
              size={this.state.pageSize}
              current={this.state.page}
              total={this.state.total}
              onChange={this.pageChange}
          />
          }
          </div>
      </div>
    )
  }
}

export default withRouter(RightBox)

import React, { Component } from "react"
import Header from 'components/BigTitle'
import LeftBox from './LeftBox'
import RightBox from './RightBox'
import styles from './styles.scss'

class LogManager extends Component {

    render() {
        return (
            <section id={styles['logManager']}>
                <div className={styles.container}>
                    <Header title="日志管理" />
                    <LeftBox />
                    <RightBox />
                </div>
            </section>
        )
    }
}

export default LogManager
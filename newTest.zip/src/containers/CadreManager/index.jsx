import React, {Component} from "react";
import styles from './styles.scss';

export default class CadreManagerContainer extends Component {

    render() {
        return (
            <section id={styles['CadreManager']}>
                <div className={styles.container}>
                    {this.props.children}
                </div>
            </section>
        )
    }
}
import React, {Component} from 'react';
import style from './style.scss';
import Education from './subPage/education/education';
import PublicSecurity from './subPage/PublicSecurity'
import Industry from './subPage/Industry'
import Build from './subPage/Build'
import Immigration from './subPage/Immigration'
import Health from './subPage/health/health';
import People from './subPage/people/people';
import Land from './subPage/land/Land';
import Map from './subPage/map';
import immutable from 'immutable'
import createHistory from 'history/createHashHistory'
const history = createHistory()
import resource from '../../util/resource'

export default class Index extends Component {

    constructor(props) {
        super(props);
        this.state = {
            data: immutable.fromJS([]),
            MapData: immutable.fromJS([]),
            index: 0,
            show:false
        }
        this.code = null;
        this.param ={
            name:'guizhou',
            district_code:null,
            flag:false
        }
    }
    componentDidMount() {
        let scope = JSON.parse(sessionStorage.getItem('manager'))
        this.param.district_code = scope.scope;
        this.code = scope.scope;
        this.handleName(scope.scope);
        this.find(scope.scope)
        this._initDatas()
    }
    handleReturn=()=>{
        this.param.district_code = 520000000000;
        this.param.name = 'guizhou'
        this.setState({
            show:false,
            index:0
        },this._initDatas())
    }

    find = (scope)=>{
        let s = [520100000000, 520200000000, 520300000000, 520400000000,520500000000,520600000000, 522300000000, 522600000000, 522700000000];
        for(let i =0; i< s.length; i++){
            if(this.code === 520000000000){
                this.param.name = this.param.name;
                return;
            }else if(s[i] === scope){
                this.param.name = this.param.name;
                return;
            }
        }
        console.log(this.r)
        this.getLastId();
    }

    getLastId = () =>{
        resource.get( `/xixiu-server/region/getRegionById/${this.param.district_code}` ).then(res =>{
            if(res.status ===200){
                let scope = res.data.parentid;
                this.param.district_code = scope;
                this.param.flag = true;
                this.handleName(scope);
                this._initDatas();
            }
        })
    }

    _initDatas = () => {
        resource.get(`/pww/statistics/v0.1/report/heat?district_code=${this.param.district_code}`).then(res => {
            if(res.data.heat.length === 1){
                this.setState({
                    data: immutable.fromJS(res.data),
                })
            }else{
                this.setState({
                    data: immutable.fromJS(res.data),
                    MapData: immutable.fromJS(res.data.heat)
                })
            }
        })
    }

    clickMap = (area,code) => {
        if(this.state.show){
            return;
        }
        if(code === this.param.district_code){
            return;
        }
        let data = this.state.MapData;
        this.param.district_code = code;
        let codes = {'贵阳市': 520100000000,'六盘水市': 520200000000, '遵义市': 520300000000,  '安顺市': 520400000000, '毕节市': 520500000000, '铜仁市': 520600000000, '黔西南布依族苗族自治州': 522300000000, '黔东南苗族侗族自治州': 522600000000, '黔南布依族苗族自治州': 522700000000}
        let city = codes[area];
        this.handleName(city);
        for (let i = 0, len = data.size; i < len; i++) {
            if (data.getIn([i, 'district_string']) === area && this.code === 520000000000) {
                this.setState({
                    show:true
                },this._initDatas())
            }else{
                this._initDatas()
            }
        }
    }

    handleName =(city) =>{
        switch (city) {
            case 520100000000:
                this.param.name='guiyang';
                break;
            case 520200000000:
                this.param.name='liupanshui';
                break;
            case 520300000000:
                this.param.name='zunyi';
                break;
            case 520400000000:
                this.param.name='anshun';
                break;
            case 520500000000:
                this.param.name='bijie';
                break;
            case 520600000000:
                this.param.name='tongren';
                break;
            case 522300000000:
                this.param.name='qianxinan';
                break;
            case 522600000000:
                this.param.name='qiandongnan';
                break;
            case 522700000000:
                this.param.name='qiannan';
                break;
            default:
                this.param.name = this.param.name;
                break;
        }
    }


    render() {
        let {MapData,data} = this.state;
        return (
            <section id={style['index-style']}>
                <div className={style.shadow}>
                    <div className={style.left}>
                        <div style={{height: '12.85rem', marginBottom: '1rem'}}>
                            <PublicSecurity data={data}/>
                        </div>
                        <div style={{height: '18.15rem', marginBottom: '1rem'}}>
                            <Build data={data}/>
                        </div>
                        <div style={{height: '11.7rem'}}>
                            <Industry data={data}/>
                        </div>
                    </div>
                    <div className={style.center}>
                        <div className={style.map}>
                            <Map data={MapData} clickMap={this.clickMap} name={this.param.name} id="zhongguo"/>
                        </div>
                        <div className={style.return} style={{display:this.state.show ? 'block' : 'none'}}>
                            <i className="iconfont">&#xe618;</i>
                            <span onClick={this.handleReturn}>返回</span>
                        </div>
                        <div className={style.c_left}>
                            <div style={{height: '11.7rem', width: '19.4rem'}}>
                                <Immigration data={data}/>
                            </div>
                        </div>
                        <Land data={data} />
                    </div>
                    <div className={style.right}>
                        <Education id="edu" data={data}/>
                        <Health data={data} />
                        <People id="people" data={data}/>
                    </div>
                </div>

            </section>
        )
    }
}

// 上帝保佑,永无bug
import React, {Component} from "react";
import {Link,hashHistory} from 'react-router';
import style from './industry.scss'
import Card from '../../../components/Card'
import resource from '../../../util/resource'
import echarts from 'echarts'
import createHistory from 'history/createHashHistory'
const history = createHistory()

class Pie extends Component {

    constructor (props) {
        super(props);

        this.deg = 0;
    }

    initPie = () => {
        let chart = document.querySelector('#container');
        var rect = chart.getBoundingClientRect();
        this.stage = new Konva.Stage({
            container: 'container',
            width: rect.width,
            height: rect.height
        });

        if(!this.props.data)
        {
            return;
        }

        var data = this.props.data.getIn(['content','gongshang']);
		var join_hzs = data && data.getIn(['join_hzs']) || 0;
		var zczb_50_100 = data && data.getIn(['zczb_50_100']) || 0;
		var zczb_100_ = data && data.getIn(['zczb_100_']) || 0;

        this.drawBorder(this.stage);
        this.drawSector(this.stage,parseInt(join_hzs / (join_hzs + zczb_50_100 + zczb_100_) * 360));
        this.drawSectorText(this.stage,join_hzs);
        var linePointPosition = this.drawBlock(this.stage,zczb_50_100,zczb_100_);
        this.drawLine(this.stage,linePointPosition);
    }

    drawBorder = (stage) => {
        var layer = new Konva.Layer();
        var ring = new Konva.Arc({
            x: stage.getHeight() / 2,
            y: stage.getHeight() / 2,
            innerRadius: stage.getHeight() / 2 - 10,
            outerRadius: stage.getHeight() / 2 - 5,
            angle: 360,
            fill: '#3d78dc'
        });
        layer.add(ring);
        stage.add(layer);
    }

    drawSector = (stage,degree) => {
        this.layer = new Konva.Layer();
        this.arcPie = new Konva.Arc({
            x: stage.getHeight() / 2,
            y: stage.getHeight() / 2,
            innerRadius: stage.getHeight() / 2 - 5,
            // outerRadius: 70,
            angle: 0,
            rotation: -180 + degree/2,
            fill: '#0ce0f5',
            clockwise: true
        });

        this.layer.add(this.arcPie);

        this.arcPie.to({
            x: stage.getHeight() / 2,
            y: stage.getHeight() / 2,
            innerRadius: stage.getHeight() / 2 - 5,
            // outerRadius: 70,
            angle: -degree,
            rotation: -180 + degree/2,
            fill: '#0ce0f5',
            clockwise: true,
            duration: 1.5,
            easing: Konva.Easings.EaseOut
        });

        this.layer.on('mouseover', (e) => {
            this.arcPie.setInnerRadius(this.stage.getHeight() / 2);
            this.layer.draw();
        })

        this.layer.on('mouseleave', (e) => {
            this.arcPie.setInnerRadius(this.stage.getHeight() / 2 - 5);
            this.layer.draw();
        })

        stage.add(this.layer);

    }

    drawSectorText = (stage,text) => {
        var layer = new Konva.Layer();
        var text = new Konva.Text({
            x: 5,
            y: stage.getHeight() / 2 - 7,
            width: stage.getHeight() / 2,
            align: 'center',
            text: text + '',
            fontSize: this.getFontSize() * 0.7,
            fill: 'white'
        });
        layer.add(text);
        stage.add(layer);
    }

    getLine = (point, dot, r) => {
        var r_square = Math.pow(r, 2); // r的平方
        var point_v = point[1] - dot[1]; //point到x轴的距离的平方
        var point_h = point[0] - dot[0]; //point到y轴的距离的平方
        var c_square = Math.pow(point_v, 2) + Math.pow(point_h, 2); //point到圆心的距离的平方

        var c = Math.sqrt(c_square); //point到圆心的距离

        var sinA = Math.abs(point_v) / c; //sinA
        var cosA = Math.abs(point_h) / c; //cosA
        var b_square = c_square - r_square; //point到切点的距离的平方
        var b = Math.sqrt(b_square); //point到切点的距离

        var sinB = b / c; //sinB
        var cosB = r / c; //cosB
        //以圆心为坐标圆点，确定point所在的象限
        var quadrant = 1; //默认值
        var pm_h = point_h == 0 ? point_h : point_h / Math.abs(point_h); //水平方向
        var pm_v = point_v == 0 ? point_v : point_v / Math.abs(point_v); //垂直方向
        var hv = pm_h * pm_v; //相乘，-1时point在一三象限，+1时point在二四象限，0时point在轴上
        switch (hv) {
            case 1:
                if ((pm_h + pm_v) == -2) {
                    quadrant = 2; //第二象限
                } else {
                    quadrant = 4; //第四象限
                }
                break;
            case -1:
                if ((pm_h - pm_v) == -2) {
                    quadrant = 3; //第三象限
                }
                break;
            case 0:
                if ((pm_h + pm_v) == -1) { //point在x轴的负半轴或者y轴的正半轴时，断定point在第二象限
                    quadrant = 2;
                }
                if ((pm_h + pm_v) == 1) { //point在x轴的正半轴或者y轴的负半轴时，断定point在第四象限
                    quadrant = 4;
                }
                break;
            default:
        }
        var sinC = 0;
        var conC = 0;
        var sinD = 0;
        var conD = 0;
        switch (quadrant) {
            case 1:
                sinC = cosB * cosA + sinB * sinA; //sinC = sin(90+(B-A)) = cos(B-A) = cosB*cosA+sinB*sinA
                conC = -(sinB * cosA - cosB * sinA); //cosC = cos(90+(B-A)) = -sin(B-A) = -(sinB*cosA-cosB*sinA)
                sinD = -(cosA * cosB - sinA * sinB); //sinD = sin(270-(A+B))
                conD = -(sinA * cosB + cosA * sinB); //conD = cos(270-(A+B))
                break;
            case 2:
                sinC = -(cosB * cosA - sinB * sinA); //sinC = sin(-90+(A+B))
                conC = sinA * cosB + cosA * sinB; //conC = cos(-90+(A+B))
                sinD = cosA * cosB + sinA * sinB; //sinD = sin(90+(A-B))
                conD = -(sinA * cosB - cosA * sinB); //conD = cos(90+(A-B))
                break;
            case 3:
                sinC = -(cosA * cosB + sinA * sinB); //sinC = sin(-90+(A-B))
                conC = -(sinA * cosB - cosA * sinB); //conC = cos(-90+(A-B))
                sinD = (cosA * cosB - sinA * sinB);
                conD = sinA * cosB + cosA * sinB;
                break;
            case 4:
                sinC = cosA * cosB - sinA * sinB;
                conC = -(sinA * cosB + cosA * sinB)
                sinD = -(cosA * cosB + sinA * sinB); //sinD = sin(270+(A-B))
                conD = (sinA * cosB - cosA * sinB); //conD = cos(270+(A-B))
                break;
            default:
        }
        return {
            point1: {x: point[0] + b * conC, y: point[1] + b * sinC},
            point2: {x: point[0] + b * conD, y: point[1] + b * sinD}
        }; //两个切点位置
    }

    drawLine = (stage,position) => {
        var layer = new Konva.Layer();

        var x1 = position.top.x - stage.getHeight() / 2;
        var y1 = position.top.y - stage.getHeight() / 2;

        var x2 = position.bottom.x - stage.getHeight() / 2;
        var y2 = position.bottom.y - stage.getHeight() / 2;

        var line1 = {...this.getLine([x1,y1],[0,0],stage.getHeight() / 2 - 5)};
        line1.x = line1.point1.y < 0 ? line1.point1.x : line1.point2.x;
        line1.y = line1.point1.y < 0 ? line1.point1.y : line1.point2.y;
        var line2 = {...this.getLine([x2,y2],[0,0],stage.getHeight() / 2 - 5)};
        line2.x = line2.point1.y > 0 ? line2.point1.x : line2.point2.x;
        line2.y = line2.point1.y > 0 ? line2.point1.y : line2.point2.y;

        var d1 = Math.sqrt(Math.pow(position.top.x - stage.getHeight() / 2 - line1.x,2) + Math.pow(position.top.y - stage.getHeight() / 2 - line1.y,2));
        var sin1 = (position.top.y - stage.getHeight() / 2 - line1.y) / d1;
        var degree1 = Math.asin( sin1 ) / (2 * Math.PI) * 360;

        var d2 = Math.sqrt(Math.pow(position.bottom.x - stage.getHeight() / 2 - line2.x,2) + Math.pow(position.bottom.y - stage.getHeight() / 2 - line2.y,2));
        var sin2 = (position.bottom.y - stage.getHeight() / 2 - line2.y) / d2;
        var degree2 = Math.asin( sin2 ) / (2 * Math.PI) * 360;

        var topLine = new Konva.Rect({
            x: stage.getHeight() / 2 + line1.x,
            y: stage.getHeight() / 2 + line1.y,
            width: 0,
            height: 1,
            rotation: degree1,
            fillLinearGradientStartPoint: {
                // x: sin1 / 2 * d1 + stage.getHeight() / 2 + line1.y,
                // y: sin1 / 2 * d1 + stage.getHeight() / 2 + line1.y,
                x: 0,
                y: 0
            },
            fillLinearGradientEndPoint: {
                x: position.top.x,
                y: position.top.y
            },
            fillLinearGradientColorStops: [0, 'transparent', 0.5, '#fff', 0.9, '#fff', 1, 'transparent']
        });

        var bottomLine = new Konva.Rect({
            x: stage.getHeight() / 2 + line2.x,
            y: stage.getHeight() / 2 + line2.y,
            width: 0,
            height: 1,
            rotation: degree2,
            fillLinearGradientStartPoint: {
                x: 0,
                y: stage.getHeight(),
            },
            fillLinearGradientEndPoint: {
                x: position.bottom.x,
                y: position.bottom.y
            },
            fillLinearGradientColorStops: [0, 'transparent', 0.5, '#fff', 0.9, '#fff', 1, 'transparent']
        });
        layer.add(topLine);

        topLine.to({
            width: d1,
            duration: 1.5,
            delay: 1.5,
            easing: Konva.Easings.EaseOut
        });

        layer.add(bottomLine);

        bottomLine.to({
            width: d2,
            duration: 1.5,
            easing: Konva.Easings.EaseOut
        });

        stage.add(layer);
    }

    getBlockHeight = (n,total,full) => {
        var rate = n / total;
        return parseInt(rate * full);
    }

    drawBlock = (stage,n1,n2) => {
        var layer = new Konva.Layer();
        var margin = parseInt(this.getFontSize() * 1.7);
        var height1 = this.getBlockHeight(n1, n1 + n2, stage.getHeight() - margin - 3);
        var height2 = this.getBlockHeight(n2, n1 + n2, stage.getHeight() - margin - 3);

        var rect1 = new Konva.Rect({
            x: stage.getWidth() - 52,
            y: margin / 2,
            width: 52,
            height: height1 >= 14 ? height1 : 14,
            fill: '#a2a2a2'
        });

        var rect2 = new Konva.Rect({
            x: stage.getWidth() - 52,
            y: margin / 2 + (height1 >= 14 ? height1 : 14) + 3,
            width: 52,
            height: height2 >= 14 ? height2 : 14,
            fill: '#e79608'
        });

        var preText1 = new Konva.Text({
            text: n1 + '',
            fontSize: this.getFontSize() * 0.7,
        });
        var preText2 = new Konva.Text({
            text: n1 + '',
            fontSize: this.getFontSize() * 0.7,
        });

        var textWidth1 = preText1.getTextWidth();
        var textWidth2 = preText2.getTextWidth();

        var textHeight1 = margin / 2 + (height1 >= 14 ? height1 : 14) / 2 - (this.getFontSize() * 0.7 >= 12 ? (this.getFontSize() * 0.7 / 2) : (12 / 2));
        var textHeight2 = margin / 2 + (height1 >= 14 ? height1 : 14) + 3 + (height2 >= 14 ? height2 : 14) / 2 - (this.getFontSize() * 0.7 >= 12 ? (this.getFontSize() * 0.7 / 2) : (12 / 2));

        var text1 = new Konva.Text({
            x: stage.getWidth() - 52,
            y: textHeight1,
            width: 52,
            align: 'center',
            text: n1 + '',
            fontSize: this.getFontSize() * 0.7,
            fill: 'white'
        });

        var text2 = new Konva.Text({
            x: stage.getWidth() - 52,
            y: textHeight2,
            width: 52,
            align: 'center',
            text: n2 + '',
            fontSize: this.getFontSize() * 0.7,
            fill: 'white'
        });
        layer.add(rect1);
        layer.add(rect2);
        layer.add(text1);
        layer.add(text2);
        stage.add(layer);

        return {
            top: {
                x: stage.getWidth() - 52,
                y: margin / 2,
            },
            bottom: {
                x: stage.getWidth() - 52,
                y: margin / 2 + (height1 >= 14 ? height1 : 14) + (height2 >= 14 ? height2 : 14) + 3
            }
        };
    }

    getFontSize = () => {
        var w = window.innerWidth;
        if(w >= 1920)
        {
            return 20;
        }else if(w < 1920 && w >= 1600)
        {
            return 16.67;
        }else if(w < 1600 && w >= 1400)
        {
            return 15;
        }else{
            return 14.23;
        }
    }

    componentDidMount () {
        window.addEventListener('resize',this.initPie);
    }

    componentDidUpdate (prevProps) {
        if(prevProps.data === this.props.data)
        {
            return;
        }

        this.initPie();
    }

    componentWillUnmount () {
        window.removeEventListener('resize',this.resize);
        this.layer.off('mouseover');
        this.layer.off('mouseleave');
    }

    render () {
        return (
            <div id='container' style={{height: '100%'}}></div>
        );
    }
}

export default class Industry extends Component {
    constructor(props){
        super(props);
    }

    render () {
        return (
            <div className={style.container}>
                <Card title='工商局' margin>
                    <div className={style.content}>
                        <h2>法人信息</h2>
                        <div className={style.contentInfo}>
                            <div style={{height: '7.1rem', width: '12.4rem'}}>
                                <Pie data={this.props.data}/>
                            </div>
                            <div className={style.contentInfo_right}>
                                <div className={style.row}>
                                    <div className={style.block} style={{background: '#0ce0f5'}}></div>
                                    <p>农民专用合作社</p>
                                </div>
                                <div className={style.row}>
                                    <div className={style.block} style={{background: '#a2a2a2'}}></div>
                                    <p>注册资本50~100万民企</p>
                                </div>
                                <div className={style.row}>
                                    <div className={style.block} style={{background: '#e79608'}}></div>
                                    <p>注册资本100万以上民企</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </Card>
            </div>
        );
    }
}

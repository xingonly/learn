// 上帝保佑,永无bug
import React, {Component} from "react";
import {Link,hashHistory} from 'react-router';
import style from './publicSecurity.scss'
import Card from '../../../components/Card'
import resource from '../../../util/resource'
import echarts from 'echarts'
import createHistory from 'history/createHashHistory'
const history = createHistory()

export default class PublicSecurity extends Component {
    constructor(props){
        super(props);
    }

    state = {
        data: {}
    }

    initData = () => {
        var data = this.props.data.getIn(['content','gongan']);
        this.setState({
            data: {
                car: data.getIn(['small_car_count']),
                vehicles: data.getIn(['agricultural_vehicle_count']),
                motorcycle: data.getIn(['motorcycle_count']),
                bus: data.getIn(['passenger_car_count'])
            }
        });
    }

    getWidth = (num) => {
        if(!num)
        {
            return 0;
        }
        var max = 0;
        for(let key in this.state.data)
        {
            if(this.state.data[key] > max)
            {
                max = this.state.data[key];
            }
        }
        return (parseInt(num/max*0.8*100) < 1 ? 1 : parseInt(num/max*0.8*100)) + '%';
    }

    componentDidUpdate (prevProps) {
        if(prevProps.data === this.props.data)
        {
            return;
        }

        this.initData();
    }

    render () {
        return (
            <div className={style.container}>
                <Card title='公安厅' margin>
                    <div className={style.content}>
                        <div className={style.iconSupport}>
                            <div>
                                <img src={require('../images/car.png')}/>
                            </div>
                            <div>
                                <img src={require('../images/vehicles.png')}/>
                            </div>
                            <div>
                                <img src={require('../images/motorcycle.png')}/>
                            </div>
                            <div>
                                <img src={require('../images/bus.png')}/>
                            </div>
                        </div>
                        <div className={style.labelSupport}>
                            <div>小轿车</div>
                            <div>农用车</div>
                            <div>摩托车</div>
                            <div>客车</div>
                        </div>
                        <div className={style.lineSupport}>
                            <div>
                                <div className={style.line} style={{width: this.getWidth(this.state.data.car)}}></div>
                                <div>{this.state.data.car}</div>
                            </div>
                            <div>
                                <div className={style.line} style={{width: this.getWidth(this.state.data.vehicles)}}></div>
                                <div>{this.state.data.vehicles}</div>
                            </div>
                            <div>
                                <div className={style.line} style={{width: this.getWidth(this.state.data.motorcycle)}}></div>
                                <div>{this.state.data.motorcycle}</div>
                            </div>
                            <div>
                                <div className={style.line} style={{width: this.getWidth(this.state.data.bus)}}></div>
                                <div>{this.state.data.bus}</div>
                            </div>
                        </div>
                    </div>
                </Card>
            </div>
        );
    }
}

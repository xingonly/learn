import React, {Component} from 'react';
import style from './Land.scss';

export default class Land extends Component {

    constructor(props) {
        super(props);
    }

    componentDidUpdate (prevProps) {
        if(prevProps.data === this.props.data)
        {
            return;
        }
        this.initData();
    }

    state = {}

    initData = () => {
        var data = this.props.data.getIn(['content','guotu']);
        this.setState({
            picture_count: data.getIn(['is_registered_count']),
        });
    }

    render() {
        return (
            <section id={style['land']}>
                <h6 className={style.title}>国土厅</h6>
                <div className={style.con}>
                    <i className={"iconfont" + " " + style.icon}>&#xe7cf;</i>
                    <div className={style.text}>
                        <p className={style.font1}>{this.state.picture_count}</p>
                        <p className={style.font2}>有房屋不动产登记信息贫困户</p>
                    </div>
                </div>

            </section>
        )
    }
}
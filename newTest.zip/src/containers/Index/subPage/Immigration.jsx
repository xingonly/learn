// 上帝保佑,永无bug
import React, {Component} from "react";
import {Link,hashHistory} from 'react-router';
import style from './immigration.scss'
import Card from '../../../components/Card'
import resource from '../../../util/resource'
import echarts from 'echarts'
import createHistory from 'history/createHashHistory'
const history = createHistory()

export default class Immigration extends Component {
    constructor(props){
        super(props);
    }

    state = {}

    initData = () => {
        var data = this.props.data.getIn(['content','yimin']);
        this.setState({
            poor_people_total: data.getIn(['poor_people_total']),
            poor_house_total: data.getIn(['poor_house_total']),
            out_count: data.getIn(['out_count']),
            in_count: data.getIn(['in_count']),
            place_count: data.getIn(['place_count'])
        });
    }

    componentDidUpdate (prevProps) {
        if(prevProps.data === this.props.data)
        {
            return;
        }
        this.initData();
    }

    render () {
        return (
            <div className={style.container}>
                <Card title='移民局' subTitle='易地扶贫搬迁情况' margin>
                    <div className={style.content}>
                        <div className={style.row}>
                            <div className={style.col}>
                                <div style={{width: '1.65rem'}} className={style.img}>
                                    <img src={require('../images/people.png')}/>
                                </div>
                                <div>
                                    <p>搬迁人数</p>
                                    <p className={style.number}>{this.state.poor_people_total}</p>
                                </div>
                            </div>
                            <div className={style.col}>
                                <div style={{width: '1.8rem'}} className={style.img}>
                                    <img src={require('../images/houses.png')}/>
                                </div>
                                <div>
                                    <p>搬迁户数</p>
                                    <p className={style.number}>{this.state.poor_house_total}</p>
                                </div>
                            </div>
                        </div>
                        <div className={style.row}>
                            <div className={style.col}>
                                <div style={{width: '1.85rem'}} className={style.img}>
                                    <img src={require('../images/move.png')}/>
                                </div>
                                <div>
                                    <p>迁出地</p>
                                    <p className={style.number}>{this.state.out_count}</p>
                                </div>
                            </div>
                            <div className={style.col}>
                                <div style={{width: '1.9rem'}} className={style.img}>
                                    <img src={require('../images/in.png')}/>
                                </div>
                                <div>
                                    <p>迁入地</p>
                                    <p className={style.number}>{this.state.in_count}</p>
                                </div>
                            </div>
                            <div className={style.col}>
                                <div style={{width: '1.9rem'}} className={style.img}>
                                    <img src={require('../images/position.png')}/>
                                </div>
                                <div>
                                    <p>安置点</p>
                                    <p className={style.number}>{this.state.place_count}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </Card>
            </div>
        );
    }
}

import React, {Component} from 'react';
import style from './style.scss';
import img1 from '../../imges/01.png';
import img2 from '../../imges/02.png';
import img3 from '../../imges/03.png';
import img4 from '../../imges/04.png';
import img5 from '../../imges/05.png';
import img6 from '../../imges/06.png';
import img7 from '../../imges/07.png';

export default class Health extends Component {

    constructor(props) {
        super(props);
        this.img = null;
    }


    handleImg1Width = () => {
        let s = document.querySelector("#ss").offsetWidth;
        let imgs = document.querySelector("#imgs");
        if(imgs.getElementsByTagName('span').length>0){
            imgs.removeChild('span');
        }
        let span = document.createElement("span");
        this.img = imgs.appendChild(span);
        let number = parseInt(s / 7) +4;
        for(let i = 0; i < number; i++){
            let x = parseInt(Math.random()*(7)+1);
            let img = document.createElement("img");
            this.img.appendChild(img).setAttribute('src',this.handleImgUel(x));
        }

    };
    handleImg2Width = () => {
        let s = document.querySelector("#ss1").offsetWidth;
        let imgs = document.querySelector("#imgs1");
        if(imgs.getElementsByTagName('span').length>0){
            imgs.removeChild('span');
        }

            let span = document.createElement("span");
            this.img = imgs.appendChild(span);
            let number = parseInt(s / 7) +4;
            for(let i = 0; i < number; i++){
                let x = parseInt(Math.random()*(7)+1);
                let img = document.createElement("img");
                this.img.appendChild(img).setAttribute('src',this.handleImgUel(x));
            }



    };
    handleImgUel = (x) =>{
        switch (x){
            case 1:
                return img1
                break;
            case 2:
                return img2
                break;
            case 3:
                return img3
                break;
            case 4:
                return img4
                break;
            case 5:
                return img5
                break;
            case 6:
                return img6
                break;
            case 7:
                return img7
                break;
        }
    }

    componentWillReceiveProps(props) {

        this.initData(props);

    }

    state = {}

    initData = (props) => {
        var data = props.data.getIn(['content','weiji']);
        this.setState({
            major_illness: data.getIn(['major_illness']),
            ncms_count: data.getIn(['ncms_poor_people']),
        },()=>{
                this.handleImg1Width()
                this.handleImg2Width();
            }
        );
    }

    render() {
        return (
            <div className={style.wrap}>
                <h6 className={style.title}>卫计委</h6>
                {/*<div id={this.props.id} className={style.canvas}></div>*/}
                <div className={style.left}>
                    <p className={style.imggroup} id="imgs">
                    </p>
                    <p className={style.l_font}>
                        <span className={style.num} id="ss">{this.state.major_illness}</span>
                        <i>人</i>
                    </p>
                    <p className={style.cotent}>患有重大疾病</p>
                </div>
                <div className={style.right}>
                    <p className={style.imggroup} id="imgs1">
                    </p>
                    <p className={style.l_font}>
                        <span className={style.num} id="ss1">{this.state.ncms_count}</span>
                        <i>人</i>
                    </p>
                    <p className={style.cotent}>参加新农合贫困人口</p>
                </div>
            </div>
        )
    }
}
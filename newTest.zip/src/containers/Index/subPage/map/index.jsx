import React, {Component} from "react"
import echarts from 'echarts'
import { immutableRenderDecorator } from 'react-immutable-render-mixin'

import style from './style.scss'

@immutableRenderDecorator
export default class Map extends Component {

    constructor(props) {
        super(props)
        this.myChart = null
    }

    componentDidMount() {
        let geoJson = require('../../json/guizhou.json');
        this.myChart = echarts.init(document.getElementById(this.props.id));
        echarts.registerMap(name, geoJson);
        this.myChart.on('click', this.clickMap);

        window.addEventListener('resize', this.myChart.resize)
    }

    componentWillReceiveProps(props) {
        if(props.data.size === 1){
            return;
        }else {
            if(props.name){
                let geoJson = require(`../../json/${props.name}.json`);
                echarts.registerMap(name, geoJson)
            }else{
                let geoJson = require('../../json/guizhou.json');
                echarts.registerMap(name, geoJson)
            }
            let areaData = this.handleData(props.data);
            let minMax = this.findMaxMin(props.data);
            if(minMax.length === 0){
                return;
            }else{
                this.myChart.setOption(this.getOption(areaData, minMax))
            }
        }
    }

    componentWillUnmount() {
        // this.myChart.dispose()
        window.removeEventListener('resize', this.myChart.resize);
        this.myChart.off('click', this.clickMap);
    }
    sortNumber = (a,b)=> {
        return a - b
    }

    findMaxMin = (data) =>{
        let num = [];
        for (let i = 0, len = data.size; i < len; i++) {
            if(i !== 0) {
                num.push(data.getIn([i, 'data']));
            }
        }
        let max = num.sort(this.sortNumber);
        return max
    }

    handleData = ( data ) =>{
        let areaData = [];
        for (let i = 0, len = data.size; i < len; i++) {
            if(i !== 0){
                areaData.push({
                    name:data.getIn([i, 'district_string']),
                    value:data.getIn([i, 'data']),
                    code:data.getIn([i, 'district_code']),
                    house:data.getIn([i, 'commodity_house_count']),
                    company:data.getIn([i, 'have_zcqy']),
                    car:data.getIn([i, 'small_car_count']),
                })
            }
        }
        return areaData
    }

    clickMap = (parmas) => {
        this.props.clickMap(parmas.name,parmas.data.code)
    }

    getOption = (data,min) => {
        let option = {
            tooltip: {
                trigger: 'item',
                formatter: (item) => {
                    return(
                        `<div style="padding: .5rem">
                        <p style="line-height: 1.75rem;color: #0ce0f5">${item.name}</p>
                        <p style="line-height: 1.75rem">异常人数:${item.data.value}</p>
                        <p style="line-height: 1.75rem">有车辆:${item.data.car}</p>
                        <p style="line-height: 1.75rem">有房产:${item.data.house}</p>
                        <p style="line-height: 1.75rem">有公司:${item.data.company}</p>
                    </div>`
                    )}
            },
            visualMap: {
                min: min[0],
                max: min[min.length-1],
                right: 40,
                top: 'bottom',
                text: ['高', '低'], // 文本，默认为数值文本
                inRange: {
                    color: ['#45abd9','#36456e']
                },
                textStyle: {
                    color: '#fff'
                },
                calculable: true
            },
            series: [{
                type: 'map',
                mapType: name,
                label: {
                    normal: {
                        show: true,
                        textStyle: {
                            color: '#fff'
                        }
                    },
                    emphasis: {
                        textStyle: {
                            color: '#fff'
                        }
                    }
                },
                itemStyle: {
                    normal: {
                        borderColor: '#fff',
                        areaColor: '#fff'
                    },
                    emphasis: {
                        areaColor: '#0ce0f5',
                        borderWidth: 0
                    }
                },
                animation: false,
                data:data
            }]
        }

        return option
    }


    render() {
        return (
            <div id={this.props.id} className={style.map} style={{opacity: '0.9'}}></div>
        )
    }
}

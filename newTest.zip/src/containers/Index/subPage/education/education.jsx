import React, {Component} from 'react';
import style from './edu.scss';
import echarts from 'echarts';

export default class Education extends Component {

    constructor(props) {
        super(props);
        this.myChart = null;
        this.pipChart = null;
    }

    componentDidMount() {
		this.myChart = echarts.init(document.getElementById(this.props.id));
		this.pipChart = echarts.init(this.refs.pp);
		if(this.props.data.size !==0){
			let data = this.props.data.getIn(['content','jiaoyu']);
			this.getOption();
			this.getPie();
			window.addEventListener('resize', this.myChart.resize)
			window.addEventListener('resize', this.pipChart.resize)
		}
    }
    state = {}
    componentWillReceiveProps(props) {
        let data = props.data.getIn(['content','jiaoyu']);
        let shuju = [];
        if (data) {
			shuju.push(
				{
					value:data.getIn(['secondary_school_count']),
					name:'中职'
				}
			)
			shuju.push(
				{
					value:data.getIn(['high_school_count']),
					name:'高中'
				}
			)
			shuju.push(
				{
					value:data.getIn(['junior_college_count']),
					name:'大专'
				}
			)
			shuju.push(
				{
					value:data.getIn(['undergraduate_count']),
					name:'本科'
				}
			)
			this.setState({
				poor_student_count:data.getIn(['poor_student_count']),
				drop_out_count:data.getIn(['drop_out_count'])
			})
			let liang = [];
			liang.push({
				value: data.getIn(['not_subsidy_undergraduate_count']),
				name: '本科'
			})
			liang.push({
				value: data.getIn(['not_subsidy_junior_college_count']),
				name: '大专'
			})
			this.setState({
				ben:data.getIn(['undergraduate_count']),
				da:data.getIn(['junior_college_count']),
				gao:data.getIn(['high_school_count']),
				zhong:data.getIn(['secondary_school_count'])
			},()=>{
				this.getOption(shuju);
				this.getPie(liang);
			})
        }
    }

    componentWillUnmount() {
        this.myChart.dispose()
        this.pipChart.dispose()
        window.removeEventListener('resize', this.myChart.resize)
        window.removeEventListener('resize', this.pipChart.resize)
    }

    handleAdd = (num) =>{
        let sum = 0;
        for (let i = 0; i< num.length; i++){
            sum += num[i].value;
        }
        return sum
    }

    getOption = (data1) => {
        this.myChart = echarts.init(document.getElementById(this.props.id));
        let dataStyle = {
            normal: {
                label: {show:false},
                labelLine: {show:false},
                borderColor:'#00041d',
                borderWidth:2
            }
        };
        let placeHolderStyle = {
            normal : {
                color: 'rgba(0,0,0,0)',
                label: {show:false},
                labelLine: {show:false}
            },
            emphasis : {
                color: 'rgba(0,0,0,0)'
            }
        };
        let option = {
            color: ['#023e74', '#0b5da7','#177bc6', '#3399ca'],
            tooltip : {
                show: true,
                formatter: "{a} <br/>{b} : {c} ({d}%)"
            },
            series : [
                {
                    name:'本科',
                    type:'pie',
                    clockWise:false,
                    radius : ['62%','76%'],
                    itemStyle : dataStyle,
                    hoverAnimation: false,
                    data:[data1[3],
                        {
                            value:data1[3].value*0.65,
                            name:'invisible',
                            itemStyle : placeHolderStyle
                        }
                    ]
                },
                {
                    name:'大专',
                    type:'pie',
                    clockWise:false,
                    radius : ['48%', '62%'],
                    itemStyle : dataStyle,
                    hoverAnimation: false,

                    data:[data1[2],
                {
                    value:data1[2].value*0.50,
                    name:'invisible',
                    itemStyle : placeHolderStyle
                }]
                },
                {
                    name:'高中',
                    type:'pie',
                    clockWise:false,
                    hoverAnimation: false,
                    radius : ['34%', '48%'],
                    itemStyle : dataStyle,

                    data:[
                        data1[1],
                        {
                            value:data1[1].value*0.35,
                            name:'invisible',
                            itemStyle : placeHolderStyle
                        }
                    ]
                },
                {
                    name:'中职',
                    type:'pie',
                    clockWise:false,
                    hoverAnimation: false,
                    radius : ['20%', '34%'],
                    itemStyle : dataStyle,

                    data:[
                        data1[0],
                        {
                            value:data1[0].value*0.30,
                            name:'invisible',
                            itemStyle : placeHolderStyle
                        }
                    ]
                }

            ]
        }
        this.myChart.setOption(option)
    }
    getPie = (data) => {
        this.pipChart = echarts.init(this.refs.pp);
        let option = {
            tooltip: {
                trigger: 'item',
                formatter: "{a} <br/>{b} : {c} ({d}%)"
            },
            title:{
                text:this.handleAdd(data),
                textStyle:{
                    color:'#0ce0f5',
                    fontSize:18
                },
                left: '35%',
                top: '47%',
            },
            legend: {
                orient: 'vertical',
                right: '7%',
                bottom:'20%',
                itemWidth:12,
                itemHeight:12,
                textStyle:{
                    color:'#d8d8d8'
                },
                data: ['本科','大专'],
            },
            color:['#0ab3ca','#21648e'],
            series: [{
                name: '未两助三免',
                type: 'pie',
                radius: ['50%', '60%'],
                label: {
                    normal: {
                       show:false
                    }
                },
                labelLine: {
                    normal: {
                        show:false
                    }
                },
                center:['43%','50%'],
                data: data
            }]
        }
        this.pipChart.setOption(option);
    }

    render() {
        return (
            <div className={style.wrap}>
                <h6 className={style.title}>教育厅</h6>
                <div id={this.props.id} className={style.canvas}>
                </div>
                <div className={style.student} style={{display:'none'}}>
                    <i className={"iconfont" + " " + style.icon}>&#xe60e;</i>
                    <div className={style.text}>
                        <p className={style.t1}>{this.state.poor_student_count}人</p>
                        <p className={style.t2}>在校贫困生</p>
                    </div>
                </div>
                <div className={style.poor} style={{display:'none'}}>
                    <i className={"iconfont" + " " + style.icon}>&#xe61e;</i>
                    <div className={style.text}>
                        <p className={style.t1}>{this.state.drop_out_count}人</p>
                        <p className={style.t2}>辍学贫困生</p>
                    </div>
                </div>
                <div className={style.item}>
                    <p className={style.li}><span className={style.line}/><span> 本科 {this.state.ben}</span></p>
                    <p className={style.li}><span className={style.line}/><span> 大专 {this.state.da}</span></p>
                    <p className={style.li}><span className={style.line}/><span> 高中 {this.state.gao}</span></p>
                    <p className={style.li}><span className={style.line}/><span> 中职 {this.state.zhong}</span></p>
                </div>
                <p className={style.font1}>在校贫困生</p>
                <p className={style.font2}>未两助三免</p>
                <div ref="pp" className={style.canvas}>
                </div>
            </div>
        )
    }
}
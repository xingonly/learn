import React, {Component} from 'react';
import style from './style.scss';
import echarts from 'echarts';

export default class People extends Component {

    constructor(props) {
        super(props)
        this.myChart = null
    }

    componentDidMount() {
		this.myChart = echarts.init(document.getElementById(this.props.id));
        if(this.props.data.size !==0){
            let data = this.props.data.getIn(['content','minzheng']);
            let dibao = [{value:data.getIn('guaranteed_count'),name:'享受低保补助贫困户'}];
            let shuju = [];
            shuju.push({
                value:data.getIn(['village_5_guaranteed_count']),
                name:'农村五保贫困户'
            })
            shuju.push({
                value:data.getIn(['village_low_security_count']),
                name:'农村低保贫困户'
            })
            shuju.push({
                value:data.getIn(['city_low_security_count']),
                name:'城市低保贫困户'
            })
            this.getOption(shuju,dibao);
            window.addEventListener('resize', this.myChart.resize)
        }else{
            this.getOption();
            window.addEventListener('resize', this.myChart.resize)
        }

    }

    componentWillReceiveProps(props) {
        let data = props.data.getIn(['content','minzheng']);
		let dibao = [];
        let shuju = [];
        if(data) {
			dibao = [{value:data.getIn(['guaranteed_count']),name:'享受低保补助贫困户'}];
			shuju.push({
				value:data.getIn(['village_5_guaranteed_count']),
				name:'农村五保贫困户'
			})
			shuju.push({
				value:data.getIn(['village_low_security_count']),
				name:'农村低保贫困户'
			})
			shuju.push({
				value:data.getIn(['city_low_security_count']),
				name:'城市低保贫困户'
			})
			this.getOption(shuju,dibao);
        }
    }

    componentWillUnmount() {
        this.myChart.dispose()
        window.removeEventListener('resize', this.myChart.resize)
    }

    handlexx =(data) =>{
        // let da = [];
        if(!data){
            return
        }else{
            return data[0].value
        }
    }

    getOption = (data1,data2) => {
        let option = {
            tooltip: {
                trigger: 'item',
                formatter: "{a} <br/>{b}: {c} ({d}%)"
            },
            color: ['#e79607', '#3970cd','#0ce0f5'],
            legend: { //图例组件，颜色和名字
                right:"10%",
                top:'50%',
                orient: 'vertical',
                itemGap: 12, //图例每项之间的间隔
                itemWidth: 15,
                itemHeight: 15,
                itemRadius:'50%',
                icon: 'circle',
                data: ['农村五保贫困户', '农村低保贫困户', '城市低保贫困户'],
                textStyle: {
                    color: '#d8d8d8',
                    fontStyle: 'normal',
                    fontFamily: '微软雅黑',
                    fontSize: 14,
                }
            },
            title:{
                text:this.handlexx(data2),
                left: '28%',
                top: '51%',
                textStyle:{
                    color:'#d8d8d8',
                    fontSize:16
                },
            },
            series: [{
                name: '贫困户',
                type: 'pie',
                clockwise: false, //饼图的扇区是否是顺时针排布
                minAngle: 20, //最小的扇区角度（0 ~ 360）
                center: ['35%', '55%'], //饼图的中心（圆心）坐标
                radius: ['45%', '70%'], //饼图的半径
                avoidLabelOverlap: true, ////是否启用防止标签重叠
                itemStyle: { //图形样式
                    normal: {
                        borderColor: '#1e2239',
                        borderWidth: 1.5,
                    },
                },
                label: { //标签的位置
                    normal: {
                        show: true,
                        position: 'inside', //标签的位置
                        formatter: "{d}%",
                        textStyle: {
                            color: '#fff',
                        }
                    },
                    emphasis: {
                        show: true,
                        textStyle: {
                            fontWeight: 'bold'
                        }
                    }
                },
                data: data1
            }, {
                name: '',
                type: 'pie',
                clockwise: false,
                silent: true,
                minAngle: 20, //最小的扇区角度（0 ~ 360）

                center: ['35%', '55%'], //饼图的中心（圆心）坐标
                radius: ['0%', "25%"], //饼图的半径
                itemStyle: { //图形样式
                    normal: {
                        color: '#1e6f9e',
                    }
                },
                label: { //标签的位置
                    normal: {
                        show: false,
                        position: 'inner', //标签的位置
                        formatter: "{c}",
                    }
                },
                data: data2
            }]
        }

        this.myChart.setOption(option)
    }

    render() {
        return (
            <div className={style.wrap}>
                <h6 className={style.title}>民政厅</h6>
                <div id={this.props.id} className={style.canvas}></div>
                <div className={style.apn}>
                    <span className={style.cricle}/>
                    <span>享受低保补助贫困户</span>
                </div>
            </div>
        )
    }
}
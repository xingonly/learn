// 上帝保佑,永无bug
import React, {Component} from "react";
import {Link,hashHistory} from 'react-router';
import style from './build.scss'
import Card from '../../../components/Card'
import resource from '../../../util/resource'
import echarts from 'echarts'
import createHistory from 'history/createHashHistory'
const history = createHistory()

export default class Build extends Component {
    constructor(props){
        super(props);
    }

    state = {
        nowPerson: 0
    }

    interval = () => {
        var addOnece = parseInt(this.state.commodityHouse/125);
        if(this.state.nowPerson >= this.state.commodityHouse)
        {
            this.setState({
                nowPerson: this.state.commodityHouse
            });
            clearInterval(this.intervaler);
        }else{
            this.setState({
                nowPerson: this.state.nowPerson + addOnece
            });
        }
    }

    initData = () => {
        var data = this.props.data.getIn(['content','jianshe']);
        this.setState({
            transformationComplete: data.getIn(['transformation_complete_count']),
            transformationIncomplete: data.getIn(['transformation_incomplete_count']),
            commodityHouse: data.getIn(['commodity_house_count']),
            nowPerson: 0
        },() => {
            this.intervaler = setInterval(this.interval,16);
        });
    }

    componentDidUpdate (prevProps) {
        if(prevProps.data === this.props.data)
        {
            return;
        }
        this.initData();
    }

    componentWillUnmount () {
        clearInterval(this.intervaler);
    }

    render () {
        return (
            <div className={style.container}>
                <Card title='住建厅' margin>
                    <div className={style.content}>
                        <div className={style.left}>
                            <h2>危房改造</h2>
                            <div className={style.img}>
                                <div className={style.triangle}>
                                    <div className={style.topTriangle}>
                                        {this.state.transformationIncomplete}
                                    </div>
                                    <div className={style.bottomTriangle}>
                                        {this.state.transformationComplete}
                                    </div>
                                </div>
                            </div>
                            <div className={style.bottom}>
                                <div className={style.row}>
                                    <div style={{background: '#0ce0f5'}}></div>
                                    <p>已完成危房改造</p>
                                </div>
                                <div className={style.row}>
                                    <div style={{background: '#3d78dc'}}></div>
                                    <p>未完成危房改造</p>
                                </div>
                            </div>
                        </div>
                        <div className={style.right}>
                            <h2>购买商品房</h2>
                            <div className={style.img}>
                                <img src={require('../images/house.png')}/>
                            </div>
                            <p className={style.info}>
                                <span className={style.number}>{this.state.nowPerson}</span>
                                <span className={style.person}>人</span>
                            </p>
                        </div>
                    </div>
                </Card>
            </div>
        );
    }
}
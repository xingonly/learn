import React, {Component} from 'react';
import style from './style.scss';
import Filter from './subpage/Filter';
import resource from 'resource';
import TimeStorage from 'util/TimeStorage';
import Card from 'components/Card';
import Table from 'components/Table';
import {
  Medical,
  House,
  Education
} from './subpage/BasicInfo';
import createHistory from 'history/createHashHistory';
const history = createHistory();

class BasicProtection extends Component {

  state = {
    list: [],
    personList: [],
    location: [],
    active: {},
    district_code: '',
    year: new Date().getFullYear(),
    pageable: {
      start: 0,
      total: 0,
      size: 8
    }
  }

  basicInfoMap = {
    no_education_rate: Education,
    no_medical_rate: Medical,
    no_house_rate: House,
    no_water_rate: null,
    no_road_rate: null,
    no_communication_rate: null
  }

  titleMap = {
    no_education_rate: '教育未保障对象',
    no_medical_rate: '医疗未保障对象',
    no_house_rate: '住房未保障对象',
    no_water_rate: '饮水未保障对象',
    no_road_rate: '道路未保障对象',
    no_communication_rate: '通讯未保障对象'
  }

  columnsMap = {
    no_education_rate: [
      {label: ' ', filter: (item) => (
        <div className={style.avatar}>
          <img src={item.pic} onError={(e) => {
              e.target.src = require('./nanren.png');
            }}/>
        </div>
      ), style: {
        width: '6rem'
      }},
      {label: '性别', key: 'full_name'},
      {label: '身份证号', key: 'idnumber'},
      {label: '辍学年级', key: 'drop_out_grade', filter: (item) => {
        return item.drop_out_grade || '-'
      }},
      {label: '辍学状态', key: 'drop_out_reason', filter: (item) => {
        return item.drop_out_reason || '-'
      }},
      {label: '贫困状态', key: 'drop_out_reason', filter: (item) => {
        const status = item.status;
        switch (status)
        {
          case '0': return <img src={require('./images/poverty.png')} />
          case '1': return <img src={require('./images/outofpoverty.png')} />
          default: return <img src={require('./images/nopoverty.png')} />
        }
      }}
    ],
    no_medical_rate: [
      {label: ' ', filter: (item) => (
        <div className={style.avatar}>
          <img src={item.pic} onError={(e) => {
              e.target.src = require('./nanren.png');
            }}/>
        </div>
      ), style: {
        width: '6rem'
      }},
      {label: '姓名', key: 'full_name'},
      {label: '身份证号', key: 'idnumber'},
      {label: '家庭住址', key: 'district_string'},
      {label: '贫困类型', key: 'poor_status'},
      {label: '关注状态', filter: (item) => (
        <img style={{cursor: 'pointer'}} onClick={() => {
            this.attention(item);
          }} src={require(item.attention ? './unattention.png' : './attention.png')}/>
      )}
    ],
    no_house_rate: [
      {label: ' ', filter: (item) => (
        <div className={style.avatar}>
          <img src={item.pic} onError={(e) => {
              e.target.src = require('./nanren.png');
            }}/>
        </div>
      ), style: {
        width: '6rem'
      }},
      {label: '姓名', key: 'full_name'},
      {label: '身份证号', key: 'idnumber'},
      {label: '改造原因', key: 'transform_reason'},
      {label: '改造方式', key: 'transform_way'},
      {label: '贫困类型', key: 'poor_status'},
      {label: '关注状态', filter: (item) => (
        <img style={{cursor: 'pointer'}} onClick={() => {
            this.attention(item);
          }} src={require(item.attention ? './unattention.png' : './attention.png')}/>
      )}
    ],
    no_water_rate: [],
    no_road_rate: [],
    no_communication_rate: []
  }

  attention = (item) => {
    const { pageable, year } = this.state;
    if(item.attention)
    {
      resource.get(`/xixiu-server/people/attentionPeople/cancel/${item.peopleid}`).then((res) => {
        if(res.status === 200)
        {
          this.initPersonList(pageable.current, pageable.size);
        }
      });
    }else{
      resource.get(`/xixiu-server/people/attentionPeople/${item.peopleid}`).then((res) => {
        this.initPersonList(pageable.current, pageable.size);
      });
    }
  }

  getRegions = () => {
    const storage = new TimeStorage({
      time: 604800
    });
    const location = storage.getItem('location');
    if(!location)
    {
      resource.get('/xixiu-server/region/getAllRegion').then((res) => {
        storage.setItem('location', res.data || []);
        this.setState({
          location: res.data || []
        });
      });
    }else{
      this.setState({ location });
    }
  }

  isDeepEmpty = (obj) => {
    let result = true;
    if(typeof obj !== 'object' && (obj || obj === 0) )
    {
      return false;
    }
    for(let key in obj)
    {
      if(typeof obj[key] === 'object')
      {
        result = this.isDeepEmpty(obj[key]);
        if(!result)
        {
          return result;
        }
      }else{
        if(obj[key] || obj[key] === 0)
        {
          return false;
        }
      }
    }
    return result;
  }

  initIconList = (districtCode, year) => {
    const current = new Date().getFullYear();
    const fieldList = ['no_education_rate', 'no_medical_rate', 'no_house_rate', 'no_water_rate', 'no_road_rate', 'no_communication_rate'];
    resource.post('/xixiu-server/app/guarantee_area_list', {
      district_code: districtCode || 520402000000,
      // year: year || current
    }).then((res) => {
      if(res.status === 200)
      {
        this.setState({
          list: res.data || [],
          active: (() => {
            const data = res.data || [];
            for(let i = 0;i < data.length;i++)
            {
              for(let j = 0;j < fieldList.length;j++)
              {
                if(data[i][fieldList[j]])
                {
                  return {
                    id: data[i].id,
                    key: fieldList[j],
                    data: data[i]
                  };
                }
              }
            }

            return {};
          })()
        }, () => {
          if(!this.isDeepEmpty(this.state.active))
          {
            this.initPersonList();
          }else{
            this.setState({
              personList: []
            });
          }
        });
      }
    });
  }

  regionTranslate = (code) => {
    if(!this.state.location.length)
    {
      return '';
    }

    const match = this.state.location.find((item) => item.id == code);
    if(match)
    {
      return match.name;
    }else{
      return '';
    }
  }

  onRowClick = (item) => {
    let obj = {
      inputValue: item.idnumber,
      region: {
        shi: '',
        xian: '',
        xiang: '',
        zheng: ''
      }
    };

    sessionStorage.setItem('keyWord',JSON.stringify(obj));
    // sessionStorage.setItem('fromTo','EnterpriseVillages');
    history.push('/main/object/objectSearch');
  }

  checkDept = (item, key) => {
    if(item[key] === null)
    {
      return;
    }
    this.setState({
      active: {
        id: item.id,
        key: key,
        data: item
      }
    }, () => {
      this.initPersonList();
    });
  }

  initPersonList = (page, size) => {
    const data = this.state.active && this.state.active.data;
    const key = this.state.active && this.state.active.key;
    const typeMap = {
      no_education_rate: 'is_not_education',
      no_medical_rate: 'is_not_medical',
      no_house_rate: 'is_not_house',
      no_water_rate: 'is_not_water',
      no_road_rate: 'is_not_road',
      no_communication_rate: 'is_not_communication'
    };
    this.setState({
      loading: true
    }, () => {
      const current = new Date().getFullYear();
      resource.post('/xixiu-server/app/guarantee_people_list', {
        "district_code": data.district_code,
        "page": page || 0,
        "size": size || 8,
        "type_": typeMap[key],
        // "year": data.year
      }).then((res) => {
        if(res.status === 200)
        {
          this.setState({
            personList: res.data && res.data.data || [],
            pageable: {
              current: page || 0,
              size: size || 8,
              total: res.data && res.data.count || 0,
              start: 0
            }
          });
        }
        this.setState({
          loading: false
        });
      }, () => {
        this.setState({
          loading: false
        });
      });
    });
  }

  pageChange = (page, size) => {
    this.initPersonList(page, size);
  }

  onFilter = ({district_code, index}) => {
    // this.setState({district_code, year});
    this.initIconList(district_code);
  }

  componentWillMount () {
    this.initIconList();
    this.getRegions();
  }

	render() {
    const { list, personList, active, loading, pageable, location } = this.state;
    const BasicInfo = this.basicInfoMap[active.key];
    const getIconFontClassName = (item, key) => {
      const baseClass = 'iconfont';
      const id = item.id;
      const value = item[key];
      if(active.id == id && active.key == key)
      {
        return baseClass + ' ' + style.active;
      }else{
        if(value !== null)
        {
          return baseClass;
        }else{
          return baseClass + ' ' + style.disabled;
        }
      }
    }
		return (
			<div className={style.container}>
        <div className={style.leftContent}>
          <div className={style.filter}>
            <Filter onChange={this.onFilter}/>
          </div>
          <div className={!list || !list.length ? style.iconListEmpty : style.iconList}>
            {
              !list || !list.length ? (
                <div>暂无数据</div>
              ) : (
                <table>
                  {
                    list.map((item, index) => (
                      <tbody key={index} className={active.id == item.id ? style.activeTbody : ''}>
                        <tr style={index === 0 ? {} : {borderTop: '1px solid #07575e'}}>
                          <td style={{maxWidth: '9rem', textAlign: 'center'}} rowSpan={2}>{this.regionTranslate(item.district_code)}</td>
                          <td>
                            <div className={style.tdContainer}>
                              <i onClick={() => {
                                  this.checkDept(item, 'no_education_rate');
                                }} className={getIconFontClassName(item, 'no_education_rate')}>&#xe62b;</i>
                              <span>{item.no_education_rate || 0}</span>
                            </div>
                          </td>
                          <td>
                            <div className={style.tdContainer}>
                              <i onClick={() => {
                                  this.checkDept(item, 'no_medical_rate');
                                }} className={getIconFontClassName(item, 'no_medical_rate')}>&#xe61c;</i>
                              <span>{item.no_medical_rate || 0}</span>
                            </div>
                          </td>
                          <td>
                            <div className={style.tdContainer}>
                              <i onClick={() => {
                                  this.checkDept(item, 'no_house_rate');
                                }} className={getIconFontClassName(item, 'no_house_rate')}>&#xe63c;</i>
                              <span>{item.no_house_rate || 0}</span>
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <td>
                            <div className={style.tdContainer}>
                              <i style={{fontSize: '2rem'}} onClick={() => {
                                  this.checkDept(item, 'no_water_rate');
                                }} className={getIconFontClassName(item, 'no_water_rate')}>&#xe663;</i>
                              <span>{item.no_water_rate || 0}</span>
                            </div>
                          </td>
                          <td>
                            <div className={style.tdContainer}>
                              <i style={{fontSize: '1.8rem'}} onClick={() => {
                                  this.checkDept(item, 'no_road_rate');
                                }} className={getIconFontClassName(item, 'no_road_rate')}>&#xe613;</i>
                              <span>{item.no_road_rate || 0}</span>
                            </div>
                          </td>
                          <td>
                            <div className={style.tdContainer}>
                              <i style={{fontSize: '1.45rem'}} onClick={() => {
                                  this.checkDept(item, 'no_communication_rate');
                                }} className={getIconFontClassName(item, 'no_communication_rate')}>&#xe62a;</i>
                              <span>{item.no_communication_rate || 0}</span>
                            </div>
                          </td>
                        </tr>
                      </tbody>
                    ))
                  }
                </table>
              )
            }
          </div>
        </div>
        <div className={style.rightContent}>
          <Card className={style.basicInfo} title='基本信息'>
            {
              BasicInfo ? <BasicInfo data={active} place={this.regionTranslate(active.data && active.data.district_code || '')}/> : <div style={{textAlign: 'center'}}>暂无数据</div>
            }
          </Card>
          <Card className={style.personList} title={this.titleMap[active.key] || '未保障对象'}>
            <Table onRowClick={this.onRowClick} onChange={this.pageChange} pageable={pageable} loading={loading} className={style.personTable} columns={active.key && this.columnsMap[active.key] || []} dataSource={personList}/>
          </Card>
        </div>
			</div>
		)
	}
}

export default BasicProtection;

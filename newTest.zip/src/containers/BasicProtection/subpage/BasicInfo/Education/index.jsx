import React, {Component} from 'react';
import style from './style.scss';

class Education extends Component {

  render() {
    const { data, place } = this.props;
    const infos = data.data;
    return (
      <div className={style.container}>
        <div>
          <label>地区：</label>
          <span>{place}</span>
        </div>
        <div>
          <label>贫困人数：</label>
          <span>{infos.poor_count}</span>
        </div>
        <div>
          <label>适学人数：</label>
          <span>{infos.need_education_count}</span>
        </div>
        <div>
          <label>在校学生：</label>
          <span>{infos.under_education_count}</span>
        </div>
        <div>
          <label>辍学人数：</label>
          <span>{infos.no_education_count}</span>
        </div>
      </div>
    )
  }
}

export default Education;

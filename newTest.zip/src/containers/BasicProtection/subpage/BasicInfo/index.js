import House from './House';
import Medical from './Medical';
import Education from './Education';

export {
  House,
  Medical,
  Education
};

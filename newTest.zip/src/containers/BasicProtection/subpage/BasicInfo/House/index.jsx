import React, {Component} from 'react';
import style from './style.scss';

class House extends Component {

  render() {
    const { data, place } = this.props;
    const infos = data.data;
    return (
      <div className={style.container}>
        <div>
          <label>地区：</label>
          <span>{place}</span>
        </div>
        <div>
          <label>贫困人数：</label>
          <span>{infos.poor_count}</span>
        </div>
        <div>
          <label>住房未保障人数：</label>
          <span>{infos.no_house_count}</span>
        </div>
        <div>
          <label>危房改造人数：</label>
          <span>{infos.join_count}</span>
        </div>
      </div>
    )
  }
}

export default House;

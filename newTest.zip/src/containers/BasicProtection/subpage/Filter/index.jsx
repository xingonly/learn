import React, {Component} from 'react';
import style from './style.scss';
import Select from 'components/PowerSelect';
import resource from 'resource';

class Filter extends Component {

	constructor (props) {
		super(props);

		this.prevParams = {};

		this.state = {
			cityList: [],
			countyList: [],
			xiangList: [],
			cunList: [],
			yearList: (() => {
				const current = new Date().getFullYear();
				const list = [];
				for(let i = current;i > current - 100;i--)
				{
					list.push({
						text: i,
						value: i
					});
				}
				return list;
			})()
		};

		var manager = JSON.parse(sessionStorage.getItem('manager'));
		var scope = {
			scope: manager.scope,
			sheng: manager.sheng,
			shi: manager.shi,
			xian: manager.xian,
			xiang: manager.xiang
		};

		var scope1 = {
			scope: manager.scope,
			district: manager.shi
		}

		var scope2 = {
			scope: manager.scope,
			district:  manager.xian
		}

		var scope3 = {
			scope: manager.scope,
			district: manager.xiang
		}

		var scope4 = {
			scope: manager.scope,
			district:  manager.cun
		}

		this.scope1 = scope1;
		this.scope2 = scope2;
		this.scope3 = scope3;
		this.scope4 = scope4;
	}

	onCityChange = (item, field, index) => {
		this.onChange(index);
		if(!field)
		{
			return;
		}
		if(item.id)
		{
			resource.get('/xixiu-server/region/getRegionByParentid/' + item.id).then((res) => {
				const list = res.data || [];
				this.setState({
					[field]: list
				});
			});
		}else{
			this.setState({
				[field]: []
			});
		}
	}

	onYearChange = (item) => {
		this.setState({
			year: item.value
		}, () => {
			this.onChange();
		});
	}

	onChange = (index) => {
		if(this.props.onChange)
		{
			let district_code = '';
			let name = '';
			// for(let i = 4;i >= 1;i--)
			// {
			// 	const item = this.refs['select' + i].getItem();
			// 	if(item && item.id)
			// 	{
			// 		district_code = item.id;
			// 		break;
			// 	}
			// }
			const item = this.refs['select' + (index + 1)].getItem();
			if(item && item.id)
			{
				district_code = item.id;
				name = item.name;
			}else{
				const prevItem = this.refs['select' + index] && this.refs['select' + index].getItem() || '';
				if(prevItem)
				{
					district_code = prevItem.id;
					name = prevItem.name;
					index = index - 1;
				}else{
					name = '全部';
				}
			}
			const params = {
				district_code,
				name,
				// year: this.state.year
				index: index
			};
			if(this.prevParams.district_code == params.district_code)
			{
				return;
			}
			this.prevParams = params;
			this.props.onChange(params);
		}
	}

	initCity = () => {
			resource.get('/xixiu-server/region/getRegionByParentid/520402000000').then((res) => {
				const list = res.data || [];
				this.setState({
					xiangList: list
				});
			});
	}

	deepCompile = (obj1, obj2) => {
		return JSON.stringify(obj1) === JSON.stringify(obj2);
	}

	initValues = () => {
		const values = JSON.parse(JSON.stringify(this.props.values || []));
		for(let i = 0;i < 4;i++)
		{
			const selector = this.refs['select' + (i + 1)];
			if(values[i])
			{
				selector.setItem(values[i]);
			}else{
				selector.setItem({id: '', name: '全部'});
			}
		}
	}

	componentDidMount () {
		this.initCity();
		if(this.props.level)
		{
			this.initValues();
		}
	}

	componentDidUpdate (prevProps, prevState) {
		if(this.props.values && (JSON.stringify(prevProps.values) !== JSON.stringify(this.props.values)))
		{
			this.initValues();
		}
	}

	render() {
		const { cityList, countyList, xiangList, cunList, yearList } = this.state;
		return (
			<div className={style.container}>
				<div className={style.title}>
					保障统计
				</div>
				<div className={style.filter}>
					<div className={style.label}>
						西秀区
					</div>
					<Select
						compact
						list={[{
							id: '',
							name: '乡/镇'
						}].concat(xiangList)}
						onChange={(item) => this.onCityChange(item, 'cunList', 2)}
						scope={this.scope3}
						ref='select3'
						map={{
							value: 'id',
							text: 'name'
						}}/>
					<Select
						compact
						list={[{
							id: '',
							name: '村/社区'
						}].concat(cunList)}
						onChange={(item) => this.onCityChange(item, '', 3)}
						scope={this.scope4}
						ref='select4'
						map={{
							value: 'id',
							text: 'name'
						}}/>
				</div>
			</div>
		)
	}
}

export default Filter;

// 上帝保佑,永无bug
import React, {Component} from "react";
import {Link,hashHistory} from 'react-router';
import Notice from '../../components/Notice';
import style from './style.scss';
import Card from '../../components/Card';
import resource from '../../util/resource';
import MySelect from '../../components/MySelect';
import Pagination from '../../components/Pagination';
import { KEYWORD } from '../../constants/storage';
import createHistory from 'history/createHashHistory';
import NoData from '../../components/noData';
const history = createHistory();

export default class ObjectMgmt extends Component {
    constructor(props){
        super(props);
        this.state = {
            attentionPageable: {
                start: 0,
                total: 0,
                current: 0
            },
            helpPageable: {
                start: 0,
                total: 0,
                current: 0
            },
            attentionList: [],
            helpList: [],
            optionsType: [
                {label: '请选择', value: ''},
                {label: '未脱贫', value: '0'},
                {label: '脱贫', value: '1'},
                {label: '预脱贫', value: '2'},
                {label: '返贫', value: '3'}
            ],
            type: '请选择',
            typeValue: '',
            searchInputValue: ''
        };
    }

    initAttentionData = (page,size) => {
        resource.get(`/xixiu-server/people/getPageAttentionPeople?page=${page}&size=${size}&status=${this.state.typeValue}&name=${this.state.searchInputValue}`).then( res => {
            var state = {...this.state};
            state.attentionList = res.data.content;
            state.attentionPageable.total = res.data.totalElements;
            state.attentionPageable.current = res.data.number;
            state.attentionPageable.size = res.data.size;
            this.setState(state);
        });
    }

    initHelpData = (page,size) => {
        resource.get(`/xixiu-server/people/getPageSupportResponsible?page=${page}&size=${size}`).then( res => {
            var state = {...this.state};
            state.helpList = res.data.content;
            state.helpPageable.total = res.data.totalElements;
            state.helpPageable.current = res.data.number;
            state.helpPageable.size = res.data.size;
            this.setState(state);
        });
    }

    follow = (id,e) => {
        e.stopPropagation();
        resource.get(`/xixiu-server/people/attentionPeople/${id}`).then( (res) => {
            if(res.status === 200)
            {
                Notice.success('','关注成功');
                this.initAttentionData(this.state.attentionPageable.current,8);
            }
        })
    }

    unfollow = (id,e) => {
        e.stopPropagation();
        resource.get(`/xixiu-server/people/attentionPeople/cancel/${id}`).then( (res) => {
            if(res.status === 200)
            {
                Notice.success('','取消关注成功');
                this.initAttentionData(this.state.attentionPageable.current,8);
            }
        })
    }

    attentionChange = (page,size) => {
        this.initAttentionData(page,size);
    }

    helpChange = (page,size) => {
        this.initHelpData(page,size);
    }

    checkDetail = (item,index) => {
        let obj = {
            inputValue: item.idnumber,
            region: {
                shi: '',
                xian: '',
                xiang: '',
                zheng: ''
            }
        }

        sessionStorage.setItem(KEYWORD, JSON.stringify(obj))

        history.push('/main/object/objectSearch');

        this.setState({
            currentActive: index
        })
    }

    componentDidMount () {
        this.initAttentionData(0,8);
        this.initHelpData(0,8);
    }

    onError = (e) => {
        e.target.src = require('./images/nanren.png');
    }

    handleClickType = (obj, type) => {
        let label = obj.label,
            value = obj.value;
        this.setState({
            [type]: label,
            typeValue: value,
            searchInputValue: ''
        }, () => {
            let searchInputId = document.getElementById('searchInputId');
            searchInputId.value = '';
            this.initAttentionData(this.state.attentionPageable.current, 8)
        })
    }

    inputChange = e => {
        let v = e.target.value
        this.setState({
            searchInputValue: v
        })
    }

    searchRequire = () => {
        let state = {...this.state};
        state.attentionPageable.current = 0;
        this.setState(state, () => {
            this.initAttentionData(this.state.attentionPageable.current, 8)
        });
    }

    render() {

        return (
            <div className={style.container}>
                <Card title = "关注对象"
                      footer = {
                        <div className={style.pagination}>
                            {
                                this.state.attentionPageable.current > 0?
                                    <Pagination {...this.state.attentionPageable} onChange={this.attentionChange}/>
                                    : null
                            }
                        </div>
                      }
                      // subTitle = {
                      //     <div className={style.searchSubTitle}>
                      //         <div className={style.selectSubTitle}>
                      //             <MySelect
                      //                 value={this.state.type}
                      //                 options={this.state.optionsType}
                      //                 handleClick={this.handleClickType}
                      //                 name="type"
                      //             />
                      //         </div>
                      //         <input id='searchInputId' onChange={this.inputChange} className={style.iptSubTitle} placeholder='请输入姓名或身份证号' />
                      //         <span onClick={this.searchRequire} className={style.spnSubTitle}>
                      //             <i className='iconfont'>&#xe6d1;</i>
                      //         </span>
                      //     </div>
                      // }
                >
                    <div className={style.attentionContent}>
                        {
                            this.state.attentionList.length ? (
                                <ul className={style.list}>
                                    {
                                        this.state.attentionList.map((item,index) => {
                                            return (
                                                <li key={index} className={this.state.currentActive === index ? (style.active) : ''} onClick={this.checkDetail.bind(this,item,index)}>
                                                    <div className={style.headIcon}>
                                                        <div>
                                                            <img src={item.headurl} onError={this.onError}/>
                                                        </div>
                                                    </div>
                                                    <div className={style.fullName}>{item.fullName}</div>
                                                    <div className={style.gender}>{item.gender}</div>
                                                    <div className={style.idnumber}>{item.idnumber}</div>
                                                    <div className={style.status}>
                                                        {
                                                            item.status === '0' || item.status === '1' || item.status === '2' || item.status === '3' ? (
                                                                <img src={require(`./images/${item.status}.png`)}/>
                                                            ) : ''
                                                        }
                                                    </div>
                                                    <div className={style.attention}>{item.attention ? (
                                                            <img src={require('./images/unattention.png')} onClick={this.unfollow.bind(this,item.id)}/>
                                                        ) : (
                                                            <img src={require('./images/attention.png')} onClick={this.follow.bind(this,item.id)}/>
                                                        )}</div>
                                                </li>
                                            );
                                        })
                                    }
                                </ul>
                            ) : (
                                <div className={style.empty}>
                                    <span style={{display: 'inline-block', textAlign: 'center'}}><NoData /></span>
                                </div>
                            )
                        }
                    </div>
                </Card>
                <Card title="帮扶对象" footer={
                        <div className={style.pagination}>
                            {
                                this.state.helpPageable.current > 0?
                                    <Pagination {...this.state.helpPageable} onChange={this.helpChange}/>
                                    : null
                            }
                        </div>
                    }>
                    <div className={style.helpContent}>
                        {
                            this.state.helpList.length ? (
                                <ul className={style.list}>
                                    {
                                        this.state.helpList.map((item,index) => {
                                            return (
                                                <li key={index} className={this.state.currentActive === index ? (style.active) : ''} onClick={this.checkDetail.bind(this,item,index)}>
                                                    <div className={style.headIcon}>
                                                        <div>
                                                            <img src={item.headurl} onError={this.onError}/>
                                                        </div>
                                                    </div>
                                                    <div className={style.fullName}>{item.fullName}</div>
                                                    <div className={style.gender}>{item.gender}</div>
                                                    <div className={style.idnumber}>{item.idnumber}</div>
                                                    <div className={style.status}>
                                                        {
                                                            item.status === '0' || item.status === '1' || item.status === '2' || item.status === '3' ? (
                                                                <img src={require(`./images/${item.status}.png`)}/>
                                                            ) : ''
                                                        }
                                                    </div>
                                                    <div className={style.attention}>{item.attention ? (
                                                        <img src={require('./images/unattention.png')} onClick={this.unfollow.bind(this,item.id)}/>
                                                    ) : (
                                                        <img src={require('./images/attention.png')} onClick={this.follow.bind(this,item.id)}/>
                                                    )}</div>
                                                </li>
                                            );
                                        })
                                    }
                                </ul>
                            ) : (
                                <div className={style.empty}>
                                    <span style={{display: 'inline-block', textAlign: 'center'}}><NoData /></span>
                                </div>
                            )
                        }
                    </div>
                </Card>
            </div>
        );
    }
}

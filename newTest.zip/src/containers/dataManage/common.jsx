let Trim = (str,is_global) => {
    var result;
    result = str.replace(/(^\s+)|(\s+$)/g,"");
    if(is_global.toLowerCase()=="g")
    {
        result = result.replace(/\s/g,"");
    }
    return result;
}

//所有的数据
let allData = [
    {"region":"alive1","label":"1","length":"生存","type":"alive"},
    {"region":"alive2","label":"2","length":"死亡","type":"alive"},
    {"region":"countUnit01","label":"01","length":"公里","type":"countUnit"},
    {"region":"countUnit02","label":"02","length":"平方米","type":"countUnit"},
    {"region":"countUnit03","label":"03","length":"立方米","type":"countUnit"},
    {"region":"countUnit04","label":"04","length":"亩","type":"countUnit"},
    {"region":"countUnit05","label":"05","length":"个","type":"countUnit"},
    {"region":"countUnit06","label":"06","length":"头","type":"countUnit"},
    {"region":"countUnit07","label":"07","length":"只","type":"countUnit"},
    {"region":"countUnit08","label":"08","length":"辆","type":"countUnit"},
    {"region":"countUnit09","label":"09","length":"尾","type":"countUnit"},
    {"region":"countUnit10","label":"10","length":"人","type":"countUnit"},
    {"region":"countUnit13","label":"13","length":"元","type":"countUnit"},
    {"region":"countUnit14","label":"14","length":"口","type":"countUnit"},
    {"region":"countUnit99","label":"99","length":"其他","type":"countUnit"},
    {"region":"education10","label":"10","length":"研究生及以上","type":"education"},
    {"region":"education11","label":"11","length":"博士研究生","type":"education"},
    {"region":"education14","label":"14","length":"硕士研究生","type":"education"},
    {"region":"education20","label":"20","length":"大学本科","type":"education"},
    {"region":"education30","label":"30","length":"大学专科","type":"education"},
    {"region":"education40","label":"40","length":"中专技校","type":"education"},
    {"region":"education41","label":"41","length":"中等专科","type":"education"},
    {"region":"education44","label":"44","length":"职业高中","type":"education"},
    {"region":"education47","label":"47","length":"技工学校","type":"education"},
    {"region":"education60","label":"60","length":"普通高中","type":"education"},
    {"region":"education70","label":"70","length":"初中","type":"education"},
    {"region":"education80","label":"80","length":"小学","type":"education"},
    {"region":"education90","label":"90","length":"其他","type":"education"},
    {"region":"educationLevel01","label":"01","length":"文盲或半文盲","type":"educationLevel"},
    {"region":"educationLevel02","label":"02","length":"小学","type":"educationLevel"},
    {"region":"educationLevel03","label":"03","length":"初中","type":"educationLevel"},
    {"region":"educationLevel04","label":"04","length":"高中","type":"educationLevel"},
    {"region":"educationLevel05","label":"05","length":"大专及以上","type":"educationLevel"},
    {"region":"educationLevel06","label":"06","length":"学龄前儿童","type":"educationLevel"},
    {"region":"ethnic01","label":"01","length":"汉族","type":"ethnic"},
    {"region":"ethnic02","label":"02","length":"满族","type":"ethnic"},
    {"region":"ethnic03","label":"03","length":"回族","type":"ethnic"},
    {"region":"ethnic04","label":"04","length":"蒙古族","type":"ethnic"},
    {"region":"ethnic05","label":"05","length":"藏族","type":"ethnic"},
    {"region":"ethnic06","label":"06","length":"维吾尔族","type":"ethnic"},
    {"region":"ethnic07","label":"07","length":"苗族","type":"ethnic"},
    {"region":"ethnic08","label":"08","length":"彝族","type":"ethnic"},
    {"region":"ethnic09","label":"09","length":"壮族","type":"ethnic"},
    {"region":"ethnic10","label":"10","length":"布依族","type":"ethnic"},
    {"region":"ethnic11","label":"11","length":"朝鲜族","type":"ethnic"},
    {"region":"ethnic12","label":"12","length":"侗族","type":"ethnic"},
    {"region":"ethnic13","label":"13","length":"瑶族","type":"ethnic"},
    {"region":"ethnic14","label":"14","length":"白族","type":"ethnic"},
    {"region":"ethnic15","label":"15","length":"土家族","type":"ethnic"},
    {"region":"ethnic16","label":"16","length":"哈尼族","type":"ethnic"},
    {"region":"ethnic17","label":"17","length":"哈萨克族","type":"ethnic"},
    {"region":"ethnic18","label":"18","length":"傣族","type":"ethnic"},
    {"region":"ethnic19","label":"19","length":"黎族","type":"ethnic"},
    {"region":"ethnic20","label":"20","length":"僳僳族","type":"ethnic"},
    {"region":"ethnic21","label":"21","length":"佤族","type":"ethnic"},
    {"region":"ethnic22","label":"22","length":"畲族","type":"ethnic"},
    {"region":"ethnic23","label":"23","length":"高山族","type":"ethnic"},
    {"region":"ethnic24","label":"24","length":"拉祜族","type":"ethnic"},
    {"region":"ethnic25","label":"25","length":"水族","type":"ethnic"},
    {"region":"ethnic26","label":"26","length":"东乡族","type":"ethnic"},
    {"region":"ethnic27","label":"27","length":"纳西族","type":"ethnic"},
    {"region":"ethnic28","label":"28","length":"景颇族","type":"ethnic"},
    {"region":"ethnic29","label":"29","length":"柯尔克孜族","type":"ethnic"},
    {"region":"ethnic30","label":"30","length":"土族","type":"ethnic"},
    {"region":"ethnic31","label":"31","length":"达斡尔族","type":"ethnic"},
    {"region":"ethnic32","label":"32","length":"仫佬族","type":"ethnic"},
    {"region":"ethnic33","label":"33","length":"羌族","type":"ethnic"},
    {"region":"ethnic34","label":"34","length":"布朗族","type":"ethnic"},
    {"region":"ethnic35","label":"35","length":"撒拉族","type":"ethnic"},
    {"region":"ethnic36","label":"36","length":"毛南族","type":"ethnic"},
    {"region":"ethnic37","label":"37","length":"仡佬族","type":"ethnic"},
    {"region":"ethnic38","label":"38","length":"锡伯族","type":"ethnic"},
    {"region":"ethnic39","label":"39","length":"阿昌族","type":"ethnic"},
    {"region":"ethnic40","label":"40","length":"普米族","type":"ethnic"},
    {"region":"ethnic41","label":"41","length":"塔吉克族","type":"ethnic"},
    {"region":"ethnic42","label":"42","length":"怒族","type":"ethnic"},
    {"region":"ethnic43","label":"43","length":"乌孜别克族","type":"ethnic"},
    {"region":"ethnic44","label":"44","length":"俄罗斯族","type":"ethnic"},
    {"region":"ethnic45","label":"45","length":"鄂温克族","type":"ethnic"},
    {"region":"ethnic46","label":"46","length":"德昂族","type":"ethnic"},
    {"region":"ethnic47","label":"47","length":"保安族","type":"ethnic"},
    {"region":"ethnic48","label":"48","length":"裕固族","type":"ethnic"},
    {"region":"ethnic49","label":"49","length":"京族","type":"ethnic"},
    {"region":"ethnic50","label":"50","length":"塔塔尔族","type":"ethnic"},
    {"region":"ethnic51","label":"51","length":"独龙族","type":"ethnic"},
    {"region":"ethnic52","label":"52","length":"鄂伦春族","type":"ethnic"},
    {"region":"ethnic53","label":"53","length":"赫哲族","type":"ethnic"},
    {"region":"ethnic54","label":"54","length":"门巴族","type":"ethnic"},
    {"region":"ethnic55","label":"55","length":"珞巴族","type":"ethnic"},
    {"region":"ethnic56","label":"56","length":"基诺族","type":"ethnic"},
    {"region":"ethnic99","label":"99","length":"其他","type":"ethnic"},
    {"region":"fuelTtype01","label":"01","length":"柴草","type":"fuelTtype"},
    {"region":"fuelTtype02","label":"02","length":"干畜粪","type":"fuelTtype"},
    {"region":"fuelTtype03","label":"03","length":"煤炭","type":"fuelTtype"},
    {"region":"fuelTtype04","label":"04","length":"清洁能源","type":"fuelTtype"},
    {"region":"fuelTtype99","label":"99","length":"其他","type":"fuelTtype"},
    {"region":"gender1","label":"1","length":"男","type":"gender"},
    {"region":"gender2","label":"2","length":"女","type":"gender"},
    {"region":"gender9","label":"9","length":"其他","type":"gender"},
    {"region":"health01","label":"01","length":"健康","type":"health"},
    {"region":"health02","label":"02","length":"长期慢性病","type":"health"},
    {"region":"health03","label":"03","length":"患有大病","type":"health"},
    {"region":"health04","label":"04","length":"其他","type":"health"},
    {"region":"homeRoad01","label":"01","length":"泥土路","type":"homeRoad"},
    {"region":"homeRoad02","label":"02","length":"砂石路","type":"homeRoad"},
    {"region":"homeRoad03","label":"03","length":"水泥路","type":"homeRoad"},
    {"region":"homeRoad04","label":"04","length":"沥青路","type":"homeRoad"},
    {"region":"id","label":"code","length":"name","type":"type"},
    {"region":"labor01","label":"01","length":"普通劳动力","type":"labor"},
    {"region":"labor02","label":"02","length":"技能劳动力","type":"labor"},
    {"region":"labor03","label":"03","length":"丧失劳动力","type":"labor"},
    {"region":"labor04","label":"04","length":"无劳动力","type":"labor"},
    {"region":"licence01","label":"01","length":"居民身份证（户口簿）","type":"licence"},
    {"region":"licence02","label":"02","length":"中国人民解放军军官证","type":"licence"},
    {"region":"licence09","label":"09","length":"残疾人证","type":"licence"},
    {"region":"mainPoorCauses01","label":"01","length":"因病","type":"mainPoorCauses"},
    {"region":"mainPoorCauses02","label":"02","length":"因残","type":"mainPoorCauses"},
    {"region":"mainPoorCauses03","label":"03","length":"因学","type":"mainPoorCauses"},
    {"region":"mainPoorCauses04","label":"04","length":"因灾","type":"mainPoorCauses"},
    {"region":"mainPoorCauses05","label":"05","length":"缺土地","type":"mainPoorCauses"},
    {"region":"mainPoorCauses06","label":"06","length":"缺水","type":"mainPoorCauses"},
    {"region":"mainPoorCauses07","label":"07","length":"缺技术","type":"mainPoorCauses"},
    {"region":"mainPoorCauses08","label":"08","length":"缺劳力","type":"mainPoorCauses"},
    {"region":"mainPoorCauses09","label":"09","length":"缺资金","type":"mainPoorCauses"},
    {"region":"mainPoorCauses10","label":"10","length":"交通条件落后","type":"mainPoorCauses"},
    {"region":"mainPoorCauses11","label":"11","length":"自身发展动力不足","type":"mainPoorCauses"},
    {"region":"mainPoorCauses99","label":"99","length":"其他","type":"mainPoorCauses"},
    {"region":"otherPoorCauses01","label":"01","length":"因病","type":"otherPoorCauses"},
    {"region":"otherPoorCauses02","label":"02","length":"因残","type":"otherPoorCauses"},
    {"region":"otherPoorCauses03","label":"03","length":"因学","type":"otherPoorCauses"},
    {"region":"otherPoorCauses04","label":"04","length":"因灾","type":"otherPoorCauses"},
    {"region":"otherPoorCauses05","label":"05","length":"缺土地","type":"otherPoorCauses"},
    {"region":"otherPoorCauses06","label":"06","length":"缺水","type":"otherPoorCauses"},
    {"region":"otherPoorCauses07","label":"07","length":"缺技术","type":"otherPoorCauses"},
    {"region":"otherPoorCauses08","label":"08","length":"缺劳力","type":"otherPoorCauses"},
    {"region":"otherPoorCauses09","label":"09","length":"缺资金","type":"otherPoorCauses"},
    {"region":"otherPoorCauses10","label":"10","length":"交通条件落后","type":"otherPoorCauses"},
    {"region":"otherPoorCauses11","label":"11","length":"自身发展动力不足","type":"otherPoorCauses"},
    {"region":"otherPoorCauses12","label":"12","length":"因婚","type":"otherPoorCauses"},
    {"region":"otherPoorCauses99","label":"99","length":"其他","type":"otherPoorCauses"},
    {"region":"politicalStatus01","label":"01","length":"中共党员","type":"politicalStatus"},
    {"region":"politicalStatus02","label":"02","length":"中共预备党员","type":"politicalStatus"},
    {"region":"politicalStatus03","label":"03","length":"共青团员","type":"politicalStatus"},
    {"region":"politicalStatus04","label":"04","length":"民革会员","type":"politicalStatus"},
    {"region":"politicalStatus05","label":"05","length":"民盟盟员","type":"politicalStatus"},
    {"region":"politicalStatus06","label":"06","length":"民建会员","type":"politicalStatus"},
    {"region":"politicalStatus07","label":"07","length":"民进会员","type":"politicalStatus"},
    {"region":"politicalStatus08","label":"08","length":"农工党党员","type":"politicalStatus"},
    {"region":"politicalStatus09","label":"09","length":"致公党党员","type":"politicalStatus"},
    {"region":"politicalStatus10","label":"10","length":"九三学社社员","type":"politicalStatus"},
    {"region":"politicalStatus11","label":"11","length":"台盟盟员","type":"politicalStatus"},
    {"region":"politicalStatus12","label":"12","length":"无党派民主人士","type":"politicalStatus"},
    {"region":"politicalStatus13","label":"13","length":"群众","type":"politicalStatus"},
    {"region":"poorstandard01","label":"01","length":"国家标准","type":"poorstandard"},
    {"region":"poorstandard02","label":"02","length":"省定标准","type":"poorstandard"},
    {"region":"poorstandard03","label":"03","length":"市定标准","type":"poorstandard"},
    {"region":"poorstatus0","label":"0","length":"未脱贫","type":"poorstatus"},
    {"region":"poorstatus1","label":"1","length":"脱贫","type":"poorstatus"},
    {"region":"poorstatus2","label":"2","length":"预脱贫","type":"poorstatus"},
    {"region":"poorstatus3","label":"3","length":"返贫","type":"poorstatus"},
    {"region":"povertyAttribute01","label":"01","length":"一般贫困户","type":"povertyAttribute"},
    {"region":"povertyAttribute02","label":"02","length":"低保户","type":"povertyAttribute"},
    {"region":"povertyAttribute03","label":"03","length":"五保户","type":"povertyAttribute"},
    {"region":"povertyAttribute04","label":"04","length":"低保贫困户","type":"povertyAttribute"},
    {"region":"povertyAttribute05","label":"05","length":"一般农户","type":"povertyAttribute"},
    {"region":"povertyAttribute06","label":"06","length":"五保贫困户","type":"povertyAttribute"},
    {"region":"relationship01","label":"01","length":"户主","type":"relationship"},
    {"region":"relationship02","label":"02","length":"配偶","type":"relationship"},
    {"region":"relationship03","label":"03","length":"之子","type":"relationship"},
    {"region":"relationship04","label":"04","length":"之女","type":"relationship"},
    {"region":"relationship05","label":"05","length":"之儿媳","type":"relationship"},
    {"region":"relationship06","label":"06","length":"之女婿","type":"relationship"},
    {"region":"relationship07","label":"07","length":"之孙子","type":"relationship"},
    {"region":"relationship08","label":"08","length":"之孙女","type":"relationship"},
    {"region":"relationship09","label":"09","length":"之外孙子","type":"relationship"},
    {"region":"relationship10","label":"10","length":"之外孙女","type":"relationship"},
    {"region":"relationship11","label":"11","length":"之父","type":"relationship"},
    {"region":"relationship12","label":"12","length":"之母","type":"relationship"},
    {"region":"relationship13","label":"13","length":"之岳父","type":"relationship"},
    {"region":"relationship14","label":"14","length":"之岳母","type":"relationship"},
    {"region":"relationship15","label":"15","length":"之公公","type":"relationship"},
    {"region":"relationship16","label":"16","length":"之婆婆","type":"relationship"},
    {"region":"relationship17","label":"17","length":"之祖父","type":"relationship"},
    {"region":"relationship18","label":"18","length":"之祖母","type":"relationship"},
    {"region":"relationship19","label":"19","length":"之外祖父","type":"relationship"},
    {"region":"relationship20","label":"20","length":"之外祖母","type":"relationship"},
    {"region":"relationship99","label":"99","length":"其他","type":"relationship"},
    {"region":"school01","label":"01","length":"非在校生","type":"school"},
    {"region":"school02","label":"02","length":"学前教育","type":"school"},
    {"region":"school03","label":"03","length":"小学","type":"school"},
    {"region":"school04","label":"04","length":"七年级","type":"school"},
    {"region":"school05","label":"05","length":"八年级","type":"school"},
    {"region":"school06","label":"06","length":"九年级","type":"school"},
    {"region":"school07","label":"07","length":"高中一年级","type":"school"},
    {"region":"school08","label":"08","length":"高中二年级","type":"school"},
    {"region":"school09","label":"09","length":"高中三年级","type":"school"},
    {"region":"school10","label":"10","length":"中职一年级","type":"school"},
    {"region":"school11","label":"11","length":"中职二年级","type":"school"},
    {"region":"school12","label":"12","length":"中职三年级","type":"school"},
    {"region":"school13","label":"13","length":"高职一年级","type":"school"},
    {"region":"school14","label":"14","length":"高职二年级","type":"school"},
    {"region":"school15","label":"15","length":"高职三年级","type":"school"},
    {"region":"school16","label":"16","length":"大专及以上","type":"school"},
    {"region":"work01","label":"01","length":"乡（镇）内务工","type":"work"},
    {"region":"work02","label":"02","length":"乡（镇）外县内务工","type":"work"},
    {"region":"work03","label":"03","length":"县外省内务工","type":"work"},
    {"region":"work04","label":"04","length":"省外务工","type":"work"},
    {"region":"work99","label":"99","length":"其他","type":"work"},

];


//过滤数据方法
let handleFilter = (type) => {
    let newData = {};
    allData.map((obj, index) => {
        if(obj.type === type){
            newData[obj.label] = obj.length
        }
    })
    return newData
}
//1识别标准
let sbbzData = handleFilter('poorstandard');

//2贫困户属性
let pkfsxData = handleFilter('povertyAttribute');

//3贫困状态
let pkztData = handleFilter('poorstatus');

//4主要致贫原因
let zyzpyyData = handleFilter('mainPoorCauses');

//民族
let mzData = handleFilter('ethnic');

//5其他致贫原因
let qtzpyyData = handleFilter('otherPoorCauses');

//入户路类型
let rhllxData = handleFilter('homeRoad');


//与户主关系
let relationData = handleFilter('relationship');

//文化程度
let whcdData = handleFilter('educationLevel');


//在校生情况
let zxsqkData = handleFilter('school');

//健康状态
let jkztData = handleFilter('health');

//劳动能力
let ndnlData = handleFilter('labor');

//劳动能力
let wgztData = handleFilter('work');


//政治面貌
let zzmmData = handleFilter('politicalStatus');

//主要燃料类型
let zyrllxData = handleFilter('politicalStatus');


//贫困户属性
let pkhsxData = handleFilter('povertyAttribute');


export {
    Trim,
    sbbzData,
    pkfsxData,
    pkztData,
    zyzpyyData,
    mzData,
    qtzpyyData,
    rhllxData,
    relationData,
    whcdData,
    zxsqkData,
    jkztData,
    ndnlData,
    wgztData,
    zzmmData,
    zyrllxData,
    pkhsxData
}

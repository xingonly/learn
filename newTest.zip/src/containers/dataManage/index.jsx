import React , { Component } from 'react'
import style from './style.scss'
import { withRouter } from 'react-router-dom'
import Header from '../povertyAlleviation/subpage/header'
import Left from './subpage/left'
import Right from './subpage/right'

class App extends  Component{
    render(){
        return (
            <div className={style.box}>
                <Header showBold={true}>
                    <span>数据管理</span>
                </Header>
                <div className={style.container}>
                    <div className={style.left}>
                        <Left/>
                    </div>
                    <div className={style.right}>
                        <Right/>
                    </div>
                </div>
            </div>
        )
    }
}

export default withRouter(App)
import React, { Component } from 'react'
import { withRouter } from 'react-router-dom'
import echarts from 'echarts'
import resource from 'util/resource'
import Title from 'components/Title'

class chart extends Component{
    constructor(props){
        super(props);
        this.chart = null;
        this.paramas = {
            "district_code": 520402000000,
            "year": "2017"
        };
        this.header = [
            {
                name:'家庭信息',
                label:'family',
                value:0
            },{
                name:'家庭成员',
                label:'people',
                value:0
            },{
                name:'致贫原因',
                label:'poorCause',
                value:0
            },{
                name:'住房信息',
                label:'house',
                value:0
            },{
                name:'家庭成员',
                label:'newPeople',
                value:0
            },{
                name:'家电信息',
                label:'householdAppliance',
                value:0
            },{
                name:'机车信息',
                label:'transportation',
                value:0
            },{
                name:'生活条件',
                label:'liveCondition',
                value:0
            },{
                name:'生产条件',
                label:'productionCondition',
                value:0
            },{
                name:'总收入',
                label:'income',
                value:0
            },{
                name:'纯收入',
                label:'netIncome',
                value:0
            },{
                name:'其他资金',
                label:'expenditure',
                value:0
            }
        ];
        this.state = {
            optionData:[],
            initData:{
                vehicle_count:0,
                company_count:0,
                fsupported_count:0,
                house_count:0
            }
        };
    }

    componentWillMount(){
        this.getInitData();
    }

    componentDidMount(){
        this.myChart = echarts.init(this.refs.barTest);
        this.getOption();
        let _this = this;
        window.addEventListener("resize",function(){
            _this.myChart.resize();
        });
    }

    getInitData = () => {
        resource.get('/xixiu-server/edit/countByType').then((res) => {
            if(res.message === 'success'){
                let state = this.state;
                state.optionData = res.data ? res.data : [];
                if(state.optionData.length) {
                    this.handleData(state.optionData)
                }
                this.setState(state,() => {
                    this.getOption();
                });
            }
        })
    }

    handleData = (data) => {
        if(!data.length){
            return;
        }
        this.header.map((obj, index) => {
            data.map((ob, i) => {
                if(obj.label === ob[0]){
                    obj.value = ob[1];
                }
            })
        })
    }

    getOption  = (data) => {
        let dataX = [],
            dataY = [],
            peopleData = 0;
        this.header.map((obj, index) => {
            if(obj.name !== '家庭成员'){
                dataX.push(obj.name);
                dataY.push(obj.value)
            }else{
                peopleData += obj.value
            }
        })
        dataX.splice(2,0,'家庭成员');
        dataY.splice(2,0,peopleData);
        let option={
            tooltip:{
                trigger: 'axis',
                axisPointer : {
                    type : 'shadow'
                }
            },
            grid: {
                bottom: '25%'
            },
            xAxis:{
                data:dataX,
                axisLine: {
                    lineStyle: {
                        color: '#eaeaea',
                        width: 1
                    }
                },
                splitLine: {
                    lineStyle: {
                        color: '#eaeaea',
                        width: 2
                    }
                },
                axisTick:{
                    show: false
                },
                axisLabel: {
                    rotate: -45,
                    interval: 0,
                    margin: 15,
                    textStyle: {
                        color:'#717171'
                    }
                }
            },
            yAxis:{
                name: '',
                nameTextStyle: {
                    color: '#717171',
                    fontSize: 14
                },
                axisLine: {
                    show: false
                },
                axisTick: {
                    show: false
                },
                splitLine: {
                    lineStyle: {
                        color: '#f7f7f7'
                    }
                },
                axisLabel: {
                    textStyle: {
                        color:'#717171'
                    }
                }
            },
            series:[{
                name:'',
                type:'bar',
                barMaxWidth: 20,
                data:dataY,
                itemStyle:{
                    normal:{
                        barBorderRadius:40,
                        color:'#0fb2c3',
                        borderWidth:2,
                        shadowColor:'rgba(168,225,226,0.5)'
                    }
                }

            }]
        };
        this.myChart.setOption(option);

    }

    handleSelect = (id) => {
        this.paramas.district_code = parseInt(id)
        this.getInitData()
    }

    render(){
        let { initData } = this.state;
        return(
                <div ref="barTest" style={{height:'100%',width:'100%'}}></div>
        )
    }
}

export default withRouter(chart)
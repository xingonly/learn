import React , { Component } from 'react'
import style from './style.scss'
import { withRouter } from 'react-router-dom'

class App extends  Component{
    handleCancel = () => {
        if(this.props.handleCancel){
            this.props.handleCancel();
        }
    }

    handleSure = () => {
        if(this.props.handleSure){
            this.props.handleSure()
        }
    }

    render(){
        return (
            <div className={style.box}
                 onClick={this.handleCancel}
            >
                <div className={style.container}
                     onClick={(e) => {
                         e.stopPropagation();
                     }}
                >
                    <div
                        className={style.cancel}
                        onClick={this.handleCancel}
                    >X</div>
                    <div className={style.header}>操作内容</div>
                    <div className={style.content}>
                        { this.props.children }
                    </div>
                    {/*<div className={style.footer}>
                        <span
                            onClick={this.handleSure}
                        >确定</span>
                    </div>*/}
                </div>
            </div>
        )
    }
}

export default withRouter(App)
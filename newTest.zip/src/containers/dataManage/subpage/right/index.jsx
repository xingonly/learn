import React , { Component } from 'react'
import style from './style.scss'
import { withRouter } from 'react-router-dom'
import SearchRegion from '../searchRegion'
import Alert from '../alert'
import NoData from '../../../../components/noData'
import Loadding from '../../../../components/Loading'
import moment from 'moment'
import common from '../../common.scss'
import resource from '../../../../util/resource'
import Pagination from '../../../../components/Pagination'
import have from '../images/have.png'
import ShowImage from 'components/showImage'
import RenderInBody from '../alert/alert'
import {
    Trim,
    sbbzData,
    pkfsxData,
    pkztData,
    zyzpyyData,
    mzData,
    qtzpyyData,
    rhllxData,
    relationData,
    whcdData,
    zxsqkData,
    jkztData,
    ndnlData,
    wgztData,
    zzmmData,
    zyrllxData,
    pkhsxData
} from '../../common'


//数据转换
let handleData = (status) => {
    let operation = '';
    switch (status){
        case '0': operation = '未脱贫';break;
        case '1': operation = '已脱贫';break;
        case '2': operation = '预脱贫';break;
        case '3': operation = '返贫';break;
        default:operation = '---'
    };

    return operation
}


//家电信息修改 图 undefined
let homeInfo = (type, data, handleShowImage) => {
    let newData =
        <div className={style.body}>
            <div className={style.header}>{type}修改</div>
            {
                typeof(data.washingMachine) !== 'undefined' ?
                    <dl>
                        <dt>洗衣机：</dt>
                        <dd>
                            {data.washingMachine ? "有":"否"}
                            {
                                data.washingMachinePic ?
                                    <img src={have} alt="" onClick={ () => handleShowImage(data.washingMachinePic)}/>:''
                            }
                        </dd>
                    </dl>:''
            }
            {
                typeof(data.refrigerator) !== 'undefined' ?
                    <dl>
                        <dt>电冰箱：</dt>
                        <dd>
                            {data.refrigerator ? "有":"否"}
                            {
                                data.refrigeratorPic ?
                                    <img src={have} alt="" onClick={ () => handleShowImage(data.refrigeratorPic)}/>:''
                            }
                        </dd>
                    </dl>:''
            }
            {
                typeof(data.colorTv) !== 'undefined' ?
                    <dl>
                        <dt>电视机：</dt>
                        <dd>
                            {data.colorTv ? "有":"否"}
                            {
                                data.colorTvPic ?
                                    <img src={have} alt="" onClick={ () => handleShowImage(data.colorTvPic)}/>:''
                            }
                        </dd>
                    </dl>:''
            }
            {
                typeof(data.airconditioning) !== 'undefined' ?
                    <dl>
                        <dt>空调：</dt>
                        <dd>
                            {data.airconditioning ? "有":"否"}
                            {
                                data.airconditioningPic ?
                                    <img src={have} alt="" onClick={ () => handleShowImage(data.airconditioningPic)}/>:''
                            }
                        </dd>
                    </dl>:''
            }
            {
                typeof(data.waterHeater) !== 'undefined' ?
                    <dl>
                        <dt>热水器：</dt>
                        <dd>
                            {data.waterHeater ? "有":"否"}
                            {
                                data.waterHeaterPic ?
                                    <img src={have} alt="" onClick={ () => handleShowImage(data.waterHeaterPic)}/>:''
                            }
                        </dd>
                    </dl>:''
            }
            {
                typeof(data.fixedTelephone) !== 'undefined' ?
                    <dl>
                        <dt>固定电话：</dt>
                        <dd>
                            {data.fixedTelephone ? "有":"否"}
                            {
                                data.fixedTelephonePic ?
                                    <img src={have} alt="" onClick={ () => handleShowImage(data.fixedTelephonePic)}/>:''
                            }
                        </dd>
                    </dl>:''
            }
            {
                typeof(data.mobileTelephone) !== 'undefined' ?
                    <dl>
                        <dt>移动电话：</dt>
                        <dd>
                            {data.mobileTelephone ? "有":"否"}
                            {
                                data.mobileTelephonePic ?
                                    <img src={have} alt="" onClick={ () => handleShowImage(data.mobileTelephonePic)}/>:''
                            }
                            <img src={have} alt="" onClick={ () => handleShowImage(data.mobileTelephonePic)}/>
                        </dd>
                    </dl>:''
            }
            {
                typeof(data.agriculturalMachinery) !== 'undefined' ?
                    <dl>
                        <dt>农业机器：</dt>
                        <dd>
                            {data.agriculturalMachinery ? "有":"否"}
                            {
                                data.agriculturalMachineryPic ?
                                    <img src={have} alt="" onClick={ () => handleShowImage(data.agriculturalMachineryPic)}/>:''
                            }
                        </dd>
                    </dl>:''
            }
        </div>;
    return newData;
}

//住房信息修改 图 undefined
let zfInfo = (type, data, handleShowImage) => {
    let newData =
        <div className={style.body}>
            <div className={style.header}>{type}修改</div>
            {
                typeof(data.area) !== 'undefined' ?
                    <dl>
                        <dt>居住面积（平方米）：</dt>
                        <dd>
                            {data.area}
                            {
                                data.areaPic ?
                                    <img src={have} alt="" onClick={ () => handleShowImage(data.areaPic)}/>:''

                            }

                        </dd>
                    </dl>:''
            }
            {
                typeof(data.dangerous) !== 'undefined' ?
                    <dl>
                        <dt>主要住房是否危房：</dt>
                        <dd>
                            {data.dangerous ? '是' : '否'}
                            {
                                data.dangerousPic ?
                                    <img src={have} alt="" onClick={ () => handleShowImage(data.dangerousPic)}/>:''

                            }
                        </dd>
                    </dl>:''
            }
            {
                typeof(data.sanitaryToilet) !== 'undefined'?
                    <dl>
                        <dt>有无卫生厕所：</dt>
                        <dd>
                            {data.sanitaryToilet ? '是' : '否'}
                            {
                                data.sanitaryToiletPic ?
                                    <img src={have} alt="" onClick={ () => handleShowImage(data.sanitaryToiletPic)}/>:''

                            }
                        </dd>
                    </dl>:''
            }
            {
                typeof(data.fuelType) !== 'undefined' ?
                    <dl>
                        <dt>主要燃料类型：</dt>
                        <dd>
                            {zyrllxData[data.fuelType]}
                            {
                                data.fuelTypePic ?
                                    <img src={have} alt="" onClick={ () => handleShowImage(data.fuelTypePic)}/>:''

                            }
                        </dd>
                    </dl>:''
            }
            {
                typeof(data.buildingTime) !== 'undefined' ?
                    <dl>
                        <dt>建房时间：</dt>
                        <dd>{data.buildingTime}</dd>
                    </dl>:''
            }
            {
                typeof(data.mainBuildingStructure) !== 'undefined' ?
                    <dl>
                        <dt>房屋主要结构：</dt>
                        <dd>
                            {data.mainBuildingStructure}
                            {
                                data.mainBuildingStructurePic ?
                                    <img src={have} alt="" onClick={ () => handleShowImage(data.mainBuildingStructurePic)}/>:''

                            }
                        </dd>
                    </dl>:''
            }
            {
                typeof(data.relocationPovertyRelief) !== 'undefined' ?
                    <dl>
                        <dt>易地扶贫搬迁情况：</dt>
                        <dd>{data.relocationPovertyRelief}</dd>
                    </dl>:''
            }
        </div>;
    return newData;
}


//机车信息修改 图 undefined
let jcInfo = (type, data, handleShowImage) => {
    let newData =
        <div className={style.body}>
            <div className={style.header}>{type}修改</div>
            {
                typeof(data.familyCar) !== 'undefined' ?
                    <dl>
                        <dt>小轿车：</dt>
                        <dd>
                            {data.familyCar ? '有':'无'}
                            {
                                data.familyCarPic ?
                                    <img src={have} alt="" onClick={ () => handleShowImage(data.familyCarPic)}/>:''
                            }
                        </dd>
                    </dl>:''
            }
            {
                typeof(data.farmVehicle) !== 'undefined' ?
                    <dl>
                        <dt>农用车：</dt>
                        <dd>
                            {data.farmVehicle ? '有':'无'}
                            {
                                data.farmVehiclePic ?
                                    <img src={have} alt="" onClick={ () => handleShowImage(data.farmVehiclePic)}/>:''
                            }
                        </dd>
                    </dl>:''
            }
            {
                typeof(data.motorcycle) !== 'undefined' ?
                    <dl>
                        <dt>摩托车：</dt>
                        <dd>
                            {data.motorcycle ? '有':'无'}
                            {
                                data.motorcyclePic ?
                                    <img src={have} alt="" onClick={ () => handleShowImage(data.motorcyclePic)}/>:''
                            }
                        </dd>
                    </dl>:''
            }
            {
                typeof(data.bicycle) !== 'undefined' ?
                    <dl>
                        <dt>自行车：</dt>
                        <dd>
                            {data.bicycle ? '有':'无'}
                            {
                                data.motorcyclePic ?
                                    <img src={have} alt="" onClick={ () => handleShowImage(data.bicyclePic)}/>:''
                            }
                        </dd>
                    </dl>:''
            }
        </div>;
    return newData;
}


//生活条件修改 图 undefined
let liveInfo = (type, data,handleShowImage) => {
    let newData =
        <div className={style.body}>
            <div className={style.header}>{type}修改</div>
            {
                typeof(data.drinkingWaterDifficult) !== 'undefined'?
                    <dl>
                        <dt>饮水是否困难：</dt>
                        <dd>
                            {data.drinkingWaterDifficult ? '是':'否'}
                            {
                                data.drinkingWaterDifficultPic ?<img src={have} alt="" onClick={ () => handleShowImage(data.drinkingWaterDifficultPic)}/>:""
                            }
                        </dd>
                    </dl>:''
            }
            {
                typeof(data.drinkingWaterSafe) !== 'undefined' ?
                    <dl>
                        <dt>饮水是否安全：</dt>
                        <dd>
                            {
                                data.drinkingWaterSafePic ?<img src={have} alt="" onClick={ () => handleShowImage(data.drinkingWaterSafePic)}/>:""
                            }
                            {data.drinkingWaterSafe ? '是':'否'}
                        </dd>
                    </dl>:''
            }
            {
                typeof(data.drinkingSituation) !== 'undefined' ?
                    <dl>
                        <dt>饮水情况：</dt>
                        <dd>
                            {
                                data.drinkingSituationPic ?<img src={have} alt="" onClick={ () => handleShowImage(data.drinkingSituationPic)}/>:""
                            }
                            {data.drinkingSituation}
                        </dd>
                    </dl>:''
            }
            {
                typeof(data.lifeElectricity) !== 'undefined' ?
                    <dl>
                        <dt>是否通生活用电：</dt>
                        <dd>
                            {
                                data.lifeElectricityPic ?<img src={have} alt="" onClick={ () => handleShowImage(data.lifeElectricityPic)}/>:""
                            }
                            {data.lifeElectricity ? '是':'否'}
                        </dd>
                    </dl>:''
            }
            {
                typeof(data.distanceMainRoad) !== 'undefined' ?
                    <dl>
                        <dt>距离村主干路（公里）：</dt>
                        <dd>
                            {
                                data.distanceMainRoadPic ?<img src={have} alt="" onClick={ () => handleShowImage(data.distanceMainRoadPic)}/>:""
                            }
                            {data.distanceMainRoad}
                        </dd>
                    </dl>:''
            }
            {
                data.homeRoadType ?
                    <dl>
                        <dt>入户路类型：</dt>
                        <dd>
                            {
                                data.homeRoadTypePic ?<img src={have} alt="" onClick={ () => handleShowImage(data.homeRoadTypePic)}/>:""
                            }
                            {rhllxData[data.homeRoadType]}
                        </dd>
                    </dl>:''
            }
            {
                typeof(data.farmersCooperative) !== 'undefined' ?
                    <dl>
                        <dt>是否参加农村合作社：</dt>
                        <dd>
                            {
                                data.farmersCooperativePic ?<img src={have} alt="" onClick={ () => handleShowImage(data.farmersCooperativePic)}/>:""
                            }
                            {data.farmersCooperative ? '是':'否'}
                        </dd>
                    </dl>:''
            }
            {
                typeof(data.kitche) !== 'undefined' ?
                    <dl>
                        <dt>是否完成厨房改造：</dt>
                        <dd>
                            {
                                data.kitchenPic ?<img src={have} alt="" onClick={ () => handleShowImage(data.kitchenPic)}/>:""
                            }
                            {data.kitche ? '是':'否'}
                        </dd>
                    </dl>:''
            }
            {
                typeof(data.toilet) !== 'undefined' ?
                    <dl>
                        <dt>是否完成厕所改造：</dt>
                        <dd>
                            {
                                data.toiletPic ?<img src={have} alt="" onClick={ () => handleShowImage(data.toiletPic)}/>:""
                            }
                            {data.toilet ? '是':'否'}
                        </dd>
                    </dl>:''
            }
            {
                typeof(data.sty) !== 'undefined' ?
                    <dl>
                        <dt>是否完成圈舍改造：</dt>
                        <dd>
                            {
                                data.styPic ?<img src={have} alt="" onClick={ () => handleShowImage(data.styPic)}/>:""
                            }
                            {data.sty ? '是':'否'}
                        </dd>
                    </dl>:''
            }
        </div>;
    return newData;
}


//生产条件修改 无 undefined
let productInfo = (type, data) => {
    let newData =
        <div className={style.body}>
            <div className={style.header}>{type}修改</div>
            {
                typeof(data.cultivatedArea) !== 'undefined' ?
                    <dl>
                        <dt>耕地面积（亩）：</dt>
                        <dd>{data.cultivatedArea}</dd>
                    </dl>:''
            }
            {
                typeof(data.effectiveIrrigationArea) !== 'undefined' ?
                    <dl>
                        <dt>有效灌溉面积（亩）：</dt>
                        <dd>{data.effectiveIrrigationArea}</dd>
                    </dl>:''
            }
            {
                typeof(data.fieldArea) !== 'undefined' ?
                    <dl>
                        <dt>田（亩）：</dt>
                        <dd>{data.fieldArea}</dd>
                    </dl>:''
            }
            {
                typeof(data.landArea) !== 'undefined' ?
                    <dl>
                        <dt>土（亩）：</dt>
                        <dd>{data.landArea}</dd>
                    </dl>:''
            }
            {
                typeof(data.woodlandArea) !== 'undefined' ?
                    <dl>
                        <dt>林地面积（亩）：</dt>
                        <dd>{data.woodlandArea}</dd>
                    </dl>:''
            }
            {
                typeof(data.returnForestArea) !== 'undefined' ?
                    <dl>
                        <dt>退耕还林面积（亩）：</dt>
                        <dd>{data.returnForestArea}</dd>
                    </dl>:''
            }
            {
                typeof(data.orchardArea) !== 'undefined' ?
                    <dl>
                        <dt>林果面积（亩）：</dt>
                        <dd>{data.orchardArea}</dd>
                    </dl>:''
            }
            {
                typeof(data.grasslandArea) !== 'undefined' ?
                    <dl>
                        <dt>牧地面积（亩）：</dt>
                        <dd>{data.grasslandArea}</dd>
                    </dl>:''
            }
            {
                typeof(data.waterSurfaceArea) !== 'undefined' ?
                    <dl>
                        <dt>水面面积（亩）：</dt>
                        <dd>{data.waterSurfaceArea}</dd>
                    </dl>:''
            }
        </div>;
    return newData;
}


//致贫原因修改 无 undefined
let zpInfo = (type, data) => {
    let otherCausesData = data.otherCauses ? data.otherCauses.split(",") : [];
    let newData =
        <div className={style.body}>
            <div className={style.header}>{type}修改</div>
            {
                typeof(data.mainCauses) !== 'undefined' ?
                    <dl>
                        <dt>主要致贫原因：</dt>
                        <dd>{zyzpyyData[data.mainCauses]}</dd>
                    </dl>:''
            }
            {
                typeof(data.otherCauses) !== 'undefined' ?
                    <dl>
                        <dt style={{width:'19%'}}>其他致贫原因：</dt>
                        <dd style={{width:'80%'}}>
                            <span>
                                {
                                    otherCausesData.length ? otherCausesData.map((obj, index ) => {
                                        let thData = '，';
                                        if(otherCausesData.length - 1 === index){
                                            thData = ''
                                        }
                                        return (qtzpyyData[obj] + thData)
                                    }):''
                                }
                             </span>
                        </dd>
                    </dl>:''
            }
            {
                typeof(data.supportPlanTyp) !== 'undefined' ?
                    <dl>
                        <dt>帮扶规划类型：</dt>
                        <dd>{data.supportPlanTyp}</dd>
                    </dl>:''
            }
            {
                typeof(data.identificationStandard) !== 'undefined' ?
                    <dl>
                        <dt>识别标准：</dt>
                        <dd>{data.identificationStandard}</dd>
                    </dl>:''
            }
            {
                typeof(data.povertyAttribute) !== 'undefined' ?
                    <dl>
                        <dt>贫困户属性：</dt>
                        <dd>{pkhsxData[data.povertyAttribute]}</dd>
                    </dl>:''
            }
        </div>;
    return newData;
}

//纯收入信息修改 无 undefined
let csrInfo = (type, data) => {
    let newData =
        <div className={style.body}>
            <div className={style.header}>{type}修改</div>
            {
                typeof(data.netIncome) !== 'undefined' ?
                    <dl>
                        <dt>纯收入：</dt>
                        <dd>{data.netIncome}</dd>
                    </dl>:''
            }
            {
                typeof(data.percapitaNetIncome) !== 'undefined' ?
                    <dl>
                        <dt>人均纯收入：</dt>
                        <dd>{data.percapitaNetIncome}</dd>
                    </dl>:''
            }
        </div>;
    return newData;
}

//总收入信息修改 无 undefined
let zsrInfo = (type, data) => {
    let newData =
        <div className={style.body}>
            <div className={style.header}>{type}修改</div>
            {
                typeof(data.wageIncome) !== 'undefined' ?
                    <dl>
                        <dt>工资收入：</dt>
                        <dd>{data.wageIncome}</dd>
                    </dl>:''
            }
            {
                typeof(data.productionOperationIncome) !== 'undefined' ?
                    <dl>
                        <dt>生产经营性收入：</dt>
                        <dd>{data.productionOperationIncome}</dd>
                    </dl>:''
            }
            {
                typeof(data.propertyIncome) !== 'undefined' ?
                    <dl>
                        <dt>财产性收入：</dt>
                        <dd>{data.propertyIncome}</dd>
                    </dl>:''
            }
            {
                typeof(data.transterIncome) !== 'undefined' ?
                    <dl>
                        <dt>转移性收入：</dt>
                        <dd>{data.transterIncome}</dd>
                    </dl>:''
            }
            {
                typeof(data.otherTransterIncome) !== 'undefined' ?
                    <dl>
                        <dt>其他转移性收入：</dt>
                        <dd>{data.otherTransterIncome}</dd>
                    </dl>:''
            }
        </div>;
    return newData;
}



//其他资金信息修改 无 undefined
let qtzjInfo = (type, data) => {
    let newData =
        <div className={style.body}>
            <div className={style.header}>{type}修改</div>
            {
                typeof(data.productiveExpenditure) !== 'undefined' ?
                    <dl>
                        <dt>生产经营性支出：</dt>
                        <dd><span>{data.productiveExpenditure}</span></dd>
                    </dl>:''
            }
            {
                typeof(data.birthControlExpenditure) !== 'undefined' ?
                    <dl>
                        <dt>计划生育金：</dt>
                        <dd><span>{data.birthControlExpenditure}</span></dd>
                    </dl>:''
            }
            {
                typeof(data.incomeSecurity) !== 'undefined' ?
                    <dl>
                        <dt>低保金：</dt>
                        <dd><span>{data.incomeSecurity}</span></dd>
                    </dl>:''
            }
            {
                typeof(data.fiveIncomeSecurity) !== 'undefined' ?
                    <dl>
                        <dt>五保金：</dt>
                        <dd><span>{data.fiveIncomeSecurity}</span></dd>
                    </dl>:''
            }
            {
                typeof(data.pension) !== 'undefined' ?
                    <dl>
                        <dt>养老保险金：</dt>
                        <dd><span>{data.pension}</span></dd>
                    </dl>:''
            }
            {
                typeof(data.ecologicalSecurityFund) !== 'undefined' ?
                    <dl>
                        <dt>生态保险金：</dt>
                        <dd><span>{data.ecologicalSecurityFund}</span></dd>
                    </dl>:''
            }

        </div>;
    return newData;
}

//家庭信息修改 无 undefined
let jtInfo = (type, data) => {
    let newData =
        <div className={style.body}>
            <div className={style.header}>{type}修改</div>{/*
            {
                data.productiveExpenditure ?
                    <dl>
                        <dt>户主姓名：</dt>
                        <dd><span>{data.productiveExpenditure || '---'}</span></dd>
                    </dl>:''
            }*/}
            {
                typeof(data.linePhone) !== 'undefined' ?
                    <dl>
                        <dt>联系电话：</dt>
                        <dd><span>{data.linePhone}</span></dd>
                    </dl>:''
            }
            {
                typeof(data.accountBankname) !== 'undefined' ?
                    <dl>
                        <dt>开户银行：</dt>
                        <dd><span>{data.accountBankname}</span></dd>
                    </dl>:''
            }
            {
                typeof(data.accountNumber) !== 'undefined' ?
                    <dl>
                        <dt>银行账号：</dt>
                        <dd><span>{data.accountNumber}</span></dd>
                    </dl>:''
            }
            {
                typeof(data.firstYear) !== 'undefined' ?
                    <dl>
                        <dt>建档立卡时间：</dt>
                        <dd><span>{data.firstYear}</span></dd>
                    </dl>:''
            }
            {
                typeof(data.statusTime) !== 'undefined' ?
                    <dl>
                        <dt>脱贫时间：</dt>
                        <dd><span>{data.statusTime}</span></dd>
                    </dl>:''
            }
            {
                typeof(data.status) !== 'undefined' ?
                    <dl>
                        <dt>脱贫状态：</dt>
                        <dd><span>{handleData(data.status)}</span></dd>
                    </dl>:''
            }

        </div>;
    return newData;
}


//人口信息修改 无 undefined
let rkInfo = (type, data,idNumber,show) => {
    let newData =
        <div className={style.body}>
            <div className={style.header}>{type}修改</div>
            <dl style={{display:show ? 'block':'none'}}>
                <dt>证件号：</dt>
                <dd><span>{idNumber}</span></dd>
            </dl>
            <dl  style={{display:show ? 'block':'none'}}>
                <dt style={{fontWeight:'bold'}}>修改值：</dt>
                <dd></dd>
            </dl>
            {
                typeof(data.fullName) !== 'undefined' ?
                    <dl>
                        <dt>姓名：</dt>
                        <dd><span>{data.fullName }</span></dd>
                    </dl>:''
            }
            {
                typeof(data.idnumber) !== 'undefined' ?
                    <dl>
                        <dt>证件号：</dt>
                        <dd><span>{data.idnumber}</span></dd>
                    </dl>:''
            }
            {
                typeof(data.relationship) !== 'undefined' ?
                    <dl>
                        <dt>关系：</dt>
                        <dd><span>{relationData[data.relationship]}</span></dd>
                    </dl>:''
            }
            {
                typeof(data.ethnic) !== 'undefined' ?
                    <dl>
                        <dt>名族：</dt>
                        <dd><span>{mzData[data.ethnic]}</span></dd>
                    </dl>:''
            }
            {
                typeof(data.gender) !== 'undefined' ?
                    <dl>
                        <dt>性别：</dt>
                        <dd><span>{data.gender.toString()  === '1' ? '男' : '女'}</span></dd>
                    </dl>:''
            }
            {
                typeof(data.educationLevel) !== 'undefined' ?
                    <dl>
                        <dt>文化程度：</dt>
                        <dd><span>{whcdData[data.educationLevel]}</span></dd>
                    </dl>:''
            }
            {
                typeof(data.schoolSituation) !== 'undefined' ?
                    <dl>
                        <dt>在校生情况：</dt>
                        <dd><span>{zxsqkData[data.schoolSituation]}</span></dd>
                    </dl>:''
            }
            {
                typeof(data.health) !== 'undefined' ?
                    <dl>
                        <dt>健康状态：</dt>
                        <dd><span>{jkztData[data.health]}</span></dd>
                    </dl>:''
            }{
            typeof(data.laborAbility) !== 'undefined' ?
                <dl>
                    <dt>劳动能力：</dt>
                    <dd><span>{ndnlData[data.laborAbility]}</span></dd>
                </dl>:''
        }{
            typeof(data.workSituation) !== 'undefined' ?
                <dl>
                    <dt>务工状态：</dt>
                    <dd><span>{wgztData[data.workSituation]}</span></dd>
                </dl>:''
        }{
            typeof(data.workTime) !== 'undefined' ?
                <dl>
                    <dt>务工时间：</dt>
                    <dd><span>{data.workTime}</span></dd>
                </dl>:''
        }
            {
                typeof(data.ncms) !== 'undefined' ?
                    <dl>
                        <dt>新农合：</dt>
                        <dd><span>{data.ncms ? '有' : '无'}</span></dd>
                    </dl>:''
            }
            {
                typeof(data.residentPension) !== 'undefined' ?
                    <dl>
                        <dt>居民养老：</dt>
                        <dd><span>{data.residentPension ? '有' : '无'}</span></dd>
                    </dl>:''
            }
            {
                typeof(data.joinReason) !== 'undefined' ?
                    <dl>
                        <dt>添加原因：</dt>
                        <dd><span>{data.joinReason}</span></dd>
                    </dl>:''
            }
            {
                typeof(data.transferEmployment) !== 'undefined' ?
                    <dl>
                        <dt>是否劳动转移就业：</dt>
                        <dd><span>{data.transferEmployment ? '是':'否'}</span></dd>
                    </dl>:''
            }
            {
                typeof(data.politicalStatus) !== 'undefined' ?
                    <dl>
                        <dt>政治面貌：</dt>
                        <dd><span>{zzmmData[data.politicalStatus]}</span></dd>
                    </dl>:''
            }
            {
                typeof(data.medicalSecurity) !== 'undefined' ?
                <dl>
                    <dt>是否参加城市职工医联保险：</dt>
                    <dd><span>{data.medicalSecurity ? '是':'否'}</span></dd>
                </dl>:''
            }
            {
                typeof(data.currentSchoolName) !== 'undefined' ?
                    <dl>
                        <dt>在读学校名称：</dt>
                        <dd><span>{data.currentSchoolName}</span></dd>
                    </dl>:''
            }

        </div>;
    return newData;
}



class App extends  Component{
    constructor(props){
        super(props);
        this.paramas = {
            commitName:'',
            districtCode:'520400000000',
            page:0,
            size:11,
            createTimeStart:null,
            createTimeEnd:null,
        }
        this.state = {
            showAlert:'',
            initData:[],
            total:0,
            current:1,
            showAlertImage:''
        };
    }

    handleShowImage = (url) => {
        let state = { ...this.state };
        state.showAlertImage  = <RenderInBody><ShowImage handleClose = { () => this.handleCancelImage() } url={url}/></RenderInBody>;
        this.setState(state);
    }

    handleCancel = () => {
        let state = this.state;
        state.showAlert = '';
        this.setState(state);
    }

    handleCancelImage = () => {
        let state = this.state;
        state.showAlertImage = '';
        this.setState(state)
    }


    componentWillMount(){
        this.getInitData();
    }

    getInitData = () => {
        let {districtCode,commitName,page,size,createTimeEnd,createTimeStart,process,department} = this.paramas;
        let url = `page=${page}&size=${size}`;
        if(districtCode){
            url += `&districtCode=${districtCode}`
        }
        if(commitName){
            url += `&commitName=${commitName}`
        }
        if(createTimeEnd){
            url += `&createTimeEnd=${createTimeEnd}`
        }
        if(createTimeStart){
            url += `&createTimeStart=${createTimeStart}`
        }
        resource.get(`/xixiu-server/edit/passed?${url}&sort=id,desc`).then((res) => {
            let state = this.state;
            this.loadding = false;
            if(res.status === 200){
                state.initData = res.data && res.data.content.length > 0 ? res.data.content:[];
                state.total = res.data && res.data.totalElements ? res.data.totalElements:0;
            }
            this.setState(state);
        })
    }

    handleToDetail = (type,data,connectionId) => {
        let state = this.state;
        let newType = '';
        let content = '';
        let newData = JSON.parse(data);
        switch (type){
            case 'family': newType = '家庭信息'; content = jtInfo('家庭信息', newData); break;//
            case 'poorCause': newType = '致贫原因';content = zpInfo('致贫原因', newData);break;//
            case 'house': newType = '住房信息';content = zfInfo('住房信息', newData, this.handleShowImage);break;//
            case 'householdAppliance':
                newType = '家电信息';/*('家电信息',newData)*/
                content = content = homeInfo('家电信息', newData, this.handleShowImage)
            break;//
            case 'transportation': newType = '机车信息';content = jcInfo('机车信息', newData, this.handleShowImage);break;
            case 'liveCondition': newType = '生活条件'; content = liveInfo('生活条件', newData, this.handleShowImage);break;//
            case 'productionCondition': newType = '生产条件';content = productInfo('生产条件',newData);break;//
            case 'income': newType = '总收入';content = zsrInfo('总收入',newData);break;//
            case 'expenditure': newType = '其他资金';content = qtzjInfo('其他资金',newData);break;//
            case 'netIncome': newType = '纯收入';content = csrInfo('纯收入',newData);break;//
            case 'people': newType = '纯收入';content = rkInfo('人口信息',newData,connectionId,true);break;//
            case 'newPeople': newType = '纯收入';content = rkInfo('人口信息',newData,connectionId,false);break;//
            default : newType = '人口信息';content = rkInfo('人口信息',newData,connectionId,true);break;
        }
        state.showAlert =  <Alert handleCancel={this.handleCancel}>{content}</Alert>;
        this.setState(state);
    }

    handlePageChange = (page,size) => {
        let state = this.state;
        state.current = page;
        this.paramas.page = page - 1;
        state.initData = [];
        this.loadding = true;
        this.setState(state,() => {
            this.getInitData()
        })
    }

    handleAllocated = (data) => {
        this.paramas.page = 0;
        this.paramas.commitName = data.commitName ? Trim(data.commitName,'g'):'';
        this.paramas.districtCode = data.districtCode ? data.districtCode:'520400000000';
        this.paramas.createTimeStart = data.createTimeStart ? moment(data.createTimeStart).format('YYYY-MM-DD HH:mm:ss') :'';
        this.paramas.createTimeEnd = data.createTimeEnd ? moment(data.createTimeEnd).format('YYYY-MM-DD HH:mm:ss') :'';
        let state = this.state;
        state.current = 1;
        this.loadding = true;
        state.initData = [];
        this.setState(state,() => {
            this.getInitData();
        });
    }

    render(){
        let {size} = this.paramas;
        let { showAlert,initData,total,current,showAlertImage } = this.state;
        let len = initData.length;
        return (
            <div className={style.box}>
                <SearchRegion
                    title="操作查询"
                    handleOk={this.handleAllocated}
                />
                <div className={style.content}>
                    <div className={common.tableRegion}>
                        <table>
                            <thead>
                            <tr>
                                <td>干部姓名</td>
                                <td>提交日期</td>
                                <td>被修改户</td>
                                <td>帮扶区域</td>
                                <td></td>
                            </tr>
                            </thead>
                            <tbody>
                            {
                                len  && !this.loadding? initData.map((obj,index) => {
                                    return (
                                        <tr key={index}>
                                            <td>
                                                {obj.commitName || '---'}
                                                <i style={{left:0}}></i>
                                                </td>
                                            <td>{obj.createTime ? moment(obj.createTime).format('YYYY-MM-DD') :'---'}</td>
                                            <td>{obj.fullName|| '---'}</td>
                                            <td>{obj.address|| '---'}</td>
                                            <td
                                                style={{width:'80px'}}
                                            >
                                                    <span style={{color:'#57b0b9',cursor:'pointer'}}
                                                          onClick={() => this.handleToDetail(obj.type,obj.data)}
                                                    >详情</span>
                                                <i style={{right:0}}></i></td>
                                        </tr>
                                    )
                                }):''
                            }
                            </tbody>
                        </table>
                        {
                            !len && !this.loadding    ?  <NoData/> : ''
                        }

                        {
                            this.loadding ? <Loadding/> :''
                        }
                        {
                            total ?
                                <div className={common.pagination}>
                                    <Pagination
                                        total={total}
                                        current={current}
                                        size={size}
                                        start={1}
                                        onChange={this.handlePageChange}
                                    />
                                </div> :''
                        }

                    </div>
                </div>
                { showAlert }
                { showAlertImage }
            </div>
        )
    }
}

export default withRouter(App)
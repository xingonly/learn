import React , { Component } from 'react'
import style from './style.scss'
import { withRouter } from 'react-router-dom'
import Title from '../../../../components/Title'
import Bar from '../chart/bar'
import resource from '../../../../util/resource'
import NoData from '../../../../components/noData'

class App extends  Component{
    constructor(props){
        super(props);
        this.initData = [
            {
                name:'你大爷的',
                value:100,
            },{
                name:'你大爷的',
                value:100,
            },{
                name:'你大爷的',
                value:100,
            },{
                name:'你大爷的',
                value:100,
            },{
                name:'你大爷的',
                value:100,
            },{
                name:'你大爷的',
                value:100,
            },{
                name:'你大爷的',
                value:100,
            },{
                name:'你大爷的',
                value:100,
            },{
                name:'你大爷的',
                value:100,
            },{
                name:'你大爷的',
                value:100,
            },{
                name:'你大爷的',
                value:100,
            },{
                name:'你大爷的',
                value:100,
            },{
                name:'你大爷的',
                value:100,
            },{
                name:'你大爷的',
                value:100,
            },
        ];
        this.state = {
            initData:[]
        }
    }

    componentWillMount(){
        this.getInitData();
    }
    getInitData = () => {
        resource.get(`/xixiu-server/edit/countByDistrictCode`).then((res) => {
            let state = this.state;
            if(res.status === 200){
                state.initData = res.data && res.data.length > 0 ? res.data:[];
            }
            this.setState(state);
            this.setState({
                detail:res.data&&res.data.content
            });
        })
    }

    render(){
        let {initData} = this.state;
        let len = initData.length;
        return (
            <div className={style.box}>
                <Title name="数据操作统计"/>
                <div className={style.content}>
                    <div className={style.topRegion}>
                        {
                            len ? initData.map((obj, index) => {
                                return(
                                    <dl key={index}>
                                        <dt>{obj[2] || '0'}</dt>
                                        <dd>{obj[1] || '---'}</dd>
                                    </dl>
                            )}) :''
                        }
                        {
                            !len ? <NoData/>:''
                        }
                    </div>
                    <div className={style.bottomChart}>
                        <div className={style.bottomHeader}>修改情况统计</div>
                        <div className={style.chart}>
                            <Bar/>
                        </div>
                    </div>
                </div>
            </div>
        )
    }
}

export default withRouter(App)
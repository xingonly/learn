import React,{ Component } from 'react'
import style from './style.scss'
import common from '../../common.scss'
import { withRouter } from 'react-router-dom'
import Datatime from 'react-datetime'
import Selection from '../Selection'
import resource from '../../../../util/resource'
import moment from 'moment'

class App extends Component{
    constructor(){
    super();

    this.arrArea = [];
    this.paramas = {
        createTimeStart:null,
        createTimeEnd:null,
        commitName:'',
        districtCode:''
    };
    //记录选中的乡镇村
    this.initLogData = {
        xiang:'',
        cun:''
    }
    this.partName = null;
    this.state = {
        createTimeStart:0,
        createTimeEnd:0,
        label:'commitName',
        area: {
            shi: null,
            xian: null,
            xiang: null,
            zheng: null
        }

    };
}
    handleOk = () => {
        if(this.props.handleOk){
            this.paramas.commitName = this.partName.value;
            this.props.handleOk(this.paramas);
        }
    }

    //移除其它选这框
    removeSelect = (name,callback) =>{
        switch (name){
            case 'shi':
                this.state.area.xian = null;
                this.state.area.xiang = null;
                this.state.area.zheng = null;
                this.setState({
                    area: this.state.area
                });
                this.refs.shi.setValue({ name:"市",id:null });
                this.refs.xian.setValue({ name:"县",id:null });
                this.refs.xiang.setValue({ name:"乡/镇",id:null });
                this.refs.zheng.setValue({ name:"村/社区",id:null });
                break;
            case 'xian':
                this.state.area.xiang = null;
                this.state.area.zheng = null;
                this.setState({
                    area: this.state.area
                });
                this.refs.xian.setValue({ name:"县",id:null });
                this.refs.xiang.setValue({ name:"乡/镇",id:null });
                this.refs.zheng.setValue({ name:"村/社区",id:null });
                break;
            case 'xiang':
                this.state.area.zheng = null;
                this.setState({
                    area: this.state.area
                });
                this.refs.xiang.setValue({ name:"乡/镇",id:null });
                this.refs.zheng.setValue({ name:"村/社区",id:null });
                break;
            default:
                break;
        }
        if(typeof callback === 'function'){
            callback;
        }
    }



    searchArea = (type,data)=>{
        let arrId;
        let arr = this.arrArea.filter((item)=>{
            return item > 0;
        });
        if(data){
            arrId = arr[arr.length - 1] || this.state.topArea[0].id;
            this.paramas.districtCode = arrId;
            if(type === 'zheng'){
                this.initLogData.xiang = arrId;
            }
        }else{
            if(type === 'zheng'){
                this.paramas.districtCode = '520400000000';
            }else{
                this.paramas.districtCode = this.initLogData.xiang;
            }
        }
        this.partName.value = '';
        this.handleOk();
    };


    handleTimeChange= (e,label) => {
        let state = this.state;
        if(label === 'createTimeEnd'){
            let data = Datatime.moment(e).subtract( -1, 'day' );
            state[label] = (new Date(data._d)).getTime() ? (new Date(data._d)).getTime() :0;
            this.paramas[label] = (new Date(data._d)).getTime() ? (new Date(data._d)).getTime() : null ;
            this.partName.value = '';
        }else{
            state[label] = (new Date(e._d)).getTime() ? (new Date(e._d)).getTime() :0;
            this.paramas[label] = (new Date(e._d)).getTime() ? (new Date(e._d)).getTime() : null ;
            this.partName.value = '';
        }
        this.setState(state,this.handleOk);
    }

    handleChange = (e) => {
        let state = this.state;
        state.label = e.target.value;
        this.partName.value = '';
        this.setState(state)
    }

    // regions地区的查询
    getRegion = (id,ob,func) => {
        this.removeSelect(ob,this.getRegionData(id,ob,func));
    };

    //获取数据
    getRegionData = (id,ob,func) =>{
        resource.get(`/xixiu-server/region/getRegionByParentid/${id}`).then((res) => {
            if(res.status === 200) {
                let result = res.data;
                let obj = {
                    name: '请选择',
                    id: ''
                };
                result.unshift(obj);
                this.state.area[ob] = result;
                this.setState({
                    area: this.state.area
                },() => {
                    if(func){
                        func(ob,id);
                    }
                });
            }
        });
    };

    changeArea = (type,item) =>{
        let arr = ['shi','xian','xiang','zheng'];
        if(type === ''){
            this.arrArea.splice(3,1,item.id);
        }else{
            if(this.arrArea[arr.indexOf(type) - 1] !== ''){
                this.arrArea.splice(arr.indexOf(type) - 1,this.arrArea.length -arr.indexOf(type) + 1 ,item.id);
            }else{
                this.arrArea.splice(arr.indexOf(type) - 1,1 ,item.id);
            }
        }
        if(item.id && type !=''){
            this.getRegion(item.id,type,this.searchArea);
        }else{
            this.removeSelect(arr[arr.indexOf(type) - 1]);
            this.searchArea(type,item.id)
        }
    };

    componentDidMount = () => {
        this.getRegion('520402000000','xiang');
    };

    handleClear = (type) => {
        let state = this.state;
        state[type] = '';
        this.paramas[type] = '';
        this.setState(state, this.handleOk)
    }

    render(){
        let { createTimeStart,createTimeEnd, label} = this.state;
        let toDay = Datatime.moment().subtract( 0, 'day' );
        let startData = function( e ){
            let newtTime = createTimeEnd ? Datatime.moment(moment(createTimeEnd ? createTimeEnd : 0).format('YYYY-MM-DD')).subtract( 0, 'day' ):0;
            return e.isBefore( newtTime ? newtTime : toDay );
        };
        let end = Datatime.moment(moment(createTimeStart ? createTimeStart : 0).format('YYYY-MM-DD')).subtract( 1, 'day' );
        let endTimeData = function( current ){
            return current.isBetween( end, toDay);
        };

        return(
            <div className={style.box}>
                <div className={style.header}>{this.props.title}</div>
                <div className={style.content}
                >
                    <dl>
                        <dt>提交日期：</dt>
                        <dd className={common.forTime}>
                            <div className={common.startTime}>
                                <Datatime
                                    dateFormat='YYYY-MM-DD'
                                    onChange={(e) => this.handleTimeChange(e,'createTimeStart')}
                                    locale="zh_CN"
                                    utc={false}
                                    value={createTimeStart}
                                    inputProps={{ placeholder: '起始日期 ',readOnly: true }}
                                    timeFormat = {false}
                                    closeOnSelect = {true}
                                    isValidDate = {startData}
                                />
                                <span
                                    className={common.clear}
                                    style={{display: createTimeStart ? 'block':'none'}}
                                    onClick={() => this.handleClear('createTimeStart')}
                                >X</span>
                            </div>
                            <span className={common.line}></span>
                            <div className={common.endTime}>
                                <Datatime
                                    dateFormat='YYYY-MM-DD'
                                    onChange={(e) => this.handleTimeChange(e,'createTimeEnd')}
                                    locale="zh_CN"
                                    utc={false}
                                    value={ createTimeEnd ? Datatime.moment(moment(createTimeEnd ? createTimeEnd : 0).format('YYYY-MM-DD')).subtract( 1, 'day' ) :''}
                                    inputProps={{ placeholder: '结束日期 ',readOnly: true }}
                                    timeFormat = {false}
                                    closeOnSelect = {true}
                                    isValidDate = {endTimeData}
                                />
                                <span
                                    className={common.clear}
                                    onClick={() => this.handleClear('createTimeEnd')}
                                    style={{display: createTimeEnd ? 'block':'none'}}
                                >X</span>
                            </div>
                            <div className={style.selectBox} style={{fontWeight:'normal'}}>
                                <div className={style.areaOptions}>
                                    <Selection ref="xian"
                                               tipData="西秀区"
                                               defaultSelect="xian"
                                               name="xiang"
                                               data={[{name:'西秀区',id:'520402000000'}]}/>
                                </div>
                                <div className={style.areaOptions}>
                                    <Selection ref="xiang"
                                               tipData="镇/乡"
                                               defaultSelect="xiang"
                                               name="zheng"
                                               data={this.state.area.xiang}
                                               onChange={this.changeArea} />
                                </div>
                                <div className={style.areaOptions}>
                                    <Selection ref="zheng"
                                               tipData="村/社区"
                                               defaultSelect="zheng"
                                               name="cun"
                                               data={this.state.area.zheng}
                                               onChange={this.changeArea}/>
                                </div>
                                {/*<span className={style.searchSpan} onClick={this.searchArea}></span>*/}
                            </div>
                            <div className={style.inputValue}>
                                <input type="text"
                                       ref={(e) => { this.partName = e }}
                                       placeholder="请输入干部姓名"
                                />
                                <i onClick={this.handleOk} className={`iconfont ${style['searchIcon']}`}>&#xe6d1;</i>
                            </div>
                            {/*
                            <span
                                className={style.buttonSure}
                                onClick={this.handleOk}
                            >确认</span>*/}
                        </dd>
                    </dl>
                </div>
            </div>
        )
    }
}
export default withRouter(App)
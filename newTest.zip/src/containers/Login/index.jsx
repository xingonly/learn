//測試
import React from 'react'
import resource from '../../util/resource'
let Login = (props) => {
    let handleClick  = () => {
        resource.post('/xixiu-user/security/tokenAuthen',{
            username:'guiugi',
            password:'nidaye'
        }).then((res) => {
            console.log(res)
        })
    }
    return (
        <div onClick={handleClick}>
            这里是loginfdfasdfdafda
        </div>
    )
}

export default Login

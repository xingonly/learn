import React, {Component} from "react";
import { message } from 'antd';
import { dataAnalysis } from '../../../../../configs/endpoints.prod';
import Title from '../../../../../components/Title';
import style from './index.scss';
import resource from '../../../../../util/resource';

export default class App extends Component {
    constructor() {
        super();
        this.state = {
            // 已脱贫
            ytp: 0,
            // 未脱贫
            wtp: 0,
            // 返贫
            fp: 0,
            mapData: [],
            poorNum: 0,
            notPoorNum: 0,
            totalPoorNum: 0
        }
    }

    componentDidMount() {
        this.requirePoorPeopleStatus();
        this.requireStatisticsData2();
        this.requirePoorCounty();
        this.requireNotPoorCounty();
    }

    requirePoorPeopleStatus = () => {
        resource.get(`${dataAnalysis.getPoorPeopleStatus}?region=520402000000`).then(res => {
            if(res.status !== 200) {
                message.error(res.message);
            }else {
                let ytp = 0;
                let wtp = 0;
                let fp = 0;
                let totalNum = 0;
                let totalPoorNum = 0;
                let newRes = res.data;
                if(newRes.length > 0) {
                    for(let item of newRes) {
                        totalNum = totalNum + item.value;
                        totalPoorNum = totalPoorNum + item.value;
                        if(item.name === '脱贫') {
                            ytp = item.value
                        }
                        if(item.name === '未脱贫') {
                            wtp = item.value
                        }
                        if(item.name === '返贫') {
                            fp = item.value
                        }
                    }
                }else {
                    // 数据为零时，分母置为1
                    totalNum = 1
                }
                ytp = ((ytp/totalNum)*100).toFixed(2);
                wtp = ((wtp/totalNum)*100).toFixed(2);
                fp = ((fp/totalNum)*100).toFixed(2);
                this.setState({
                    ytp: ytp,
                    wtp: wtp,
                    fp: fp,
                    totalPoorNum: totalPoorNum
                })
            }
        })
    };

    requireStatisticsData2 = () => {
        resource.get(`${dataAnalysis.getStatisticsData2}/520402000000`).then(res => {
            if(res.status !== 200) {
                message.error(res.message);
            }else {
                this.setState({
                    mapData: res.data
                })
            }
        })
    }

    requirePoorCounty = () => {
        resource.get(`${dataAnalysis.getIsPoorCounty}/1`).then(res => {
            if(res.status !== 200) {
                message.error(res.message);
            }else {
                this.setState({
                    poorNum: res.data
                })
            }
        })
    };

    requireNotPoorCounty = () => {
        resource.get(`${dataAnalysis.getIsPoorCounty}/0`).then(res => {
            if(res.status !== 200) {
                message.error(res.message);
            }else {
                this.setState({
                    notPoorNum: res.data
                })
            }
        })
    };

    render() {
        return (
            <section className={style['map-container']}>
                <Title name="调度指挥"/>
                <div className={style['map']}>
                    <div className={style['gaodei-map']} id="container">
                        {
                            this.state.mapData.map((obj, index) => (
                                <div style={{
                                    width: `${Math.ceil(obj.value/50)}px`,
                                    height: `${Math.ceil(obj.value/50)}px`
                                }} className={style['point']} key={index}>
                                    <ul style={{left: `${Math.ceil((obj.value/50)+5)}px`, top: `${Math.ceil((obj.value/50)+5)}px`}} className={style['tooltip']}>
                                        <li>
                                            <span>{!!obj.name? obj.name: '--'}</span>
                                        </li>
                                        <li>
                                            <span>{!!obj.value? `贫困人数：${obj.value}`: '--'}</span>
                                        </li>
                                        <li>
                                            <span>{!!obj.values[1].value? `已脱贫：${obj.values[1].value}`: '--'}</span>
                                        </li>
                                        <li>
                                            <span>{!!obj.values[0].value? `未脱贫：${obj.values[0].value}`: '--'}</span>
                                        </li>
                                    </ul>
                                </div>
                            ))
                        }
                        <div className={style['coverMap']}>
                        </div>
                    </div>
                    <div style={{top: '2.5rem'}} className={style['same-left']}>
                        <div className={style['title']}>
                            <span>建档立卡贫困村数</span>
                        </div>
                        <div className={style['content']}>
                            <span>{this.state.poorNum}</span>
                            <span>(个)</span>
                        </div>
                    </div>
                    <div style={{top: '8rem'}} className={style['same-left']}>
                        <div className={style['title']}>
                            <span>非贫困村数</span>
                        </div>
                        <div className={style['content']}>
                            <span>{this.state.notPoorNum}</span>
                            <span>(个)</span>
                        </div>
                    </div>
                    <div style={{top: '13.5rem'}} className={style['same-left']}>
                        <div className={style['title']}>
                            <span>建档立卡情况</span>
                        </div>
                        <div className={style['content']}>
                            <span>{this.state.totalPoorNum}</span>
                            <span>(人)</span>
                        </div>
                    </div>
                    {/*<div style={{bottom: '10.6rem'}} className={style['same-right']}>*/}
                        {/*<span>已脱贫：</span>*/}
                        {/*<span>{`${85.27}%`}</span>*/}
                    {/*</div>*/}
                    {/*<div style={{bottom: '7rem'}} className={style['same-right']}>*/}
                        {/*<span>未脱贫：</span>*/}
                        {/*<span>{`${13.90}%`}</span>*/}
                    {/*</div>*/}
                    {/*<div style={{bottom: '3.5rem'}} className={style['same-right']}>*/}
                        {/*<span>返贫：</span>*/}
                        {/*<span>{`${0.82}%`}</span>*/}
                    {/*</div>*/}
                    <div style={{bottom: '10.6rem'}} className={style['same-right']}>
                        <span>已脱贫：</span>
                        <span>{`${this.state.ytp}%`}</span>
                    </div>
                    <div style={{bottom: '7rem'}} className={style['same-right']}>
                        <span>未脱贫：</span>
                        <span>{`${this.state.wtp}%`}</span>
                    </div>
                    <div style={{bottom: '3.5rem'}} className={style['same-right']}>
                        <span>返贫：</span>
                        <span>{`${this.state.fp}%`}</span>
                    </div>
                </div>
            </section>
        )
    }
}
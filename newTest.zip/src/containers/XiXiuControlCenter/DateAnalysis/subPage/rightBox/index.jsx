import React, {Component} from "react";
import style from './index.scss';
import Title from '../../../../../components/Title';
import Line from './subPage/Line';
import Pip from './subPage/Pip';
import Sex from './subPage/Sex';
import resource from '../../../../../util/resource';

export default class RightBox extends Component {
    constructor(props){
        super(props);
        this.state = {
            gender:[],
            age:[],
            reason:[]
        }
    }

    componentDidMount(){
        this.getReason();
        this.getGender();
        this.getAge();
    }

    getReason = () => {
        resource.get( `/xixiu-server/dataStatistics/getPoorCauses?region=520400000000` ).then(res =>{
            if(res.status === 200){
                this.setState({
                    reason:res.data
                })
            }
        })
    }
    getGender = () =>{
        resource.get( `/xixiu-server/dataStatistics/getGenderRatio?region=520402000000` ).then(res =>{
            if(res.status === 200){
                this.setState({
                    gender:res.data
                })
            }
        })
    }
    getAge = () =>{
        resource.get( `/xixiu-server/dataStatistics/getAgeRatioUi?region=520402000000` ).then(res =>{
            if(res.status === 200){
                this.setState({
                    age:res.data
                })
            }
        })
    }
    render() {
        return (
            <section className={style.RightBox}>
                <div className={style.reason}>
                    <Title name="建档立卡致贫原因统计"/>
                    <div className={style.chart}>
                        <Pip id='pip' data={this.state.reason}/>
                    </div>
                </div>
                <div className={style.sex}>
                    <Title name="建档立卡性别比例"/>
                    <div className={style.chart}>
                        <Sex data={this.state.gender}/>
                    </div>
                </div>
                <div className={style.age}>
                    <Title name="建档立卡年龄分布"/>
                    <div className={style.chart}>
                        <Line id='line' data={this.state.age}/>
                    </div>
                </div>
            </section>
        )
    }
}
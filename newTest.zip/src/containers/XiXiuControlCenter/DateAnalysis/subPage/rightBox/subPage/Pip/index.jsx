import React, {Component} from "react";
import echarts from "echarts";

export default class Pip extends Component {
    constructor(props) {
        super(props)
        this.myChart = null
    }

    componentDidMount() {
        this.myChart = echarts.init(document.getElementById(this.props.id))
        // this.myChart.setOption(this.getOption())
        window.addEventListener('resize', this.myChart.resize)
    }

    componentWillReceiveProps(props) {
        this.myChart.setOption(this.getOption(props.data))
    }

    componentWillUnmount() {
        this.myChart.dispose()
        window.removeEventListener('resize', this.myChart.resize)
    }
    getOption = (date) => {
        let rect = document.getElementById(this.props.id).getBoundingClientRect()
        let colorEmpty = ['#63daf2','#fb8700','#fcb700','#fddb3c','#fce88f','#128973',
            '#0ea98a','#22bfa0','#54e0c5','#65f5da','#daecf8','#97e8f9'];
        let colorError = ['#54b9cd', '#d67200', '#d49c00', '#d7b933','#d6c678','#0f7462',
            '#0c8e76','#1ca289','#47bea8','#55d1b9','#bac8d3','#80c5d4'];
        let menus = [];
        let emptyDate = [];
        let valueDate = [];
        for(let i = 0,len = date.length; i < len; i++){
            menus.push(date[i].name);
            emptyDate.push({value: date[i].value,name:''});
            valueDate.push({value: date[i].value,name:date[i].name});
        }
        let colorWai = colorEmpty.slice(0,date.length)
        let colorNei = colorError.slice(0,date.length)
        let option = {
            tooltip: {
                trigger: 'item',
                formatter: "{b}:  {d}%",
            },
            legend: {
                icon:'circle',
                orient: 'vertical',
                x: 'right',
                y:'center',
                align: 'left',
                data:menus,
                textStyle: {
                    color: '#000',
                    fontSize: 10
                },
                itemWidth: 9,
                height:'100%',
                itemGap: rect.height / 50,
                formatter:function(name){
                    let oa = option.series[1].data;
                    let colors = option.series[1].color;
                    let num = 0;
                    for(let i = 0; i < oa.length; i++){
                        num = num + oa[i].value;
                    }
                    for(let i = 0; i < oa.length; i++){
                        if(name === oa[i].name){
                            return name + '     ' + (oa[i].value/num * 100).toFixed(2) + '%' + '     ' + oa[i].value;
                        }
                    }
                }
            },
            series: [
                {
                    name:'访问来源',
                    type:'pie',
                    hoverAnimation: false,
                    legendHoverLink:false,
                    radius: ['45%', '55%'],
                    center: ['36%', '50%'],
                    color: colorNei,
                    label: {
                        normal: {
                            position: 'inner'
                        }
                    },
                    labelLine: {
                        normal: {
                            show: false
                        },

                    },
                    tooltip: {
                        show:false,
                    },
                    data:emptyDate
                },
                {
                    name:'访问来源2',
                    type:'pie',
                    avoidLabelOverlap: false,
                    radius: ['55%', '77%'],
                    center: ['36%', '50%'],
                    color: colorWai,
                    label: {
                        normal: {
                            show: false,
                            position: 'center'
                        },
                        emphasis:{
                            show: true,
                            textStyle:{
                                fontSize: '16',
                                color:'#687182',
                                textShadowColor: '#000',
                                textShadowBlur: 20
                            }
                        }
                    },
                    labelLine: {
                        normal: {
                            show: false
                        },

                    },
                    data:valueDate
                }
            ]
        };
        return option
    }
    render() {
        return (
            <div style={{width:'100%',height:'100%'}} id={this.props.id}/>
        )
    }
}
// 上帝保佑,永无bug

import React, {Component} from "react"
import {immutableRenderDecorator} from 'react-immutable-render-mixin'

import style from './style.scss'

@immutableRenderDecorator
export default class Sex extends Component {

    constructor(props) {
        super(props);
        this.state = {
            bodyPercent: 0,
            girlPercent: 0
        }
    }

    /*componentDidMount(){
        let props = this.props;
        let body,girl;
        for(let i = 0; i < props.data.length; i++){
            if(props.data[i].name === '男'){
                body = props.data[i].value;
            }else if(props.data[i].name === '女'){
                girl = props.data[i].value
            }
        }
        // let body = props.data.get('男')
        // let girl = props.data.get('女')
        let bodyPercent = (body / (body + girl) * 100).toFixed(1) + '%'
        let girlPercent = (girl / (body + girl) * 100).toFixed(1) + '%'
        this.setState({
            bodyPercent,
            girlPercent
        })
        requestNextAnimationFrame(() => {
            this.refs.boy.style.width = bodyPercent
            this.refs.girl.style.width = girlPercent
        })
    }*/

    componentWillReceiveProps(props) {
        let body,girl;
        for(let i = 0; i < props.data.length; i++){
            if(props.data[i].name === '男'){
                body = props.data[i].value;
            }else if(props.data[i].name === '女'){
                girl = props.data[i].value
            }
        }
        let bodyPercent, girlPercent;
        if(!body || !girl){
            bodyPercent = '0%';
            girlPercent = '0%';
        } else {
            bodyPercent = (body / (body + girl) * 100).toFixed(1) + '%'
            girlPercent = (girl / (body + girl) * 100).toFixed(1) + '%'
        }
        this.setState({
            bodyPercent,
            girlPercent
        })
        requestNextAnimationFrame(() => {
            this.refs.boy.style.width = bodyPercent
            this.refs.girl.style.width = girlPercent
        })
    }

    render() {
        return (
            <div className={style.wrap}>
                <dl>
                    <dt>女</dt>
                    <dd><div style={{background: 'linear-gradient(to right,#fab800,#fae98f)'}} ref="girl" /></dd>
                    <dd>{this.state.girlPercent}</dd>
                </dl>
                <dl>
                    <dt>男</dt>
                    <dd><div style={{background: 'linear-gradient(to right,#57a8b9,#abfdee)'}} ref="boy" /> </dd>
                    <dd>{this.state.bodyPercent}</dd>
                </dl>
            </div>
        )
    }
}

import React, {Component} from "react";
import style from './index.scss';
import DateAnalysis from './DateAnalysis'
import DataStatistics from './DataStatistics'

export default class XiXiuControlCenter extends Component {
    constructor(props){
        super(props);
        this.state = {
            show:false,
        };
    }

    handleTable = (status) => {
        let state = this.state;
        state.show = status;
        this.setState(state);
    }
    render() {
        let { show } = this.state;
        return (
            <section id={style['XiXiuControlCenter']}>
                <div className={style.container}>
                    {
                        !show ? <DateAnalysis/>:< DataStatistics/>
                    }
                </div>
                <ul className={style.table}>
                    <li
                        className={style[!show ? 'active':'']}
                        onClick={() => this.handleTable(false)}
                    ></li>
                    <li
                        className={style[show ? 'active':'']}
                        onClick={() => this.handleTable(true)}
                    ></li>
                </ul>
            </section>
        )
    }
}
import React, {Component} from "react";
import LeftBox from './subPage/leftBox'
import RightBox from './subPage/rightBox'

export default class DateAnalysis extends Component {

    render() {
        return (
            <section>
                <LeftBox />
                <RightBox />
            </section>
        )
    }
}
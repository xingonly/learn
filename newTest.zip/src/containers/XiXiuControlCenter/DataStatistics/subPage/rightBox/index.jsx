import React, {Component} from "react";
import style from './index.scss';
import Title from '../../../../../components/Title';
import Line from './subPage/Line';
import Pip from './subPage/Pip';
import Pip1 from './subPage/Pip/pie1';
import Sex from './subPage/Sex';
import resource from '../../../../../util/resource';
import sg from '../leftBox/images/sg.jpg'

export default class RightBox extends Component {
    constructor(props){
        super(props);
        this.state = {
            gender:[],
            age:[],
            reason:[]
        }
    }

    componentDidMount(){/*
        this.getReason();
        this.getGender();
        this.getAge();*/
    }

    getReason = () => {
        resource.get( `/xixiu-server/dataStatistics/getPoorCauses?region=520400000000` ).then(res =>{
            if(res.status === 200){
                this.setState({
                    reason:res.data
                })
            }
        })
    }
    getGender = () =>{
        resource.get( `/xixiu-server/dataStatistics/getGenderRatio?region=520402000000` ).then(res =>{
            if(res.status === 200){
                this.setState({
                    gender:res.data
                })
            }
        })
    }
    getAge = () =>{
        resource.get( `/xixiu-server/dataStatistics/getAgeRatioUi?region=520402000000` ).then(res =>{
            if(res.status === 200){
                this.setState({
                    age:res.data
                })
            }
        })
    }
    render() {
        return (
            <section className={style.RightBox}>
                <div className={style.reason}>
                    <Title name="非建档立卡家庭属性统计"/>
                    <div className={style.chart}>
                        <Pip id='pip1' data={this.state.reason}/>
                    </div>
                </div>
                <div className={style.sex}>
                    <Title name="危房比例"/>
                    <div className={style.chart}>
                        <Sex data={this.state.gender}/>
                    </div>
                </div>
                <div className={style.age}>
                    <Title name="三改完成情况"/>
                    <div className={style.chart}>
                        <div className={style.header}>
                            <dl>
                                <dt></dt>
                                <dd>未完成</dd>
                            </dl>
                            <dl>
                                <dt style={{background:'#57afb8'}}></dt>
                                <dd>已完成</dd>
                            </dl>
                        </div>
                        <div className={style.pie}>
                            <Pip1 id="pie2" url="/statistics/kitchen"></Pip1>
                            <div className={style.textRegion}>厨改完成情况</div>
                        </div>
                        <div className={style.pie}>
                            <Pip1 id="pie3" url="/statistics/sty"></Pip1>
                            <div className={style.textRegion}>圈改完成情况</div>
                        </div>
                        <div className={style.pie}>
                            <Pip1 id="pie4" url="/statistics/toilet"></Pip1>
                            <div className={style.textRegion}>厕改完成情况</div>
                        </div>
                    </div>
                </div>
            </section>
        )
    }
}
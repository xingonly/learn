import React, {Component} from "react";
import echarts from "echarts";

export default class Pip extends Component {
    constructor(props) {
        super(props)
        this.myChart = null
    }

    componentDidMount() {
        this.myChart = echarts.init(document.getElementById(this.props.id))
        // this.myChart.setOption(this.getOption())
        window.addEventListener('resize', this.myChart.resize)
    }

    componentWillReceiveProps(props) {
        this.myChart.setOption(this.getOption(props.data))
    }

    componentWillUnmount() {
        this.myChart.dispose()
        window.removeEventListener('resize', this.myChart.resize)
    }
    getOption = (data) => {
        let ageDate = [];
        for(let i = 0,len = data.length; i < len; i++){
            ageDate.push(data[i].value);
        }
        let option = {
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    lineStyle: {
                        color: '#ddd'
                    }
                },
                formatter:'{b}岁：{c} (人)',
                backgroundColor: '#596573',
                padding: [5, 10],
                textStyle: {
                    color: '#fff',
                },
                extraCssText: 'box-shadow: 0 0 5px rgba(0,0,0,0.3)'
            },
            grid: {
                top: '10%',
                left: '10%', //grid 组件离容器左侧的距离。
                right: '5%', //grid 组件离容器右侧的距离。
                bottom: '12%', //grid 组件离容器下侧的距离。
            },
            xAxis: {
                type: 'category',
                data: ['1-18', '18-28', '28-38', '38-48', '48-58', '58-68', '68以上'],
                // boundaryGap: false,
                splitLine: {
                    show: false,
                },
                axisTick: {
                    show: false
                },
                axisLine: {
                    lineStyle: {
                        color: '#f7f7f7'
                    }
                },
                axisLabel: {
                    margin: 10,
                    textStyle: {
                        fontSize: 10,
                        color:'#646b7b'
                    }
                }
            },
            yAxis: {
                type: 'value',
                splitLine: {
                    lineStyle: {
                        color: ['#f7f7f7']
                    }
                },
                axisTick: {
                    show: false
                },
                axisLine: {
                    show:false
                },
                axisLabel: {
                    margin: 10,
                    textStyle: {
                        fontSize: 12,
                        color:'#646b7b'
                    }
                }
            },
            series: [{
                name: '今日',
                type: 'bar',
                data: ageDate,
                barWidth: '35%',
                itemStyle: {
                    normal: {
                        color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                            offset: 0,
                            color: '#55abba'
                        }, {
                            offset: 1,
                            color: '#fff'
                        }], false),
                        barBorderRadius: [5,5,0,0]
                    }
                },
            }]
        };
        return option
    }
    render() {
        return (
            <div style={{width:'100%',height:'100%'}} id={this.props.id}/>
        )
    }
}
import React, {Component} from "react";
import echarts from "echarts";
import resource from 'util/resource'

export default class Pip extends Component {
    constructor(props) {
        super(props)
        this.myChart = null
        this.state= {
            optionData:[]
        }
    }


    componentDidMount() {
        this.myChart = echarts.init(document.getElementById(this.props.id))
        this.getInitData();
        window.addEventListener('resize', this.myChart.resize)
    }

    /*componentWillReceiveProps(props) {
     this.myChart.setOption(this.getOption(props.data))
     }*/

    getInitData = () => {
        resource.get(`/xixiu-work${this.props.url}`).then((res) => {
            if(res.status === 200){
                let state = this.state;
                state.optionData = res.data && res.data.length ? res.data : [];
                this.setState(state,() => {
                    this.myChart.setOption(this.getOption())
                });
            }
        })
    }

    componentWillUnmount() {
        this.myChart.dispose()
        window.removeEventListener('resize', this.myChart.resize)
    }
    getOption = (date) => {
        /*let data = ['边缘户','老人户','光棍户','大病户','残疾户','低保户'];
         let value = [ 123,223,352,426,123,324];*/
        let state = this.state;
        if(!state.optionData.length){
            return;
        }
        let rect = document.getElementById(this.props.id).getBoundingClientRect()
        let colorEmpty = ['#59b6b7','#fce274','#fcb700','#fddb3c','#fce88f','#128973',
            '#0ea98a','#22bfa0','#54e0c5','#65f5da','#daecf8','#97e8f9'];
        let colorError = ['#59b6b7', '#fce274', '#d49c00', '#d7b933','#d6c678','#0f7462',
            '#0c8e76','#1ca289','#47bea8','#55d1b9','#bac8d3','#80c5d4'];
        let menus = [];
        let emptyDate = [];
        let valueDate = [];
        for(let i = 0; i < 2; i++){
            if(state.optionData[i] &&state.optionData[i].key === true){
                menus.push('已完成');
                emptyDate.push({value: state.optionData[i] &&state.optionData[i].value || 0,name:''});
                valueDate.push({value: state.optionData[i] &&state.optionData[i].value || 0,name:'已完成'});
            }else{
                menus.push('未完成');
                emptyDate.push({value: state.optionData[i] &&state.optionData[i].value || 0,name:''});
                valueDate.push({value: state.optionData[i] &&state.optionData[i].value || 0,name:'未完成'});
            }
        }

        console.log(menus,valueDate)
        let colorWai = colorEmpty.slice(0,2)
        let colorNei = colorError.slice(0,2)
        let option = {
            tooltip: {
                trigger: 'item',
                formatter: "{b}:  {d}%",
            },
            legend: {
                icon:'circle',
                orient: 'vertical',
                x: 'right',
                y:'center',
                show:false,
                align: 'left',
                data:menus,
                textStyle: {
                    color: '#000',
                    fontSize: 10
                },
                itemWidth: 9,
                height:'100%',
                itemGap: rect.height / 50,
                formatter:function(name){
                    let oa = option.series[1].data;
                    let colors = option.series[1].color;
                    let num = 0;
                    for(let i = 0; i < oa.length; i++){
                        num = num + oa[i].value;
                    }
                    for(let i = 0; i < oa.length; i++){
                        if(name === oa[i].name){
                            return name + '     ' + (oa[i].value/num * 100).toFixed(2) + '%' + '     ' + oa[i].value;
                        }
                    }
                }
            },
            series: [
                {
                    name:'访问来源',
                    type:'pie',
                    hoverAnimation: false,
                    legendHoverLink:false,
                    radius: ['35%', '45%'],
                    center: ['50%', '50%'],
                    color: colorNei,
                    label: {
                        normal: {
                            show:false,
                        }
                    },
                    labelLine: {
                        normal: {
                            show: false
                        },

                    },
                    tooltip: {
                        show:false,
                    },
                    data:emptyDate
                },
                {
                    name:'访问来源2',
                    type:'pie',
                    avoidLabelOverlap: false,
                    radius: ['45%', '60%'],
                    center: ['50%', '50%'],
                    color: colorWai,
                    label: {
                        normal: {
                            show: true,
                            formatter:'{d}%'
                        },
                        emphasis:{
                            show: false,
                            textStyle:{
                                fontSize: '16',
                                color:'#687182',
                                textShadowColor: '#000',
                                textShadowBlur: 20
                            }
                        }
                    },
                    labelLine: {
                        normal: {
                            show: true,
                            length:1
                        },

                    },
                    data:valueDate
                }
            ]
        };
        return option
    }
    render() {
        return (
            <div style={{width:'100%',height:'100%'}} id={this.props.id}/>
        )
    }
}
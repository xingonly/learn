import React, { Component } from 'react'
import { withRouter } from 'react-router-dom'
import echarts from 'echarts'
import resource from 'util/resource'
import Title from 'components/Title'

class chart extends Component{
    constructor(props){
        super(props);
        this.chart = null;
        this.paramas = {
            "district_code": 520402000000,
            "year": "2017"
        };
        this.state = {
            optionData:[],
            initData:{
                vehicle_count:0,
                company_count:0,
                fsupported_count:0,
                house_count:0
            }
        };
    }

    componentWillMount(){
        this.getInitData();
    }

    componentDidMount(){
        this.myChart = echarts.init(this.refs.barTest);
        let _this = this;
        window.addEventListener("resize",function(){
            _this.myChart.resize();
        });
    }

    getInitData = () => {
        resource.get('/xixiu-work/statistics/collection').then((res) => {
            if(res.status === 200){
                let state = this.state;
                state.optionData = res.data && res.data.length ? res.data : [];
                this.setState(state,() => {
                    this.getOption();
                });
            }
        })
    }

    getOption  = () => {
        let state = this.state;
        let data = [];
        let xAxisName = [];
        if(!state.optionData){
            return;
        }
        state.optionData.map((obj, index) => {
            xAxisName.push(obj.name)
            data.push(obj.value)
        });
        let option = {
            color:['#fbaa26','#1ad1be','#f47b8c','#14cbe9'],
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'shadow'
                }
            },
            legend: {
                data: ['已采集'],
                right:'2%',
                orient:'vertical',
                top:'50%',
                show:false

            },
            grid: {
                left: '3%',
                right: '20%',
                bottom: '3%',
                containLabel: true
            },
            xAxis: {
                type: 'value',
                boundaryGap: [0, 0.01],
                show:false,
                splitLine:{
                    show:false
                },
                axisTick:{
                    show:false
                },
                axisLabel: {
                    color:'red'
                }
            },
            yAxis: {
                type: 'category',
                data: xAxisName,
                axisLine:{
                    lineStyle:{
                        color:'#77808d'
                    },
                },
                splitLine:{
                    show:false
                },
                axisTick:{
                    show:false
                },
                axisLabel:{
                    show:true,
                    color:'#77808d',
                },
            },
            series: [
                {
                    name: '已采集',
                    type: 'bar',
                    data: data,
                    label:{
                        normal: {
                            show:true,
                            color:'#55abb9',
                            formatter:'{c}'
                        }

                    },
                    itemStyle:{
                        normal:{
                            barBorderRadius:40,
                            color: new echarts.graphic.LinearGradient(1,0,0, 1, [{
                                offset: 0,
                                color: '#aefced',
                            }, {
                                offset: 1,
                                color: '#55abb9',
                            }]),
                        },
                    }
                }
            ]
        };
        this.myChart.setOption(option);

    }

    render(){
        let { initData } = this.state;
        return(
                <div ref="barTest" style={{height:'100%',width:'100%'}}></div>
        )
    }
}

export default withRouter(chart)
import React, {Component} from "react";
import { message } from 'antd';
import { dataAnalysis } from '../../../../../configs/endpoints.prod';
import Title from '../../../../../components/Title';
import style from './index.scss';
import resource from '../../../../../util/resource';
import all from './images/all.jpg'
import Bar from './chart/bar'

export default class App extends Component {
    constructor() {
        super();
        this.state = {
            // 已脱贫
            ytp: 0,
            // 未脱贫
            wtp: 0,
            // 返贫
            fp: 0,
            mapData: [],
        }
    }

    componentDidMount() {
        this.requirePoorPeopleStatus();
        this.requireStatisticsData2();
    }

    requirePoorPeopleStatus = () => {
        resource.get(`${dataAnalysis.getPoorPeopleStatus}?region=520402000000`).then(res => {
            if(res.status !== 200) {
                message.error(res.message);
            }else {
                let ytp = 0;
                let wtp = 0;
                let fp = 0;
                let totalNum = 0;
                let newRes = res.data;
                if(newRes.length > 0) {
                    for(let item of newRes) {
                        totalNum = totalNum + item.value;
                        if(item.name === '脱贫') {
                            ytp = item.value
                        }
                        if(item.name === '未脱贫') {
                            wtp = item.value
                        }
                        if(item.name === '返贫') {
                            fp = item.value
                        }
                    }
                }else {
                    // 数据为零时，分母置为1
                    totalNum = 1
                }
                ytp = ((ytp/totalNum)*100).toFixed(2);
                wtp = ((wtp/totalNum)*100).toFixed(2);
                fp = ((fp/totalNum)*100).toFixed(2);
                this.setState({
                    ytp: ytp,
                    wtp: wtp,
                    fp: fp
                })
            }
        })
    };

    requireStatisticsData2 = () => {
        resource.get(`${dataAnalysis.getStatisticsData2}/520402000000`).then(res => {
            if(res.status !== 200) {
                message.error(res.message);
            }else {
                this.setState({
                    mapData: res.data
                })
            }
        })
    }

    render() {
        return (
            <section className={style['map-container']}>
                <Title name="采集户数统计"/>
                <div className={style['map']}>
                    <Bar/>
                </div>
            </section>
        )
    }
}
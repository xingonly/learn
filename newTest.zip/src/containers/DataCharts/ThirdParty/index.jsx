import React, {Component} from 'react';
import style from './style.scss';
import immutable from 'immutable';
import Modal from '../../../components/Rodal';
import resource from '../../../util/resource';
import icon from './images/confirm.png';
import moment from 'moment';

export default class ThirdParty extends Component {

    constructor(props) {
        super(props);
        this.copy = {};
        this.copy1 = {};
        this.state = {
            show:false,
            show1:false,
            show2:false,
            all:false,//全选
            data:[],
            index:-1,
            index1:-1,
            isOpen:false,//弹出框
            areaData:{},
            openIndex:1,
            department:'公安厅',
            year:'2017',
            juban:[],
            time:[],
            header:[],//表头
            key:[],
            area:[],
            key1:'',
            area1:[],
            area2:[],
            width:'',
            areade:{},
            xianArea:[],
            table1:[],
            table2:[],
        };
        //实时年份wangkegui
        let year = moment().format("YYYY");
        console.log(year)
        this.param = {
            department:'gongan',
            year:year,
            table:[]
        };
        this.area = [];
    }
    //部门选择
    handleShow = () => {
        this.setState({
            show:!this.state.show
        })
    };
    handleShow1 = () => {
        this.setState({
            show1:!this.state.show1
        })
    };
    //导出
    handleOut = () => {
        this.setState({
            isOpen:true
        })
    };
    handleRodal = () => {
        this.params = {};
        this.setState({
            isOpen:false,
            openIndex:1,
            areaData:this.state.areade,
            all:false,
            table2:[]
        })
    };
    componentDidMount(){
        this.getField();
        this.handleHeader();
        this.handleData();
        this.handleArea();
        // this.getTableList();

    }
    componentDidUpdate(){
        let ju = document.querySelector('#ju');
        let length = this.state.data.length;
        if(length){
            ju.style.height = length * 2 + 'rem';
            ju.style.lineHeight = length * 2 + 'rem';
        }else {
			ju.style.height = 2 + 'rem';
			ju.style.lineHeight = 2 + 'rem';
        }
        /*if(width > 1400){
			ju.style.height = h - 40 + 'px';
			ju.style.lineHeight = h - 40 + 'px';
        }else {
			ju.style.height = h - 2 * 14.23 + 'px';
			ju.style.lineHeight = h - 2 * 14.23 + 'px';
        }*/

    }
    //显示更多
    moreHeight = (index) => {
        if (this.state.index === index){
            this.setState({
                index: -1
            });
        }else{
            this.setState({
                index
            })
        }
    };
    //向下箭头
    downUp = (index,item) => {
        if (this.state.index1 === index){
            this.setState({
                index1: -1,
                show2:false,
            });
        }else{
            let array = this.copyObj(this.copy);
            for(let i in array){
                if(item === i){
                    this.setState({
                        index1:index,
                        area1:array[i],
                        show2:true,
                        key1:item
                    })
                }
            }
        }
    };
    //更改高度
    getHeight = () => {
        let item = this.state.data.length;
        // return item * 40 +'rem';
    };
    //copy
    copyObj = (obj) => {
        if(typeof obj !== 'object' || obj === null)
        {
            return obj;
        }
        let result = obj instanceof Array ? [] : {};
        for(let key in obj)
        {
            result[key] = this.copyObj(obj[key]);
        }

        return result;
    };
    //全选
    handleAll = () => {
        let date = this.copyObj(this.state.areaData);
        if(this.state.all){
            for (let i in date){
                date[i]= [];
            }
            this.setState({
                all:!this.state.all,
                areaData:date
            });
        }else{
            for (let i in date){
                date[i] = this.copy[i];
            }
            this.setState({
                all:!this.state.all,
                areaData:date
            })
        }
    };
    //单选
    handleOne = (item) => {
        let area = this.copyObj(this.state.areaData);
        if(this.state.areaData[item].length > 0){
            area[item]= [];
            this.setState({
                areaData:area,
            });
        }else{
            for(let i in this.copy){
                if(item === i){
                    area[item] = this.copy[i];
                }
            }
            this.setState({
                areaData:area
            });

        }
    };
    //县单选
    handleXian = (item) =>{
        let xian = this.copyObj(this.state.areaData);
        if(xian[this.state.key1].indexOf(item)!== -1){
            xian[this.state.key1].splice(this.state.areaData[this.state.key1].indexOf(item),1);
            this.setState({
                areaData:xian
            })
        }else{
            xian[this.state.key1].push(item);
            this.setState({
                areaData:xian
            })
        }
    };
    handleIndex = (index) => {
        console.log(index);
        this.setState({
            openIndex:index
        })
    };
    //获取数据
    handleData = () => {
        resource.get(`/xixiu-server/dataStatistics/getStatisticsReport?department=${this.param.department}&year=${this.param.year}`).then(res => {
            if(res.status === 200){
                let content = res.data.content;
                let area = [];
                area.push(content[0]);
                for(let i =0;i<content[0].child.length;i++){
                    area.push(content[0].child[i]);
                }
                this.setState({
                    data:area
                });
            }
        })
    };
    //字典
    getField = () => {
        resource.get(`/pww/statistics/v0.1/range`).then(res => {
            if(res.status === 200){
                this.setState({
                    juban:res.data.content.department,
                    time:res.data.content.year
                })
            }
        })
    };
    //选择局办
    handleCho = (index) =>{
        this.param.department = index.value;
        this.setState({
            department :index.display,
            show:!this.state.show
        },()=>{this.handleData();this.handleHeader()})
    };
    handleCho1 = (index) =>{
        this.param.year = index.value;
        this.setState({
            year :index.display,
            show1:!this.state.show1
        })
    };
    //表头
    handleHeader = () => {
        resource.get(`/pww/statistics/v0.1/dict?deptCode=${this.param.department}`).then(res => {
            if(res.status === 200){
                let key = [];
                for(let i = 0; i< res.data.content.length;i++){
                    key.push(res.data.content[i].column_name);
                }
                let table = document.querySelector('#table');
                let width = '';
                if(key.length < 8){
                    table.style.width = 25 + 8.5 * 8.5 + 'rem';
                    width = 17 + 8.5 * 8.5 + 'rem';
                }else{
                    table.style.width = 25 + key.length * 8.5 + 'rem';
                    width = 17 + key.length * 8.5 + 'rem';
                }

                this.setState({
                    header:res.data.content,
                    key:key,
                    width:width
                });
            }
        })
    };
    //地区
    handleArea = () =>{
        resource.get(`/xixiu-server/regions/getMyRegionList`).then(res =>{
            if(res.status === 200){
                let areaData = {};
                let areade = {};
                for(let i = 0;i < res.data.length;i++){
                    areaData[res.data[i].name] = [];
                    areade[res.data[i].name] = [];
                    let xian = [];
                    for(let j=0; j< res.data[i].region.length; j++){
                        xian.push(res.data[i].region[j].name);
                    }
                    this.copy[res.data[i].name]=xian;
                }
                this.setState({
                    area:res.data,
                    areaData:areaData,
                    areade:areaData
                })
            }
        })
    };
    //下一步
    handleNext = () => {
        let area = [];
        for( let i in this.state.areaData){
            for(let j = 0 ; j < this.state.areaData[i].length ; j++){
                area.push(this.state.areaData[i][j]);
            }
        }
        if(area.length > 0){
            this.getTableList();
        }else{
            alert("请选择需要导出的地区!");
        }
    };
    //选中的表
    handleOne1 = (item) => {
        let table = this.state.table2;
        if(this.state.table2.indexOf(item) !== -1){
            let index = this.state.table2.indexOf(item);
            table.splice(index,1);
            this.setState({
                table2:table
            })
        }else{
            table.push(item);
            this.setState({
                table2:table
            })

        }
    };
    //确认导出
    handleConfirm = () => {
        let area =[];
        for (let i in this.state.areaData){
            if(this.state.areaData[i].length > 0){
                // area.push(i);
                for(let j = 0 ; j < this.state.areaData[i].length ; j++){
                    area.push(this.state.areaData[i][j]);
                }
            }
        }
        if(this.state.table2.length > 0){
            let area1 = area.toString();
            let tt = this.state.table2.toString();
            let data = `{"districtCode":"${area1}","table":"${tt}","department":"${this.state.department}"}`;
            let xhr = new XMLHttpRequest();
            xhr.withCredentials = true;
            xhr.addEventListener("readystatechange", () => {
                if (xhr.readyState === 4) {
                    let header = xhr.getResponseHeader('Content-Disposition');
                    let content = xhr.response;
                    let data = new Blob([content],{type:"application/octet-stream"});
                    let downloadUrl = window.URL.createObjectURL(data);
                    let anchor = document.createElement("a");
                    anchor.href = downloadUrl;
                    anchor.download = decodeURIComponent(header);
                    anchor.click();
                    window.URL.revokeObjectURL(data);
                    this.handleIndex(3);
                }
            });
            xhr.open("POST", "/welfare-files/welfare/getReportFile");
            let token = sessionStorage.getItem('token');
            xhr.responseType = "blob";
            xhr.setRequestHeader('token', sessionStorage.getItem('token'));
            xhr.send(data);
        }else{
            return;
        }

    };

    //获取表名
    getTableList = () => {
        resource.post(`/welfare-files/welfare/getTables`,{department:this.state.department}).then(res => {
            if(res.status === 200){
                this.handleIndex(2);
                this.setState({
                    table1:res.data
                });
            }
        })
    };

    render() {

        return (
            <section id={style['third']}>
                <ul className={style.ul}>
                    <li onClick={()=>{this.props.onChange(1)}}>基本情况-贫困状况</li>
                    <li className={style.active}>第三方数据清洗</li>
                    <li onClick={()=>{this.props.onChange(3)}} >精准统计</li>
                </ul>
                <div className={style.choice}>
                    <div className={style.ju} style={{ marginLeft:'8rem'}}>
                        <span>{this.state.department}</span>
                        {
                            this.state.show ? <i className={"iconfont"+" "+style.xia} onClick={this.handleShow}>&#xe791;</i>:
                            <i className={"iconfont"+" "+style.xia} onClick={this.handleShow}>&#xe792;</i>
                        }
                        <div style={{display:this.state.show ? 'block':'none'}} className={style.pulldown}>
                            {
                                this.state.juban.map((item,index) => {
                                    return(
                                        <div className={style.p_item} onClick={()=>{this.handleCho(item)}} key={index}>{item.display}</div>
                                    )
                                })
                            }
                        </div>
                    </div>
                    <div className={style.ju} style={{marginLeft:'10px',display:'none'}}>
                        <span>{this.state.year}</span>
                        {
                            this.state.show1 ? <i className={"iconfont"+" "+style.xia} onClick={this.handleShow1}>&#xe791;</i>:
                                <i className={"iconfont"+" "+style.xia} onClick={this.handleShow1}>&#xe792;</i>
                        }
                        <div style={{display:this.state.show1 ? 'block':'none'}} className={style.pulldown}>
                            {
                                this.state.time.map((item,index) => {
                                    return(
                                        <div className={style.p_item} onClick={()=>{this.handleCho1(item)}} key={index}>{item.display}</div>
                                    )
                                })
                            }

                        </div>
                    </div>
                    <div className={style.search + ' ' + "iconfont"}>&#xe6d1;</div>
                </div>
                <div className={style.out}>
                    <span className={style.down} onClick={this.handleOut}>
                        <span>导出</span>
                        <i className={"iconfont"+' '+style.icon}>&#xe63d;</i>
                    </span>
                </div>
                <div className={style.box}>
                    <div id="table" className={style.tttt}>
                        <div className={style.table}>
                            <span className={style.t_item}>局办</span>
                            <span className={style.t_item}>
                        <span>区域</span>
                    </span>
                            {
                                this.state.header.map((item,index)=>{
                                    return(
                                        <span className={style.t_item} key={index}>
                                        <span>{item.column_value}</span>
                                </span>
                                    )
                                })
                            }
                        </div>
                        <div className={style.first} id="ju">{this.state.department}</div>
                        {
                            this.state.data.map((item,index)=>{
                                return(
                                    <div className={style.subTable} style={{width:this.state.width}} key={index}>
                                        <div className={style.table1} style={{backgroundColor: '#092032'}}>
                                    <span className={style.t_item1}>
                                        <span onClick={()=>{this.moreHeight(index)}}>{item.data.district_string}</span>
                                        {
                                            this.state.index === index ? <i className="iconfont" onClick={()=>{this.moreHeight(index)}}>&#xe603;</i>:<i onClick={()=>{this.moreHeight(index)}} className="iconfont">&#xe602;</i>
                                        }
                                    </span>
                                            {
                                                this.state.key.map((item1,index1)=>{
                                                    return(
                                                        <span className={style.t_item1} key={index1}>{item.data[item1] || '-'}</span>
                                                    )
                                                })
                                            }
                                        </div>
                                        {
											this.state.index === index ? <div style={{height: this.state.index === index ? this.getHeight(): 0}} className={style.table2}>
												{
													item.child.map((item2,index2)=>{
														return(
                                                            <div className={style.table1} key={index2}>
                                                    <span className={style.t_item2}>
                                                        <span>{item.child[index2]&&item.child[index2].data.district_string}</span>
                                                    </span>
																{
																	this.state.key.map((item3,index3)=>{
																		return(
                                                                            <span className={style.t_item1} key={index3}>{item.child[index2] && item.child[index2].data[item3] || '-'}</span>
																		);
																	})
																}
                                                            </div>
														)
													})
												}
                                            </div>:null
                                        }


                                    </div>
                                )
                            })
                        }
                    </div>

                </div>


                <Modal width={950} height={600} isOpen={this.state.isOpen} onClose={this.handleRodal}>
                    <div className={style.rodal}>
                        <div className={style.progress}>
                            <div className={style.line}>
                                <span className={style.p_item1}>
                                    <span className={style.num + " " + style.num_active}>1</span>
                                </span>
                                <span className={style.p_item2}>
                                    <span className={this.state.openIndex == 2 || this.state.openIndex == 3 ? style.num + " " + style.num_active : style.num}>2</span>
                                </span>
                                <span className={style.p_item3}>
                                    <span className={this.state.openIndex == 3 ? style.num + " " + style.num_active : style.num}>3</span>
                                </span>
                                <span className={style.p_text1 + " " + style.color}>请选择需要导出的地区</span>
                                <span className={this.state.openIndex == 2 || this.state.openIndex == 3 ? style.p_text2+ " " + style.color:style.p_text2}>请选择需要导出的名单类别</span>
                                <span className={this.state.openIndex == 3 ? style.p_text3+ " " + style.color : style.p_text3}>完成</span>
                            </div>
                        </div>
                        {
                            this.state.openIndex === 1 ? <div className={style.area}>
                                <div>
                                    <div className={style.cityname}>地区(市) ：</div>
                                    <div className={style.cityitem}>
                                        <p><div className={style.bbd + " " + style['text-overflow']}><span className={this.state.all ? style.fangk +" "+ style.f_active : style.fangk} onClick={this.handleAll}/><span>全选</span></div></p>
                                        <p className={style.p_font}>
                                            {
                                                this.state.area.map((item,index) => {
                                                    return(
                                                        <div className={style.bbd} key={index}>
                                                            <span className={this.state.areaData[item.name].length === 0 ? style.fangk : style.fangk +" "+ style.f_active} onClick={() =>{this.handleOne(item.name)}}/>
                                                            <span>{item.name}{
                                                                this.state.index1 === index ? <i onClick={()=>{this.downUp(index,item.name)}} className="iconfont" style={{cursor:'pointer'}}>&#xe614;</i>: <i style={{cursor:'pointer'}} className="iconfont" onClick={()=>{this.downUp(index,item.name)}}>&#xe613;</i>
                                                            }</span>
                                                        </div>
                                                    )
                                                })
                                            }
                                        </p>
                                    </div>
                                </div>
                                <div className={style.city} style={{display:this.state.show2 ? 'block': 'none'}}>
                                    <div className={style.cityname}><span style={{lineHeight:'37px'}}>地区(县) ：</span></div>
                                    <div className={style.cityitem}>
                                        <p className={style.p_font}>
                                            {
                                                this.state.area1.map((item,index) => {
                                                    return(
                                                        <div className={style.bbd + " " + style['text-overflow']} key={index}>
                                                            <span className={this.state.areaData[this.state.key1].indexOf(item) === -1 ? style.fangk : style.fangk +" "+ style.f_active} onClick={() =>{this.handleXian(item)}}/>
                                                            <span>{item}</span>
                                                        </div>
                                                    )
                                                })
                                            }
                                        </p>
                                    </div>
                                </div>
                                <div className={style.city}>
                                    <div className={style.cityname}><span style={{lineHeight:'37px'}}>已选(地区) ：</span></div>
                                    <div className={style.cityitem1}>
                                        {
                                            Object.keys(this.state.areaData).map((item,index) =>{
                                                return(
                                                    <p className={style.p_font1} key={index} style={{display:this.state.areaData[item].length > 0 ? 'block': 'none'}}>
                                                        <span className={style.p_ccc}>{item}:</span>
                                                        <span className={style.p_ccc1}>
                                                            {
                                                                this.state.areaData[item].map((item1,index1) =>{
                                                                    return(
                                                                        <span key={index1} className={style.f_item1 +" "+ style['text-overflow']}>{item1}</span>
                                                                    )
                                                                })
                                                            }
                                                        </span>
                                                    </p>
                                                )
                                            })
                                        }
                                    </div>
                                </div>
                                <div className={style.btnssss}>
                                    <button onClick={this.handleNext}>下一步</button>
                                </div>
                            </div> : this.state.openIndex === 2 ? <div className={style.second}>
                                <div className={style.tableList}>
                                    {
                                        this.state.table1.map((item, index) => {
                                            return(
                                                <div className={this.state.table2.indexOf(item) !== -1 ? style.list_item + " "+ style.list_active:style.list_item} key={index} onClick={() => {this.handleOne1(item)}}>
                                                    <span>{item}</span>
                                                    <div style={{display:this.state.table2.indexOf(item) !== -1 ? 'block' : 'none'}} className={style.icon1}/>
                                                </div>
                                            )
                                        })
                                    }
                                </div>
                                <div className={style.btnssss}>
                                    <button onClick={() => {this.handleIndex(1)}} style={{backgroundColor:'#a1a1a1'}}>上一步</button>
                                    <button onClick={this.handleConfirm}>确认导出</button>
                                </div>
                            </div> : <div className={style.second}>
                                <div className={style.tableList}>
                                    <span style={{color:'#11c8d6'}}>已完成导出！</span>
                                </div>
                                <div className={style.btnssss}>
                                    <button onClick={this.handleRodal}>关闭</button>
                                </div>
                            </div>
                        }
                    </div>
                </Modal>
        </section>
        )
    }
}
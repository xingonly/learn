import React, {Component} from "react";
import style from './style.scss';
import Select from '../../../components/Select1';
import resources from '../../../util/resource';
import TimeStorage from 'util/TimeStorage';

export default class App extends Component {
    constructor(props){
        super(props);
        this.state = {
            poorStatus: '请选择',
            xianName: '请选择',
            townName: '请选择',
            list:[],
            shi:[],
            xian:[],
            town:[],
            year: '时间'
        }
        this.params = {
            code: 520000000000
        }
    }
    componentDidMount(){
        let regions = new TimeStorage();
        this.regions = regions.getItem('location');
        this.getData();
        this.getCode(0);
    }

    getData = () => {
        resources.post('/welfare-accurateidentification/app/statistics_area_list',{
            "district_code": this.params.code,
            "year": "2017"
        }).then(res => {
            if(res.status === 200){
                this.setState({
                    list:res.data
                })
            }
        })
    }

    getCode = (index) => {
        resources.get(`/xixiu-server/region/getRegionByParentid/${this.params.code}`).then(res => {
            if(res.status === 200){
                if(index === 0){
                    let option = {'name':'全省','id':520000000000};
                    res.data.unshift(option);
                    this.setState({
                        shi:res.data,
                        xian: [],
                        town: []
                    })
                }else if(index === 1){
                    this.setState({
                        xian:res.data,
                        town: []
                    })
                }else {
                    this.setState({
                        town:res.data
                    })
                }
            }
        })
    }

    handlePoor = (obj, name) => {
        this.params.code= obj.id;
        this.setState({
            poorStatus: obj.name,
            xianName: '请选择',
            townName: '请选择',
            xian: [],
            town: []
        },() => {
            if(obj.name === '全省'){
                return;
            }
            this.getCode(1)
        })
    }
    handlexian = (obj, name) => {
        this.params.code= obj.id;
        this.setState({
            xianName: obj.name,
            townName: '请选择',
            town: []
        },() => {
            this.getCode(2)
        })
    }
    handleTow = ( obj, name) => {
        this.params.code= obj.id;
        this.setState({
            townName: obj.name
        })
    }
    handleYear = (obj, name) => {
        this.setState({
            year: obj.name
        })
    }

    handleName = (code) => {
        const match = this.regions.find((item) => item.id == code);
        if(match)
        {
            return match.name;
        }else{
            return '--';
        }
    }

    render() {
        return (
            <section id={style['Count']}>
                <ul className={style.ul}>
                    <li onClick={()=>{this.props.onChange(1)}}>基本情况-贫困状况</li>
                    <li onClick={()=>{this.props.onChange(2)}} >第三方数据清洗</li>
                    <li className={style.active}>精准统计</li>
                </ul>
                <div className={style.searchItem}>
                    <Select
                        value={this.state.poorStatus}
                        options={this.state.shi}
                        handleClick={this.handlePoor}/>
                    <Select
                        value={this.state.xianName}
                        options={this.state.xian}
                        handleClick={this.handlexian}/>
                    <Select
                        value={this.state.townName}
                        options={this.state.town}
                        handleClick={this.handleTow}/>
                   {/* <Select
                        value={this.state.year}
                        options={[{id:'2017', name:2017},{id:'2016', name:'2016'}]}
                        handleClick={this.handleYear}/>*/}
                    <div className={style.searchBtn + ' ' + "iconfont"} onClick={this.getData}>&#xe6d1;</div>
                </div>
                <div className={style.out}>
                    <span className={style.down} onClick={this.handleOut} style={{display:'none'}}>
                        <span>导出</span>
                        <i className={"iconfont"+' '+style.icon}>&#xe63d;</i>
                    </span>
                </div>
                <div className={style.table+ ' '+ style.scrollTable}>
                    <p>当前指标</p>
                    <table>
                        <thead>
                            <tr className={style.thead}>
                                <th>区域</th>
                                <th>贫困识别精准(%)</th>
                                <th>人均年收入达标(%)</th>
                                <th>人均年收入(元)</th>
                                <th>产业扶贫效益(%)</th>
                                <th>种植业</th>
                                <th>养殖业</th>
                                <th>农产品加工</th>
                                <th>农产品流通</th>
                                <th>其他产业</th>
                            </tr>
                        </thead>
                        <tbody id={style['tbody']}>
                        {
                            this.state.list.map((item,index) => {
                                return(
                                    <tr className={style.tbody} key={index}>
                                        <td>{item && this.handleName(item.district_code)}</td>
                                        <td>{item.poor_rate || '--'}</td>
                                        <td>{item.income_rate || '--'}</td>
                                        <td>{item.percapita_net_income || '--'}</td>
                                        <td>{item.cyfp_rate || '--'}</td>
                                        <td>--</td>
                                        <td>--</td>
                                        <td>--</td>
                                        <td>--</td>
                                        <td>--</td>
                                    </tr>
                                )
                            })
                        }
                        </tbody>
                    </table>
                </div>
            </section>
        )
    }
}
import React, {Component} from 'react';
import Poor from './PoorStatus';
import Third from './ThirdParty';
import Count from './Count';

export default class DataCharts extends Component {

    constructor(props) {
        super(props);
        this.state = {
            show : 1
        }
    }

    handleShow = (index) => {
        this.setState({
            show:index
        })
    };


    render() {

        return (
            <section style={{height:'47.5rem'}}>
                {
                    this.state.show === 1 ? <Poor onChange={this.handleShow}/> : this.state.show === 2 ?
                        <Third onChange={this.handleShow}/>: <Count onChange={this.handleShow}/>

                }
            </section>
        )
    }
}
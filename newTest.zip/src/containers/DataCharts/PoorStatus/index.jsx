import React, {Component} from 'react'
import style from "./style.scss"
import Search from "./images/search.gif"
import Export from "./images/export.gif"
import Pagination from "../../../components/Pagination"
import resource from "../../../util/resource"
import Datetime from 'react-datetime'
import Notice from '../../../components/Notice'
import moment from 'moment'
export default class PoorStatus extends Component {
    constructor(props) {
        super(props);
        this.currentTime = moment().format('YYYY');
        this.state={
            regionCode:"",
            arr1:"",
            arr2:"",
            currentData:"",
            current:0,
            nowData: this.currentTime + '-01',
            total:-1,
            infoData:"",
            stateShow:true
        };
        this.params={
            token:""
        };
        this.region = JSON.parse(sessionStorage.getItem('manager'));
    }
    toGray = (value,domName) => {
        let Dom = document.getElementById(domName)
        let option = Dom.querySelectorAll("option")
        let len = option.length;
        for(var i=0;i<len;i++){
            if(option[i].value==value){
                option[i].selected=true;
            }else{
                option[i].disabled="disabled";
            }
        }

    }
    onChange = (a,b) =>{
        let state = this.state;
        state.current = a;
        if(this.state.stateShow){
            this.handleData(a - 1 ,b,this.state.nowData,this.state.currentData)
        }else{
            this.handleData(a - 1,b,this.state.nowData,this.state.regionCode)
        }
        this.setState(state);

    }
    handleDownload = () => {
        resource.get(`/xixiu-server/reportForm/getTokenAk?region=${this.state.currentData}`).then((res) => {
            if (res.status === 200){
                this.params.token = res.data;
            }
        });

    };
    time = () => {
        this.timer = setInterval(this.handleDownload, 50000);
    };

    getRegionCode = () => {
        resource.get( `/xixiu-server/region/getTopRegion` ).then( ( res ) =>{
            if(res.message){
                this.setState({
                    regionCode: res.data[0].id
                },()=>{
                    this.getInitAreaData(this.state.regionCode);
                    this.handleData(0,15,this.state.nowData,this.state.regionCode)
                });
            }
        });
    }
    componentDidMount(){
        //this.toGray("guigui","ProValue")
        this.getRegionCode();
        this.handleDownload();
        this.time();
    }
    componentDidUpdate (prevProps, prevState){
        if(this.region.shi!==null&&prevState.arr1!==""&&prevState.arr2===""){
            this.toGray(this.region.shi,"ProValue");
            this.getInitAreaData(this.region.shi)
        }
        if(this.region.xian!==null&&prevState.arr1!==""&&prevState.arr2!==""){
            this.toGray(this.region.xian,"XainValue");
        }
    }
    handleData = (a,b,c,d) => {
        resource.get(`/xixiu-server/reportForm/getPageReportForm/?page=${a}&size=${b}&date=${c}&region=${d}`).then((res) => {
            if(res.status === 200){
                this.setState({
                    infoData: res.data.content,
                    total:res.data.totalElements
                })
            }
        })
    };
    componentWillUnmount() {
        clearInterval(this.timer);
    }
    getInitAreaData = (a) => {
        resource.get( `/xixiu-server/region/getRegionByParentid/${a}` ).then( ( res ) =>{
            if(res.message==="success"){
                if(this.state.arr1===""){
                    this.setState({
                        arr1:res.data,
                    })
                }else{
                    this.setState({
                        arr2:res.data,
                    })
                }
            }
            else{
                Notice.error(res.message)
            }
        });
    }
    handleShow = (index) => {
        if(this.props.onChange){
            this.props.onChange(index)
        }
    }
    GetDetail = (e)=> {
        if(e.target.value==="全部"){
            this.setState({
                currentData:"",
                arr2:""
            })
            return
        }
        this.setState({
            currentData:e.target.value
        })
        this.getInitAreaData(e.target.value)
    }
    GetDetail2= (e)=> {
        if(e.target.value==="全部"){
            this.setState({
                currentData:this.refs.ProValue.value
             })
            return
        }
        this.setState({
            currentData:e.target.value
        })
    }
    Download = () => {
        let region = parseInt(this.state.currentData ? this.state.currentData : this.state.regionCode);
        let year = moment(this.state.nowData).format("YYYY");
        window.open(`/xixiu-server/reportForm/download/${this.params.token}?year=${year}&region=${region}`);
    };
    GetDataTime = (a) => {
        let Data=new Date(a._d)
        let year=Data.getFullYear()+"-01";
        this.setState({
            nowData:year
        })
    }
    handleSearch = () => {
        this.setState({
            stateShow:true,
        })
        this.handleData(0,15,this.state.nowData,this.state.currentData)
    }
    render() {
        let nowDate = Datetime.moment();
        let valid = function( current ){
            return current.isBefore(nowDate );
        };
        this.arr4=["区域","总人口数","贫困人口数","贫困户数","贫困发生率","农民人均纯收入","一般贫困户","低保户","五保户","低保贫困户","五保贫困户","一般农户","因病","因残","因学","因灾","缺土地","缺水","缺劳力","缺技术","缺资金","交通条件落后","自身发展","中共党员","劳动力人数","外出务工人数","财政收入","耕地面积","林地面积","退耕还林面积","未实现饮水数","饮水困难户数","参加新型","参加城镇","参加城乡","危房户数","到乡镇是路","是否通客运班车","已通生产用数","卫生数个数","公共卫生个数","垃圾集中点个数","通宽带户数","能用手机的户数"];
        return (
            <section className={style.Box}>
                <div className={style.heaader}>
                    <div className={style.Nav}>
                        <ul>
                            <li>基本情况-贫困状况</li>
                            <li onClick={()=>{this.handleShow(2)}}>第三方数据清洗</li>
                            <li onClick={()=>{this.handleShow(3)}}>精准统计</li>
                        </ul>
                    </div>
                    <div className={style.Search}>
                        <ul ref="SearchData">
                            <li>
                                <select onChange={this.GetDetail} data-key="ProValue" ref="ProValue" id="ProValue">
                                    <option value="全部">全部</option>
                                    {
                                        this.state.arr1!==""?this.state.arr1.map((obj,index) => {
                                            return(
                                                <option key={index} value={obj.id}>{obj.name}</option>
                                            )
                                        }):""
                                    }
                                </select>
                            </li>
                            <li>
                                <select onChange={this.GetDetail2} data-key="XainValue" id="XainValue">
                                    <option value="全部">全部</option>
                                    {
                                        this.state.arr2!==""?this.state.arr2.map((obj,index) => {
                                            return(
                                                <option key={index} value={obj.id}>{obj.name}</option>
                                            )
                                        }):""
                                    }
                                </select>
                            </li>
                            <li>
                                <Datetime dateFormat="YYYY" timeFormat={false} locale="zh_CN" closeOnSelect={true} isValidDate={valid}  inputProps={{'readOnly':true,'defaultValue':'时间起点'}} onChange={this.GetDataTime} defaultValue={this.currentTime}></Datetime>
                            </li>
                        </ul>
                        <div className={style.Img}><img src={Search} onClick={this.handleSearch}/></div>
                    </div>
                </div>
                <div className={style.Export}><button onClick={this.Download}>导出<img src={Export}/></button></div>
                <div className={style.main}>
                    <div className={style.content}>
                        <h6>当前指标</h6>
                        <div className={style.table}>
                            <table>
                                <thead>
                                <tr>
                                    {
                                        this.arr4.map((obj,index) => {
                                            return(
                                                <td key={index}>{obj}</td>
                                            )
                                        })
                                    }
                                </tr>
                                </thead>
                                <tbody>
                                {
                                    this.state.infoData!== "" && this.state.infoData.length > 0  ? this.state.infoData.map((obj,index)=>{
                                        return(
                                            <tr key={index}>
                                                <td key={Math.random()+1}>{obj.regionName||"-"}</td>
                                                <td key={Math.random()+2}>{"-"}</td>
                                                <td key={Math.random()+3}>{obj.population||"-"}</td>
                                                <td key={Math.random()+4}>{obj.hu||"-"}</td>
                                                <td key={Math.random()+5}>{"-"}</td>
                                                <td key={Math.random()+6}>{obj.percapitaNetIncome||"-"}</td>
                                                <td key={Math.random()+7}>{obj.sumPovertyAttribute01||"-"}</td>
                                                <td key={Math.random()+8}>-</td>
                                                <td key={Math.random()+9}>-</td>
                                                <td key={Math.random()+10}>{obj.sumPovertyAttribute04||"-"}</td>
                                                <td key={Math.random()+11}>{obj.sumPovertyAttribute06||"-"}</td>
                                                <td key={Math.random()+12}>{obj.sumPovertyAttribute05||"-"}</td>
                                                <td key={Math.random()+13}>{obj.sumMainPoorCauses01||"-"}</td>
                                                <td key={Math.random()+14}>{obj.sumMainPoorCauses02||"-"}</td>
                                                <td key={Math.random()+15}>{obj.sumMainPoorCauses03||"-"}</td>
                                                <td key={Math.random()+16}>{obj.sumMainPoorCauses04||"-"}</td>
                                                <td key={Math.random()+17}>{obj.sumMainPoorCauses05||"-"}</td>
                                                <td key={Math.random()+18}>{obj.sumMainPoorCauses06||"-"}</td>
                                                <td key={Math.random()+19}>{obj.sumMainPoorCauses08||"-"}</td>
                                                <td key={Math.random()+20}>{obj.sumMainPoorCauses07||"-"}</td>
                                                <td key={Math.random()+21}>{obj.sumMainPoorCauses09||"-"}</td>
                                                <td key={Math.random()+22}>{obj.sumMainPoorCauses10||"-"}</td>
                                                <td key={Math.random()+23}>{obj.sumMainPoorCauses11||"-"}</td>
                                                <td key={Math.random()+24}>{obj.partyMember||"-"}</td>
                                                <td key={Math.random()+25}>{obj.laborNum||"-"}</td>
                                                <td key={Math.random()+26}>{obj.outWork||"-"}</td>
                                                <td key={Math.random()+27}>-</td>
                                                <td key={Math.random()+28}>{obj.cultivatedArea||"-"}</td>
                                                <td key={Math.random()+29}>{obj.woodlandArea||"-"}</td>
                                                <td key={Math.random()+30}>{obj.returnForestArea||"-"}</td>
                                                <td key={Math.random()+31}>-</td>
                                                <td key={Math.random()+32}>{obj.drinkingWaterDifficult||"-"}</td>
                                                <td key={Math.random()+33}>-</td>
                                                <td key={Math.random()+34}>{obj.medicalSecurity||"-"}</td>
                                                <td key={Math.random()+35}>{obj.residentPension||"-"}</td>
                                                <td key={Math.random()+36}>{obj.dangerousHouse||"-"}</td>
                                                <td key={Math.random()+37}>-</td>
                                                <td key={Math.random()+38}>-</td>
                                                <td key={Math.random()+39}>-</td>
                                                <td key={Math.random()+40}>-</td>
                                                <td key={Math.random()+41}>-</td>
                                                <td key={Math.random()+42}>-</td>
                                                <td key={Math.random()+43}>-</td>
                                                <td key={Math.random()+44}>-</td>
                                            </tr>
                                        )
                                    }):<tr>
                                        <td style={{minHeight:'400px',lineHeight:'400px',textAlign:'center'}} colSpan={20}>暂无数据</td>
                                    </tr>
                                }
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div className={style.Pagination}>
                        {
                            this.state.total >15 ?
                                <Pagination
                                    total={this.state.total!==-1?this.state.total:-1}
                                    start={1}
                                    current={this.state.current}
                                    onChange={this.onChange}
                                    size={15}
                                />:""
                        }
                    </div>
                </div>
            </section>
        )
    }
}
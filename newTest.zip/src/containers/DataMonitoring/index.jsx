// 上帝保佑,永无bug

import React, {Component} from "react"
import style from './style.scss'
import Card from '../../components/Card'
import Table from '../../components/Table'
import Filter from './subPage/Filter.jsx'
import createHistory from 'history/createHashHistory'
import object from './images/object.png'
const history = createHistory()
import echarts from 'echarts'
import resource from '../../util/resource'

export default class DataMonitoring extends Component {

    state = {
        openModal: '',
        monitoringDataSource: [],
        warningDataSource: [],
        monitoringLoading: true,
        warningLoading: true,
        chartData: [],
        index: 0,
        show: false,
        sIndex: -1,
        left:0,
        top:0,
        text:'',
        ting:[],
        sData:0
    }

    onCheckDetail = (item) => {
      let obj = {
        inputValue: item.idnumber,
        region: {
          shi: '',
          xian: '',
          xiang: '',
          zheng: ''
        }
      };

      sessionStorage.setItem('keyWord',JSON.stringify(obj));
      sessionStorage.setItem('fromTo','DataMonitor-'+item.department);
      history.push('/main/object/objectSearch');
    }

    copyObj = (obj) => {
      if(typeof obj !== 'object' || obj === null)
      {
        return obj;
      }
      let result = obj instanceof Array ? [] : {};
      for(let key in obj)
      {
        result[key] = this.copyObj(obj[key]);
      }

      return result;
    }

    initEcharts = (target) => {
        if(!target)
        {
            return;
        }

        var option = {
            color: ['#11d0df'],
            tooltip : {
                trigger: 'axis',
                axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                    type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                }
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis : [
                {
                    type: 'category',
                    data: (() => {
                        let list = [];
                        if(this.state.chartData.length)
                        {
                            list = this.copyObj(this.state.chartData);
                        }
                        for(let i = 0;i < list.length;i++)
                        {
                            if(list[i].department === '总量')
                            {
                                list.splice(i,1);
                                break;
                            }
                        }
                        return list.map((item,index) => {
                            return item.department
                        });
                    })(),
                    axisTick: {
                        alignWithLabel: true
                    },
                    axisLine: {
                        lineStyle: {
                            color: '#363b50',
                            shadowBlur: 2,
                            shadowColor: 'rgba(54,59,80,0.5)',
                            width: 2
                        }
                    },
                    axisLabel: {
                        textStyle: {
                            color: '#fff'
                        }
                    }
                }
            ],
            yAxis : [
                {
                    type : 'value',
                    axisLine: {
                        lineStyle: {
                            color: '#363b50',
                            width: 2
                        }
                    },
                    axisTick: {
                        show: false
                    },
                    axisLabel: {
                        textStyle: {
                            color: '#fff'
                        }
                    },
                    splitLine: {
                        lineStyle: {
                            color: '#363b50',
                            width: 2
                        }
                    }
                }
            ],
            series : [
                {
                    name:'交换数据：',
                    type:'bar',
                    barWidth: 25,
                    data: (() => {
                        let list = [];
                        if(this.state.chartData.length)
                        {
                            list = this.copyObj(this.state.chartData);
                        }
                        for(let i = 0;i < list.length;i++)
                        {
                            if(list[i].department === '总量')
                            {
                                list.splice(i,1);
                                break;
                            }
                        }
                        return list.map((item,index) => {
                            return item.exchange
                        });
                    })(),
                    itemStyle: {
                        normal: {

                        },
                        emphasis: {

                        }
                    }
                }
            ]
        };

        if(!this.echarts)
        {
            this.echarts = echarts.init(target);
        }
        this.echarts.setOption(option);
    }

    handleDataOpen = () => {
        history.push('/main/dataAnalysis/monitoring');
    }

    handleWarningOpen = () => {
        history.push('/main/dataAnalysis/warning');
    }

    initMonitoringData = () => {
        var s = {...this.state};
        s.monitoringLoading = true;
        this.setState(s);
        resource.get('/pww/exchange/v0.1/monitoring' + '?page=1&size=9').then((res) => {
            var state = {...this.state};
            state.monitoringDataSource = res.data.content;
            state.monitoringLoading = false;
            this.setState(state);
        });
    }

    initWarningData = (deptCode) => {
        var s = {...this.state};
        s.warningLoading = true;
        this.setState(s);
        resource.post('/xixiu-server/dataComparison/getPageDifferent',{
            page: 1,
            size: 7,
            deptCode: deptCode
        }).then((res) => {
            var state = {...this.state};
            if(res.data)
            {
                state.warningDataSource = res.data.content;
            }else{
                state.warningDataSource = [];
            }
            state.warningLoading = false;
            this.setState(state);
        });
    }

    filterChange = (item) => {
        this.initWarningData(item.key);
    }

    onResize = () => {
        if(this.echarts)
        {
            this.echarts.resize();
        }
    }

    initData = () => {
        resource.get('/xixiu-server/exchangeData/getCountByDepartment').then((res) => {
            var total = {
                name: '总量',
                department: '总量',
                exchange: 0
            };
            var state = {...this.state};
            for(let i = 0;i < res.data.length;i++)
            {
                total.exchange = total.exchange + res.data[i].exchange;
            }
            state.chartData = res.data;
            state.chartData.unshift(total);
            this.setState(state);
            this.initEcharts(this.refs.bar);
        });
    }

    componentDidMount () {
        window.addEventListener('resize',this.onResize);
        this.initMonitoringData();
        this.initWarningData();
        this.initData();
        this.initEcharts(this.refs.bar);
        this.getData();
    }

    componentWillUnmount () {
        window.removeEventListener('resize',this.onResize);
        if(this.echarts)
        {
            this.echarts.dispose();
        }
    }

    getData = () => {
        resource.get('/xixiu-server/exchangeData/getCountByDepartment').then(res => {
            if(res.status === 200){
                this.setState({
                    ting: res.data,
                })
            }
        })
    }
    handleIndex = (index,left,top,text,name) => {
        let data;
        for(let i = 0;i < this.state.ting.length;i++){
            if(this.state.ting[i].name === name){
                data= this.state.ting[i].exchange
            }
        }
        this.setState({
            sIndex: index,
            show:true,
            left:left,
            top:top,
            text:text,
            sData: data
        })
    }
    handleIndex1 = () => {
        this.setState({
            sIndex: -1,
            show:false
        })
    }

    render() {

        const columns1 = [
            {
                label: '部门',
                key: 'department'
            },
            {
                label: '数据项目',
                key: 'data_type',
                limit: 10
            },
            {
                label: '数据大小',
                key: 'data_count'
            },
            {
                label: '交易时间',
                key: 'exchange_time',
                filter: (item) => {
                    if(!item.exchange_time)
                    {
                        return '-';
                    }else{
                        var time = new Date(item.exchange_time);
                        return time.getFullYear() + '年' + (time.getMonth() + 1) + '月' + time.getDate() + '日 ' + (time.getHours() < 10 ? ('0' + time.getHours()) : time.getHours()) + ':' + (time.getMinutes() < 10 ? ('0' + time.getMinutes()) : time.getMinutes()) + ':' + (time.getSeconds() < 10 ? ('0' + time.getSeconds()) : time.getSeconds());
                    }
                }
            },
            {
                label: '状态',
                key: 'data_status'
            }
        ];

        return (
            <div className={style.container}>
                {
                    this.props.match.isExact ? (
                        <div className={style.normal}>
                            <div className={style.left}>
                                <div className={style.map}>
                                    <div className={style.m_t1}>贵州省扶贫办</div>
                                    <div className={style.m_t2}>{this.state.ting.length!==0?this.state.ting[7].exchange:0}条</div>
                                    <div className={style.m_t3}>建档立卡数据</div>
                                    <div className={style.m_box1} onMouseOver={()=> {this.handleIndex(0, '30%', '56%','万企帮万村','工商联')}} onMouseOut={this.handleIndex1}>工商联</div>
                                    <div className={style.m_box2} onMouseOver={()=> {this.handleIndex(1,'15%','51%','高考录取信息','招生办')}} onMouseOut={this.handleIndex1}>招生办</div>
                                    <div className={style.m_box3} onMouseOver={()=> {this.handleIndex(2,'5%','46%','房屋类不动产信息、房屋照片','国土')}} onMouseOut={this.handleIndex1}>国土厅</div>
                                    <div className={style.m_box4} onMouseOver={()=> {this.handleIndex(3,'0%','37%','企业法人、农民专业合作社','工商')}} onMouseOut={this.handleIndex1}>工商局</div>
                                    <div className={style.m_box5} onMouseOver={()=> {this.handleIndex(4,'5%','16%','养老保险、医疗保险','人社')}} onMouseOut={this.handleIndex1}>人社厅</div>
                                    <div className={style.m_box6} onMouseOver={()=> {this.handleIndex(5,'15%','9%','商品房备案等级、危房改造','建设')}} onMouseOut={this.handleIndex1}>住建厅</div>
                                    <div className={style.m_box7} onMouseOver={()=> {this.handleIndex(6,'26%','7%','安全饮水项目','水利')}} onMouseOut={this.handleIndex1}>水利厅</div>
                                    <div className={style.m_box8} onMouseOver={()=> {this.handleIndex(7,'58%','7%','参加新农合、患有重大疾病','卫计委')}} onMouseOut={this.handleIndex1}>卫计委</div>
                                    <div className={style.m_box9} onMouseOver={()=> {this.handleIndex(8,'80%','12%','户籍信息、机动车注册、驾驶证','公安')}} onMouseOut={this.handleIndex1}>公安厅</div>
                                    <div className={style.m_box10} onMouseOver={()=> {this.handleIndex(9,'80%','34%','异地扶贫搬迁','移民')}} onMouseOut={this.handleIndex1}>移民局</div>
                                    <div className={style.m_box11} onMouseOver={()=> {this.handleIndex(10,'81%','47%','两助三免补助信息','教育')}} onMouseOut={this.handleIndex1}>教育厅</div>
                                    <div className={style.m_box12} onMouseOver={()=> {this.handleIndex(11,'70%','55%','低保、优抚对象、孤儿','民政')}} onMouseOut={this.handleIndex1}>民政厅</div>
                                    <div style={{display:this.state.show ? 'block' : 'none',left:this.state.left,top:this.state.top}} className={style.data}>
                                        <p>{this.state.sData}条</p>
                                        <p>{this.state.text}</p>
                                    </div>
                                </div>
                            </div>
                            <div className={style.right}>
                                <div className={style.monitoring}>
                                    <Card title="数据交换实时监控" tool handleOpen={this.handleDataOpen}>
                                        <Table columns={columns1} dataSource={this.state.monitoringDataSource} loading={this.state.monitoringLoading} autoScroll={{
                                            height: '17.57rem',
                                            speed: 20
                                            }}/>
                                    </Card>
                                </div>
                                <div className={style.warningContainer}>
                                    <Card title="业务量监控">
                                        <div className={style.left_content}>
                                            <div ref='bar' id='data_monitoring_echarts' style={{width: '100%', height: '19rem'}}></div>
                                        </div>
                                    </Card>
                                </div>
                            </div>
                        </div>
                    ) : this.props.children
                }
            </div>
        )
    }
}

// 上帝保佑,永无bug

import React, {Component} from "react"
import style from './dataMonitoringOpen.scss'
import Card from '../../../components/Card'
import Table from '../../../components/Table'
import Filter from './Filter'
import Select from './Select'
import createHistory from 'history/createHashHistory'
const history = createHistory()
import resource from '../../../util/resource'

export default class DataMonitoringOpen extends Component {

    state = {
        openModal: '',
        monitoringDataSource: [],
        pageable: {
            start: 1,
            total: 0
        },
        loading: true
    }

    filter = ''

    handleClose = () => {
        history.push('/main/dataAnalysis/data_monitoring');
    }

    onFilterChange = (item) => {
        this.filter = item.key;
        this.initMonitoringData(1,17,item.key);
    }

    initMonitoringData = (page,size,deptCode) => {
        var s = {...this.state};
        s.loading = true;
        this.setState(s);
        resource.get('/pww/exchange/v0.1/monitoring' + '?page=' + (page ? page : 1) + '&size=' + (size ? size : 17) + (deptCode ? ('&deptCode=' + deptCode) : '')).then((res) => {
            var state = {...this.state};
            state.monitoringDataSource = res.data.content;
            state.pageable.total = res.data.total;
            state.pageable.size = res.data.size;
            state.loading = false;
            this.setState(state);
        });
    }

    changePage = (page,size) => {
        this.initMonitoringData(page,size,this.filter);
    }

    componentDidMount () {
        this.initMonitoringData();
    }

    render() {

        const columns1 = [
            {
                label: '部门',
                key: 'department'
            },
            {
                label: '数据项目',
                key: 'data_type'
            },
            {
                label: '数据大小',
                key: 'data_count'
            },
            {
                label: '交易时间',
                key: 'exchange_time',
                filter: (item) => {
                    if(!item.exchange_time)
                    {
                        return '-';
                    }else{
                        var time = new Date(item.exchange_time);
                        return time.getFullYear() + '年' + (time.getMonth() + 1) + '月' + time.getDate() + '日 ' + (time.getHours() < 10 ? ('0' + time.getHours()) : time.getHours()) + ':' + (time.getMinutes() < 10 ? ('0' + time.getMinutes()) : time.getMinutes()) + ':' + (time.getSeconds() < 10 ? ('0' + time.getSeconds()) : time.getSeconds());
                    }
                }
            },
            {
                label: '状态',
                key: 'data_status'
            }
        ];

        const list = [
            {
                key: '',
                text: '全部'
            },
            {
                text: '扶贫办',
                key: 'fupin'
            },
            {
                text: '公安',
                key: 'gongan'
            },
            {
                text: '工商',
                key: 'gongshang'
            },
            {
                text: '卫计',
                key: 'weiji'
            },
            {
                text: '移民',
                key: 'yimin'
            },
            {
                text: '民政',
                key: 'minzheng'
            },
            {
                text: '教育',
                key: 'jiaoyu'
            },
            {
                text: '人社',
                key: 'renshe'
            },
            {
                text: '住建',
                key: 'jianshe'
            },
            {
                text: '水利',
                key: 'shuili'
            },
            {
                text: '国土',
                key: 'guotu'
            },
            {
                text: '工商联',
                key: 'gonglian'
            }
        ];

        return (
            <div className={style.container}>
                <Card title="数据交换实时监控" tool open handleClose={this.handleClose} subTitle={
                        <div className={style.tools}>
                            <div className={style.filter}>
                                <Filter list={list} onChange={this.onFilterChange}/>
                            </div>
                        </div>
                    }>
                    <Table columns={columns1} dataSource={this.state.monitoringDataSource} onChange={this.changePage} loading={this.state.loading} autoScroll={{
                        height: '39rem',
                        speed: 20
                        }}/>
                </Card>
            </div>
        )
    }
}

// 上帝保佑,永无bug

import React, {Component} from "react"
import style from './filter.scss'

export default class Filter extends Component {

    state = {

    }

    prev = () => {
        var dom = this.refs.wrap;
        dom.scrollLeft = (dom.scrollLeft - 80) < 0 ? 0 : (dom.scrollLeft - 80);
    }

    next = () => {
        var dom = this.refs.wrap;
        dom.scrollLeft += 80;
    }

    click = (item,e) => {
        var reg = new RegExp('(' + style.active + ')','g');
        var parent = e.target.parentElement;
        for(let i = 0;i < parent.children.length;i++)
        {
            parent.children[i].className = parent.children[i].className.replace(reg,'');
        }

        e.target.className = style.active;

        if(this.props.onChange)
        {
            this.props.onChange(item);
        }
    }

    render() {

        return (
            <div className={style.container}>
                {
                    this.props.wrap ? (
                        <img src={require('../images/filter_arrow_left.png')} style={{marginRight: '13px'}} onClick={this.prev}/>
                    ) : ''
                }
                <div className={style.wrap} ref='wrap'>
                    <ul>
                        {
                            (this.props.list instanceof Array) ? this.props.list.map((item,index) => {
                                return (
                                    <li key={index} className={index === 0 ? style.active : ''} value={item.key} onClick={this.click.bind(this,item)}>{item.text ? item.text : item.key}</li>
                                )
                            }) : ''
                        }
                    </ul>
                </div>
                {
                    this.props.wrap ? (
                        <img src={require('../images/filter_arrow_right.png')} style={{marginLeft: '13px'}} onClick={this.next}/>
                    ) : ''
                }
            </div>
        )
    }
}

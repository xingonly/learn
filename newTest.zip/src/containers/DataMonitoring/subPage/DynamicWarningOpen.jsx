// 上帝保佑,永无bug

import React, {Component} from "react"
import style from './dynamicWarningOpen.scss'
import Card from '../../../components/Card'
import Table from '../../../components/Table'
import Filter from './Filter.jsx'
import Select from './Select.jsx'
import createHistory from 'history/createHashHistory'
const history = createHistory()
import resource from '../../../util/resource'

export default class DynamicWarningOpen extends Component {

    constructor (props) {
        super(props);
        var manager = JSON.parse(sessionStorage.getItem('manager'));

        this.scope1 = {
          scope: manager.scope,
          district: manager.shi
        };

        this.scope2 = {
          scope: manager.scope,
          district: manager.xian
        };

        this.scope3 = {
          scope: manager.scope,
          district: manager.xiang
        };

        this.scope4 = {
          scope: manager.scope,
          district: manager.cun
        };
    }

    state = {
        openModal: '',
        warningDataSource: [],
        pageable: {
            start: 1,
            size: 17,
            total: 0,
            current: 1
        },
        loading: true,
        total: 0,
        cityList: [],
        countyList: [],
        countryList: [],
        villageList: [],
        warningTypeList: [{
            id: '',
            name: '全部'
        }],
        selectItem: {
          diffs: {value: ''},
          status: {value: ''}
        },
        columns: [
            {
                label: '姓名',
                key: 'full_name'
            },
            {
                label: '身份证',
                key: 'idnumber'
            },
            {
                label: '部门',
                key: 'department_name'
            },
            {
                label: '异常情况',
                key: 'diffs',
                filter: (item) => {
                    if(item.diffs && item.field_name && item.diffs.length > 0)
                    {
                        var result = '';
                        for(let i = 0;i < item.diffs.length;i++)
                        {
                            if(!item.field_name[item.diffs[i]])
                            {
                                continue;
                            }
                            if(i < item.diffs.length - 1)
                            {
                                result = result + item.field_name[item.diffs[i]] + '/';
                            }else{
                                result = result + item.field_name[item.diffs[i]];
                            }
                        }

                        if(result)
                        {
                            if(result.length > 18)
                            {
                                return (
                                    <div title={result}>
                                        {result.substr(0,18) + '...'}
                                    </div>
                                );
                            }else{
                                return result;
                            }
                        }else{
                            return '-';
                        }
                    }else{
                        return '-';
                    }
                }
            },
            {
              label: '贫困状态',
              key: 'status',
              filter: (item) => {
                const value = item.status;
                if(!value)
                {
                  return '-';
                }

                if(value == '0')
                {
                  return '未脱贫';
                }

                if(value == '1')
                {
                  return '已脱贫';
                }

                if(value == '3')
                {
                  return '返贫';
                }
              }
            },
            {
                filter: (item) => {
                    return (
                        <div>
                            <a style={{color: '#fab943'}} onClick={this.onCheckDetail.bind(this,item)}>查看详情 > ></a>
                        </div>
                    );
                }
            }
        ]
    }

    handleClose = () => {
        history.push('/main/dataAnalysis/data_monitoring');
    }

    initWarningData = (page,size,deptCode,districtCode) => {
        var s = {...this.state};
        s.loading = true;
        this.setState(s);
        resource.post('/xixiu-server/dataComparison/getPageDifferent',{
            page: page ? page : 1,
            size: size ? size : 17,
            deptCode: deptCode,
            districtCode: districtCode,
            diffs: s.selectItem.diffs && s.selectItem.diffs.value,
            status: s.selectItem.status && s.selectItem.status.value
        }).then((res) => {
            var state = {...this.state};
            state.warningDataSource = res.data.content;
            state.pageable.total = res.data.totalElements;
            state.pageable.current = page ? page : 1;
            state.loading = false;
            state.total = res.data.totalElements;
            this.setState(state);
        });
    }

    resetSelect = () => {
      var state = {...this.state};
      state.selectItem = {
        diffs: {value: ''},
        status: {value: ''}
      };
      this.setState(state);
    }

    initWarningTypeList = (type) => {
      this.resetSelect();
        resource.get('/pww/statistics/v0.1/range?type=diffs' + (type ? ('&deptCode=' + type) : '')).then((res) => {
            var state = {...this.state};
            if(res.data.content.diffs)
            {
                res.data.content.diffs.unshift({
                    value: '',
                    display: '全部'
                });
                state.columns[3].selectList = type ? res.data.content.diffs : '';
                this.setState(state);
            }else{
                state.columns[3].selectList = '';
                this.setState(state);
            }
        });
    }

    onHeaderSelect = (item) => {
      this.setState({
        selectItem: item
      }, () => {
        this.initWarningData(1,17,this.filter,this.districtCode);
      });
    }

    onFilterChange = (item) => {
        this.filter = item.key;
        this.initWarningData(1,17,this.filter,this.districtCode);
        this.initWarningTypeList(item.key);
    }

    changePage = (page,size) => {
        this.initWarningData(page,size,this.filter,this.districtCode,this.state.selectItem);
    }

    initCity = () => {
        resource.get('/xixiu-server/region/getRegionByParentid/520000000000').then((res) => {
            var state = {...this.state};
            res.data.unshift({
                id: '',
                name: '全部'
            });
            state.cityList = res.data;
            this.setState(state);
        });
    }

    onCityChange = (item) => {
        var state = {...this.state};
        if(item.id)
        {
            resource.get('/xixiu-server/region/getRegionByParentid/' + item.id).then((res) => {
                res.data.unshift({
                    id: '',
                    name: '全部'
                });
                state.countyList = res.data;
                this.setState(state);
            });
        }else{
            state.countyList = [{
                id: '',
                name: '全部'
            }];
            this.setState(state);
        }
    }

    onCountyChange = (item) => {
        var state = {...this.state};
        if(item.id)
        {
            resource.get('/xixiu-server/region/getRegionByParentid/' + item.id).then((res) => {
                res.data.unshift({
                    id: '',
                    name: '全部'
                });
                state.countryList = res.data;
                this.setState(state);
            });
        }else{
            state.countryList = [{
                id: '',
                name: '全部'
            }];
            this.setState(state);
        }
    }

    onCountryChange = (item) => {
        var state = {...this.state};
        if(item.id)
        {
            resource.get('/xixiu-server/region/getRegionByParentid/' + item.id).then((res) => {
                res.data.unshift({
                    id: '',
                    name: '全部'
                });
                state.villageList = res.data;
                this.setState(state);
            });
        }else{
            state.villageList = [{
                id: '',
                name: '全部'
            }];
            this.setState(state);
        }
    }

    search = () => {
      this.resetSelect();
      for(let i = 1;i <= 4;i++)
      {
          let code = this.refs['select' + i].getItem().id;
          if(!code)
          {
              if(this.refs['select' + (i - 1)])
              {
                  this.districtCode = this.refs['select' + (i - 1)].getItem().id;
              }else{
                  this.districtCode = 520000000000;
              }

              break;
          }else{
            if(i === 4)
            {
              this.districtCode = code;
            }
          }
      }
        this.initWarningData(0,17,this.filter,this.districtCode);
    }

    onCheckDetail = (item) => {
      let obj = {
        inputValue: item.idnumber,
        region: {
          shi: '',
          xian: '',
          xiang: '',
          zheng: ''
        }
      };

      sessionStorage.setItem('keyWord',JSON.stringify(obj));
      history.push('/main/object/objectSearch');
    }

    componentDidMount () {
        this.initWarningData();
        this.initCity();
    }

    render() {

        const list = [
            {
                key: '',
                text: '全部'
            },
            {
                text: '公安',
                key: 'gongan'
            },
            {
                text: '教育',
                key: 'jiaoyu'
            },
            {
                text: '移民',
                key: 'yimin'
            },
            {
                text: '工商',
                key: 'gongshang'
            },
            {
                text: '民政',
                key: 'minzheng'
            },
            {
                text: '人社',
                key: 'renshe'
            },
            {
                text: '卫计',
                key: 'weiji'
            },
            {
                text: '住建',
                key: 'jianshe'
            },
            {
                text: '国土',
                key: 'guotu'
            }
        ];

        return (
            <div className={style.container}>
                <Card title="动态预警" handleClose={this.handleClose} subTitle={
                        <div className={style.tools}>
                            <div className={style.filter}>
                                <Filter list={list} onChange={this.onFilterChange}/>
                            </div>
                            <div className={style.select}>
                                <Select list={this.state.cityList} onChange={this.onCityChange} scope={this.scope1} ref='select1' map={{
                                        value: 'id',
                                        text: 'name'
                                    }}/>
                                  <Select list={this.state.countyList} onChange={this.onCountyChange} scope={this.scope2} ref='select2' map={{
                                        value: 'id',
                                        text: 'name'
                                    }}/>
                                  <Select list={this.state.countryList} onChange={this.onCountryChange} scope={this.scope3} ref='select3' map={{
                                        value: 'id',
                                        text: 'name'
                                    }}/>
                                  <Select list={this.state.villageList} onChange={this.onVillageChange} scope={this.scope4} ref='select4' map={{
                                        value: 'id',
                                        text: 'name'
                                    }}/>
                                <button onClick={this.search}>
                                    <img src={require('../images/search.png')}/>
                                </button>
                            </div>
                        </div>
                    }>
                    <p className={style.title}>
                        数据异常共计
                        <span>{this.state.total}</span>
                        条
                    </p>
                    <Table noEnd columns={this.state.columns} dataSource={this.state.warningDataSource} pageable={this.state.pageable} onChange={this.changePage} onHeaderSelect={this.onHeaderSelect} loading={this.state.loading} selectItem={this.state.selectItem}/>
                </Card>
            </div>
        )
    }
}

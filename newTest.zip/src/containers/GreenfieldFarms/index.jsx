import React, { Component } from 'react';
import style from './index.scss';
import BigTitle from '../../components/BigTitle';

export default class GreenfieldFarms extends Component {
    constructor() {
        super()
    }
    render() {
        return (
            <div className={style['farms-container']}>
                <header>
                    <BigTitle title='绿野芳田公司' />
                </header>
            </div>
        )
    }
}
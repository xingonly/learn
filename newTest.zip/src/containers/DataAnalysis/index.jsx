// 上帝保佑,永无bug

import React, {Component} from "react"
import { NavLink } from 'react-router-dom'

import style from './style.scss'

export default class DataAnalysis extends Component {

    render() {
        return (
            <div className={style.wrap}>
                <nav className={style.navs}>
                    <NavLink to="/main/dataAnalysis/data" activeClassName={style.active}><span>数据统计</span></NavLink>
                    <NavLink to="/main/dataAnalysis/data_monitoring" activeClassName={style.active}><span>数据监控</span></NavLink>
                    <NavLink to="/main/dataAnalysis/warning" activeClassName={style.active}><span>动态预警</span></NavLink>
                    <NavLink to="/main/dataAnalysis/datacharts" activeClassName={style.active}><span>数据报表</span></NavLink>
                </nav>
                {this.props.children}
            </div>
        )
    }
}

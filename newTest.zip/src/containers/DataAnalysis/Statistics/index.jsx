// 上帝保佑,永无bug

import React, {Component} from "react"
import createHistory from 'history/createHashHistory'
const history = createHistory()
import resource from '../../../util/resource'
import Exponent from './subPage/Exponent'
import Sex from './subPage/Sex'
import Age from './subPage/Age'
import Reason from './subPage/Reason'
import Map from './subPage/Map'
import Monitor from './subPage/Monitor'
import immutable from 'immutable'

import style from './style.scss'

export default class index extends Component {

    constructor(props) {
        super(props)
        this.regin = null;
        this.state = {
            index:0,
            reason:[],
            status:[],
            gender:[],
            age:[],
            map:[],
            show:false
        }
        this.param = {
            region:null,
            name:null,
            flag:false
        }
    }

    componentDidMount() {
        let scope = JSON.parse(sessionStorage.getItem('manager'))
        this.param.region = scope.scope;
        this.regin = scope.scope;
        this.handleName(scope.scope);
        this.find(scope.scope);
        this.getReason();
        this.getAge();
        this.getGender()
        this.getStatus();
        this.getMapData();
    }

    getReason = () =>{
        resource.get( `/xixiu-server/dataStatistics/getPoorCauses?region=${this.param.region}` ).then(res =>{
            if(res.status === 200){
                this.setState({
                    reason:res.data
                })
            }
        })
    }
    getStatus = () =>{
        resource.get( `/xixiu-server/dataStatistics/getPoorPeopleStatus?region=${this.param.region}` ).then(res =>{
            if(res.status === 200){
                this.setState({
                    status:res.data
                })
            }
        })
    }
    getGender = () =>{
        resource.get( `/xixiu-server/dataStatistics/getGenderRatio?region=${this.param.region}` ).then(res =>{
            if(res.status === 200){
                this.setState({
                    gender:res.data
                })
            }
        })
    }
    getAge = () =>{
        resource.get( `/xixiu-server/dataStatistics/getAgeRatioUi?region=${this.param.region}` ).then(res =>{
            if(res.status === 200){
                this.setState({
                    age:res.data
                })
            }
        })
    }
    getLastId = () =>{
        resource.get( `/xixiu-server/region/getRegionById/${this.param.region}` ).then(res =>{
            if(res.status ===200){
                let scope = res.data.parentid;
                this.param.region = scope;
                this.param.flag = true;
                this.handleName(scope);
                this.getMapData();
            }
        })
    }
    getMapData = () =>{
        resource.get( `/xixiu-server/dataStatistics/getStatisticsData2/${this.param.region}` ).then(res =>{
            if(res.status === 200){
                if(!res.data.length){
                    return;
                }else if(this.param.flag){
                    this.setState({
                        map:res.data
                    })
                }else{
                    this.setState({
                        map:res.data
                    })
                }

            }
        })
    }

    clickMap = (area,scope) => {
        if(this.state.show){
            return;
        }
        let data = this.state.map;
        this.handleName(scope);
        this.param.region = scope;
        for (let i = 0; i < data.length; i++) {
            if (data[i].name === area && this.regin === 520000000000) {
                this.setState({
                    show:true
                },()=>{
                    this.getAge();
                    this.getReason();
                    this.getStatus();
                    this.getGender();
                    this.getMapData();
                })
            }else{
                this.getAge();
                this.getReason();
                this.getStatus();
                this.getGender();
                this.getMapData();
            }
        }
    }

    handleName =(scope) =>{
        switch (scope) {
            case 520100000000:
                this.param.name='guiyang';
                break;
            case 520200000000:
                this.param.name='liupanshui';
                break;
            case 520300000000:
                this.param.name='zunyi';
                break;
            case 520400000000:
                this.param.name='anshun';
                break;
            case 520500000000:
                this.param.name='bijie';
                break;
            case 520600000000:
                this.param.name='tongren';
                break;
            case 522300000000:
                this.param.name='qianxinan';
                break;
            case 522600000000:
                this.param.name='qiandongnan';
                break;
            case 522700000000:
                this.param.name='qiannan';
                break;
            default:
                this.param.name = this.param.name;
                break;
        }
    }

    find = (scope)=>{
        let s = [520100000000, 520200000000, 520300000000, 520400000000,520500000000,520600000000, 522300000000, 522600000000, 522700000000];
        for(let i =0; i< s.length; i++){
            if(this.regin === 520000000000){
                this.param.name = this.param.name;
                return;
            }else if(s[i] === scope){
                this.param.name = this.param.name;
                return;
            }
        }
        this.getLastId();
    }

    handleReturn = ()=>{
        this.param.name = 'guizhou';
        this.param.region = 520000000000;
        this.setState({
            show:false
        },()=>{
            this.getAge();
            this.getReason();
            this.getStatus();
            this.getGender();
            this.getMapData();
        })
    }

    handleMoney = (num) => {
        let money = num+'';
        return money.replace(/\B(?=(\d{3})+(?!\d))/g, ',')
    }

    render() {
        return (
            <div className={style.wrap}>
                <div className={style.shadow}>
                    <div className={style.left}>
                        <Reason id="reason" data={this.state.reason} />
                        {/*<Monitor data={data.get(index)} />*/}
                        <Monitor />
                    </div>
                    <div className={style.center}>
                        <div className={style.center_top}>
                            <div className={style.top_item}>
                                <p>贫困人口总数</p>
                                <div className={style.poor_item}>
                                    {this.state.status.length > 0 ? this.handleMoney(this.state.status[0].value+this.state.status[1].value+this.state.status[2].value+this.state.status[3].value): 0}
                                </div>
                            </div>
                            <div className={style.top_item}>
                                <p>已脱贫人口数</p>
                                <div className={style.poor_item}>
                                    {this.state.status.length > 0 ? this.handleMoney(this.state.status[1].value): 0}
                                </div>
                            </div>
                            <div className={style.top_item}>
                                <p>未脱贫人口数</p>
                                <div className={style.poor_item}>
                                    {this.state.status.length > 0 ? this.handleMoney(this.state.status[0].value+this.state.status[2].value+this.state.status[3].value): 0}
                                </div>
                            </div>
                        </div>
                        <Map data={this.state.map} name={this.param.name} clickMap={this.clickMap}/>
                        <div className={style.return} style={{display:this.state.show ? 'block' : 'none'}}>
                            <i className="iconfont">&#xe618;</i>
                            <span onClick={this.handleReturn}>返回</span>
                        </div>
                    </div>
                    <div className={style.right}>
                        <Exponent id="exponent" data={this.state.status} />
                        <Sex data={this.state.gender} />
                        <Age data={this.state.age} id="age" />
                    </div>
                </div>

            </div>
        )
    }
}

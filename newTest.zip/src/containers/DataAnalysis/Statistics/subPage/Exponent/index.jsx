// 上帝保佑,永无bug

import React, {Component} from "react"
import {immutableRenderDecorator} from 'react-immutable-render-mixin'
import Konva from 'konva'

import style from './style.scss'


/*
 *   脱贫指数
 */
@immutableRenderDecorator
export default class Exponent extends Component {

    constructor(props) {
        super(props)
        this.param = {
            not: 0,     // 未脱贫
            yet: 0,     // 已脱贫
            back: 0,    // 返贫
            plan: 0,    // 预脱贫
            total: 0    // 总计
        }
        this.ringLayer = null
        this.pre = null    // 上一次鼠标移入的环形
    }

    componentDidMount() {
        window.addEventListener('resize', this.draw)
    }

    componentWillReceiveProps(props) {
        console.log(props)
        this.param.not = props.data[0].value || 0;
        this.param.yet = props.data[1].value || 0;
        this.param.back = props.data[2].value || 0;
        this.param.plan = props.data[3].value || 0;
        let count = this.param.not + this.param.yet + this.param.back + this.param.plan;
        this.param.total = count > 0 ? count : 1;
        this.draw()
    }

    componentWillUnmount() {
        if(this.ringLayer){
            this.ringLayer.off('mouseover')
            this.ringLayer.off('mouseleave')
        }
        window.removeEventListener('resize', this.draw)
    }

    draw = () => {
        let exponent = document.querySelector('#' + this.props.id),
            rect = exponent.getBoundingClientRect(),
            stage = new Konva.Stage({
                container: this.props.id,
                width: rect.width,
                height: rect.height
            })
        this.drawBg(stage)
        this.drawData(stage)
        this.drawDesc(stage)
    }

    /*
     *   根据数据画出环形图比例
     */
    drawData = (stage) => {
        this.ringLayer = new Konva.Layer()
        let datas = [{key: '未脱贫', color: '#3d77da', value: this.param.not}, {key: '已脱贫', color: '#0de0f5', value: this.param.yet},
            {key: '返贫', color: '#f602ed', value: this.param.back}, {key: '预脱贫', color: '#f60262', value: this.param.plan}]
        let radius = [{inner: 0.13, outer: 0.14}, {inner: 0.115, outer: 0.14},
            {inner: 0.15, outer: 0.16}, {inner: 0.14,outer: 0.16}]
        let arc = null,
            rotation = -100
        for (let i = 0; i < 4; i++) {
            arc = new Konva.Arc({
                x: stage.getWidth() * 0.27,
                y: stage.getHeight() / 1.8,
                innerRadius: stage.getWidth() * radius[i].inner,
                outerRadius: stage.getWidth() * radius[i].outer,
                angle: datas[i].value / this.param.total * 360,
                fill: datas[i].color,
                rotation: rotation
            })
            rotation += datas[i].value / this.param.total * 360
            this.ringLayer.add(arc)
        }

        this.ringLayer.on('mouseover', (event) => {
            if (this.pre) {
                this.pre.setOuterRadius(this.pre.getOuterRadius() - 5)
            }
            this.pre = event.target
            event.target.setOuterRadius(event.target.getOuterRadius() + 5)
            this.ringLayer.draw()
        });
        this.ringLayer.on('mouseleave', () => {
            this.pre.setOuterRadius(this.pre.getOuterRadius() - 5)
            this.ringLayer.draw()
            this.pre = null
        });
        stage.add(this.ringLayer)

    }

    drawDesc = (stage) => {
        let datas = [{key: '未脱贫', color: '#3d77da', value: this.param.not}, {key: '已脱贫', color: '#0de0f5', value: this.param.yet},
            {key: '返贫', color: '#f602ed', value: this.param.back}, {key: '预脱贫', color: '#f60262', value: this.param.plan}],
            layer = new Konva.Layer(),
            initX = stage.getWidth() * 0.528,
            initY = stage.getHeight() / 1.8 - 74 + 9,
            circle = null,
            des = null,
            value = null
        for (let i = 0; i < 4; i++) {
            circle = new Konva.Circle({
                x: initX + 9,
                y: initY + (41 * i),
                radius: 9,
                fill: datas[i].color
            })
            des = new Konva.Text({
                x: initX + 36 ,
                y: initY + (41 * i) - 7,
                text: datas[i].key,
                fontSize: 14,
                fill: '#fff',
                align: 'left'
            })

            value = new Konva.Text({
                x: stage.getWidth() * 0.79,
                y: initY + (41 * i) - 7,
                text: (datas[i].value / this.param.total * 100).toFixed(1) + '%',
                fontSize: 14,
                fill: '#fff',
                width: 60,
                align: 'right'
            })
            layer.add(circle)
            layer.add(des)
            layer.add(value)
        }

        stage.add(layer)
    }

    /*
     *   画背景圆
     */
    drawBg = (stage) => {
        let layer = new Konva.Layer(),
            outerCircle = new Konva.Circle({
                x: stage.getWidth() * 0.27,
                y: stage.getHeight() / 1.8,
                radius: stage.getHeight() * 0.34,
                shadowColor: '#fff',
                shadowBlur: 8,
                stroke: '#b8b8c0',
                strokeWidth: 1
            }),
            innerCircle = new Konva.Circle({
                x: stage.getWidth() * 0.27,
                y: stage.getHeight() / 1.8,
                radius: stage.getHeight() * 0.131,
                shadowColor: '#fff',
                shadowBlur: 8,
                stroke: '#b8b8c0',
                strokeWidth: 1
            })
        layer.add(outerCircle)
        layer.add(innerCircle)
        stage.add(layer)
    }


    render() {
        return (
            <div className={style.wrap}>
                <h6 className={style.title}>脱贫指数</h6>
                <div id={this.props.id} className={style.canvas}></div>
            </div>

        )
    }
}

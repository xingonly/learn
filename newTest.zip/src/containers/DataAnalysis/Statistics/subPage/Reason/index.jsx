// 上帝保佑,永无bug

import React, {Component} from "react"
import echarts from 'echarts'
import { immutableRenderDecorator } from 'react-immutable-render-mixin'

import style from './style.scss'

/*
*    主要致贫原因
*/
@immutableRenderDecorator
export default class Reason extends Component {

    constructor(props) {
        super(props)
        this.myChart = null
    }

    componentDidMount() {
        this.myChart = echarts.init(document.getElementById(this.props.id))
        window.addEventListener('resize', this.myChart.resize)
    }

    componentWillReceiveProps(props) {
        this.myChart.setOption(this.getOption(props.data))
    }

    componentWillUnmount() {
        this.myChart.dispose()
        window.removeEventListener('resize', this.myChart.resize)
    }


    getOption = (data) => {
        let rect = document.getElementById(this.props.id).getBoundingClientRect()
        let option = {
            legend: {
                orient: 'vertical',
                right: 40,
                top: rect.height / 4.3,
                data: ['因病', '因残', '因学', '因灾', '缺水', '缺土地', '缺技术', '缺劳力', '缺资金', '交通条件落后', '自身发展动力不足','其他'],
                textStyle: {
                    color: '#fff',
                    fontSize: 10
                },
                itemWidth: 9,
                itemGap: rect.height / 40,
                icon: 'circle'
            },
            color:['#017bea', '#1494f5', '#39adf6', '#63c7f9', '#9eedfc', '#0ce0f5', '#33effa', '#88fffd', '#f50463', '#fd5a9b', '#5afbfd'],
            series: [
                {
                    name: '访问来源',
                    type: 'pie',
                    center: ['32%', '57%'],
                    radius: ['52%', '60%'],
                    avoidLabelOverlap: false,
                    label: {
                        normal: {
                            show: false,
                            position: 'center'
                        },
                        emphasis: {
                            show: true,
                            formatter: '{b}\n{d}%',
                            textStyle: {
                                fontSize: '16',
                                fontWeight: 'bold'
                            }
                        }
                    },
                    data: data
                }
            ]
        }

        return option
    }

    render() {
        return (
            <div className={style.wrap}>
                <h6 className={style.title}>主要致贫原因</h6>
                <div id={this.props.id} className={style.canvas}></div>
            </div>
        )
    }
}

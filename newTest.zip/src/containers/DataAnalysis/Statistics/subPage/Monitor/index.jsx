// 上帝保佑,永无bug

import React, {Component} from "react"
import resource from '../../../../../util/resource'
import {immutableRenderDecorator} from 'react-immutable-render-mixin'
import echarts from 'echarts'

import style from './style.scss'

/*
 *   业务量监控
 */
@immutableRenderDecorator
export default class Monitor extends Component {

    constructor(props) {
        super(props)
        this.myChart = null
    }

    componentDidMount() {
        this._initData()
        this.myChart = echarts.init(this.refs.column)
        window.addEventListener('resize', this.myChart.resize)
    }


    componentWillUnmount() {
        this.myChart.dispose()
        window.removeEventListener('resize', this.myChart.resize)
    }

    _initData = () => {
        resource.get('/xixiu-server/exchangeData/getCountByDepartment').then(res => {
            if(res.status === 200){
                let data = {}
                for (let item of res.data) {
                    data[item.name] = item.exchange
                }
                this.myChart.setOption(this.getOption(data))
            }
        })
    }

    getOption = (data) => {
        let keys = Object.keys(data)
        let values = []
        for (let key of keys) {
            values.push(data[key])
        }

        let option = {
            color: ['#0ce0f5'],
            tooltip : {
                trigger: 'axis',
                axisPointer : {            // 坐标轴指示器，坐标轴触发有效
                    type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
                }
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '8%',
                top: '20%',
                containLabel: true
            },
            xAxis : [
                {
                    type : 'category',
                    data : keys,
                    axisTick: {
                        show: false
                    },
                    axisLine: {
                        lineStyle: {
                            color: '#fff'
                        }
                    },
                    axisLabel: {
                        textStyle: {
                            color: '#fff'
                        }
                    }
                }
            ],
            yAxis : [
                {
                    type : 'value',
                    axisTick: {
                        show: false
                    },
                    axisLabel: {
                        textStyle: {
                            color: '#fff'
                        }
                    },
                    axisLine: {
                        lineStyle: {
                            color: '#fff'
                        }
                    },
                    splitLine: false,
                    name: '变化数据/条'
                },

            ],
            series : [
                {
                    name:'直接访问',
                    type:'bar',
                    barWidth: '30%',
                    data: values
                }
            ]
        }

        return option
    }

    render() {
        return (
            <div className={style.wrap}>
                <h6 className={style.title}>业务量监控</h6>
                <div ref="column" className={style.canvas}></div>
            </div>
        )
    }
}

// 上帝保佑,永无bug

import React, {Component} from "react"
import echarts from 'echarts'
import { immutableRenderDecorator } from 'react-immutable-render-mixin'

import style from './style.scss'

@immutableRenderDecorator
export default class Map extends Component {

    constructor(props) {
        super(props);
        this.myChart = null
    }

    componentDidMount() {
        let geoJson = require('../../json/guizhou.json')
        this.myChart = echarts.init(document.getElementById('guizhoumap'))
        echarts.registerMap(name, geoJson)

        this.myChart.on('click', this.clickMap);

        window.addEventListener('resize', this.myChart.resize)
    }

    componentWillReceiveProps(props) {
        if(props.name){
            let geoJson = require(`../../json/${props.name}.json`);
            echarts.registerMap(name, geoJson)
        }else{
            let geoJson = require('../../json/guizhou.json');
            echarts.registerMap(name, geoJson)
        }
        let minMax = this.findMaxMin(props.data);
        if(minMax.length === 0){
            return
        }else{
            this.myChart.setOption(this.getOption(props.data,minMax))
        }

    }
    sortNumber = (a,b)=> {
        return a - b
    }
    findMaxMin = (data) =>{
        console.log(data);
        let num = [];
        for (let i = 0, len = data.length; i < len; i++) {
            num.push(data[i].value);
        }
        let max = num.sort(this.sortNumber);
        return max
    }

    componentWillUnmount() {
        this.myChart.dispose()
        window.removeEventListener('resize', this.myChart.resize)
        this.myChart.off('click', this.clickMap);
    }
    clickMap = (parmas) => {
        this.props.clickMap(parmas.name,parmas.data.scope)
    }

    getOption = (data,minmax) => {
        let option = {
            tooltip: {
                trigger: 'item',
                formatter: (item) => {
                    return(
                    `<div style="padding: .5rem">
                        <p style="line-height: 1.75rem">${item.name}:${item.data.value}</p>
                        <p style="line-height: 1.75rem">已脱贫:${item.data.values[1].value}</p>
                        <p style="line-height: 1.75rem">未脱贫:${item.data.values[0].value+item.data.values[2].value+item.data.values[3].value}</p>
                    </div>`
                )}
            },
            visualMap: {
                min: minmax[0],
                max: minmax[minmax.length - 1],
                right: 40,
                top: 'bottom',
                text: ['高', '低'], // 文本，默认为数值文本
                inRange: {
                    color: ['#45abd9','#36456e']
                },
                textStyle: {
                    color: '#fff'
                },
                calculable: true
            },
            series: [{
                type: 'map',
                mapType: name,
                label: {
                    normal: {
                        show: true,
                        textStyle: {
                            color: '#fff'
                        }
                    },
                    emphasis: {
                        textStyle: {
                            color: '#fff'
                        }
                    }
                },
                itemStyle: {
                    normal: {
                        borderColor: '#fff',
                        areaColor: '#fff'
                    },
                    emphasis: {
                        areaColor: '#0ce0f5',
                        borderWidth: 0
                    }
                },
                animation: false,
                data:data
            }]
        }
        return option
    }


    render() {
        return (
            <div id="guizhoumap" className={style.map} style={{opacity: '0.9'}}></div>
        )
    }
}

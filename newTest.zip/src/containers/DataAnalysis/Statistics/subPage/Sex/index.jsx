// 上帝保佑,永无bug

import React, {Component} from "react"
import {immutableRenderDecorator} from 'react-immutable-render-mixin'

import style from './style.scss'

@immutableRenderDecorator
export default class Sex extends Component {

    constructor(props) {
        super(props)
        this.state = {
            bodyPercent: 0,
            girlPercent: 0
        }
    }

    componentWillReceiveProps(props) {
        let body,girl;
        for(let i = 0; i < props.data.length; i++){
            if(props.data[i].name === '男'){
                body = props.data[i].value;
            }else if(props.data[i].name === '女'){
                girl = props.data[i].value
            }
        }
        // let body = props.data.get('男')
        // let girl = props.data.get('女')
        let bodyPercent = (body / (body + girl) * 100).toFixed(1) + '%'
        let girlPercent = (girl / (body + girl) * 100).toFixed(1) + '%'
        this.setState({
            bodyPercent,
            girlPercent
        })
        requestNextAnimationFrame(() => {
            this.refs.boy.style.width = bodyPercent
            this.refs.girl.style.width = girlPercent
        })
    }

    render() {
        return (
            <div className={style.wrap}>
                <h6 className={style.title}>性别比例</h6>
                <dl>
                    <dt>男性</dt>
                    <dd><div style={{backgroundColor: '#079eaf'}} ref="boy"></div></dd>
                    <dd>{this.state.bodyPercent}</dd>
                </dl>
                <dl>
                    <dt>女性</dt>
                    <dd><div style={{backgroundColor: '#0ce0f5'}} ref="girl"></div> </dd>
                    <dd>{this.state.girlPercent}</dd>
                </dl>
            </div>
        )
    }
}

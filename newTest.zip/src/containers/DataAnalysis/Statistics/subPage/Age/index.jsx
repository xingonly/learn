// 上帝保佑,永无bug

import React, {Component} from "react"
import Konva from 'konva'
import {immutableRenderDecorator} from 'react-immutable-render-mixin'

import style from './style.scss'

/*
*   年龄比例
*/
@immutableRenderDecorator
export default class Age extends Component {

    constructor(props) {
        super(props)
        this.param = null
    }

    componentDidMount() {
        window.addEventListener('resize', this.draw)
    }

    componentWillReceiveProps(props) {
        this.param = props
        this.draw()
    }

    componentWillUnmount() {
        window.removeEventListener('resize', this.draw)
    }

    draw = () => {
        let age = document.querySelector('#' + this.props.id),
            rect = age.getBoundingClientRect(),
            stage = new Konva.Stage({
                container: this.props.id,
                width: rect.width,
                height: rect.height
            })
        this.drawAxis(stage)
        this.drawData(stage, this.param)
    }


    drawData = (stage, props) => {
        let data = props.data
        let layer = new Konva.Layer(),
            datas = [data[0].value, data[1].value, data[2].value, data[3].value, data[4].value, data[5].value],
            initY = stage.getHeight() * 0.81 - 10,
            diffY = initY - stage.getHeight() * 0.243,
            width = stage.getWidth(),
            innerCircle = null,
            outerCircle = null,
            line = null,
            zone = null
        let total = datas.reduce((prev, cur) => {
            return prev + cur
        })

        for (let i = 0, len = datas.length; i < len; i++) {
            let x = 60 + width * 0.047 + width * 0.1136 * ( i + 0.5)
            let y = initY - datas[i] / total * diffY

            zone = new Konva.Shape({
                sceneFunc: function(context) {
                    context.beginPath()
                    context.moveTo(60 + width * 0.047 + width * 0.1136 * i + 1, initY)
                    context.lineTo(x, y)
                    context.lineTo(60 + width * 0.047 + width * 0.1136 * (i + 1), initY)
                    context.closePath()
                    context.fillStrokeShape(this)
                },
                fillLinearGradientStartPoint: {x: x, y: y},
                fillLinearGradientEndPoint: {x: x, y: initY},
                fillLinearGradientColorStops: [0, '#0595b0', 1, '#020923']
            })

            line = new Konva.Line({
                points: [60 + width * 0.047 + width * 0.1136 * i + 1, initY, x, y, 60 + width * 0.047 + width * 0.1136 * (i + 1), initY],
                stroke: '#0ba7c0',
                fill: 'red',
                strokeWidth: 2,
            })

            outerCircle = new Konva.Circle({
                x: x,
                y: y,
                radius: 7,
                fill: '#057487',
            })
            innerCircle = new Konva.Circle({
                x: x,
                y: y,
                radius: 4,
                fill: '#08adc0',
            })

            layer.add(new Konva.Text({
                x: x,
                y: y - 22,
                text: (datas[i] / total * 100).toFixed(1) + '%',
                fontSize: 12,
                offsetX: 18,
                fill: '#fff'
            }));
            layer.add(zone)
            layer.add(outerCircle)
            layer.add(innerCircle)
            layer.add(line)
        }


        stage.add(layer)
    }

    drawAxis = (stage) => {
        let layer = new Konva.Layer(),
            height = stage.getHeight(),
            width = stage.getWidth(),
            yLen = 5,
            yText = null,
            xText = null,
            xkeys = ['0', '18', '28', '38', '48', '58', '68岁以上'],
            xAxis = new Konva.Line({
                points: [70, height * 0.81, width - 30, height * 0.81],     // 0.81 最低点高度占容器高度的比例
                stroke: '#fff',
                strokeWidth: 1,
            }),
            yAxis = new Konva.Line({
                points: [70, height * 0.81, 70, height * 0.243],           // 0.243  最高点高度占容器高度的比例
                stroke: '#fff',
                strokeWidth: 1,
            })

        for (let i = 0; i < yLen; i++) {
            yText = new Konva.Text({
                x: 20,
                y: height * 0.81 - (height * 0.13 * i) - 14,             // 0.81  最低点高度占容器高度的比例, 0.13 每个值之间距离的比例
                text: 100 / yLen * i + '%',
                fontSize: 14,
                fill: '#fff',
                width: 40,
                align: 'right'
            })
            layer.add(yText)
        }
        let left = 52;
        for (let i = 0, len = xkeys.length; i < len; i++) {
            if (i === len - 1) {
                left = 40
            }
            xText = new Konva.Text({
                x: left + width * 0.047 + width * 0.1136 * i,           // 60 距离容器左边的值  0.047  第一个点到y轴距离占容器比, 0.1136 每个x坐标的距离与容器比例
                y: height * 0.81 + 10,
                text: xkeys[i],
                fontSize: 14,
                fill: '#fff'
            })
            layer.add(xText)
        }

        layer.add(xAxis)
        layer.add(yAxis)
        stage.add(layer)
    }

    render() {
        return (
            <div className={style.wrap}>
                <h6 className={style.title}>年龄比例</h6>
                <div id={this.props.id} className={style.canvas}></div>
            </div>
        )
    }
}

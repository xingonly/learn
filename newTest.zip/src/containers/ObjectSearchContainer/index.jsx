import React, { Component } from 'react';
import styles from './index.scss';

export default class ObjectSearchContainer extends Component {
    render() {
        return (
            <section className={styles['object-search-container']}>
                <div className={styles.container}>
                    {this.props.children}
                </div>
            </section>
        )
    }
}
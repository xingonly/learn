//測試
import React from 'react'
let Main = (props) => {
    return (
        <div>
            这里是内容区域
        </div>
    )
}

export default Main

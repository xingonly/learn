let url= '/xixiu-server';

export default url
import React,{ Component } from 'react'
import style from './style.scss'
import common from '../../common.scss'
import { withRouter } from 'react-router-dom'
import Datatime from 'react-datetime'
import moment from 'moment'

class App extends Component{
    constructor(){
    super();
    this.paramas = {
        createTimeStart:null,
        createTimeEnd:null,
        fullName:'',
        commitName:''
    };
    this.state = {
        createTimeStart:0,
        createTimeEnd:0,
        label:'commitName'

    };

    this.selectData = [
        {
            name:'反馈干部',
            label:'commitName'
        },{
            name:'需求部门',
            label:'department'
        }
    ]

    this.roles = JSON.parse(sessionStorage.getItem('roles'));
}
    handleOk = () => {
        if(this.props.handleOk){
            this.paramas.fullName = this.name.value;
            this.paramas[this.state.label] = this.partName.value;
            if(this.state.label === 'commitName'){
                this.paramas.department = '';
            }else{
                this.paramas.commitName = '';
            }
            this.props.handleOk(this.paramas);
        }
    }

    handleTimeChange= (e,label) => {
        let state = this.state;
        if(label === 'createTimeEnd'){
            let data = Datatime.moment(e).subtract( -1, 'day' );
            state[label] = (new Date(data._d)).getTime() ? (new Date(data._d)).getTime() :0;
            this.paramas[label] = (new Date(data._d)).getTime() ? (new Date(data._d)).getTime() : null ;
        }else{
            state[label] = (new Date(e._d)).getTime() ? (new Date(e._d)).getTime() :0;
            this.paramas[label] = (new Date(e._d)).getTime() ? (new Date(e._d)).getTime() : null ;
        }
        this.setState(state);
    }

    handleChange = (e) => {
        let state = this.state;
        state.label = e.target.value;
        this.partName.value = '';
        this.setState(state)
    }


    handleClear = (type) => {
        let state = this.state;
        state[type] = '';
        this.paramas[type] = '';
        this.setState(state)
    }

    render(){
        let { createTimeStart,createTimeEnd, label} = this.state;
        let toDay = Datatime.moment().subtract( 0, 'day' );
        let startData = function( e ){
            let newtTime = createTimeEnd ? Datatime.moment(moment(createTimeEnd ? createTimeEnd : 0).format('YYYY-MM-DD')).subtract( 0, 'day' ):0;
            return e.isBefore( newtTime ? newtTime : toDay );
        };
        let end = Datatime.moment(moment(createTimeStart ? createTimeStart : 0).format('YYYY-MM-DD')).subtract( 1, 'day' );
        let endTimeData = function( current ){
            return current.isBetween( end, toDay);
        };
        return(
            <div className={style.box}>
                <div className={style.header}>{this.props.title}</div>
                <div className={style.content}
                     style={{display: this.roles && this.roles[1] && this.roles[1] === 'USE_MANAGER_CENTER' ? 'block':'none'}}
                >
                    <dl>
                        <dt style={{padding:'0'}}>户主姓名：</dt>
                        <dd>
                            <input type="text"
                                   ref={(e) => { this.name = e }}
                                   placeholder="请输入姓名"
                            />
                        </dd>
                    </dl>
                    <dl>
                        <dt>
                            {
                                this.props.type ?
                                    <select
                                        name=""
                                        id=""
                                        onChange={this.handleChange}
                                        className={style.select}
                                    >
                                        {
                                            this.selectData.map((obj, index) => {
                                                return (
                                                    <option
                                                        key={index}
                                                        value={obj.label}
                                                    >{obj.name}</option>
                                                )
                                            })
                                        }
                                    </select>:
                                    '反馈干部'
                            }
                            ：</dt>
                        <dd>
                            <input type="text"
                                   ref={(e) => { this.partName = e }}
                                   placeholder={ label === 'commitName' ?  "请输入姓名" :"请输入部门"}
                            />
                        </dd>
                    </dl>
                    <dl>
                        <dt>反馈日期：</dt>
                        <dd className={common.forTime}>
                            <div className={common.startTime}>
                                <Datatime
                                    dateFormat='YYYY-MM-DD'
                                    onChange={(e) => this.handleTimeChange(e,'createTimeStart')}
                                    locale="zh_CN"
                                    utc={false}
                                    value={createTimeStart}
                                    inputProps={{ placeholder: '起始日期 ',readOnly: true }}
                                    timeFormat = {false}
                                    closeOnSelect = {true}
                                    isValidDate = {startData}
                                />
                                <span
                                    className={common.clear}
                                    style={{display: createTimeStart ? 'block':'none'}}
                                    onClick={() => this.handleClear('createTimeStart')}
                                >X</span>
                            </div>
                            <span className={common.line}></span>
                            <div className={common.endTime}>
                                <Datatime
                                    dateFormat='YYYY-MM-DD'
                                    onChange={(e) => this.handleTimeChange(e,'createTimeEnd')}
                                    locale="zh_CN"
                                    utc={false}
                                    value={ createTimeEnd ? Datatime.moment(moment(createTimeEnd ? createTimeEnd : 0).format('YYYY-MM-DD')).subtract( 1, 'day' ) :''}
                                    inputProps={{ placeholder: '结束日期 ',readOnly: true }}
                                    timeFormat = {false}
                                    closeOnSelect = {true}
                                    isValidDate = {endTimeData}
                                />
                                <span
                                    className={common.clear}
                                    style={{display: createTimeEnd ? 'block':'none'}}
                                    onClick={() => this.handleClear('createTimeEnd')}
                                >X</span>
                            </div>
                            <span
                                className={style.buttonSure}
                                onClick={this.handleOk}
                            >确认</span>
                        </dd>
                    </dl>
                </div>
            </div>
        )
    }
}
export default withRouter(App)
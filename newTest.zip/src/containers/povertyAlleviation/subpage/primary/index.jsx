import React, {Component} from 'react';
import style from './style.scss';
import {Modal,message} from 'antd';
import resource from "resource";
import urlData from '../../config'


let manager=sessionStorage.getItem('manager') || null;
let managers = manager && JSON.parse(manager);
export default class DemandManageAllocated extends Component {

    constructor(props) {
        super(props);
        this.paramas= {
            "departments": [],
            "remark": ""
        }
        this.parama= {
            "remark": ""
        }
        this.paramat= {
            "remark": ""
        }


        this.initSelectData = [
            {
                name:'扶贫办',
                selected: false
            },{
                name:'教育局',
                selected: false
            },{
                name:'金融办',
                selected: false
            },{
                name:'工商联',
                selected: false
            },{
                name:'残联',
                selected: false
            },{
                name:'民政局',
                selected: false
            },{
                name:'人社局',
                selected: false
            },{
                name:'水务局',
                selected: false
            },{
                name:'交通局',
                selected: false
            },{
                name:'卫计局',
                selected: false
            },{
                name:'移民局',
                selected: false
            },{
                name:'住建局',
                selected: false
            },{
                name:'国土办',
                selected: false
            },{
                name:'招生办',
                selected: false
            },{
                name:'农业局',
                selected: false
            }
        ];
        this.state={
            detail:[],
            dpartment:this.initSelectData,
            textvalue:'',
            visible:false
        }
    }
    componentDidMount(){

    }

    textvalueChange=(e)=>{
        if(e.target.value.length<=120){
            this.setState({
                textvalue:e.target.value,
            })
        }else{
            e.target.value=false
        }
    }

    handleData = () => {
        let state = this.state;
        let data = [];
        state.dpartment.map((obj, index) => {
            if(obj.selected){
                data.push(obj.name);
            }
        });
        return data;
    };

    clickDepartment=(e,index)=>{
        let state = this.state;
        state.dpartment[index].selected = !state.dpartment[index].selected;
        this.setState(state)
    }

    handleOk = (mystatus) => {
        this.paramat={
            "remark":this.state.textvalue
        }
        this.paramas.departments = this.handleData();
        this.paramas.remark = this.state.textvalue;
        if(!managers.department||managers.department==='调度中心'){
            if(this.state.textvalue && this.paramas.departments.length){
                this.getAllocated();
            }else{
                message.info('请选择部门和输入需求任务意见')
            }
        }else{
            if(this.state.textvalue){
                this.getAllocated(mystatus);
            }else{
                message.info('输入需求任务意见')
            }
        }
    }

    getAllocated = (mystatus) =>{
        this.paramas= {
            "departments": this.paramas.departments,
            "remark": this.paramas.remark
        }
        if(!managers.department||managers.department==='调度中心'){
            resource.put(`${urlData}/require/assign/${this.props.detail.id}`,this.paramas).then((res)=>{
                if(res.status === 200){
                    if(this.props.handleOk){
                        this.props.handleOk();
                    }
                }else{
                    message.info(res.message)
                }
            })
        }else{
            resource.put(`${urlData}/require/solve/${this.props.detail.id}?solve=${mystatus}`,this.paramat).then((res)=>{
                console.log(res)
                if(res.status === 200){
                    if(this.props.handleOk){
                        this.props.handleOk();
                    }
                }else{
                    message.info(res.message)
                }
            })
        }

    };

    getAllocatedClose = () =>{
        resource.put(`${urlData}/require/close/${this.props.detail.id}`,this.parama).then((res)=>{
            if(res.status === 200){
                if(this.props.handleOk){
                    this.props.handleOk();
                }
            }else{
                message.info(res.message)
            }
        })
    };

    handleCancel = (e) => {
        this.showModal()
        this.parama.remark=this.state.textvalue
        this.getAllocatedClose()
    };
    handleCancels = (e) => {
        if(this.props.handleCancel){
            this.props.handleCancel()
        }
    };
    handleOksure=()=>{
        this.setState({
            visible:false
        })
    }
    showModal = () => {
        this.setState({
            visible: true,
        });
    }
    showModal1 = () => {
        this.setState({
            visible: false,
        });
    }
    render() {
        let {detail} = this.props
        return (
            <Modal
                footer={null}
                width={550}
                visible={true}
                onCancel={this.handleCancels}
            >
                <div className={style.popup}>
                    <div className={style.total}>任务分配</div>
                        <div className={style.popupcontent}>
                            <div className={style.divide}>
                                <div>
                                    <span>姓名：</span>
                                    <span>{detail.fullName||'---'}</span>
                                </div>
                                <div>
                                    <span>贫困状态：</span>
                                    <span>{detail.poorStatus==='0'?'未脱贫':detail.poorStatus==='1'?'已脱贫':detail.poorStatus==='2'?'预脱贫':detail.poorStatus==='3'?'返贫':'---'}</span>
                                </div>
                                <div>
                                    <span>需求名称：</span>
                                    <span>{detail.requireName||'---'}</span>
                                </div>
                                <div>
                                    <span>反馈干部：</span>
                                    <span>{detail.commitName||'---'}</span>
                                </div>

                            </div>
                            <div  className={style.divide}>
                                <div>
                                    <span>家庭住址：</span>
                                    <span>{detail.address||'---'}</span>
                                </div>
                                <div>
                                    <span>致贫原因：</span>
                                    <span>{detail.poorCause||'---'}</span>
                                </div>
                                <div>
                                    <span>需求详情：</span>
                                    <span>{detail.requireDetail||'---'}</span>
                                </div>
                                <div>
                                    <span>反馈时间：</span>
                                    <span>{detail.createTime||'---'}</span>
                                </div>

                            </div>
                        </div>
                    <div className={style.popuptotal} style={{display:!managers.department||managers.department==='调度中心'?'block':'none'}}>选择办理部门</div>
                    <ul className={style.department}>
                        {
                            this.state.dpartment.map((item,index)=>{
                                return(
                                    <li
                                        style={{
                                            background:item.selected ? '#5BBCB5':'',
                                            color:item.selected ? '#fff':'',
                                            display:!managers.department||managers.department==='调度中心'?'inlineBlock':'none'
                                        }}
                                        key={index}
                                        className={style.departmentson}
                                        onClick={(e)=>this.clickDepartment(e,index)}
                                        id='myli'
                                    >
                                        {
                                            item.statubtn===1?
                                            item.name:item.name
                                        }
                                    </li>
                                )
                            })
                        }
                        <div>
                            <textarea
                                className={style.mytext} rows="4" cols="71"
                                placeholder={!managers.department||managers.department==='调度中心'?'需求任务意见（120字以内）':'情况说明（120字以内）'}
                                value={this.state.textvalue}
                                onChange={this.textvalueChange}></textarea>
                        </div>
                    </ul>


                    <div className={style.scbtn} style={{display:!managers.department||managers.department==='调度中心'?'block':'none'}}>
                        <button
                            onClick={()=>this.showModal()}
                            className={style.close}
                        >
                            需求关闭
                        </button>
                        <Modal
                            footer={null}
                            width={300}
                            visible={this.state.visible}
                            onOk={this.handleOksure}
                            onCancel={this.handleOksure}
                            style={{marginTop:'15%'}}
                        >
                            <div className={style.pbtn}>
                                <h1 className={style.myh1}>提示</h1>
                                <div>
                                    <div  className={style.pmytext} >确认是否关闭需求?</div>
                                    <button className={style.pclose}     onClick={this.handleCancels}>取消</button>
                                    <button className={style.pclose}    onClick={this.handleCancel}>确定</button>
                                </div>
                            </div>
                        </Modal>
                        <button
                            onClick={this.handleOk}
                            className={style.close}
                        >
                            确定分配
                        </button>
                    </div>
                    <div className={style.scbtn} style={{display:!managers.department||managers.department==='调度中心'?'none':'block'}}>
                        <button
                            onClick={()=>this.handleOk(false)}
                            className={style.close}
                        >
                            不能解决
                        </button>
                        <button
                            onClick={()=>this.handleOk(true)}
                            className={style.close}
                        >
                            已解决
                        </button>
                    </div>

                </div>
            </Modal>

        )
    }
}
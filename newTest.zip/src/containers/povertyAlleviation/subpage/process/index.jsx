import React, {Component} from 'react';
import style from './style.scss';
import json from './data.json';
import resource from 'resource';

const colorRgb = (color, opacity) => {
    var reg = /^#([0-9a-fA-f]{3}|[0-9a-fA-f]{6})$/;
    var sColor = color.toLowerCase();
    if(sColor && reg.test(sColor)){
        if(sColor.length === 4){
            var sColorNew = "#";
            for(let i = 1;i < 4;i+=1){
                sColorNew += sColor.slice(i,i+1).concat(sColor.slice(i,i+1));
            }
            sColor = sColorNew;
        }
        var sColorChange = [];
        for(let i = 1;i < 7;i += 2){
            sColorChange.push(parseInt("0x"+sColor.slice(i,i+2)));
        }
        return (opacity ? 'rgba' : 'rgb') + '(' + sColorChange.join(',') + (opacity ? (',' + opacity) : '') + ')';
    }else{
        return sColor;
    }
};

const passColor = '#60b6bc';
const branchColor = {
  '已解决': passColor,
  '待办理': '#fbbc11',
  '不能解决': '#ff3a15'
};
const textWidth = 200;
const fontSize = 14;
const radius = 8;
const shadowRadius = 13;
const between = 80;
const padding = 100;
const processRound = {
  '已提交': 0,
  '已审核': 1,
  '已拒绝': 1,
  '已关闭': 2,
  '已分配': 2,
  '已办理': 3,
  '已确认': 4,
  '已落实': 5,
  '未落实': 5
};
const circleMap = {
  '已提交': {
    num: 2,
    color: '#fbbc11'
  },
  '已审核': {
    num: 3,
    color: '#fbbc11'
  },
  '已拒绝': {
    num: 2,
    color: '#ff3a15',
  },
  '已关闭': {
    num: 3,
    color: '#ff3a15',
  },
  '已分配': {
    num: 4,
    color: '#60b6bc',
  },
  '已办理': {
    num: 5,
    color: '#fbbc11',
  },
  '已确认': {
    num: 6,
    color: '#fbbc11',
  },
  '已落实': {
    num: 6,
    color: '#60b6bc',
  },
  '未落实': {
    num: 6,
    color: '#fbbc11',
  }
};

let passMap;

class Process extends Component {

  state = {
    height: 170,
    data: {}
  }

  componentDidMount() {
    if(this.props.data)
    {
      const length = this.props.data.departmentProcess && this.props.data.departmentProcess.length || 0;
      this.setState({
        data: this.props.data,
        height: length ? (length * between + shadowRadius) : this.state.height
      }, () => {
        this.startDraw();
      });
    }
  }

  componentWillReceiveProps(nextProps) {
    if(JSON.stringify(nextProps.data) !== JSON.stringify(this.props.data))
    {
      const length = nextProps.data.departmentProcess && nextProps.data.departmentProcess.length || 0;
      this.setState({
        data: nextProps.data,
        height: length ? (length * between + shadowRadius) : this.state.height
      }, () => {
        this.startDraw();
      });
    }
  }

  initData = () => {
    const data = json.data || {};
    const length = data.departmentProcess && data.departmentProcess.length || 0;
    this.setState({
      data,
      height: length ? (length * between + shadowRadius) : this.state.height
    }, () => {
      this.startDraw();
    });
  }

  startDraw = () => {
      let chart = document.querySelector('#container');
      var rect = chart.getBoundingClientRect();
      this.stage = new Konva.Stage({
          container: 'container',
          width: rect.width,
          height: rect.height
      });

      const { data } = this.state;
      this.match = circleMap[data.process];
      const num = this.match.num;
      const currentRound = processRound[data.process];

      passMap = {
        0: {
          title: '采集情况',
          text: '驻村干部：已提交'
        },
        1: {
          title: '审核情况',
          text: '审核人：' + (currentRound > 1 ? '已审核' : (currentRound === 1 ? data.process : '未审核'))
        },
        2: {
          title: '分配情况',
          text: '调度中心：'  + (currentRound > 2 ? '已分配' : (currentRound === 2 ? data.process : '未分配'))
        },
        4: {
          title: '',
          text: '调度中心：' + (currentRound > 4 ? '已确认' : (currentRound === 4 ? data.process : '未确认'))
        },
        5: {
          title: '',
          text: '驻村干部：' + (currentRound > 5 ? '已落实' : (currentRound === 5 ? data.process : '待落实'))
        }
      };

      this.drawLine(this.stage, rect.width);
      this.drawCircle(this.stage, rect.width);
  }

  drawLine = (stage, width) => {
    const { data } = this.state;
    const containerWidth = width - padding * 2;
    const startX = (width - containerWidth) / 2;
    const endX = width - (width - containerWidth) / 2;
    const y = this.state.height / 2;

    if(this.match)
    {
      const num = this.match.num + 1;
      const cBetween = containerWidth/(num - 2);
      const branchX = startX + containerWidth - cBetween/2;
      const branchNum = data.departmentProcess && data.departmentProcess.length || 0;
      const layer = new Konva.Layer();
      if(this.match.num > 3)
      {
        if(data.departmentProcess && data.departmentProcess.length > 1)
        {
          const line = new Konva.Rect({
              x: startX,
              y: y - 1,
              width: cBetween * 3 - cBetween/2,
              height: 3,
              fillLinearGradientStartPoint: {
                  x: startX,
                  y: y - 1,
              },
              fillLinearGradientEndPoint: {
                  x: width - padding * 2,
                  y: y - 1
              },
              fillLinearGradientColorStops: [0, passColor, 1, colorRgb(passColor, '.4')]
          });
          layer.add(line);
          this.drawBranch(stage, width);
          this.drawBranchNode(stage, width, startX + cBetween * 3, y - (branchNum - 1) * between / 2);
        }else{
          const line = new Konva.Rect({
              x: startX,
              y: y - 1,
              width: containerWidth,
              height: 3,
              fillLinearGradientStartPoint: {
                  x: startX,
                  y: y - 1,
              },
              fillLinearGradientEndPoint: {
                  x: width - padding * 2,
                  y: y - 1
              },
              fillLinearGradientColorStops: [0, passColor, 1, colorRgb(passColor, '.4')]
          });

          this.drawBranchNode(stage, width, startX + cBetween * 3, y);
          layer.add(line);
        }
        stage.add(layer);
      }else{
        if(data.departmentProcess && data.departmentProcess.length > 1)
        {
          const line = new Konva.Rect({
              x: startX,
              y: y - 1,
              width: containerWidth - cBetween/2,
              height: 3,
              fillLinearGradientStartPoint: {
                  x: startX,
                  y: y - 1,
              },
              fillLinearGradientEndPoint: {
                  x: width - padding * 2,
                  y: y - 1
              },
              fillLinearGradientColorStops: [0, passColor, 1, colorRgb(passColor, '.4')]
          });
          layer.add(line);

          this.drawBranch(stage, width);

          stage.add(layer);

          this.drawBranchNode(stage, width, startX + containerWidth, y - (branchNum - 1) * between / 2);

        }else{
          const layer = new Konva.Layer();
          const line = new Konva.Rect({
              x: startX,
              y: y - 1,
              width: containerWidth,
              height: 3,
              fillLinearGradientStartPoint: {
                  x: startX,
                  y: y - 1,
              },
              fillLinearGradientEndPoint: {
                  x: width - padding * 2,
                  y: y - 1
              },
              fillLinearGradientColorStops: [0, passColor, 1, colorRgb(passColor, '.4')]
          });
          layer.add(line);
          stage.add(layer);
        }
      }
    }
  }

  drawBranch = (stage, width) => {
    const { data } = this.state;
    const containerWidth = width - padding * 2;
    const startX = (width - containerWidth) / 2;
    const endX = width - (width - containerWidth) / 2;
    const y = this.state.height / 2;
    const layer = new Konva.Layer();
    const num = this.match.num + 1;
    const cBetween = containerWidth/(num - 2);
    const branchX = startX + containerWidth - cBetween/2;
    const branchNum = data.departmentProcess && data.departmentProcess.length || 0;

    const mainBranch = new Konva.Rect({
        x: startX + cBetween * 2.5,
        y: y - (branchNum - 1) * between / 2,
        width: 3,
        height: (branchNum - 1) * between,
        fill: passColor
    });
    layer.add(mainBranch);

    for(let i = 0;i < branchNum;i++)
    {
      const branch = new Konva.Rect({
          x: startX + cBetween * 2.5,
          y: y - (branchNum - 1) * between / 2 + i * between - 1,
          width: cBetween / 2,
          height: 3,
          fillLinearGradientStartPoint: {
              x: startX + containerWidth - cBetween/2,
              y: y - (branchNum - 1) * between / 2 + i * between - 1
          },
          fillLinearGradientEndPoint: {
              x: startX + containerWidth,
              y: y - (branchNum - 1) * between / 2 + i * between - 1
          },
          fillLinearGradientColorStops: [0, passColor, 1, colorRgb(passColor, '.4')]
      });
      layer.add(branch);
    }

    stage.add(layer);
  }

  drawCircle = (stage, width) => {
    const { data } = this.state;
    const layer = new Konva.Layer();
    if(this.match)
    {
      const num = this.match.num;
      const containerWidth = width - padding * 2;
      const cBetween = containerWidth/(num - 1);
      const startX = (width - containerWidth) / 2;
      const endX = width - (width - containerWidth) / 2;
      const y = this.state.height / 2;
      if(data.departmentProcess && data.departmentProcess.length > 1)
      {
        for(let i = 0;i < num;i++)
        {
          if(i === 3)
          {

            continue;
          }
          const shadowCircle = new Konva.Circle({
            x: startX + i * cBetween,
            y: y,
            radius: shadowRadius,
            fill: colorRgb(i < num - 1 ? passColor : this.match.color, '.3'),
          });
          const circle = new Konva.Circle({
            x: startX + i * cBetween,
            y: y,
            radius,
            // fill: i < num - 1 ? passColor : match.color
            fillRadialGradientStartPoint: 0,
            fillRadialGradientStartRadius: 0,
            fillRadialGradientEndPoint: 0,
            fillRadialGradientEndRadius: radius,
            fillRadialGradientColorStops: [
              0, colorRgb(i < num - 1 ? passColor : this.match.color, '.2'),
              0.1, colorRgb(i < num - 1 ? passColor : this.match.color, '.2'),
              0.2 , colorRgb(i < num - 1 ? passColor : this.match.color, '.5'),
              1, i < num - 1 ? passColor : this.match.color
            ]
          });
          const circleBack = new Konva.Circle({
            x: startX + i * cBetween,
            y: y,
            radius,
            fill: '#ffffff'
          });

          this.drawText(stage, width, startX + i * cBetween, y, passMap[i]);

          layer.add(circleBack);
          layer.add(circle);
          layer.add(shadowCircle);
        }

      }else{
        for(let i = 0;i < num;i++)
        {
          if(i === 3)
          {
            continue;
          }
          const shadowCircle = new Konva.Circle({
            x: startX + i * cBetween,
            y: y,
            radius: shadowRadius,
            fill: colorRgb(i < num - 1 ? passColor : this.match.color, '.3'),
          });
          const circle = new Konva.Circle({
            x: startX + i * cBetween,
            y: y,
            radius,
            // fill: i < num - 1 ? passColor : match.color
            fillRadialGradientStartPoint: 0,
            fillRadialGradientStartRadius: 0,
            fillRadialGradientEndPoint: 0,
            fillRadialGradientEndRadius: radius,
            fillRadialGradientColorStops: [
              0, colorRgb(i < num - 1 ? passColor : this.match.color, '.2'),
              0.1, colorRgb(i < num - 1 ? passColor : this.match.color, '.2'),
              0.2 , colorRgb(i < num - 1 ? passColor : this.match.color, '.5'),
              1, i < num - 1 ? passColor : this.match.color
            ]
          });
          const circleBack = new Konva.Circle({
            x: startX + i * cBetween,
            y: y,
            radius,
            fill: '#ffffff'
          });

          this.drawText(stage, width, startX + i * cBetween, y, passMap[i]);

          layer.add(circleBack);
          layer.add(circle);
          layer.add(shadowCircle);
        }
      }
    }

    stage.add(layer);
  }

  drawText = (stage, width, x, y, obj, distance) => {
    distance = distance || 30
    const layer = new Konva.Layer();
    const title = new Konva.Text({
      x: x - textWidth/2,
      y: y - distance - fontSize,
      width: textWidth,
      align: 'center',
      text: obj.title,
      fontSize: fontSize,
      fill: passColor
    });
    const text = new Konva.Text({
      x: x - textWidth/2,
      y: y + distance,
      width: textWidth,
      align: 'center',
      text: obj.text,
      fontSize: fontSize,
      fill: '#000'
    });
    layer.add(title);
    layer.add(text);
    stage.add(layer);
  }

  drawBranchNode = (stage, width, x, y) => {
    const { data } = this.state;
    const nodes = data.departmentProcess;
    const layer = new Konva.Layer();
    const length = nodes && nodes.length || 0;

    for(let i = 0;i < length;i++)
    {
      const match = branchColor[nodes[i].process] || {};
      const circleBack = new Konva.Circle({
        x,
        y: y + i * between,
        radius,
        fill: '#ffffff'
      });
      const shadowCircle = new Konva.Circle({
        x,
        y: y + i * between,
        radius: shadowRadius,
        fill: colorRgb(match || passColor, '.3'),
      });
      const circle = new Konva.Circle({
        x,
        y: y + i * between,
        radius,
        fillRadialGradientStartPoint: 0,
        fillRadialGradientStartRadius: 0,
        fillRadialGradientEndPoint: 0,
        fillRadialGradientEndRadius: radius,
        fillRadialGradientColorStops: [
          0, colorRgb(match || passColor, '.2'),
          0.1, colorRgb(match || passColor, '.2'),
          0.2 , colorRgb(match || passColor, '.5'),
          1, match || passColor
        ]
      });
      if(this.match && this.match.num > 4)
      {
        const num = this.match.num;
        const containerWidth = width - padding * 2;
        const cBetween = containerWidth/(num - 1);
        if(nodes[i].process === '已解决')
        {
          this.drawNodeLine(stage, width, x, y + i * between);
        }
        if(this.match.num > 5)
        {
          const middleLine = new Konva.Rect({
              x: x + cBetween,
              y: this.state.height / 2 - 1,
              width: cBetween,
              height: 3,
              fillLinearGradientStartPoint: {
                x,
                y: y - 1,
              },
              fillLinearGradientEndPoint: {
                x: x + cBetween,
                y: y - 1,
              },
              fillLinearGradientColorStops: [0, passColor, 1, colorRgb(passColor, '.4')]
              // fill: passColor
          });
          layer.add(middleLine);
        }
      }
      layer.add(circleBack);
      layer.add(shadowCircle);
      layer.add(circle);

      this.drawText(stage, width, x, y + i * between, {
        text: nodes[i].department + '：' + nodes[i].process
      }, 20);
    }

    stage.add(layer);
  }

  drawNodeLine = (stage, width, x, y) => {
    const { data } = this.state;
    const branchNum = data.departmentProcess.length;
    const num = this.match.num;
    const containerWidth = width - padding * 2;
    const cBetween = containerWidth/(num - 1);
    const startX = (width - containerWidth) / 2;
    const endX = width - (width - containerWidth) / 2;
    const y1 = this.state.height / 2;
    const layer = new Konva.Layer();

    const line = new Konva.Rect({
        x,
        y: y - 1,
        width: Math.sqrt(cBetween * cBetween + (y - y1) * (y - y1)),
        height: 3,
        rotation: Math.atan2((y1 - y), cBetween) * 180/Math.PI,
        fillLinearGradientStartPoint: {
          x,
          y: y - 1,
        },
        fillLinearGradientEndPoint: {
          x: x + Math.sqrt(cBetween * cBetween + (y - y1) * (y - y1)),
          y: y - 1,
        },
        fillLinearGradientColorStops: [0, passColor, 1, colorRgb(passColor, '.4')]
        // fill: passColor
    });

    layer.add(line);
    stage.add(layer);

  }

	render() {
    const { height } = this.state;
		return (
			<div className={style.container} id="container" style={{height: height + 'px'}}>

			</div>
		)
	}
}

export default Process;

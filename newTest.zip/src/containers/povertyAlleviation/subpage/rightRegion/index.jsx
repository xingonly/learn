import React,{ Component } from 'react'
import style from './style.scss'
import common from '../../common.scss'
import { withRouter } from 'react-router-dom'
import { Trim } from '../../common'
import SearchRegion from '../searchRegion'
import Detail from '../detail'
import Pagination from '../../../../components/Pagination'
import resource from '../../../../util/resource'
import urlData from '../../config'
import noImg from '../images/noImg.png'
import moment from 'moment'
import NoData from '../../../../components/noData'
import Loadding from '../../../../components/Loading'

class App extends Component{
    constructor(props){
        super(props);
        this.loadding = true;
        this.detailData = null;
        this.roles = JSON.parse(sessionStorage.getItem('roles'));
        if(this.roles && this.roles[1] && this.roles[1] === 'USE_MANAGER_CENTER'){
            this.SelectData = ['任务进展','已分配','已关闭','已办理','已确认','已落实','未落实'];
            this.header = true; //header头切换 如果为true 显示调杜中心
            this.url = '/require/assigned'
        }else{
            this.SelectData = ['任务进展','已确认','已落实','未落实'];
            this.header = false;
            this.url = '/require/solved'
        }

        this.paramas = {
            fullName:'',
            commitName:'',
            page:0,
            size:7,
            sort:'',
            createTimeStart:null,
            createTimeEnd:null,
            process:'',
            department:''
        }
        this.state = {
            initData:[],
            total:0,
            current:1,
            showAlert:'',
            showDetail:false,
        };
    }
    handleAllocated = (data) => {
        this.paramas.page = 0;
        this.paramas.fullName = Trim(data.fullName,'g');
        if(data.commitName){
            this.paramas.commitName = data.commitName ? Trim(data.commitName,'g'):'';
            this.paramas.department = '';
        }else{
            this.paramas.commitName = '';
            this.paramas.department = data.department ? Trim(data.department,'g'):'';
        }
        this.paramas.createTimeStart = data.createTimeStart ? moment(data.createTimeStart).format('YYYY-MM-DD HH:mm:ss') :'';
        this.paramas.createTimeEnd = data.createTimeEnd ? moment(data.createTimeEnd).format('YYYY-MM-DD HH:mm:ss') :'';
        let state = this.state;
        state.current = 1;
        this.loadding = true;
        state.initData = [];
        this.setState(state,() => {
            this.getInitData();
        });
    }

    handlePageChange = (page,size) => {
        let state = this.state;
        state.current = page;
        this.paramas.page = page - 1;
        state.initData = [];
        this.loadding = true;
        this.setState(state,() => {
            this.getInitData()
        })
    }

    componentWillMount(){
        this.getInitData();
    }

    getInitData = () => {
    let {fullName,commitName,page,size,createTimeEnd,createTimeStart,process,department} = this.paramas;
    let url = `page=${page}&size=${size}`;
    if(fullName){
        url += `&fullName=${fullName}`
    }
    if(commitName){
        url += `&commitName=${commitName}`
    }
    if(createTimeEnd){
        url += `&createTimeEnd=${createTimeEnd}`
    }
    if(createTimeStart){
        url += `&createTimeStart=${createTimeStart}`
    }
    if(process){
        url += `&process=${process}`
    }
    if(department){
            url += `&department=${department}`
    }
    resource.get(`${urlData}${this.url}?${url}&sort=id,desc`).then((res) => {
        let state = this.state;
        this.loadding = false;
        if(res.status === 200){
            state.initData = res.data && res.data.content.length > 0 ? res.data.content:[];
            state.total = res.data && res.data.totalElements ? res.data.totalElements:0;
        }
        this.setState(state);
    })
}

    handleToDetail = (status,data) => {
        let state = this.state;
        state.showDetail = status;
        this.detailData = data ? data :null;
        this.setState(state);
    }

    handleStatus = (e) =>{
        this.paramas.process = e.target.value === '任务进展' ? '' : e.target.value;
        let state = this.state;
        state.initData = [];
        this.loadding = true;
        state.current = 1;
        this.paramas.page = 0;
        this.setState(state,() => {
            this.getInitData();
        });
    }

    handleError = (e) => {
        e.target.src = noImg;
    }

    render(){
        let {size} = this.paramas;
        let {current,initData,total,showDetail} = this.state;
        let len = initData.length;
        return(
            <div className={style.box}>
                {
                    showDetail ?
                        <Detail
                            handleToDetail={this.handleToDetail}
                            initData={this.detailData}
                            handleInitData={() => {this.getInitData()}}
                        />
                        :
                        <div className={style.container}>
                            <SearchRegion
                                title={this.header ? "已分配" :'已办理'}
                                handleOk={this.handleAllocated}
                                type={true}
                            />
                            <div className={common.tableRegion}>
                                <table>
                                    <thead>
                                    {
                                        this.header ?
                                            <tr>
                                                <td></td>
                                                <td>姓名</td>
                                                <td>需求名称</td>
                                                <td>反馈干部</td>
                                                <td>反馈日期</td>
                                                <td>
                                                    <select
                                                        className={style.select}
                                                        onChange={this.handleStatus}
                                                    >
                                                        {
                                                            this.SelectData.map((obj,index) => {
                                                                return (
                                                                    <option key={index} value={obj}>
                                                                        {obj}
                                                                    </option>
                                                                )
                                                            })
                                                        }
                                                    </select>
                                                </td>
                                                <td></td>
                                            </tr> :
                                            <tr>
                                                <td></td>
                                                <td>户主姓名</td>
                                                <td>需求名称</td>
                                                <td>反馈干部</td>
                                                <td>分配日期</td>
                                                <td>任务进展</td>
                                                <td></td>
                                            </tr>
                                    }
                                    </thead>
                                    <tbody>
                                    {
                                        len  && !this.loadding? initData.map((obj,index) => {
                                            return (
                                                <tr key={index}>
                                                    <td  style={{width:'80px'}}>
                                                        <img src={obj.headPic ? obj.headPic : noImg}
                                                             onError={this.handleError} alt=""/>
                                                        <i style={{left:0}}></i>
                                                    </td>
                                                    <td>{obj.fullName || '---'}</td>
                                                    <td>{obj.requireName|| '---'}</td>
                                                    <td>{obj.commitName|| '---'}</td>
                                                    <td>{obj.createTime ? moment(obj.createTime).format('YYYY-MM-DD') :'---'}</td>
                                                    <td>{obj.process|| '---'}</td>
                                                    <td
                                                        style={{width:'80px'}}
                                                    >
                                                    <span style={{color:'#57b0b9',cursor:'pointer'}}
                                                          onClick={() => this.handleToDetail(true,obj)}
                                                    >详情</span>
                                                        <i style={{right:0}}></i></td>
                                                </tr>
                                            )
                                        }):''
                                    }
                                    </tbody>
                                </table>
                                {
                                    !len && !this.loadding    ?  <NoData/> : ''
                                }

                                {
                                    this.loadding ? <Loadding/> :''
                                }
                                {
                                    total ?
                                        <div className={common.pagination}>
                                            <span className={style.total}>共计{total}条数据</span>
                                            <Pagination
                                                total={total}
                                                current={current}
                                                size={size}
                                                start={1}
                                                onChange={this.handlePageChange}
                                            />
                                        </div> :''
                                }

                            </div>
                        </div>
                }
            </div>
        )
    }
}
export default withRouter(App)

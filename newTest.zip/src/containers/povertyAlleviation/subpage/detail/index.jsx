import React,{ Component } from 'react'
import style from './style.scss'
import { withRouter } from 'react-router-dom'
import Header from '../header'
import goBack from '../images/return.png'
import Popup from '../allocateContinue'
import urlData from '../../config'
import ShowImage from '../../../../components/showImage'
import resource from '../../../../util/resource'
import NoData from '../../../../components/noData'
import Loadding from '../../../../components/Loading'
import Process from '../process'
import {message} from 'antd'

class App extends Component{
    constructor(props){
        super(props);
        this.loadding = true;
        this.state = {
            newData:[],
            initData:{},
            showBottom:false,
        };

        this.roles = JSON.parse(sessionStorage.getItem('roles'));
        if(this.roles && this.roles[1] && this.roles[1] === 'USE_MANAGER_CENTER'){
            this.header = true; //header头切换 如果为true 显示调杜中心
        }else{
            this.header = false;
        }
    }
    handleToDetail = (status) => {
        if(this.props.handleToDetail){
            this.props.handleToDetail(status)
        }
    }

    getInitLog = () => {
        resource.get(`${urlData}/require/operates/${this.props.initData.id}`).then((res) => {
            let state = this.state;
            this.loadding = false;
            if(res.status === 200){
                state.newData = res.data.length > 0 ? res.data:[];
            }
            this.setState(state);
        })
    }

    getInitData = () => {
        resource.get(`${urlData}/require/detail/${this.props.initData.id}`).then((res) => {
            let state = this.state;
            this.loadding = false;
            if(res.status === 200){
                state.initData = res.data ? res.data:{};
                state.showBottom = res.data && (res.data.process === '已办理' || res.data.process === '已分配') ? true:false
            }
            this.setState(state);
        })
    }

    handleSure = () => {
        if(this.state.initData.process !== '已办理'){
            return
        }
        resource.put(`${urlData}/require/confirm/${this.props.initData.id}`,{}).then((res) => {
            let state = this.state;
            this.loadding = false;
            if(res.status === 200){
                this.handleOk()
                message.success('操作成功')
            }else{
                message.info(res.message)
            }
            this.setState(state);
        })
    }

    componentWillMount(){
        this.getInitLog();
        this.getInitData();
    }

    handleCancel = (e) => {
        let state = this.state;
        state.showAlert = '';
        this.setState(state);
    }

    handleTo = () => {
        let state = this.state;
        state.showAlert = <Popup
            handleCancel={this.handleCancel}
            handleOk={this.handleOk}
            status={true}
            detail={this.state.initData}
        />
        this.setState(state);
    }

    handleOk = () => {
        this.getInitData();
        this.getInitLog();
        this.handleCancel();
        if(this.props.handleInitData){
            this.props.handleInitData();
        }
    }


    handlePicture = (url) => {
        let state = { ...this.state };
        state.showAlert = <ShowImage handleClose = { () => this.handleCancel() } url={url}/>;
        this.setState(state);
    }

    handleText = (item, num) => {
        let text1;
        if (!item) {
            text1 = '--';
        } else if (item.length > num) {
            text1 = item.substring(0, num) + '...';
        } else {
            text1 = item;
        }
        return text1;
    }

    handleShow = (str) => {
        let state = this.state;
        state[str] = 1;
        this.setState(state);
    }

    handleData = (status) => {
        let operation = '';
        switch (status){
            case '0': operation = '未脱贫';break;
            case '1': operation = '已脱贫';break;
            case '2': operation = '预脱贫';break;
            case '3': operation = '返贫';break;
            default:operation = '---'
        };

        return operation
    }

    render(){
        let {showAlert,newData,showBottom,initData} = this.state;
        let len = newData.length;
        return(
            <div className={style.box}>
                <div className={style.header}>
                    <span
                        className={style.back}
                        onClick={() => this.handleToDetail(false)}
                    ><img src={goBack} alt=""/>返回</span>
                    需求分配详情
                </div>
                <div className={style.container}>
                    <div className={style.needDetail}>
                        <Header
                            fontSize="18px"
                            margin={true}
                            showBold={false}
                        >需求详情
                            {
                                initData.requirePic ?
                                    <span className={style.checkDetail}
                                          onClick={() => this.handlePicture(initData.requirePic)}
                                          style={{display:this.state.requirePic ? 'none':'block'}}
                                    >需求图片查看</span>:''
                            }
                            <img src={initData.requirePic} alt=""
                                 style={{display:'none'}}
                                 onError={() => {
                                     this.handleShow('requirePic')
                                 }}
                            />

                        </Header>
                        <div className={style.needContent}>
                            <dl>
                                <dt
                                style={{width:'18%'}}
                                >姓名：</dt>
                                <dd>{initData.fullName || '---'}</dd>
                            </dl>
                            <dl>
                                <dt>家庭住址：</dt>
                                <dd>
                                    <span>{initData.address || '---'}</span>
                                </dd>
                            </dl>
                            <dl>
                                <dt>贫困状态：</dt>
                                <dd>{ this.handleData(initData.poorStatus)}</dd>
                            </dl>
                            <dl>
                                <dt>致贫原因：</dt>
                                <dd>
                                    <span>{initData.poorCause || '---'}</span>
                                </dd>
                            </dl>
                            <dl>
                                <dt>需求名称：</dt>
                                <dd>{initData.requireName || '---'}</dd>
                            </dl>
                            <dl>
                                <dt>需求详情：</dt>
                                <dd><span>{initData.requireDetail || '---'}</span></dd>
                            </dl>
                            <dl>
                                <dt>反馈干部：</dt>
                                <dd>{initData.commitName || '---'}</dd>
                            </dl>
                            <dl>
                                <dt>反馈时间：</dt>
                                <dd>{initData.createTime || '---'}</dd>
                            </dl>
                        </div>
                    </div>
                    <div className={style.helpProgress}>
                        <Header
                            fontSize="18px"
                            margin={true}
                            showBold={false}
                        >帮扶进展
                            {
                                initData.implementPic ?
                                    <span className={style.checkDetail}
                                          onClick={() => this.handlePicture(initData.implementPic)}
                                          style={{display:this.state.implementPic ? 'none':'block'}}
                                          ref="implementPic"
                                    >落实图片查看</span>:''
                            }
                            <img src={initData.implementPic} alt=""
                                 style={{display:'none'}}
                                 onError={() => {
                                     this.handleShow('implementPic')
                                 }}
                            />

                        </Header>
                        <div className={style.helpContent}>
                            <Process data={this.state.initData}/>
                        </div>
                    </div>
                    <div className={style.record}>
                        <Header
                            fontSize="18px"
                            margin={true}
                            showBold={false}
                        >历史记录</Header>
                        <div className={style.recordContent}>
                            <table>
                            <thead>
                            <tr>
                                <td>操作情况</td>
                                <td>说明情况</td>
                                <td>操作时间</td>
                            </tr>
                            </thead>
                            <tbody>
                            {
                                len  && !this.loadding? newData.map((obj,index) => {
                                    return (
                                        <tr key={index}>
                                            <td>{obj.operator ?  (obj.operator + '：' + obj.operation):'---'}</td>
                                            <td>
                                                <span title={obj.remark}>
                                                {this.handleText(obj.remark,15)}
                                                </span>
                                             </td>
                                            <td>{obj.operateTime|| '---'}</td>
                                        </tr>
                                    )
                                }):''
                            }
                            </tbody>
                        </table>
                            {
                                !len && !this.loadding    ?  <NoData/> : ''
                            }

                            {
                                this.loadding ? <Loadding/> :''
                            }
                        </div>
                    </div>
                    <div
                        className={style.bottom}
                        style={{display:this.header ? (showBottom ? 'block':'none') : 'none'}}
                    >
                        <span
                            onClick={() => this.handleTo()}
                        >继续分配</span>
                        <span
                            onClick={this.handleSure}
                            className={style[initData.process !== '已办理' ? 'notActive': 'active']}
                        >情况确认</span>
                    </div>
                </div>
                {showAlert}
            </div>
        )
    }
}
export default withRouter(App)

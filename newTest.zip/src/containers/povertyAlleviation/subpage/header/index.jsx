import React,{ Component } from 'react'
import style from './style.scss'
import { withRouter } from 'react-router-dom'
import munu from '../images/munu.png'

class App extends Component{
    render(){
        return(
            <div className={style.box}
                 style={{
                     fontSize: this.props.fontSize ? this.props.fontSize:'',
                     fontWeight:this.props.showBold ? 'bold':'normal',
                     margin:this.props.margin ? '0':''
                 }}
            ><img src={munu}/>{this.props.children}</div>
        )
    }
}
export default withRouter(App)
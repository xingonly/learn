import React,{ Component } from 'react'
import style from './style.scss'
import common from '../../common.scss'
import { withRouter } from 'react-router-dom'
import SearchRegion from '../searchRegion'
import Pagination from '../../../../components/Pagination'
import resource from '../../../../util/resource'
import urlData from '../../config'
import noImg from '../images/noImg.png'
import Popup from '../primary'
import NoData from '../../../../components/noData'
import moment from 'moment'
import Loadding from '../../../../components/Loading'
import { Trim } from '../../common'
import backpoverty from '../images/backpoverty.png'
import outofpoverty from '../images/outofpoverty.png'
import poverty from '../images/poverty.png'
import prepoverty from '../images/prepoverty.png'

class App extends Component{
    constructor(props){
        super(props);
        this.roles = JSON.parse(sessionStorage.getItem('roles'));
        if(this.roles && this.roles[1] && this.roles[1] === 'USE_MANAGER_CENTER'){
            this.header = true; //header头切换 如果为true 显示调杜中心
            this.url = '/require/waitingAssign';
            this.HeaderData = ['','姓名','需求名称','反馈干部','反馈日期','贫困状态',''];
        }else{
            this.header = false;
            this.url = '/require/waitingSolve';
            this.HeaderData = ['','户主姓名','需求名称','反馈干部','分配日期','贫困状态',''];
        }
        this.loadding = true;
        this.paramas = {
            fullName:'',
            commitName:'',
            page:0,
            size:7,
            sort:'',
            createTimeStart:null,
            createTimeEnd:null
        }
        this.state = {
            initData:[],
            total:0,
            current:1,
            showAlert:'',
        };
    }
    handleAllocated = (data) => {
        this.paramas.page = 0;
        this.paramas.fullName = Trim(data.fullName,'g');
        this.paramas.commitName = Trim(data.commitName,'g');
        this.paramas.createTimeStart = data.createTimeStart ? moment(data.createTimeStart).format('YYYY-MM-DD HH:mm:ss') :'';
        this.paramas.createTimeEnd = data.createTimeEnd ? moment(data.createTimeEnd).format('YYYY-MM-DD HH:mm:ss') :'';
        let state = this.state;
        state.current = 1;
        state.initData = [];
        this.loadding = true;
        this.setState(state,() => {
            this.getInitData();
        });
    }
    handlePageChange = (page,size) => {
        let state = this.state;
        state.current = page;
        this.paramas.page = page - 1;
        this.loadding = true;
        state.initData = [];
        this.setState(state,() => {
            this.getInitData()
        })
    }
    componentWillMount(){
        this.getInitData();
    }
    getInitData = () => {
        let {fullName,commitName,page,size,createTimeEnd,createTimeStart} = this.paramas;
        let url = `page=${page}&size=${size}`;
        if(fullName){
            url += `&fullName=${fullName}`
        }
        if(commitName){
            url += `&commitName=${commitName}`
        }
        if(createTimeEnd){
            url += `&createTimeEnd=${createTimeEnd}`
        }
        if(createTimeStart){
            url += `&createTimeStart=${createTimeStart}`
        }
        resource.get(`${urlData}${this.url}?${url}&sort=id,desc`).then((res) => {
            let state = this.state;
            this.loadding = false;
            if(res.status === 200){
                state.initData = res.data && res.data.content.length > 0 ? res.data.content:[];
                state.total = res.data && res.data.totalElements ? res.data.totalElements:0;
            }
            this.setState(state);
            this.setState({
                detail:res.data&&res.data.content
            });
        })
    }

    handleCancel = (e) => {
        let state = this.state
        state.showAlert = '';
        this.setState(state);
    }

    handleTo = (obj) => {
        let state = this.state;
        state.showAlert = <Popup
            handleCancel={this.handleCancel}
            handleOk={this.handleOk}
            status={true}
            detail={obj}
        />
        this.setState(state);
    }

    handleOk = () => {
        this.getInitData();
        this.handleCancel();
        if(this.props.handleInitData){
            this.props.handleInitData()
        }
    }

    handleError = (e) => {
        e.target.src = noImg;
    }
    render(){
        let {size} = this.paramas;
        let {current,initData,total,showAlert} = this.state;
        let len = initData.length;
        return(
            <div className={style.box}>
                    <div className={style.container}>
                        <SearchRegion
                            title={this.header ? "待分配" : '待办理'}
                            handleOk={this.handleAllocated}
                        />
                        <div className={common.tableRegion}>
                            <table>
                                <thead>
                                <tr>
                                    {
                                        this.HeaderData.map((obj,index) => {
                                            return(
                                                <td key={index}>
                                                    {obj}
                                                </td>
                                            )
                                        })
                                    }
                                </tr>
                                </thead>
                                <tbody>
                                {
                                    len && !this.loadding  ? initData.map((obj,index) => {
                                        let operation = '';
                                        switch (obj.poorStatus){
                                            case '0': operation = poverty ;break;
                                            case '1': operation = outofpoverty ;break;
                                            case '2': operation = prepoverty;break;
                                            case '3': operation = backpoverty;break;
                                            default: operation = '---';
                                        };
                                        return (
                                            <tr key={index}>
                                                <td  style={{width:'80px'}}>
                                                    <img
                                                        src={obj.headPic ? obj.headPic : noImg}
                                                        onError={this.handleError}
                                                        alt=""
                                                    />
                                                    <i style={{left:0}}></i>
                                                </td>
                                                <td>{obj.fullName || '---'}</td>
                                                <td>{obj.requireName|| '---'}</td>
                                                <td>{obj.commitName|| '---'}</td>
                                                <td>{obj.createTime ? moment(obj.createTime).format('YYYY-MM-DD') :'---'}</td>
                                                <td>
                                                    {
                                                        operation ?
                                                        <img
                                                            src={operation} alt=""
                                                            className={style.imgData}
                                                            style={{width:'80px',height:'32px'}}
                                                        />: '---'
                                                    }
                                                </td>
                                                <td
                                                    style={{width:'80px'}}
                                                >
                                                    <span style={{color:'#57b0b9',cursor:'pointer'}}
                                                          onClick={() => this.handleTo(obj)}
                                                    >
                                                        {
                                                            this.header ? '任务分配' : '任务办理'
                                                        }
                                                    </span>
                                                    <i style={{right:0}}></i></td>
                                            </tr>
                                        )
                                    }):''
                                }
                                </tbody>
                            </table>
                            {
                                !len && !this.loadding    ?  <NoData/> : ''
                            }

                            {
                                this.loadding ? <Loadding/> :''
                            }
                            <div className={common.pagination}>
                                {
                                    total ?
                                        <Pagination
                                            total={total}
                                            current={current}
                                            size={size}
                                            start={1}
                                            onChange={this.handlePageChange}
                                        />:''
                                }
                            </div>
                        </div>
                    </div>
                {showAlert}
            </div>
        )
    }
}
export default withRouter(App)

import React, {Component} from 'react';
import style from './style.scss';
import {Modal,message} from 'antd';
import resource from "resource";
import urlData from '../../config'

export default class DemandManageAllocated extends Component {

    constructor(props) {
        super(props);
        this.paramas= {
            "departments": [],
            "remark": ""
        }
        this.initSelectData = [
            {
                name:'扶贫办',
                selected: false,
                status:false
            },{
                name:'教育局',
                selected: false,
                status:false
            },{
                name:'金融办',
                selected: false,
                status:false
            },{
                name:'工商联',
                selected: false,
                status:false
            },{
                name:'残联',
                selected: false,
                status:false
            },{
                name:'民政局',
                selected: false,
                status:false
            },{
                name:'人社局',
                selected: false,
                status:false
            },{
                name:'水务局',
                selected: false,
                status:false
            },{
                name:'交通局',
                selected: false,
                status:false
            },{
                name:'卫计局',
                selected: false,
                status:false
            },{
                name:'移民局',
                selected: false,
                status:false
            },{
                name:'住建局',
                selected: false,
                status:false
            },{
                name:'国土办',
                selected: false,
                status:false
            },{
                name:'招生办',
                selected: false,
                status:false
            },{
                name:'农业局',
                selected: false,
                status:false
            }
        ];
        this.selectedData = [];//初始化已选择得数据
        this.state={
            detail:[],
            dpartment:this.initSelectData,
            textvalue:'',
            parama:'',
            myData:[]
        }
    }
    componentDidMount(){
        this.continueAllocate()
    }

    continueAllocate=()=>{
        let {detail} = this.props;
        let state = this.state;
        let details=detail.departmentProcess && detail.departmentProcess.length > 0 ? detail.departmentProcess:[];
        details.map((obj,index) => {
            this.selectedData.push(obj.department)
            state.dpartment.map((o,i) =>{
                if(obj.department === o.name){
                    o.status = true;
                }
            })
        })
        this.setState(state);
        /*
        for(let i=0;i<details.length;i++){
            for(let j=0;j< this.initSelectData.length;j++){
                if(details[i].department=== this.initSelectData[j].name){
                    this.initSelectData[j].status=true
                    this.setState({
                        // status:true
                    })
                }
            }
        }*/
    }

    textvalueChange=(e)=>{
        if(e.target.value.length<120){
            this.setState({
                textvalue:e.target.value,
            })
        }else{
            e.target.value=false
        }

    }

    handleData = () => {
        let state = this.state;
        let data = [];
        state.dpartment.map((obj, index) => {
            if(obj.selected){
                data.push(obj.name);
            }
        });

        let newData = this.selectedData.concat(data);
        return newData;
    };

    clickDepartment=(e,index)=>{
        let state = this.state;
        if(state.dpartment[index].status){
            return
        }
        state.dpartment[index].selected = !state.dpartment[index].selected;
        this.setState(state)
    }

    handleOk = (e) => {
        let state = this.state;
        let data = [];
        state.dpartment.map((obj, index) => {
            if(obj.selected){
                data.push(obj.name);
            }
        });
        let myData=data
        this.paramas.departments = this.handleData();
        this.paramas.remark = this.state.textvalue;
            if(this.state.textvalue && this.paramas.departments.length && myData.length){
                this.getAllocated();
            }else{
                message.info('请选择部门和输入需求任务意见')
            }


    }

    getAllocated = () =>{
        this.paramas= {
            "departments": this.paramas.departments,
            "remark": this.paramas.remark
        };

        resource.put(`${urlData}/require/assign/${this.props.detail.id}`,this.paramas).then((res)=>{
            if(res.status === 200){
                if(this.props.handleOk){
                    this.props.handleOk();
                }
            }else{
                message.info(res.message)
            }
        })
    };


    handleCancel = (e) => {
        if(this.props.handleCancel){
            this.props.handleCancel()
        }
        this.setState({
            parama:this.state.remark
        })
    };

    render() {
        let {detail} = this.props
        return (
            <Modal
                footer={null}
                width={550}
                visible={true}
                onCancel={this.handleCancel}
            >
                <div className={style.popup}>
                    <div className={style.total}>任务分配</div>
                        <div className={style.popupcontent}>
                            <div className={style.divide}>
                                <div>
                                    <span>姓名：</span>
                                    <span>{detail.fullName||'---'}</span>
                                </div>
                                <div>
                                    <span>贫困状态：</span>
                                    <span>{detail.poorStatus===0?'未脱贫':detail.poorStatus===1?'已脱贫':detail.poorStatus===2?'预脱贫':detail.poorStatus===3?'返贫':'---'}</span>
                                </div>
                                <div>
                                    <span>需求名称：</span>
                                    <span>{detail.requireName||'---'}</span>
                                </div>
                                <div>
                                    <span>反馈干部：</span>
                                    <span>{detail.commitName||'---'}</span>
                                </div>

                            </div>
                            <div  className={style.divide}>
                                <div>
                                    <span>家庭住址：</span>
                                    <span>{detail.address||'---'}</span>
                                </div>
                                <div>
                                    <span>致贫原因：</span>
                                    <span>{detail.poorCause||'---'}</span>
                                </div>
                                <div>
                                    <span>需求详情：</span>
                                    <span>{detail.requireDetail||'---'}</span>
                                </div>
                                <div>
                                    <span>反馈时间：</span>
                                    <span>{detail.createTime||'---'}</span>
                                </div>

                            </div>
                        </div>
                    <div className={style.popuptotal}>选择办理部门</div>
                    <ul className={style.department} style={{}}>
                        {
                            this.state.dpartment.map((item,index)=>{
                                return(
                                    <li
                                        style={{
                                            background:item.status ? '#ccc':(item.selected ? '#5BBCB5':'')  ,
                                            color:item.status?'#fff':(item.selected ? '#fff':'')
                                        }}
                                        key={index}
                                        className={item.status?style.active:style.departmentson}
                                        onClick={(e)=>this.clickDepartment(e,index)}

                                    >
                                        {item.name}
                                    </li>
                                )
                            })
                        }
                        <div>
                            <textarea
                                className={style.mytext}
                                rows="4"
                                cols="71"
                                placeholder='需求任务意见（120字以内）'
                                value={this.state.textvalue}
                                onChange={this.textvalueChange}
                            ></textarea>
                        </div>
                    </ul>
                    <div className={style.scbtn}>
                        <button
                            onClick={this.handleOk}
                            className={style.close}
                        >
                            确认分配
                        </button>
                    </div>

                </div>
            </Modal>

        )
    }
}
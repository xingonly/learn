import React,{ Component } from 'react'
import style from './style.scss'
import { withRouter } from 'react-router-dom'
import Header from './subpage/header'
import LeftRegin from './subpage/leftRegion'
import RightRegion from './subpage/rightRegion'

class App extends Component{
    handleInitData = (data) => {
        if(this.refs.getInitData){
            this.refs.getInitData()
        }
    }
    render(){
        return(
            <div className={style.box}>
                <Header showBold={true}>菜单扶贫</Header>
                <div className={style.container}>
                    <div className={style.left}>
                        <LeftRegin
                            handleInitData={this.handleInitData}
                        />
                    </div>
                    <div className={style.right}>
                        <RightRegion
                            ref="rightRegion"
                        />
                    </div>
                </div>
            </div>
        )
    }
}
export default withRouter(App)
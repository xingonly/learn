import React, { Component } from 'react';
import style from './index.scss';
import MySelect from '../../components/MySelect';
import resource from '../../util/resource';
import createHistory from 'history/createHashHistory';
const history = createHistory();

export default class ObjectSearchEnter extends Component {
    constructor() {
        super();
        this.state = {
            zhou: '乡/镇',
            zhouId: '',
            xian: '村/社区',
            xianId: '',
            content: [],
            optionsZhou: [],
            optionsXian: [],
            //西秀区
            provinceId: '520402000000',
            power: JSON.parse(sessionStorage.getItem('manager')),
        }
    }
    componentDidMount() {
      sessionStorage.removeItem('ID');
        this.getProvinceId()
    }
    getProvinceId = () => {
        resource.get(`/xixiu-server/region/getRegionByParentid/${this.state.provinceId}`).then((res) => {
            if(res.status !== 200) {
                console.log(res.message)
            }else {
                let optionsZhou = []
                for(let item of res.data) {
                    let data = {
                        value: item.id,
                        label: item.name
                    }
                    optionsZhou.push(data)
                }
                // optionsZhou.unshift({value: '',label: '乡/镇'});
                let powerShi = this.state.power.shi
                for(let ite of optionsZhou) {
                    if(powerShi !== null&&ite.value === powerShi) {
                        optionsZhou = [{
                            value: ite.value,
                            label: ite.label,
                        }]
                    }
                }
                this.setState({
                    optionsZhou: optionsZhou
                })
            }
        })
    };
    xianRequire = () => {
        resource.get(`/xixiu-server/region/getRegionByParentid/${this.state.provinceId}`).then((res) => {
            if(res.status !== 200) {
                console.log(res.message)
            }else {
                let optionsXian = []
                for(let item of res.data) {
                    let data = {
                        value: item.id,
                        label: item.name
                    }
                    optionsXian.push(data)
                }
                // optionsXian.unshift({value: '',label: '请选择'})
                let powerXian = this.state.power.xian
                for(let ite of optionsXian) {
                    if(powerXian !== null&&ite.value === powerXian) {
                        optionsXian = [{
                            value: ite.value,
                            label: ite.label,
                        }]
                    }
                }
                this.setState({
                    optionsXian: optionsXian
                })
            }
        })
    };
    handleClickZhou = (value,name) => {
        let label = value.label
        let v = value.value
        this.setState({
            provinceId: v
        },() => {
            this.xianRequire()
        });
        this.setState({
            [name]: label,
            zhouId: v,
            xian: '村/社区',
            inputValue: '',
            page: 0,
            content: [],
            optionsXian: [],
            optionsZhen: [],
            optionsCun: [],
        })
    };
    handleClickXian = (value,name) => {
        let label = value.label;
        let v = value.value;
        this.setState({
            provinceId: v
        });
        this.setState({
            [name]: label,
            xianId: v,
            inputValue: '',
            page: 0,
            content: [],
            optionsZhen: [],
            optionsCun: [],
        })
    };
    searchXiXiu = () => {
        this.setState({
            zhou: '乡/镇',
            xian: '村/社区',
            inputValue: '',
            page: 0,
            content: [],
            // optionsZhou: [],
            optionsXian: [],
            optionsZhen: [],
            optionsCun: [],
        })
    };
    changeInput = (e) => {
        this.setState({
            inputV: e.target.value
        })
    };
    handleSearch = () => {
        let keyWord = {
            inputValue: this.state.inputV,
            region: {
                shi: this.state.zhouId,
                xian: this.state.xianId
            }
        };
        sessionStorage.setItem('keyWord', JSON.stringify(keyWord));
        history.push('/main/object/objectSearch');
    };
    render() {
        return (
            <div className={style['enter']}>
                <div className={style['searchContainer']}>
                    <header>
                        <input onChange={this.changeInput} placeholder='请输入身份证号或姓名全称' />
                        <span onClick={this.handleSearch}>搜索</span>
                    </header>
                    <div className={style['region']}>
                        <span>地区：</span>
                        <ul>
                            <li style={{verticalAlign: 'top'}}>
                                <span onClick={this.searchXiXiu} className={style['type-select']}>
                                    西秀区
                                </span>
                            </li>
                            <li>
                                <MySelect
                                    value={this.state.zhou}
                                    options={this.state.optionsZhou}
                                    handleClick={this.handleClickZhou}
                                    name="zhou"
                                />
                            </li>
                            <li>
                                <MySelect
                                    value={this.state.xian}
                                    options={this.state.optionsXian}
                                    handleClick={this.handleClickXian}
                                    name="xian"
                                />
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        )
    }
}

import React, {Component} from 'react';
import { NavLink } from 'react-router-dom';
import style from './style.scss';

export default class Data extends Component {

    constructor(props) {
        super(props);

    }

    render() {
        return (
            <section id={style['data']}>
                {this.props.children}
                <div className={style.choice}>
                    <NavLink to="/main/dataAnalysis/data/statistics" activeClassName={style.active} />
                    <NavLink to="/main/dataAnalysis/data/index" activeClassName={style.active} />
                </div>
            </section>
        )
    }
}
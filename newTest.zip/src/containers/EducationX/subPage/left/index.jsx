// 上帝保佑,永无bug
import React, {Component} from "react";
import echarts from 'echarts';
import Datetime from 'react-datetime';
import resource from '../../../../util/resource';
import style  from './style.scss';
import Title from '../../../../components/Title'

export default class LeftBbd extends Component {
    constructor(props){
        super(props);
        this.ctrlClass = style.active;
        let year = (new Date().getFullYear() - 1).toString();
        this.districtCode = 520000000000;
        this.state = {
            dockingDate: year,
            listMap: []
        }
    }
    componentDidMount = () => {
        this.getTableList(this.districtCode);
        this.getChartData();
    };

    getData = (id) =>{
        this.districtCode = id;
        this.getTableList();
        this.getChartData();
    };

    getTableList = ()=>{
        let districtCode = this.districtCode;
        let years = this.state.dockingDate;
        resource.post('/xixiu-server/third/education/educationLevel',{districtCode,years}).then((res)=>{
            if(res.status === 200){
                this.setState({
                    listMap: res.data,
                    type: res.data[0].category
                },()=>{
                    this.propsSetRight();
                });
            }else{
                this.setState({
                    listMap: []
                });
                this.propsSetRight();
            }
        })
    };

    getChartData = ()=>{
        let districtCode = this.districtCode;
        let years = this.state.dockingDate;
        resource.post('/xixiu-server/third/education/offerType',{districtCode,years}).then((res)=>{
            if(res.status === 200){
                this.drawChart(res.data);
            }
        })
    };

    //设置日期
    setDate = (i,moment) => {
        let y = moment._d.getFullYear();
        this.setState({
            dockingDate: y.toString()
        },()=>{
            this.getTableList();
            this.getChartData();
            this.propsSetRight();
        });
    };

    setType =(e,item)=>{
        return;
        if(item.category === '合计'){
            return;
        }else{
            this.setState({
                type: item.category
            },()=>{
                this.propsSetRight();
            });
            document.querySelectorAll('.'+this.ctrlClass)[0].className = '';
            e.currentTarget.className = this.ctrlClass;
        }
    };

    propsSetRight = ()=>{
        let obj={};
        obj.code = this.districtCode;
        obj.year = this.state.dockingDate;
        obj.type = this.state.type || '本科';
        this.props.timeChange(JSON.stringify(obj));
    };

    drawChart = (data)=>{
        let  myChart = echarts.init(document.getElementById('bar'));
        myChart.setOption(this.setOption(data));
    };

    setOption = (data, zoom) => {
        let dataX = [],
            dataY = [];
        for(let i = 0; i< data.length; i++){
            dataX.push(data[i].subject_type);
            dataY.push(data[i].count);
        }
        let option={
            tooltip:{
                trigger: 'axis',
                axisPointer : {
                    type : 'shadow'
                }
            },
            grid: {
                bottom: '25%'
            },
            xAxis:{
                data:dataX,
                axisLine: {
                    lineStyle: {
                        color: '#eaeaea',
                        width: 1
                    }
                },
                splitLine: {
                    lineStyle: {
                        color: '#eaeaea',
                        width: 2
                    }
                },
                axisTick:{
                    show: false
                },
                axisLabel: {
                    rotate: -45,
                    interval: 0,
                    margin: 15,
                    textStyle: {
                        color:'#717171'
                    }
                }
            },
            yAxis:{
                name: '单位: 人',
                nameTextStyle: {
                    color: '#717171',
                    fontSize: 14
                },
                axisLine: {
                    show: false
                },
                axisTick: {
                    show: false
                },
                splitLine: {
                    lineStyle: {
                        color: '#f7f7f7'
                    }
                },
                axisLabel: {
                    textStyle: {
                        color:'#717171'
                    }
                }
            },
            series:[{
                name:'',
                type:'bar',
                barMaxWidth: 20,
                data:dataY,
                itemStyle:{
                    normal:{
                        barBorderRadius:40,
                        color:'#0fb2c3',
                        borderWidth:2,
                        shadowColor:'rgba(168,225,226,0.5)'
                    }
                }

            }]
        };
        return option;
    }

    render() {
        let nowDate = Datetime.moment();
        let valid = function( current ){
            return current.isBefore(nowDate );
        };
        return (
            <div className={style.LeftBbd}>
                <Title name="教育扶贫"/>
                <h5>高考录取贫困人数</h5>
                <div className={style.timeBox}>
                    <span>
                         {/*<Datetime dateFormat="YYYY" timeFormat={false} locale="zh_CN" isValidDate={valid} closeOnSelect={true} onChange={(event) =>{this.setDate(0,event)}} value={this.state.dockingDate} inputProps={{'readOnly':true}}></Datetime>*/}
                    </span>
                </div>
                <div className={style.tableList}>
                    <div className={style.thead}>
                        <span className={style.common}>教育程度</span>
                        <span className={style.common}>录取人数</span>
                        <span className={style.common}>两助三免</span>
                        <span className={style.common}>已脱贫</span>
                        <span className={style.common}>未脱贫</span>
                    </div>
                    <div className={style.tbody}>
                        <ul>
                            {
                                this.state.listMap.map((item,index)=>{
                                    return <li key={index} className={index===0? style.active:''} onClick={(e)=>{this.setType(e,item)}}>
                                        <span className={style.common}>{item.category || 0 }</span>
                                        <span className={style.common}>{item.count || 0 }</span>
                                        <span className={style.common}>{item.is_subsidy}</span>
                                        <span className={style.common}>{item.not_poor || 0}</span>
                                        <span className={style.common}>{item.is_poor || 0}</span>
                                    </li>
                                })
                            }
                        </ul>
                    </div>
                </div>
                <h3 className={style.pjl}>高考录取批次</h3>
                <div className={style.chartBox}>
                    <div style={{width: '100%',height: '100%'}} id="bar" ></div>
                </div>
            </div>
        );
    }
}
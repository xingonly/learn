// 上帝保佑,永无bug
import React, {Component} from "react";
import {Link} from 'react-router-dom';
import Selection from '../Selection';
import createHistory from 'history/createHashHistory';
import resource from '../../../../util/resource';
import {KEYWORD} from '../../../../constants/storage'
import PageList from '../../../../components/Pagination'
import Notice from 'components/Notice'
import style  from './style.scss';
import DefaultImg from '../../images/nanren.png';
import Att from 'static/images/follow.png'
import UnAtt from 'static/images/unFollow.png'
import NoData from '../../../../components/noData'

const history = createHistory();
export default class RightBbd extends Component {
    constructor(props) {
        super(props);
        this.state = {
            listMap: [],
            total: 0,
            type: '',
            current: 0,
            selectType: [{name: '姓名', id: 'name'}, {name: '学校', id: 'school'}],
            statusType: [{name: '贫困状态', id: ''},{name: '已脱贫', id: 1}, {name: '未脱贫', id: 0}],
            gxsx: [{name: '学历', id: ''},{name: '本科', id: '本科'}, {name: '大专', id: '大专'}],
            stype: 'name',
            status: '',
            gxsxData:'',
            tips: '请输入姓名'
        };
        this.code = 520000000000;
        this.size = 6;
    }
    componentDidMount = () => {
        //this.getTableList();
    };

    getTableList = ()=>{
        let districtCode = this.code;
        let years = this.year;
        let page = this.state.current;
        let size = this.size;
        let name = this.state.stype === 'name' ? this.refs.inputValue.value : '';
        let school = this.state.stype === 'school' ? this.refs.inputValue.value : '';
        let poor_status = this.state.status;
        let category = this.state.gxsxData;
        resource.post('/xixiu-server/third/education/studentsList',{districtCode,years,category,page,size,name,school,poor_status}).then((res)=>{
            if(res.status === 200){
                this.setState({
                    total: res.data.count,
                    listMap: res.data.content
                });
            }
        })
    };

    getData =(data)=>{
        let item = JSON.parse(data);
        this.code = item.code || 520000000000;
        this.year = item.year || (new Date().getFullYear() - 1).toString();
        this.type = item.type || '本科';
        this.setState({
            type: item.type || '本科',
            current: 0
        },()=>{
            this.getTableList();
        })
    }

    searchType =()=>{
        this.getTableList();
    };

    setDefaultImg =(event) =>{
        event.target.setAttribute('src',DefaultImg);
    };

    setPage =(data)=>{
        this.setState({
            current: data
        },()=>{
            this.getTableList();
        })
    };

    setRouter = (event, item) =>{
        let obj = {
            inputValue: item.idnumber,
            region: {
                shi: '',
                xian: '',
                xiang: '',
                zheng: ''
            }
        };
        sessionStorage.setItem(KEYWORD,JSON.stringify(obj));
        history.push('/main/object/objectSearch');
    };

    getStatus = (s) =>{
        let status;
        switch (s){
            case '已脱贫':
                status = style.commonSpan + ' ' + style.finished
                return status;
            case '未脱贫':
                status = style.commonSpan + ' ' + style.no;
                return status;
            case '返贫':
                status = style.commonSpan + ' ' + style.bk;
                return status;
            case '预脱贫':
                status = style.commonSpan + ' ' + style.reading;
                return status;
            default:
                return;
        }
    };

    changeType = (n,item)=>{
        this.setState({
            current:0,
            stype: item.id,
            tips: item.id === 'school' ? '请输入学校':'请输入姓名'
        })
    };

    attentinFn = (flag, id, e) =>{
        e.stopPropagation()
        //e.nativeEvent.stopImmediatePropagation();
        let url = '/xixiu-server/people/attentionPeople/';
        if(!flag){
            url = '/xixiu-server/people/attentionPeople/cancel/'
        }
        resource.get(url + id).then((res)=>{
            if(res.status == 200){
                Notice.success('', flag ? '取消关注成功' : '关注成功');
                this.getTableList();
            }else{
                Notice.error('', flag ? '取消关注失败' : '关注失败');
            }
        }).catch(err =>{
            throw new Error(err)
        })
    }

    changeStatus = (n,item)=>{

        this.setState({
            status: item.id,
            current:0,
        },()=>{
            this.getTableList();
        })
    }

    changegxsx = (n,item)=>{
        this.setState({
            gxsxData: item.id,
            current:0
        },()=>{
            this.getTableList();
        })
    }

    render() {
        return (
            <div className={style.rightBbd}>
                <h5>
                    <span>两助三免情况</span>
                    <div className={style.filterBox}>
                        <div className={style.statusOptions}>
                            <Selection ref="status" tipData="学历" name="" data={this.state.gxsx} onChange={this.changegxsx}/>
                        </div>
                        <div className={style.statusOptions}>
                            <Selection ref="status" tipData="贫困状态" name="" data={this.state.statusType} onChange={this.changeStatus}/>
                        </div>
                        <div className={style.areaOptions}>
                            <Selection ref="type" tipData="姓名" name="" data={this.state.selectType} onChange={this.changeType}/>
                        </div>
                        <input type="text" ref="inputValue" placeholder={this.state.tips}/>
                        <span className={style.searchSpan} onClick={this.searchType}></span>
                    </div>
                </h5>
                <div className={style.rcon}>
                    <div className={style.tableBox}>
                        <div className={style.thead}>
                            <span className={style.common + ' ' + style.commonOne}>姓名</span>
                            <span className={style.common}>两助三免</span>
                            <span className={style.common}>院校名称</span>
                            <span className={style.common}>专业名称</span>
                            <span className={style.common}>贫困状态</span>
                            <span className={style.common}>关注状态</span>
                        </div>
                        <div className={style.tbody}>
                            <ul>
                                {
                                    this.state.listMap.length > 0 ? this.state.listMap.map((item,index)=>{
                                        return <li key={index} onClick={(e)=>{this.setRouter(e,item)}}>
                                            <div className={style.common + ' ' + style.firstLi}>
                                                <div className={style.imgBox}>
                                                    <img src={item.pic || DefaultImg} onError={this.setDefaultImg} alt=""/>
                                                </div>
                                                <span className={style.pjlBbd}>{item.name}</span>
                                            </div>
                                            <div className={style.common}>{item.is_subsidy || '-'}</div>
                                            <div className={style.common}>{item.institution_name}</div>
                                            <div className={style.common}>{item.profession_name}</div>
                                            <div className={style.common}>
                                                <span className={this.getStatus(item.poorStatus)}></span>
                                            </div>
                                            <div className={style.common}>
                                                <img className={style.attention} onClick={(e)=>{this.attentinFn(item.attention, item.peopleid,e)}} src={item.attention ? Att : UnAtt} alt="-" title={item.attention ? '取消关注' : '关注'}/>
                                            </div>
                                        </li>
                                    }):<NoData/>
                                }
                            </ul>
                        </div>
                        <div className={style.pageBox}>
                            {
                                this.state.total ? <PageList total={this.state.total} current={this.state.current} start={0} size={this.size} onChange={this.setPage} />:null
                            }
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
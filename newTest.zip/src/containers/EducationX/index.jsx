// 上帝保佑,永无bug
import React, {Component} from "react";
import createHistory from 'history/createHashHistory';
import {Link} from 'react-router-dom';
import resource from '../../util/resource';
import Selection from './subPage/Selection';
import style  from './style.scss';
import LeftBbd from './subPage/left';
import RightBbd from './subPage/right'
import Header from '../povertyAlleviation/subpage/header'

const history = createHistory();
export default class Education extends Component {
    constructor(props){
        super(props);
        this.arrArea = [];
        this.state = {
            token: true,
            topArea: null,
            sendID: null,
            area: {
                shi: null,
                xian: null,
                xiang: null,
                zheng: null
            }
        }
    }
    componentDidMount = () => {
        this.getRegion('520402000000','xiang');
        let obj = {};
        this.refs.rightbbd.getData(JSON.stringify(obj));
    };

    //获取顶级区域
    getTopArea = () =>{
        if(this.state.token){
            resource.get(`/xixiu-server/region/getTopRegion`).then((res) =>{
                if (res.status === 200) {
                    this.setState({
                        topArea: res.data,
                        token: false
                    });
                    this.getRegion(res.data[0].id,'shi');
                }
            });
        }else{
            this.getRegion(this.state.topArea[0].id,'shi');
        }

    }

    changeArea = (type,item) =>{
        let arr = ['shi','xian','xiang','zheng'];
        if(type === ''){
            this.arrArea.splice(3,1,item.id);
        }else{
            if(this.arrArea[arr.indexOf(type) - 1] !== ''){
                this.arrArea.splice(arr.indexOf(type) - 1,this.arrArea.length -arr.indexOf(type) + 1 ,item.id);
            }else{
                this.arrArea.splice(arr.indexOf(type) - 1,1 ,item.id);
            }
        }
        if(item.id && type !=''){
            this.getRegion(item.id,type,this.searchArea);
        }else{
            this.removeSelect(arr[arr.indexOf(type) - 1]);
        }
    };

    //移除其它选这框
    removeSelect = (name,callback) =>{
        switch (name){
            case 'shi':
                this.state.area.xian = null;
                this.state.area.xiang = null;
                this.state.area.zheng = null;
                this.setState({
                    area: this.state.area
                });
                this.refs.shi.setValue({ name:"市",id:null });
                this.refs.xian.setValue({ name:"县",id:null });
                this.refs.xiang.setValue({ name:"乡/镇",id:null });
                this.refs.zheng.setValue({ name:"村/社区",id:null });
                break;
            case 'xian':
                this.state.area.xiang = null;
                this.state.area.zheng = null;
                this.setState({
                    area: this.state.area
                });
                this.refs.xian.setValue({ name:"县",id:null });
                this.refs.xiang.setValue({ name:"乡/镇",id:null });
                this.refs.zheng.setValue({ name:"村/社区",id:null });
                break;
            case 'xiang':
                this.state.area.zheng = null;
                this.setState({
                    area: this.state.area
                });
                this.refs.xiang.setValue({ name:"乡/镇",id:null });
                this.refs.zheng.setValue({ name:"村/社区",id:null });
                break;
            default:
                break;
        }
        if(typeof callback === 'function'){
            callback;
        }
    }

    // regions地区的查询
    getRegion = (id,ob,func) => {
        this.removeSelect(ob,this.getRegionData(id,ob,func));
    };

    //获取数据
    getRegionData = (id,ob,func) =>{
        resource.get(`/xixiu-server/region/getRegionByParentid/${id}`).then((res) => {
            if(res.status === 200) {
                let result = res.data;
                let obj = {
                    name: '请选择',
                    id: ''
                };
                result.unshift(obj);
                this.state.area[ob] = result;
                this.setState({
                    area: this.state.area
                },() => {
                    if(func){
                        func();
                    }
                });
            }
        });
    };

    searchArea = ()=>{
        let arrId;
        let arr = this.arrArea.filter((item)=>{
            return item > 0;
        });
        arrId = arr[arr.length - 1] || this.state.topArea[0].id;
        this.refs.leftbbd.getData(arrId);
    };

    actionRight =(item)=>{
        this.refs.rightbbd.getData(item);
    };

    render() {
        return (
            <div className={style.educationBox}>
                <div className={style.container}>
                    <Header showBold={true}>
                        <span>教育指数</span>
                        <div className={style.selectBox} style={{fontWeight:'normal'}}>
                            <div className={style.areaOptions}>
                                <Selection ref="xian"
                                           tipData="西秀区"
                                           defaultSelect="xian"
                                           name="xiang"
                                           data={[{name:'西秀区',id:'520402000000'}]}/>
                            </div>
                            <div className={style.areaOptions}>
                                <Selection ref="xiang"
                                           tipData="镇/乡"
                                           defaultSelect="xiang"
                                           name="zheng"
                                           data={this.state.area.xiang}
                                           onChange={this.changeArea} />
                            </div>
                            <div className={style.areaOptions}>
                                <Selection ref="zheng"
                                           tipData="村/社区"
                                           defaultSelect="zheng"
                                           name=""
                                           data={this.state.area.zheng}
                                           onChange={this.changeArea}/>
                            </div>
                            {/*<span className={style.searchSpan} onClick={this.searchArea}></span>*/}
                        </div>
                    </Header>
                    {/*<h5 className={style.titleH5}></h5>*/}
                    <div className={style.contextBox}>
                        <div className={style.leftBbd}>
                            <LeftBbd ref="leftbbd" timeChange={this.actionRight} />
                        </div>
                        <div className={style.rightBbd}>
                            <RightBbd ref="rightbbd"  />
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}
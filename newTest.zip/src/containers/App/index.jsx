//測試
import React from 'react'
import Login from "containers/Login";
let App = (props) => {
    return (
        <div>
            {props.children}
        </div>
    )
}


export default App

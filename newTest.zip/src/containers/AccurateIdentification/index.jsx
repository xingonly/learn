import React, { Component } from 'react';
import style from './style.scss';
import { withRouter } from 'react-router-dom'
import RightRegion from './subpage/rightRegion'
import Bar from './subpage/chart/bar'/*
import Pie from './subpage/chart/pie'*/
import Header from '../povertyAlleviation/subpage/header'

class Index extends Component{
    render(){
        return(
            <div className={style.box}>
                <Header showBold={true}>
                    <span>异常调度</span>
                </Header>
                <div className={style.leftRegion}>
                    <Bar/>
                </div>
                <div className={style.rightRigion}>
                    <RightRegion/>
                </div>
            </div>
        )
    }
}
export default withRouter(Index)
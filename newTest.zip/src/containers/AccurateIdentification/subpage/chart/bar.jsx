import React, { Component } from 'react'
import { withRouter } from 'react-router-dom'
import style from '../common.scss'
import Select from '../select'
import echarts from 'echarts'
import resource from 'util/resource'
import Title from 'components/Title'

class chart extends Component{
    constructor(props){
        super(props);
        this.chart = null;
        this.paramas = {
            "district_code": 520402000000,
            "year": "2017"
        };
        this.state = {
            optionData:[],
            initData:{
                vehicle_count:0,
                company_count:0,
                fsupported_count:0,
                house_count:0
            }
        };
    }

    componentWillMount(){
        this.getInitData();
        this.getAllInitData();
    }

    componentDidMount(){
        this.myChart = echarts.init(this.refs.pieTest);
        this.getOption();
        let _this = this;
        window.addEventListener("resize",function(){
            _this.myChart.resize();
        });
    }

    getAllInitData = () => {
        resource.post('/xixiu-accurateidentification/app/identification_area_list', {
            "district_code": 520400000000,
            "year": "2017"
        }).then((res) => {
            if(res.message === 'success'){
                let state = this.state;
                state.initData.vehicle_count = res.data && res.data.length ? res.data[0].vehicle_count : 0;
                state.initData.company_count = res.data && res.data.length ? res.data[0].company_count : 0;
                state.initData.fsupported_count = res.data && res.data.length ? res.data[0].fsupported_count : 0;
                state.initData.house_count = res.data && res.data.length ? res.data[0].house_count : 0;
                this.setState(state);
            }
        })
    }

    getInitData = () => {
        resource.post('/xixiu-accurateidentification/app/identification_area_list', this.paramas).then((res) => {
            if(res.message === 'success'){
                let state = this.state;
                state.optionData = res.data ? res.data : [];
                this.setState(state,() => {
                    this.getOption();
                });
            }
        })
    }

    getOption  = () => {
        let state = this.state;
        let carData = [];
        let houseData = [];
        let companyData = [];
        let supportedData = [];
        let xAxisName = [];
        state.optionData.map((obj, index) => {
            carData.push(obj.vehicle_count ? obj.vehicle_count : 0);
            houseData.push(obj.house_count  ? obj.house_count  : 0);
            companyData.push(obj.company_count  ? obj.company_count  : 0);
            supportedData .push(obj.fsupported_count  ? obj.fsupported_count  : 0);
            xAxisName.push(obj.region);
        });
        let option = {
            color:['#fbaa26','#1ad1be','#f47b8c','#14cbe9'],
            tooltip: {
                trigger: 'axis',
                axisPointer: {
                    type: 'shadow'
                }
            },
            legend: {
                data: ['有车', '有房', '有公司', '财政供养'],
                right:'2%',
                orient:'vertical',
                top:'50%',

            },
            grid: {
                left: '3%',
                right: '20%',
                bottom: '3%',
                containLabel: true
            },
            xAxis: {
                type: 'value',
                boundaryGap: [0, 0.01],
                splitLine:{
                    show:false
                },
                axisTick:{
                    show:false
                },
                axisLabel: {
                    color:'red'
                }
            },
            yAxis: {
                type: 'category',
                data: xAxisName,
                axisLine:{
                    lineStyle:{
                        color:'#434343'
                    },
                },
                splitLine:{
                    show:false
                },
                axisTick:{
                    show:false
                },
                axisLabel:{
                    color:'#434343',
                },
            },
            series: [
                {
                    name: '有车',
                    type: 'bar',
                    data: carData,
                    itemStyle:{
                        normal:{
                            barBorderRadius:40,
                            color: new echarts.graphic.LinearGradient(1,0,0, 1, [{
                                offset: 0,
                                color: '#f9f0c1',
                            }, {
                                offset: 1,
                                color: '#faac29',
                            }]),
                        },
                    }
                },
                {
                    name: '有房',
                    type: 'bar',
                    data:houseData,
                    itemStyle:{
                        normal:{
                            barBorderRadius:40,
                            color: new echarts.graphic.LinearGradient(1,0,0, 1, [{
                                offset: 0,
                                color: '#b9f6f0',
                            }, {
                                offset: 1,
                                color: '#15d0bc',
                            }]),
                        },
                    }
                },{
                    name: '有公司',
                    type: 'bar',
                    data: companyData,
                    itemStyle:{
                        normal:{
                            barBorderRadius:40,
                            color: new echarts.graphic.LinearGradient(1,0,0, 1, [{
                                offset: 0,
                                color: '#ffdddd',
                            }, {
                                offset: 1,
                                color: '#f47b8c',
                            }]),
                        },
                    }
                },{
                    name: '财政供养',
                    type: 'bar',
                    data: supportedData,
                    itemStyle:{
                        normal:{
                            barBorderRadius:40,
                            color: new echarts.graphic.LinearGradient(1,0,0, 1, [{
                                offset: 0,
                                color: '#c2f5fd',
                            }, {
                                offset: 1,
                                color: '#11cae8',
                            }]),
                        },
                    }
                },
            ]
        };
        this.myChart.setOption(option);

    }

    handleSelect = (id) => {
        this.paramas.district_code = parseInt(id)
        this.getInitData()
    }

    render(){
        let { initData } = this.state;
        console.log(initData)
        return(
            <div className={style.box}>{/*
                <Select handleSelect={this.handleSelect}/>*/}
                <div className={style.title}>
                    <Title name="异常统计"/>
                </div>
                <dl className={style.header}>
                    <dt>西秀区：</dt>
                    <dd>有车{initData.house_count}</dd>
                    <dd>有房{initData.vehicle_count}</dd>
                    <dd>有公司{initData.company_count}</dd>
                    <dd>财政供养{initData.fsupported_count}</dd>
                </dl>
                <div className={style.chartRegion}>
                    <div ref="pieTest" style={{height:'100%',width:'100%'}}></div>
                </div>
            </div>
        )
    }
}

export default withRouter(chart)
import React, { Component } from 'react'
import { withRouter } from 'react-router-dom'
import style from '../common.scss'
import Select from '../select'
import echarts from 'echarts'
import resource from '../../../../util/resource'

class chart extends Component{
    constructor(props){
        super(props);
        this.chart = null;
        this.paramas = {
            "district_code": 520000000000,
            "year": "2017"
        };
        this.state = {
            optionData:[]
        };
    }

    componentWillMount(){
        this.getInitData();
    }

    componentDidMount(){
        this.myChart = echarts.init(this.refs.pieTest);
        let _this = this;
        window.addEventListener("resize",function(){
            _this.myChart.resize();
        });
    }

    getInitData = () => {
        resource.post('/welfare-accurateidentification/app/identification_area_list', this.paramas).then((res) => {
            if(res.message === 'success'){
                let state = this.state;
                state.optionData = res.data ? res.data : [];
                this.setState(state,() => {
                    this.getOption();
                });
            }
        })
    }
    getOption  = () => {
        let state = this.state;
        let data = [];
        let dataName = [];
        state.optionData.map((obj, index) => {
            let innerData = {
                value:obj.poor_rate,
                name:obj.region
            };
            let legendName = obj.region;
            dataName.push(legendName);
            data.push(innerData);

        })
        let option = {
            color:['#004389','#1394f2','#38aef8','#65c7f8','#9cedff','#0fe0f6','#30f1f8','#89fffe','#c6fefd','#cbeddc','#3be9e0',],
            title:{
                text:'贫困识别精准率（%）',
                left:'22%',
                top:'4%',
                textStyle:{
                    fontSize:14,
                    color:'#07a9b4'
                },
            },
            tooltip: {
                formatter: "{a} <br/>{b}: {c} ({d}%)"
            },/*
             visualMap:{
             min:100,
             max:2000,
             inRange:{
             color:['#017bea','#3ceae1'],
             },
             show:false
             },*/
            legend: {
                orient: 'vertical',
                top:'10%',
                left:'50%',
                textStyle:{
                    fontSize:'16',
                    color:'#07a9b4'
                },
                icon:'circle',
                height:'80%',
                itemGap:10,
                padding:[10,20],
                formatter:function(innerData){
                    let value = '';
                    data.map((obj, index) => {
                        if(obj.name === innerData){
                            value = obj.value;
                        }
                    });
                    let newData = innerData + '  ' +value;
                    return newData
                },
                data:dataName
            },
            series: [
                {
                    name:'贫困识别精准率%',
                    type:'pie',
                    radius: ['50%', '70%'],
                    center:['30%','50%'],
                    avoidLabelOverlap: false,
                    label: {
                        normal: {
                            show: false,
                            position: 'center'
                        },
                        emphasis: {
                            show: true,
                            formatter:function(data){
                                let value = data.data.name + '\n' + data.data.value + '%';
                                return value;
                            },
                            textStyle: {
                                fontSize: '24',
                                fontWeight: 'bold'
                            }
                        }
                    },
                    labelLine: {
                        normal: {
                            show: false
                        }
                    },
                    data:data
                }
            ]
        };
        this.myChart.setOption(option);

    }

    handleSelect = (id) => {
        this.paramas.district_code = parseInt(id)
        this.getInitData()
    }
    render(){
        return(
            <div className={style.box}>
                <Select handleSelect={this.handleSelect}/>
                <div className={style.chartRegion}>
                    <div ref="pieTest" style={{height:'100%',width:'100%'}}></div>
                </div>
            </div>
        )
    }
}

export default withRouter(chart)
import React, { Component } from 'react'
import { withRouter } from 'react-router-dom'
import style from './style.scss'
import resource from '../../../../util/resource'

class chart extends Component{
    constructor(props){
        super(props);
        this.state = {
            getTopRegion:[],
            shiRegion:[],
            key:0
        };
    }

    componentWillMount(){
        this.getInitTopRegion();
    }

    getInitRegion = () => {
        resource.get(`/xixiu-server/region/getRegionByParentid/520000000000`).then((res) => {
            if(res.message === 'success'){
                let state = this.state;
                state.shiRegion = res.data ? res.data : [];
                this.setState(state)
            }
        })
    }

    getInitTopRegion = () => {
        resource.get('/xixiu-server/region/getRegionByParentid/520402000000').then((res) => {
            if(res.message === 'success'){
                let state = this.state;
                state.getTopRegion = res.data ? res.data : [];
                this.setState(state, () => {
                    this.getInitRegion();
                })
            }
        })
    }

    handleChange = (e, label) => {
        let state = this.state;
        let value = e.target.value ? e.target.value : state.getTopRegion[0].id;

        if(label === 'top'){
            state.key = ++state.key;
            this.setState(state)
        }
        if(this.props.handleSelect){
            this.props.handleSelect(value,label)
        }
    }
    render(){
        let {shiRegion, getTopRegion, key} = this.state;
        return(
            <div className={style.box}>
                <div className={style.select}>
                    <select onClick={ (e) => this.handleChange(e, 'top')}>
                        {
                            getTopRegion && getTopRegion.length > 0 ? getTopRegion.map((obj, index) => {
                                return (
                                    <option value={obj.id} key={obj.id}>{obj.name}</option>
                                )
                            }):''
                        }
                    </select>
                    <select onChange={ (e) => this.handleChange(e)} key={key}>
                        <option value="">市/州</option>
                        {
                            shiRegion && shiRegion.length > 0 ? shiRegion.map((obj, index) => {
                                return (
                                    <option value={obj.id} key={obj.id}>{obj.name}</option>
                                )
                            }):''
                        }
                    </select>
                </div>
            </div>
        )
    }
}

export default withRouter(chart)
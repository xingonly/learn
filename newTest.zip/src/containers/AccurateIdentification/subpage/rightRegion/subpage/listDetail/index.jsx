import React, { Component } from 'react';
import style from './style.scss';
import { withRouter } from 'react-router-dom'
import Pagination from "../../../../../../components/Pagination"
import List from '../list'
import Nodata from '../../../../../../components/noData'
import resource from '../../../../../../util/resource'
import back from '../list/images/back.png'

class ListDetail extends Component{
    constructor(props){
        super(props);
        this.paramas = {
            "district_code": this.props.data.district_code,
            "page": 0,
            "size": 7,
            "type_": this.props.data.type_,
        };
        this.state = {
            initData: '',
            current:0,
            inputValue:this.props.inputValue
        }
    }


    componentWillMount(){
        this.getInitData();
    }

    componentWillReceiveProps(data){
        let state = this.state;
        if(state.inputValue !== data.inputValue){
            console.log(state.inputValue)
            state.inputValue = data.inputValue;
            this.getInitData(data.inputValue);
            this.setState(state);
        }
    }

    getInitData = (data) => {
        if(data){
            this.paramas.keyword = data;
            let state = this.state;
            state.current = 0;
            this.paramas.page = 0;
            this.setState(state);
        }else{
            this.paramas.keyword = null;
        }
        resource.post('/xixiu-accurateidentification/app/identification_people_list', this.paramas).then((res) => {
            if(res.message === 'success'){
                let state = this.state;
                state.initData = res.data ? res.data : [];
                this.setState(state);
            }
        })
    }

    onChange = (page, size) => {
        let state = this.state;
        state.current = page;
        this.setState(state, () => {
            this.paramas.page = page;
            this.getInitData()
        });

    }

    render(){
        let { initData, current } = this.state;
        return(
            <div className={style.box}>
                <div className={style.back}>
                    <img src={back} onClick={ () => { this.props.handleEnter(true)}} alt=""/>
                </div>
                <div className={style.list}>
                   <List data={initData ? initData.data :[]} getInitData={this.getInitData}/>
                </div>
                <div className={style.pagination}>
                    <div className={style.inner}>
                        <Pagination
                            total={initData.count ? initData.count : 0}
                            start={0}
                            onChange={this.onChange}
                            size={this.paramas.size}
                            current={0}
                        />
                    </div>
                </div>
            </div>
        )
    }
}
export default withRouter(ListDetail)
import React, {Component} from 'react'
import style from './style.scss';
import tu from '../images/unattention.png';
import notu from './images/noAttention.png'
import outofpoverty from '../images/outofpoverty.png';
import poverty from '../images/poverty.png';
import prepoverty from '../images/prepoverty.png';
import backpoverty from '../images/backpoverty.png';
import { KEYWORD } from '../../../../../../constants/storage'
import createHistory from 'history/createHashHistory'
import male from '../images/nanren.png';
import car from './images/car.png';
import company from './images/company.png';
import house from './images/house.png';
import nocar from './images/nocar.png';
import nocompany from './images/nocompany.png';
import nohouse from './images/nohouse.png';
import haveMoney from './images/haveMoney.png';
import noMoney from './images/noMoney.png';
import resource from '../../../../../../util/resource'
import Nodata from '../../../../../../components/noData'
import Notice from '../../../../../../components/Notice'
const history = createHistory();

export default class HelpList extends Component {

	constructor(props) {
		super(props);
		this.delayTime = 0;
		this.state = {
			data:this.props.data
		}
	}
	componentWillReceiveProps(props) {
		console.log(props.data)
		if(props.data.length !== 0) {
			this.setState({
				data: props.data,
			}, () => {
				this.handleData(props.data)
			})
		}else {
			this.setState({
				data: [],
			})
		}
	}
	showImg = status => {
		if(status === null){
		}else if(parseInt(status) === 0) {
			return poverty
		}else if(parseInt(status) === 1) {
			return outofpoverty
		}else if(parseInt(status) === 2) {
			return prepoverty
		}else if(parseInt(status) === 3) {
			return backpoverty
		}
	}
	handleObj = (object) => {
		let obj = {
			inputValue: object.idnumber,
			region: {
				shi: '',
				xian: '',
				xiang: '',
				zheng: ''
			}
		}
		sessionStorage.setItem(KEYWORD, JSON.stringify(obj));

		history.push('/main/object/objectSearch');
	}

	changeUrl = (e) =>{
		e.target.setAttribute('src',male);
	}
	setDelayTime = () => {
        let timer = null;
        timer = setInterval(() => {
            if (this.delayTime <= 3) {
                this.delayTime++
            } else {
            	clearInterval(timer)
            }
        }, 1000)
    }
    follow = (id,e) => {
        resource.get(`/xixiu-server/people/attentionPeople/${id}`).then( (res) => {
            if(res.status === 200)
            {
                Notice.success('','关注成功');
                this.props.getInitData()
            }else{
                Notice.warning('',res.message);
			}
        })
    }

    unfollow = (id,e) => {
        resource.get(`/xixiu-server/people/attentionPeople/cancel/${id}`).then( (res) => {
            if(res.status === 200)
            {
                Notice.success('','取消关注成功');
                this.props.getInitData()
            }else{
                Notice.warning('',res.message);
			}
        })
    }
    handleAttention = (e,data) => {
        e.stopPropagation();
		if(!data.attention){
			this.follow(data.labelId);
		}else{
            this.unfollow(data.labelId);
		}
	}

	handleData = (data) => {
        data.map((obj, index) => {
        	this.handleGetInitData(obj.idnumber,index)
		})
	}
    showImgStatus = (status) => {
        if(status) {
            return tu;
        }else{
        	return notu;
		}
	}

    handleGetInitData = (id, index) => {
		resource.get(`/xixiu-server/welfare/searchPoorPeopleByIdnumber/${id}`).then((res) => {
			if(res.message === 'success'){
				let state = this.state;
				if(!state.data.length){
					return;
				}
				state.data[index].abandonPoverty = res.data.content[0].status;
                state.data[index].attention = res.data.content[0].attention;
                state.data[index].labelId = res.data.content[0].id;
                this.setState(state);
			}else{
                Notice.warning('', res.message);
			}
		})
	}

	render() {
		let { data } = this.state;
		return (
			<section id={style['list-help']}>
				{
                    data.length>0 ? <ul className={style.list}>
						{
							data.map((item,index) => {
								return(
									<li className={style.list_item} key={index} onClick={() => this.handleObj(item)}>
										<ul className={style['list1']}>
											<li className={style['left']}>
												<img src={item.pic || male} onError={this.changeUrl} alt="" />
											</li>
											<li className={style['middle']}>
												<span>{item.full_name || '--'}</span>
												<span>
													<img src={ item.house_count ? house : nohouse} alt=""/>
													{item.house_count || '0'}
													</span>
												<span>
													<img src={item.company_count ? company : nocompany} alt=""/>
													{item.company_count || '0'}
													</span>
												<span>
													<img src={item.car_count ? car : nocar} alt=""/>
													{item.car_count || '0'}
													</span>
												<span>
													<img src={item.is_fsupported ? haveMoney : noMoney} alt=""/>
                                                    {item.is_fsupported || '0'}
												</span>
												<span>
													{
                                                        item.abandonPoverty ?
															<img className={style.s1}
																 src={this.showImg(item.abandonPoverty)} alt=""
																 style={{verticalAlign:'text-bottom'}}
															/>:'---'
													}</span>
												<span><img className={style.s2}
														   src={this.showImgStatus(item.attention)} alt=""
														   onClick={ (e) => this.handleAttention(e,item) }
														   style={{verticalAlign:'text-bottom'}}
												/></span>
											</li>
										</ul>
									</li>
								)
							})
						}
					</ul>:
					<div className={style.noData}>
						<Nodata/>
					</div>
				}
			</section>
		)
	}
}
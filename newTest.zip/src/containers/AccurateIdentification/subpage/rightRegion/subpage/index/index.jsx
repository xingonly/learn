import React, { Component } from 'react';
import style from './style.scss';
import { withRouter } from 'react-router-dom'
import Pagination from "../../../../../../components/Pagination"
import resource from '../../../../../../util/resource'
import Nodata from '../../../../../../components/noData'

class Index extends Component{
    constructor(props){
        super(props);
        this.paramas = {
            "district_code":this.props.district_code ? parseInt(this.props.district_code) : 0,
            "type_": ''
        };
        this.optionData = [
            {
                name:'异常人数',
                value:'',
                label:'error_count'
            },
            {
                name:'有车人数',
                value:'is_vehicle',
                label:'vehicle_count'
            },
            {
                name:'有房人数',
                value:'is_house',
                label:'house_count'
            },
            {
                name:'有公司人数',
                value:'is_company',
                label:'company_count'
            }];
        this.state = {
            initData: [],
            nowData:'error_count'
        }
    }
    componentWillReceiveProps(nextProps){
        console.log(nextProps);
        if(nextProps.district_code !== this.paramas.district_code){
            this.paramas = {
                "district_code": nextProps.district_code ? parseInt(nextProps.district_code): 0,
            };
            this.getiniData()
        }
    }

    getiniData = () => {
        console.log(this.paramas.district_code);
        if(!this.paramas.district_code){
            return;
        }
        resource.post('/xixiu-accurateidentification/app/identification_area_list', this.paramas).then((res) => {
            if(res.message === 'success'){
                let state = this.state;
                state.initData = res.data ? res.data : [];
                state.initData.map((obj, index) => {
                    obj.select = false;
                });
                this.setState(state);
            }
        })
    }

    componentWillMount(){
        this.getiniData();
    }

    componentDidMount(){
    }

    handleTo = (id,type,count) => {
        if(!count){
            return
        }
        let data = {
            district_code: id,
            type_: type
        }
        if(this.props.handleEnter){
            this.props.handleEnter(false, data)
        }
    }

    handleClick = (i) => {
        let state = this.state;
        state.initData.map((obj, index) => {
            if(index === i && obj.select){
                obj.select = false;
            }else if(index === i && !obj.select){
                obj.select = true;
            }else{
                obj.select = false;
            }
        });
        this.setState(state);
    }

    handleChange = (e) => {
        let state = this.state;
        state.nowData = JSON.parse(e.target.value).label;
        this.setState(state);
    }

    render(){
        let { initData, nowData } = this.state;
        return(
            <div className={style.box}>
                <div className={style.list}>
                    {
                        initData.length > 0  ? initData.map((obj, index) =>{
                            return(
                                <dl key={index}>
                                    <dt>
                                        {obj.region ? obj.region :'---'}
                                    </dt>
                                    <dd>
                                        <ul className={style.leftRegion}>
                                            <li>
                                                <span>贫困人数：</span>{obj.poor_count || '0'}
                                            </li>
                                            <li className={style.active}>
                                                <span
                                                    onClick={ () => this.handleTo(obj.district_code,'is_vehicle',obj.car_count) }
                                                >有车人数：</span>{obj.car_count || '0'}
                                            </li>
                                            <li  className={style.active}>
                                                <span
                                                    onClick={ () => this.handleTo(obj.district_code,'is_fsupported',obj.fsupported_count) }
                                                >财政供养人数：</span>{obj.fsupported_count   || '0'}
                                            </li>
                                        </ul>
                                        <ul className={style.center}>
                                            <li  className={style.active}>
                                                <span
                                                    onClick={ () => this.handleTo(obj.district_code,'',obj.error_count) }
                                                >异常人数：</span>{obj.error_count || '0'}
                                            </li>
                                            <li  className={style.active}>
                                                <span
                                                    onClick={ () => this.handleTo(obj.district_code,'is_house',obj.house_count) }
                                                >有房人数：</span>{obj.house_count || '0'}
                                            </li>

                                            <li>
                                                <span>清退：</span>{obj.cancel_count || '0'}
                                            </li>
                                        </ul>
                                        <ul className={style.rightRegion}>
                                            <li>
                                                <span>异常识别率：</span>{obj.poor_rate === 0 || obj.poor_rate  ? obj.poor_rate+'%'  :'---'}
                                            </li>
                                            <li  className={style.active}>
                                                <span
                                                    onClick={ () => this.handleTo(obj.district_code,'is_company',obj.company_count) }
                                                >有公司人数：</span>{obj.company_count  || '0'}
                                            </li>
                                            <li>
                                                <span>未核实：</span>{obj.not_check_count === 0 || obj.not_check_count ? obj.not_check_count  :'---'}
                                            </li>
                                        </ul>{/*
                                        <div className={style.forList}>异常人员列表》</div>*/}
                                    </dd>
                                </dl>
                            )
                        }):
                            <div style={{paddingTop:'15rem'}}>
                                <Nodata/>
                            </div>
                    }
                </div>
                <div className={style.pagination} style={{display:'none'}}>
                    <Pagination total={100} start={0} onChange={this.onChange} size={15}/>
                </div>
            </div>
        )
    }
}
export default withRouter(Index)
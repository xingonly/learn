import React, { Component } from 'react';
import style from './style.scss';
import { withRouter } from 'react-router-dom'
import Index from './subpage/index'
import ListDetail from './subpage/listDetail'
import resource from '../../../../util/resource'
import { Trim } from '../../../povertyAlleviation/common'

class rightRegion extends Component{
    constructor(props){
        super(props);
        this.paramas = {
            district_code:'520402000000',
            error_type:0
        };
        this.input = null;
        this.shiValue = null;
        this.xianValue = null;
        this.district_code='';
        this.state = {
            show:true,
            getTopRegion:[],
            shiRegion:[],
            xianRegion:[],
            xiangRegion:[],
            district_code:'520402000000',
            inputValue:''

        }
    }

    componentWillMount(){
        this.getInitRegion('shiRegion', '520402000000');
    }

    getInitRegion = (label, id) => {
        resource.get(`/xixiu-server/region/getRegionByParentid/${id}`).then((res) => {
            if(res.message === 'success'){
                let state = this.state;
                state[label] = res.data ? res.data : [];
                this.setState(state)
            }
        })
    }

    /*getInitTopRegion = () => {
        resource.get('/xixiu-server/region/getRegionByParentid/520402000000').then((res) => {
            if(res.message === 'success'){
                let state = this.state;
                state.getTopRegion = res.data ? res.data : [];
                state.district_code =  res.data[0].id;;
                this.setState(state, () => {
                    this.paramas.district_code = res.data[0].id;
                })
            }
        })
    }*/

    handleChange = (e, label) => {
        let state = this.state;
        if(label === 'shiRegion' && !e.target.value){
            state.xianRegion = [];
            state.xiangRegion = [];
            this.setState(state);
        }
        if(label === 'shiRegion' && e.target.value){
            this.paramas.district_code = e.target.value;
            state.xianRegion = [];
            state.xiangRegion = [];
            state.district_code = e.target.value;
            this.getInitRegion('xianRegion',e.target.value);
        }else if(label === 'xianRegion' && e.target.value){
            this.paramas.district_code = e.target.value;
            state.district_code = e.target.value;
            this.getInitRegion('xiangRegion',e.target.value);
        }else if(label === 'xiangRegion' && e.target.value){
            state.district_code = e.target.value;
        } else if(label === 'xiangRegion' && !e.target.value){
            state.district_code = this.xianValue.value ? this.xianValue.value : state.xianRegion[0].id
        }else if(label === 'xianRegion' && !e.target.value){
            state.xiangRegion = [];
            state.district_code = this.state.shiRegion[0].id;
            state.district_code = this.shiValue.value ? this.shiValue.value : state.shiRegion[0].id
        }else{
            state.district_code = '520402000000';
        }
        this.setState(state);
    }

    handleEnter = (status, data) => {
        let state = this.state;
        state.show = status;
        if(data){
            this.district_code = data;
        }
        this.setState(state);
    }

    handleSearch = () => {
        let state = this.state;
        state.inputValue = Trim(this.input.value,'g');
        this.setState(state)
    }

    render(){
        let { show, shiRegion, district_code, inputValue, xiangRegion} = this.state;
        return(
            <div className={style.box}>
                <div className={style.selectRigon}>
                    <div style={{display:show ? 'block' : 'none'}}>
                        <select name="" id=""
                                disabled={!show}
                                style={{color: !show ? 'gray' : '#90d2cd'}}>
                        >
                            <option>西秀区</option>
                        </select>
                        <select
                            onChange={ (e) => this.handleChange(e, 'shiRegion')}
                            style={{color: !show ? 'gray' : '#90d2cd'}}
                            ref={e => this.shiValue = e}
                            disabled={!show}
                        >
                            <option value="">乡/镇</option>
                            {
                                shiRegion && shiRegion.length > 0 ? shiRegion.map((obj, index) => {
                                    return (
                                        <option value={obj.id} key={obj.id}>{obj.name}</option>
                                    )
                                }):''
                            }
                        </select>
                    </div>
                    <div style={{display:!show ? 'block' : 'none',margin:'0'}}>
                        <div className={style.inputSearch}>
                            <input
                                type="text"
                                placeholder="请输入姓名或者身份证号"
                                ref={(e) => { this.input = e }}
                            />
                            <i onClick={this.handleSearch} className={`iconfont ${style['searchIcon']}`}>&#xe6d1;</i>
                        </div>
                    </div>
                </div>
                <div className={style.container}>
                    {
                        show ? <Index handleEnter = { this.handleEnter }
                                      district_code = {district_code}/> :
                            <ListDetail handleEnter = { this.handleEnter }
                                        data = {this.district_code}
                                        inputValue={inputValue}
                            />

                    }
                </div>
            </div>
        )
    }
}
export default withRouter(rightRegion)
import React, {Component} from 'react'
import style from './style.scss';
import tu from '../../images/unattention.png';
import outofpoverty from '../../images/outofpoverty.png';
import poverty from '../../images/poverty.png';
import prepoverty from '../../images/prepoverty.png';
import backpoverty from '../../images/backpoverty.png';
import { KEYWORD } from '../../../../constants/storage'
import createHistory from 'history/createHashHistory'
import male from '../../images/nanren.png';
const history = createHistory()

export default class HelpList extends Component {

	constructor(props) {
		super(props);
		this.state = {
			data:this.props.data
		}
	}
	componentWillReceiveProps(props) {
		if(props.data.length !== 0) {
			this.setState({
				data: props.data,
			})
		}else {
			this.setState({
				data: [],
			})
		}
	}
	showImg = status => {
		if(status === '0') {
			return poverty
		}else if(status === '1') {
			return outofpoverty
		}else if(status === '2') {
			return prepoverty
		}else if(status === '3') {
			return backpoverty
		}
	}
	handleObj = (object) => {
		let obj = {
			inputValue: object.idnumber,
			region: {
				shi: '',
				xian: '',
				xiang: '',
				zheng: ''
			}
		}
		sessionStorage.setItem(KEYWORD, JSON.stringify(obj))

		history.push('/main/object/objectSearch');
	}

	changeUrl = (e) =>{
		e.target.setAttribute('src',male);
	}

	render() {
		return (
			<section id={style['list-help']}>
				{
					this.state.data.length>0 ? <ul className={style.list}>
						{
							this.state.data.map((item,index) => {
								return(
									<li className={style.list_item} key={index} onClick={()=>{this.handleObj(item)}}>
										<ul className={style['list1']}>
											<li className={style['middle']}>
                                                <li className={style['left']}>
                                                    <img src={item.headurl || male} onError={this.changeUrl} alt="" />
                                                </li>
												<span>{item.fullName || '--'}</span>
												<span>{item.gender || '--'}</span>
												<span>{item.idnumber || '--'}</span>
												<span>{item.homeAddress || '--'}</span>
												<span><img className={style.s1} src={this.showImg(item.status)} alt="" /></span>
												<span><img className={style.s2}src={tu} alt=""/></span>
											</li>
										</ul>
									</li>
								)
							})
						}
					</ul>:null
				}
			</section>
		)
	}
}
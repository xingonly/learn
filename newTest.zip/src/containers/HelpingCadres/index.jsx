import React, {Component} from 'react';
import style from './style.scss';
import MySelect from '../../components/MySelect';
import Pagination from '../../components/Pagination';
import HelpList from './subPage/list';
import male from './images/nanren.png';
import resource from '../../util/resource';

export default class HelpingCadres extends Component {

    constructor(props) {
        super(props);
        this.state = {
            zhou: '乡/镇',
            xian: '村/社区',
            zhen: '村/社区',
            optionsZhou:[],
            optionsXian:[],
            optionsZhen:[],
            optionsCun:[],
            index:null,
            i: 0,
            helper:{},//帮扶干部信息
            helpData:[],
            poorData:[],
            hu: 0,
            poorStatus: '贫困类型'
        }
        this.helper = {
            pageSize:8,
            page:0,
            total:0,
            code:520000000000,
            content:''
        }
        this.poor = {
            pageSize:7,
            page:0,
            total:0,
            id:null,
            poorStatus: ''
        }
    }
    onMouseOver = index => {
        this.setState({
            index: index
        })
    }
    onMouseOut = () => {
        this.setState({
            index: null
        })
    }
    onClick = (i,obj) => {
        sessionStorage.setItem('Page',`${this.helper.page}`);
        this.poor.id = obj.id;
        this.poor.page = 0;
        this.setState({
            i: i,
            helper:obj
        },()=>{
            this.getHelpHu();
            this.getPoorData()
        })
    }
    componentDidMount(){
        // debugger;
        this.getTopRegion();//获取顶层行政区域code
        this.getData();
    }

    //获取省和市的id和name在第一个下拉框中显示

    getTopRegion = () => {
        resource.get('/xixiu-server/region/getTopRegion').then(res => {
            if(res.status === 200){
                let code = res.data[0].id;
                this.helper.code = code;
                resource.get(`/xixiu-server/region/getRegionByParentid/${code}`).then((res) => {
                        if(res.status === 200){
                            let code = res.data[0].id;
                            this.helper.code = code;
                            resource.get(`/xixiu-server/region/getRegionByParentid/${code}`).then((res) => {
                                if(res.status === 200){
                                    let code = res.data[0].id;
                                    this.helper.code = code;
								 resource.get(`/xixiu-server/region/getRegionByParentid/${code}`).then((res) => {
									 if (res.status === 200) {
                                         let optionsZhou=[]
                                         for(let item of res.data) {
                                             let data = {
                                                 value: item.id,
                                                 label: item.name
                                             };
                                             optionsZhou.push(data)
                                         }
                                         this.setState({
                                             optionsZhou: optionsZhou
                                         });
									 }
								 })
								}
                            })
                            // optionsZhou.push({value: code ,label: name});
                        }
                    }
                )

            }
        })
    }

    handleClickZhou = (obj, name) => {
        let code = obj.value;
        this.helper.code = code;
        this.helper.page = 0;
        sessionStorage.setItem('Page','0');
        this.setState({
            zhou:obj.label,
            xian: '村/社区',
            // zhen: '村/社区',
            // cun: '村/社区'
        },()=>{
            this.handleRegion('xian',code);
            this.getData();
        })

    }
    // 贫困类型
    handlePoor = (obj, name) => {
        this.poor.poorStatus = obj.value;
        this.poor.page = 0;
        this.setState({
            poorStatus: obj.label
        },()=>{
            this.getPoorData();
        })
    }

    handleClickXian = (obj, name) =>{
        let code = obj.value;
        this.helper.code = code;
        this.helper.page = 0;
        sessionStorage.setItem('Page','0');
        this.setState({
            xian:obj.label,
            zhen: '村/社区',

        },()=>{
            this.handleRegion('zhen',code);
            this.getData();
        });
    }
    // handleClickZhen = (obj, name) =>{
    //     let code = obj.value;
    //     this.helper.code = code;
    //     this.helper.page = 0;
    //     sessionStorage.setItem('Page','0');
    //     this.setState({
    //         zhen:obj.label,
    //     },()=> {
    //         this.handleRegion('cun', code);
    //         this.getData();
    //     });
    // }
    // handleClickCun = (obj, name) =>{
    //     let code = obj.value;
    //     this.helper.page = 0;
    //     sessionStorage.setItem('Page','0');
    //     this.helper.code = code;
    //     this.setState({
    //         cun:obj.label
    //     },()=>{
    //         this.getData();
    //     })
    // }
    // 获取帮扶干部列表
    getData = () => {
        // this.helper.page = 0;
        resource.get(`/xixiu-user/sysuser/pageHelpManager?page=${this.helper.page}&size=8&code=${this.helper.code}&name=${this.helper.content}`).then(res => {
            if(res.status === 200){
                this.helper.total = res.data.totalElements;
                if(res.data.content.length && res.data.content.length > 0){
                    this.poor.id = res.data.content[0].id;
                    this.setState({
                        helper:res.data.content[0],
                        helpData:res.data.content
                    },()=>{
                        this.getHelpHu();
                        this.getPoorData();
                    })
                }else{
                    this.setState({
                        helper:{},
                        helpData: [],
                        poorData: []
                    })
                }
            }
        })
    }
    //帮扶干部分页
    helperChange =(page)=>{
        this.helper.page = page - 1;
        this.getData();
    }
    handleRegion = (type,code) => {
        resource.get(`/xixiu-server/region/getRegionByParentid/${code}`).then((res) => {
            if(res.status === 200){
                let options = [];
                for(let item of res.data) {
                    let data = {
                        value: item.id,
                        label: item.name
                    };
                    options.push(data);
                }
                switch (type) {
                    case 'xian':
                        this.setState({
                            optionsXian:options
                        });
                        break;
                    case 'zhen':
                        this.setState({
                            optionsZhen:options
                        });
                        break;
                    case 'cun':
                        this.setState({
                            optionsCun:options
                        });
                        break;
                }
            }
        })
    }
    //帮扶户数
    getHelpHu = () => {
        resource.get(`/xixiu-server/anno/getSomeoneSupportResponsibleNum?pid=${this.poor.id}`).then(res => {
            if(res.status === 200) {
                this.setState({
                    hu: res.data
                })
            }
        })
    }
    //获取帮扶对象
    getPoorData = ()=> {
        resource.get(`/xixiu-server/people/getSomeonePageSupportResponsible?page=${this.poor.page}&size=7&pid=${this.poor.id}&status=${this.poor.poorStatus}`).then(res=>{
            if(res.status === 200){
                this.poor.total = res.data.totalElements;
                this.setState({
                    poorData:res.data.content
                })
            }
        })
    }
    //贫困对象分页
    pageChange = (page) => {
        this.poor.page = page -1;
        this.getPoorData();
    }
    inputChange = (e) => {
        this.helper.content = e.target.value;
    }
    getData1 = () => {
        this.helper.page = 0;
        this.getData();
    }



    searchXiXiu = () => {
        this.setState({
            zhou: '乡/镇',
            xian: '村/社区',
            zhen: '请选择',
            cun: '请选择',
            code: '520402000000',
            page: 0,
            content: [],
            optionsXian: [],
            optionsZhen: [],
            optionsCun: [],
        },() => {
            this.getTopRegion(1)
        })
    }
    render() {
        return (
            <section id={style['HelpingCadres']}>
                <div className={style.box}>
                    <section className={style['content']}>
                        <header className={style.header}>
                            <ul>
                                <li>
                                    <span className={style.bangfulist}>帮扶干部列表</span>
                                </li>
								<li style={{ position: 'relative',bottom: '0.55rem'}}>
									<span className={style.xixiuaddress} onClick={this.searchXiXiu}>西秀区</span>
								</li>
                                <li>
                                    <MySelect
                                        value={this.state.zhou}
                                        options={this.state.optionsZhou}
                                        handleClick={this.handleClickZhou}
                                        name="zhou"
                                        width={5}
                                        measure='rem'
                                    />

                                </li>

                                <li>
                                    <MySelect
                                        value={this.state.xian}
                                        options={this.state.optionsXian}
                                        handleClick={this.handleClickXian}
                                        name="xian"
                                        width={5}
                                        measure='rem'
                                    />
                                </li>
                                {/*<li>*/}
                                    {/*<MySelect*/}
                                        {/*value={this.state.zhen}*/}
                                        {/*options={this.state.optionsZhen}*/}
                                        {/*handleClick={this.handleClickZhen}*/}
                                        {/*name="zhen"*/}
                                    {/*/>*/}
                                {/*</li>*/}
                                {/*<li>*/}
                                    {/*<MySelect*/}
                                        {/*value={this.state.cun}*/}
                                        {/*options={this.state.optionsCun}*/}
                                        {/*handleClick={this.handleClickCun}*/}
                                        {/*name="cun"*/}
                                    {/*/>*/}
                                {/*</li>*/}
                                <li style={{width:'35%'}}>
                                    <input type="search" className={style['input']} placeholder="请输入帮扶干部姓名" onChange={(event)=>{this.inputChange(event)}}/>
                                </li>
                                <li>
                                    <i className={`iconfont ${style['searchIcon']}`}   onClick={this.getData1}>&#xe6d1;</i>
                                </li>
                                {/*<li>*/}
                                {/*<input type="button" className={style['submit-btn']} value="搜索" onClick={this.getData1}/>*/}
                                {/*</li>*/}
                            </ul>
                        </header>
                        <ul id="helplists">
                            {
                                this.state.helpData.map((obj,index) => (
                                    <li className={`${style[sessionStorage.getItem('Page') === `${this.helper.page}`?(this.state.i === index?'background':''):'']} ${style[sessionStorage.getItem('Page') === `${this.helper.page}`?(this.state.i-1 === index?'border':''):'']} ${style[sessionStorage.getItem('Page') === `${this.helper.page}`?(this.state.index === index?'background':''):'']} ${style[sessionStorage.getItem('Page') === `${this.helper.page}`?(this.state.index-1 === index?'border':''):'']}`}
                                        key={index}
                                        onClick={() => {this.onClick(index,obj)}}
                                        onMouseOver={() => {this.onMouseOver(index)}}
                                        onMouseOut={() => {this.onMouseOut()}}
                                    >
                                        <ul className={style['list']}>
                                            <div className={style['left']}>
                                                <img src={ male } alt="" />
                                            </div>
                                            <div className={style['middle']}>
                                                <p>
													<span className={style.sp}>
														{obj.fullName}
													</span>
                                                    <span className={style.sp}>职位：{obj.position}</span>
                                                </p>
                                                <p>{`所属单位：${obj.department}`}</p>
                                            </div>
                                        </ul>
                                    </li>
                                ))
                            }
                        </ul>
                        {
                            this.state.helpData.length?
                                <footer className={style['footer']}>
                                    <div className={style['footer-content']}>
                                        <Pagination
                                            start={1}
                                            size={this.helper.pageSize}
                                            current={this.helper.page+1}
                                            total={this.helper.total}
                                            onChange={this.helperChange}
                                        />
                                    </div>
                                </footer>: <div className={style["empty"]}>
                                    <p>暂无数据</p>
                                    <div className={style["linear"]}></div>
                                </div>
                        }
                    </section>
                </div>
                <div className={style.box1}>
                    <div className={style.b_header}>
                        <div className={style.title}>干部详情</div>
                        <p className={style.p_font}>
                            <span className={style.s}>姓名：{this.state.helper && this.state.helper.fullName ||'--'}</span>
                            <span className={style.s}>电话：{this.state.helper && this.state.helper.linkPhone ||'--'}</span>
                            <span className={style.s}>职位：{this.state.helper && this.state.helper.position ||'--'}</span>
                            <span className={style.s}>帮扶单位名称：{this.state.helper && this.state.helper.department ||'--'}</span>
                            <span className={style.s}>帮扶户数：{this.state.hu}</span>
                        </p>
                    </div>
                    <div className={style.b_container}>
                        <div className={style.title2}>
                            帮扶对象
                        </div>
                        <div className={style.selectPoor}>
                            <MySelect
                                value={this.state.poorStatus}
                                options={[{value:'', label:'全部'},{value:'0', label:'未脱贫'},{value:'1', label:'已脱贫'},{value:'2', label:'预脱贫'},{value:'3', label:'返贫'}]}
                                handleClick={this.handlePoor}
                                name="poor"
                            />
                        </div>
                        <HelpList data={this.state.poorData}/>
                        {
                            this.state.poorData.length?
                                <footer className={style['footer']}>
                                    <div className={style['footer-content']}>
                                        <Pagination
                                            start={1}
                                            size={this.poor.pageSize}
                                            current={this.poor.page+1}
                                            total={this.poor.total}
                                            onChange={this.pageChange}
                                        />
                                    </div>
                                </footer>: <div className={style["empty1"]}>
                                    <p>暂无数据</p>
                                    <div className={style["linear"]}></div>
                                </div>
                        }
                    </div>
                </div>
            </section>
        )
    }
}

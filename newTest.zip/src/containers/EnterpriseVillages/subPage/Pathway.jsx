// 上帝保佑,永无bug

import React, {Component} from "react"
import Konva from 'konva'

export default class Pathway extends Component {

    constructor(props) {
        super(props)
        this.ringLayer = null
        this.pre = null    // 上一次鼠标移入的环形
    }

    componentDidMount() {
        window.addEventListener('resize', this.draw)
    }

    componentWillReceiveProps(props) {
        this.draw()
    }

    componentWillUnmount() {
        this.ringLayer.off('mouseover')
        this.ringLayer.off('mouseleave')
        window.removeEventListener('resize', this.draw)
    }

    draw = () => {
        let chart = document.querySelector('#chart'),
            rect = chart.getBoundingClientRect(),
            stage = new Konva.Stage({
                container: 'chart',
                width: rect.width,
                height: rect.height
            })
        this.drawDesc(stage)
        this.drawData(stage)
        this.drawBg(stage)
    }


    /*
     *   根据数据画出环形图比例
     */
    drawData = (stage) => {
        let precents = this.props.data
        let values = {}
        let total = 0
        for (let item of precents) {
            values[item.type] = item.count
            total += item.count
        }

        this.ringLayer = new Konva.Layer()
        let datas = [{key: '产业帮扶', color: '#3d77da', value: values['产业帮扶']}, {key: '就业帮扶', color: '#0de0f5', value: values['就业帮扶']},
            {key: '公益帮扶', color: '#f602ed', value: values['公益帮扶']}, {key: '技能帮扶', color: '#f60262', value: values['技能帮扶']}, {key: '其他帮扶', color: '#adf6fd', value: values['其他帮扶']}]
        let radius = [{inner: 0.105, outer: 0.11}, {inner: 0.095, outer: 0.11}, {inner: 0.115, outer: 0.12},
            {inner: 0.11, outer: 0.12}, {inner: 0.1,outer: 0.105}]
        let arc = null,
            rotation = -100
        for (let i = 0; i < datas.length; i++) {
            arc = new Konva.Arc({
                x: stage.getWidth() * 0.7,
                y: stage.getHeight() / 1.8,
                innerRadius: stage.getWidth() * radius[i].inner,
                outerRadius: stage.getWidth() * radius[i].outer,
                angle: datas[i].value / total * 360,
                fill: datas[i].color,
                rotation: rotation
            })
            rotation += datas[i].value / total * 360
            this.ringLayer.add(arc)
        }

        this.ringLayer.on('mouseover', (event) => {
            if (this.pre) {
                this.pre.setOuterRadius(this.pre.getOuterRadius() - 5)
            }
            this.pre = event.target
            event.target.setOuterRadius(event.target.getOuterRadius() + 5)
            this.ringLayer.draw()
        });
        this.ringLayer.on('mouseleave', () => {
            this.pre.setOuterRadius(this.pre.getOuterRadius() - 5)
            this.ringLayer.draw()
            this.pre = null
        });
        stage.add(this.ringLayer)

    }


    drawDesc = (stage) => {

        let precents = this.props.data
        let values = {}
        let total = 0
        for (let item of precents) {
            values[item.type] = item.count
            total += item.count
        }

        let datas = [{key: '产业帮扶', color: '#3d77da', value: values['产业帮扶']}, {key: '就业帮扶', color: '#0de0f5', value: values['就业帮扶']},
            {key: '公益帮扶', color: '#f602ed', value: values['公益帮扶']}, {key: '技能帮扶', color: '#f60262', value: values['技能帮扶']}, {key: '其他帮扶', color: '#adf6fd', value: values['其他帮扶']}],
            layer = new Konva.Layer(),
            initX = stage.getWidth() * 0.2,
            initY = stage.getHeight() / 1.8 - 74 + 9,
            circle = null,
            des = null,
            value = null
        for (let i = 0; i < datas.length; i++) {
            circle = new Konva.Circle({
                x: initX + 9,
                y: initY + (31 * i),
                radius: 9,
                fill: datas[i].color
            })
            des = new Konva.Text({
                x: initX + 36 ,
                y: initY + (31 * i) - 7,
                text: datas[i].key,
                fontSize: 14,
                fill: '#fff',
                align: 'left'
            })

            value = new Konva.Text({
                x: stage.getWidth() * 0.2 + 88,
                y: initY + (31 * i) - 7,
                text: (datas[i].value / total * 100).toFixed(1) + '%',
                fontSize: 14,
                fill: '#fff',
                // fontFamily: 'Microsoft YaHei',
                width: 60,
                align: 'right'
            })
            layer.add(circle)
            layer.add(des)
            layer.add(value)
        }

        stage.add(layer)
    }

    drawBg = (stage) => {
        let layer = new Konva.Layer(),
            outerCircle = new Konva.Circle({
                x: stage.getWidth() * 0.7,
                y: stage.getHeight() / 1.8,
                radius: stage.getHeight() * 0.3,
                shadowColor: '#fff',
                shadowBlur: 8,
                stroke: '#b8b8c0',
                strokeWidth: 1
            }),
            innerCircle = new Konva.Circle({
                x: stage.getWidth() * 0.7,
                y: stage.getHeight() / 1.8,
                radius: stage.getHeight() * 0.12,
                shadowColor: '#fff',
                shadowBlur: 8,
                stroke: '#b8b8c0',
                strokeWidth: 1
            })
        layer.add(outerCircle)
        layer.add(innerCircle)
        stage.add(layer)
    }


    render() {
        return (
            <div style={{height: '100%', position: 'relative'}}>
                <h6 style={{position: 'absolute', left: '70%', top: '10%', marginLeft: '-5%', color: '#07a7b5'}}>帮扶途径</h6>
                <div id="chart" style={{height: '100%'}}></div>
            </div>
        )
    }
}

// 上帝保佑,永无bug
import React, {Component} from "react";
import {Link,hashHistory} from 'react-router';
import Pathway from './subPage/Pathway';
import style from './style.scss'
import Card from '../../components/Card'
import Table from '../../components/Table'
import Select from '../DataMonitoring/subPage/Select'
import resource from '../../util/resource'
import echarts from 'echarts'
import Pagination from '../../components/Pagination'
import createHistory from 'history/createHashHistory'
const history = createHistory()

export default class EnterpriseVillages extends Component {
    constructor(props){
        super(props);
        this.state = {
            pageable: {
                total: 50,
                start: 0
            },
            isTable: true,
            cityList: [],
            countyList: [],
            xiangList: [],
            cunList: [],
            enterpriseList: [],
            enterprisePageable: {
                size: 19,
                start: 0,
                total: 0
            },
            chartCityList: [],
            enterpriseWayList: [],
            dataSource1: [],
            dataSource1Pageable: {
              size: 8,
              start: 0,
              total: 0
            }
        };

        this.leftTable = '1';
        this.rightType = '1';
        this.leftType = '0';
        this.colors = ['#0768bf','#057de8','#198ef8','#40a4fd','#5eb2fd','#89c6fd','#aed7fc','#08c3d5','#27e4f7','#68eefb','#a0f4fc','#0ebd9e','#16debb','#3cf2d2','#7ffce6','#a8feef','#cefcf4'];
        var manager = JSON.parse(sessionStorage.getItem('manager'));
        var scope = {
          scope: manager.scope,
          sheng: manager.sheng,
          shi: manager.shi,
          xian: manager.xian,
          xiang: manager.xiang
        };

        var scope1 = {
          scope: manager.scope,
          district: manager.shi
        }

        var scope2 = {
          scope: manager.scope,
          district:  manager.xian
        }

        var scope3 = {
          scope: manager.scope,
          district: manager.xiang
        }

        var scope4 = {
          scope: manager.scope,
          district:  manager.cun
        }

        this.scope1 = scope1;
        this.scope2 = scope2;
        this.scope3 = scope3;
        this.scope4 = scope4;
    }

    copyObj = (obj) => {
      if(typeof obj !== 'object' || obj === null)
      {
        return obj;
      }
      let result = obj instanceof Array ? [] : {};
      for(let key in obj)
      {
        result[key] = this.copyObj(obj[key]);
      }

      return result;
    }

    initEcharts = () => {
        if(!this.pie)
        {
            this.pie = echarts.init(this.refs.pie);
        }

        const pieOption = {
            color: this.colors,
            series: [
                {
                    type:'pie',
                    radius: ['65%', '80%'],
                    avoidLabelOverlap: false,
                    center: ['50%', '45%'],
                    label: {
                        normal: {
                            show: false,
                            position: 'center'
                        },
                        emphasis: {
                            show: true,
                            textStyle: {
                                fontSize: 14,
                                color: '#fff'
                            },
                            formatter: '{b}\n{d}%'
                        }
                    },
                    labelLine: {
                        normal: {
                            show: false
                        }
                    },
                    data: (() => {
                      let chartCityList = this.copyObj(this.state.chartCityList);
                      for(let i = 0;i < chartCityList.length;i++)
                      {
                        if(chartCityList[i].district === '合计')
                        {
                          chartCityList.splice(i,1);
                          break;
                        }
                      }
                      return chartCityList.map((item,index) => {
                          return {
                              name: item.district,
                              value: item.count
                          };
                      })
                    })()
                }
            ]
        };

        this.pie.setOption(pieOption);
    }

    changeType = (item,index) => {
        var state = {...this.state};
        state.isTable = !state.isTable;
        if(state.isTable)
        {
            this.changeTypeFlag = true;
            if(this.saveSearchParams)
            {
                state.inputValue = this.saveSearchParams.name;
                this.initEnterpriseList(this.state.enterprisePageable.current,this.state.enterprisePageable.size,this.saveSearchParams.xian ? this.saveSearchParams.xian : (this.saveSearchParams.shi ? this.saveSearchParams.shi : '520000000000'),this.saveSearchParams.type,this.saveSearchParams.name,this.order_by,this.sort_by,this.param);
                // this.rowOpen(this.refs.table,this.saveSearchParams.openItem,this.saveSearchParams.openIndex);
            }else{
                this.initEnterpriseList(0,19,this.districtCode,this.rightType);
            }
        }else{
            this.changeTypeFlag = false;
            this.saveSearchParams = {
                type: this.refs.selectType.getItem() ? this.refs.selectType.getItem().value : '',
                shi: this.refs.select1.getItem() ? this.refs.select1.getItem().id : '',
                xian: this.refs.select2.getItem() ? this.refs.select2.getItem().id : '',
                name: this.refs.companyName.value,
                openIndex: index,
                openItem: item
            };
          this.peopleListCompanyName = item.companyName;
          this.checkHelpList();
        }
        this.setState(state);
        if(!state.isTable)
        {
            this.clearCompanyName();
        }else{
            this.clearCompanyName(this.saveSearchParams.name);
        }
    }

    checkHelpList = (page,size) => {
      resource.post('/xixiu-server/third/company/helpList',{
        companyName: this.peopleListCompanyName,
        page: page ? page : 0,
        size: size ? size : 8
      }).then((res) => {
        var state = {...this.state};
        state.dataSource1 = res.data.content;
        state.dataSource1Pageable.total = res.data.count;
        this.setState(state);
      });
    }

    initCity = () => {
        resource.get('/xixiu-server/region/getRegionByParentid/520000000000').then((res) => {
            res.data.unshift({
                id: '',
                name: '全部'
            });
            this.setState({
                cityList: res.data
            });
        });
    }

    leftTypeChange = (item) => {
        this.leftType = item.value;
        this.initEnterpriseNumList();
        this.initEnterpriseWayList();
        this.initEcharts();
    }

    onCityChange = (item) => {
        var state = {...this.state};
        if(item.id)
        {
            resource.get('/xixiu-server/region/getRegionByParentid/' + item.id).then((res) => {
                res.data.unshift({
                    id: '',
                    name: '全部'
                });
                state.countyList = res.data;
                this.setState(state);
            });
        }else{
            state.countyList = [{
                id: '',
                name: '全部'
            }];
            this.setState(state);
        }
    }

    onCountyChange = (item) => {
        if(item.name)
        {
            resource.post('/zm/company/v0.1/group_by_type',{
                name: item.name,
                table: this.rightType,
                type_: 'county'
            }).then((res) => {
                let list = res.data && res.data.map((item, index) => {
                    return {
                        id: item,
                        name: item
                    }
                }) || [];
                list.unshift({
                    id: '',
                    name: '全部'
                });
                this.setState({
                    xiangList: list
                });
            });
        }else{
            this.setState({
                xiangList: [{
                    id: '',
                    name: '全部'
                }]
            });
        }
    }

    onXiangChange = (item) => {
        if(item.name)
        {
            resource.post('/zm/company/v0.1/group_by_type',{
                name: item.name,
                table: this.rightType,
                type_: 'town'
            }).then((res) => {
                let list = res.data && res.data.map((item, index) => {
                    return {
                        id: item,
                        name: item
                    }
                }) || [];
                list.unshift({
                    id: '',
                    name: '全部'
                });
                this.setState({
                    cunList: list
                });
            });
        }else{
            this.setState({
                cunList: [{
                    id: '',
                    name: '全部'
                }]
            });
        }
    }

    rowOpen = (scope,item,index) => {
        resource.post('/zm/company/v0.1/village_give_info',{
          _id: item._id,
           table: this.rightType
        }).then((res) => {
          var state = {...scope.state};
          state.childTemp = (
            <div className={style.rowOpen}>
                <div className={style.info}>
                    <div>
                        <label>企业名称：</label>
                        <span>{res.data.companyName}</span>
                    </div>
                    <div>
                        <label>产业帮扶（金额）：</label>
                        <span>{res.data.investRecAmountTotal + '万元'}</span>
                    </div>
                    <div>
                        <label>贫困所在地：</label>
                        <span>{res.data.adds}</span>
                    </div>
                    <div>
                        <label>就业帮扶（金额）：</label>
                        <span>{res.data.employmentSalaryCnt + '万元'}</span>
                    </div>
                    <div>
                        <label>贫困村：</label>
                        <span>{res.data.villageName}</span>
                    </div>
                    <div>
                        <label>公益帮扶（金额）：</label>
                        <span>{res.data.giveMoneyAmountCnt + '万元'}</span>
                    </div>
                    <div>
                        <label>帮扶该村总人数：</label>
                        <span>{res.data.num}</span>
                    </div>
                    <div>
                        <label>技能帮扶（金额）：</label>
                        <span>{res.data.trainMoneyCnt + '万元'}</span>
                    </div>
                    <div>
                        <label>其他帮扶：</label>
                        <span>{res.data.otherContent}</span>
                    </div>
                </div>
                <div className={style.nav}>
                    <a onClick={this.changeType.bind(this,item,index)}>查看帮扶列表 》</a>
                </div>
            </div>
          );
          scope.setState(state);
        });
    }

    leftTableChange = (item) => {
        this.leftTable = item.value;
        this.initEnterpriseNumList();
        this.initEnterpriseWayList();
        this.initEcharts();
    }

    rightTypeChange = (item) => {
        this.rightType = item.value;
        this.refs.select1.setItem({
            id: '',
            name: '全部'
        });
        this.initEnterpriseList(0,19,this.districtCode,this.rightType,'',this.order_by,this.sort_by,this.param);
        this.clearCompanyName();
    }

    // initPieChartData = () => {
    //     resource.post('/zm/company/v0.1/group_by_city',{
    //         table: this.leftTable
    //     }).then((res) => {
    //         // debugger;
    //     });
    // }

    refreshEnterpriseList = () => {
        this.initEnterpriseNumList();
        this.initEnterpriseWayList();
        this.initEcharts();
    }

    initEnterpriseNumList = (city) => {
        resource.post('/zm/company/v0.1/information_aggregation',{
            table: this.leftTable,
            type_: parseInt(this.leftType),
            city: city
        }).then((res) => {
            this.city = city;
            var state = {...this.state};
            state.chartCityList = res.data;
            this.setState(state);
            this.initEcharts();
        });
    }

    initEnterpriseWayList = (city) => {
        if(city)
        {
            resource.post('/zm/company/v0.1/group_by_give_county',{
                table: this.leftTable,
                type_: parseInt(this.leftType),
                city: city
            }).then((res) => {
                var state = {...this.state};
                state.enterpriseWayList = res.data;
                this.setState(state);

            });
        }else{
            resource.post('/zm/company/v0.1/group_by_give',{
                table: this.leftTable,
                type_: parseInt(this.leftType),
            }).then((res) => {
                var state = {...this.state};
                state.enterpriseWayList = res.data;
                this.setState(state);
            });
        }
    }

    initEnterpriseList = (page,size,districtCode,table,companyName,order,sort,param) => {
        let obj = {
            page: page ? page : 0,
            size: size ? size : 19,
            districtCode: districtCode ? (districtCode + '') : '520000000000',
            table: table ? table : '1',
            companyName: companyName,
            order_by: order,
            sort: sort
        };
        if(param)
        {
            obj[param.field] = param.value;
        }
        resource.post('/xixiu-server/third/companyList',obj).then((res) => {
            let {enterprisePageable} = this.state;
            enterprisePageable.total = res.data.count;
            enterprisePageable.page = page ? page : 0;
            enterprisePageable.current = page ? page : 0;
            this.setState({
                enterpriseList: res.data.content,
                enterprisePageable: enterprisePageable
            });
        });
    }

    clearCompanyName = (name) => {
      this.companyName = '';
      this.refs.companyName.value = name ? name : '';
    }

    search = () => {
        this.param = '';
        this.changeTypeFlag = false;
        if(this.refs.select2.getItem().id)
        {
            this.districtCode = this.refs.select2.getItem().id;
        }else{
            if(this.refs.select1.getItem().id)
            {
                this.districtCode = this.refs.select1.getItem().id;
            }else{
                this.districtCode = 520000000000
            }
        }
        if(this.refs.select3.getItem().id)
        {
            if(this.refs.select4.getItem().id)
            {
                this.param = {
                    field: 'village',
                    value: this.refs.select4.getItem().id
                }
            }else{
                this.param = {
                    field: 'town',
                    value: this.refs.select3.getItem().id
                }
            }
        }
        this.companyName = this.refs.companyName.value;
        this.initEnterpriseList(0,19,this.districtCode,this.rightType,this.companyName,this.order_by,this.sort_by,this.param);
    }

    onEnterpriseTableChange = (page,size) => {
        this.changeTypeFlag = false;
        this.initEnterpriseList(page,size,this.districtCode,this.rightType,this.companyName,this.order_by,this.sort_by,this.param);
    }

    checkCityDetail = (d) => {
        if(this.city || d === '合计')
        {
            return;
        }
        this.initEnterpriseNumList(d);
        this.initEnterpriseWayList(d);
        this.initEcharts();
    }

    inputKeyPress = (e) => {
      var code = e.keyCode || e.charCode;
      if(code == 13) {
        this.search();
      }
    }

    onCheckDetail = (item) => {
      let obj = {
        inputValue: item.idnumber,
        region: {
          shi: '',
          xian: '',
          xiang: '',
          zheng: ''
        }
      };

      sessionStorage.setItem('keyWord',JSON.stringify(obj));
      sessionStorage.setItem('fromTo','EnterpriseVillages');
      history.push('/main/object/objectSearch');
    }

    onDataSource1Change = (page,size) => {
      this.checkHelpList(page,size);
    }

    onError = (e) => {
      e.target.src = require('./images/nanren.png');
    }

    onResize = () => {
        if(this.pie)
        {
            this.pie.resize();
        }
    }

    onSort = (obj) => {
        this.order_by = 'helpPolulationNum';
        this.sort_by = obj.type.toLocaleUpperCase();
        this.initEnterpriseList(0,19,this.districtCode,this.rightType,this.companyName,this.order_by,obj.type.toLocaleUpperCase(),this.param);
    }

    componentDidMount () {
        this.initCity();
        this.initEnterpriseList();
        // this.initPieChartData();
        this.initEcharts();
        window.addEventListener('resize',this.onResize);
    }

    componentWillUnmount () {
        window.removeEventListener('resize',this.onResize);
        if(this.pie)
        {
            this.pie.dispose();
        }
    }

    render() {

        const columns = [
            {
                label: '企业名称',
                key: 'companyName',
                style: {
                    width: '65%'
                }
            },
            {
                label: '帮扶人数',
                key: 'num',
                style: {
                    width: '15%'
                },
                sortable: true
            },
            {
                label: '帮扶金额',
                key: 'total',
                filter: (item) => {
                    return item.total + '万元';
                },
                style: {
                    width: '20%'
                }
            }
        ];

        const columns1 = ['pic','name','idnumber','poorStatus'];

        const selectList = [
            {
                text: '本地民营企业帮扶',
                value: '1'
            },
            {
                text: '本地贫困村受帮扶',
                value: '2'
            }
        ];

        const selectList2 = [
            {
                text: '参与帮扶企业数',
                value: '0'
            },
            {
                text: '企业实施项目数',
                value: '1'
            },
            {
                text: '企业投入总金额',
                value: '2'
            },
            {
                text: '受帮扶村数',
                value: '3'
            },
            {
                text: '受帮扶贫困人数',
                value: '4'
            },
            {
                text: '脱贫人口数',
                value: '5'
            }
        ];

        return (
            <div className={style.container}>
                <div className={style.content}>
                    <div className={style.left}>
                        <Card title={
                            <span onClick={this.refreshEnterpriseList} style={{cursor: 'pointer'}}>
                              信息汇总
                            </span>
                          } subTitle={
                                <div className={style.totalSubTitle}>
                                    <div style={{marginRight: '0.75rem'}}>
                                        <Select autoWidth list={selectList} map={{
                                                text: 'text',
                                                value: 'value'
                                            }} onChange={this.leftTableChange}/>
                                    </div>
                                    <div>
                                        <Select autoWidth list={selectList2} map={{
                                                text: 'text',
                                                value: 'value'
                                            }} onChange={this.leftTypeChange}/>
                                    </div>
                                </div>
                            }>
                            <div className={style.chartContainer}>
                                <div>
                                    <div>
                                        <h3>受帮扶情况</h3>
                                        <div ref='pie'></div>
                                    </div>
                                    <div className={style.legend}>
                                        {
                                            this.state.chartCityList.map((item,index) => {
                                                return (
                                                    <div style={index > 12 ? {marginLeft: '1rem'} : {}} className={this.city ? style.legendDefaultInfo : style.legendInfo} key={index} onClick={this.checkCityDetail.bind(this,item.district)}>
                                                        <div className={style.block} style={{background: this.colors[index]}}></div>
                                                        <div style={item.district == '合计' ? {color: '#fff', textDecoration: 'none'} : {}}>
                                                            <span>{item.district}</span>
                                                            <span>&nbsp;&nbsp;&nbsp;&nbsp;</span>
                                                            <span>{item.count}</span>
                                                        </div>
                                                    </div>
                                                )
                                            })
                                        }
                                    </div>
                                </div>
                                <div><Pathway data={this.state.enterpriseWayList}/></div>
                            </div>
                        </Card>
                    </div>
                    <div className={style.right}>
                        <Card title="帮扶信息" subTitle={
                                <div className={style.infoTitle}>
                                    <div>
                                        <Select compact autoWidth list={selectList} disabled={!this.state.isTable} ref='selectType' map={{
                                                text: 'text',
                                                value: 'value'
                                            }} onChange={this.rightTypeChange}/>
                                    </div>
                                    <div>
                                        <Select compact list={this.state.cityList} onChange={this.onCityChange} scope={this.scope1} disabled={!this.state.isTable} ref='select1' map={{
                                                value: 'id',
                                                text: 'name'
                                            }}/>
                                    </div>
                                    <div>
                                        <Select compact list={this.state.countyList} onChange={this.onCountyChange} scope={this.scope2} disabled={!this.state.isTable} ref='select2' map={{
                                                value: 'id',
                                                text: 'name'
                                            }}/>
                                    </div>
                                    <div>
                                        <Select compact list={this.state.xiangList} onChange={this.onXiangChange} scope={this.scope3} disabled={!this.state.isTable} ref='select3' map={{
                                                value: 'id',
                                                text: 'name'
                                            }}/>
                                    </div>
                                    <div>
                                        <Select compact list={this.state.cunList} onChange={this.onCunChange} scope={this.scope4} disabled={!this.state.isTable} ref='select4' map={{
                                                value: 'id',
                                                text: 'name'
                                            }}/>
                                    </div>
                                    <div>
                                        <input type="text" placeholder={
                                            this.state.isTable ? '请输入公司名称' : '请输入姓名'
                                        } ref='companyName' onKeyPress={this.inputKeyPress}/>
                                    </div>
                                    <div className={style.search}>
                                        <button onClick={this.search}>
                                            <img src={require('./images/search.png')}/>
                                        </button>
                                    </div>
                                </div>
                            }>
                            {
                                this.state.isTable ? (
                                    <Table ref='table' columns={columns} dataSource={this.state.enterpriseList} pageable={this.state.enterprisePageable} rowOpen={this.rowOpen} open={(this.changeTypeFlag && this.saveSearchParams) ? this.saveSearchParams.openIndex : ''} onChange={this.onEnterpriseTableChange} height='39.05rem' sortCallBack={this.onSort}/>
                                ) : (
                                    <div className={style.peopleList}>
                                        <div className={style.back}>
                                            <img src={require('./images/back.png')} onClick={this.changeType}/>
                                        </div>
                                        <table className={style.peopleListContent}>
                                            <tbody>
                                                {
                                                  this.state.dataSource1.length ? (
                                                    this.state.dataSource1.map((row,rIndex) => {
                                                        return (
                                                            <tr onClick={this.onCheckDetail.bind(this,row)}>
                                                                {
                                                                    columns1.map((column,cIndex) => {
                                                                        if(column === 'pic')
                                                                        {
                                                                            return (
                                                                                <td>
                                                                                    <div className={style.avatar}>
                                                                                        <img src={row[column]} onError={this.onError}/>
                                                                                    </div>
                                                                                </td>
                                                                            );
                                                                        }else if(column === 'poorStatus')
                                                                        {
                                                                            try {
                                                                                return (
                                                                                    <td>
                                                                                        <div className={style.status}>
                                                                                            <img src={require('./images/' + row[column] + '.png')}/>
                                                                                        </div>
                                                                                    </td>
                                                                                );
                                                                            } catch (e) {
                                                                                return (
                                                                                    <td>
                                                                                        <div className={style.status}>

                                                                                        </div>
                                                                                    </td>
                                                                                );
                                                                            }
                                                                        }else{
                                                                            return (
                                                                                <td>
                                                                                    <div className={style.default}>
                                                                                        {row[column]}
                                                                                    </div>
                                                                                </td>
                                                                            );
                                                                        }
                                                                    })
                                                                }
                                                            </tr>
                                                        );
                                                    })
                                                  ) : (
                                                    <div className={style.noData} style={{height: '36.9rem',textAlign: 'center',fontSize: '0.8rem'}}>
                                                      <div>暂无数据</div>
                                                      <div className={style.noDataLine}></div>
                                                    </div>
                                                  )
                                                }
                                            </tbody>
                                        </table>
                                        {
                                            this.state.dataSource1Pageable.total && this.state.dataSource1Pageable.total > 8 ? (
                                                <div className={style.peopleListPagination}>
                                                  <Pagination {...this.state.dataSource1Pageable} onChange={this.onDataSource1Change}/>
                                                </div>
                                            ) : ''
                                        }
                                    </div>
                                )
                            }
                        </Card>
                    </div>
                </div>
            </div>
        );
    }
}

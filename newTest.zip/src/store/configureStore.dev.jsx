import {createStore, combineReducers, compose, applyMiddleware} from 'redux'
// import createFetchMiddleware from 'redux-composable-fetch';
import ThunkMiddleware from 'redux-thunk'
// import rootReducer from './reducers'
import rootReducer from '../reducers'
import DevTools from './DevTools'

const finalCreateStore = compose(
    applyMiddleware(ThunkMiddleware),
    DevTools.instrument()
)(createStore);

// const reducer = combineReducers(Object.assign({}, rootReducer))

export default function configureStore(initialState) {
    const store = finalCreateStore(rootReducer, initialState)
    return store;
}

// 上帝保佑,永无bug

// 用户名
export const USERNAME = 'username';

export const FULLNAME = 'fullname';

// 用户token
export const TOKEN = 'token';

export const RETOKEN = 'retoken';

export const REMEMBERME = 'rememberme';

export const PASSWORD = 'password';

export const PHONE = 'phone';

export const KEYWORD = 'keyWord';

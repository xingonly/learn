// 上帝保佑,永无bug
export const USERINFO_UPDATE = 'USERINFO_UPDATE'

export const ID = 'ID'

export const CHANGE_STEP = 'CHANGE_STEP'

export const SELECT_AREA_CHANGE = 'SELECT_AREA_CHANGE'

export const Params_CHANGE = 'Params_CHANGE'
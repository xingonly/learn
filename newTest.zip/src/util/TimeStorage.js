class TimeStorage {
  constructor (props) {
    // 过期时间，单位秒
    const timer = (props && props.time) || 0;

    this.getItem = (key) => {
      const hashKey = this.strHash(key || '');
      const current = new Date().getTime();
      try {
        const item = JSON.parse(localStorage.getItem(hashKey));
        if(timer)
        {
          if(current - item.time >= timer)
          {
            localStorage.removeItem(hashKey);
            return null;
          }else{
            return item.data;
          }
        }else{
          return item.data;
        }
      } catch (e) {
        return null;
      }
    }

    this.setItem = (key, item) => {
      const hashKey = this.strHash(key || '');
      const current = new Date().getTime();
      localStorage.setItem(hashKey, JSON.stringify({
        data: item,
        time: current
      }));
    }

    this.strHash = (key) => {
      const arraySize = 11113; // 数组大小一般取质数
      let hashCode = 0;
      for (let i = 0;i < key.length;i++) { // 从字符串的左边开始计算
          const letterValue = key.charCodeAt(i) - 96;  // 将获取到的字符串转换成数字，比如 a 的码值是 97，则 97 - 96 = 1 就代表a的值，同理b=2；
          hashCode = ((hashCode << 5) + letterValue) % arraySize;// 防止编码溢出，对每步结果都进行取模运算
      }
      return key + '_' + hashCode;
    }

  }
}

export default TimeStorage;

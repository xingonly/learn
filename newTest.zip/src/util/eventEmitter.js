// 上帝保佑,永无bug
import {EventEmitter} from 'events';

// 事件
export default new EventEmitter();
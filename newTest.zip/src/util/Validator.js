// 策略模式编写表单验证
export default class Validator {
    strategies = {
        isEmpty: function (value, errorMsg) {
            if (!value) {
                return errorMsg;
            }
        },
        isLegal: function (value, errorMsg, reg) {
            if (!eval(reg).test(value)) {
                return errorMsg;
            }
        }
    };

    cache = [];

    add(value, rule, errorMsg, reg) {
        this.cache.push(() => {
            return this.strategies[rule].call(this, value, errorMsg, reg);
        });
    }

    start() {
        for (let i = 0, validtorFunc; validtorFunc = this.cache[i++];) {
            let msg = validtorFunc();
            if (msg) {
                return msg;
            }
        }
    }

    reset() {
        this.cache = [];
    }
}


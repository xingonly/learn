export function convertQueryString (params) {
  var query = '';
  if(!params)
  {
    return query;
  }
  for(let key in params)
  {
      if(params[key] || params[key] === 0)
      {
          if(query.indexOf('?') === -1)
          {
              query = query + `?${key}=${params[key]}`;
          }else{
              query = query + `&${key}=${params[key]}`;
          }
      }
  }
  return query;
}

export function isDeepEmpty(obj) {
  let result = true;
  if(typeof obj !== 'object' && (obj || obj === 0) )
  {
    return false;
  }
  for(let key in obj)
  {
    if(typeof obj[key] === 'object')
    {
      result = isDeepEmpty(obj[key]);
      if(!result)
      {
        return result;
      }
    }else{
      if(obj[key] || obj[key] === 0)
      {
        return false;
      }
    }
  }
  return result;
}

export function formatDateT (d, type, split) {
  type = type || 'second';
  split = split || ['-', ':'];
  if(!d)
  {
    return;
  }

  var date = new Date(d);
  var year = date.getFullYear();
  var month = date.getMonth() < 9 ? '0' + (date.getMonth() + 1) : (date.getMonth() + 1);
  var day = date.getDate() < 10 ? '0' + date.getDate() : date.getDate();
  var hour = date.getHours() < 10 ? '0' + date.getHours() : date.getHours();
  var minute = date.getMinutes() < 10 ? '0' + date.getMinutes() : date.getMinutes();
  var second = date.getSeconds() < 10 ? '0' + date.getSeconds() : date.getSeconds();

  switch (type) {
    case 'day':
      var splitStr = split[0] + '';
      return year + splitStr + month + splitStr + day;
    default:
    return year + split[0] + month + split[0] + day + ' ' + hour + split[1] + minute + split[1] + second;
  }
}

export const deepCopy = obj => {
  if (typeof obj !== 'object' || obj === null) {
    return obj
  }
  let result = obj instanceof Array ? [] : {}
  for (let key in obj) {
    result[key] = deepCopy(obj[key])
  }

  return result
}

export const Trim = (str,is_global) => {
  let result;
  result = str.replace(/(^\s+)|(\s+$)/g,"");
  if(is_global.toLowerCase()=="g")
  {
    result = result.replace(/\s/g,"");
  }
  return result;
}

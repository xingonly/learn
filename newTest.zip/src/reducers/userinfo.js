import * as actionTypes from '../constants/redux'

export default function userinfo (state = {}, action) {
    switch (action.type) {
        case actionTypes.USERINFO_UPDATE:
            return action
        case actionTypes.ID:
            return action
        default:
            return {name: 'czl'}
    }
}
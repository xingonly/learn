import { combineReducers } from 'redux'
import userinfo from './userinfo'
import relocated from './relocated'

export default combineReducers({
    userinfo,
    relocated
})
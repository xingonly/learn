import React, {Component} from 'react'
import { connect } from 'react-redux'
class App extends Component{
    handleClick = () => {
        console.log(this.props)
    }
    render(){
        return <div onClick={this.handleClick}>
            hello,guigui
        </div>
    }
}

let newData = () => {
    return <div>{<App/>}</div>
}

export {newData}
let  addTest = ( state = 0, action) => {
    if(action.type === 'create'){
        return ++state;
    }else{
        return --state;
    }
}

export const firstNamedReducer = (state = 1, action) => state;

export const secondNamedReducer = (state = 2, action) => state;

export {addTest}
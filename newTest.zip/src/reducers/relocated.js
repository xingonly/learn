import * as actionTypes from '../constants/redux'

let initState = {
    year: new Date().getFullYear(),
    step: 0,
    district_code: 520000000000
}

export default function reloadReducer (state = initState, action) {
    switch (action.type) {
        case actionTypes.CHANGE_STEP:
            return {
                step: action.payload || 0
            };
        case actionTypes.SELECT_AREA_CHANGE:
            return action
        case actionTypes.Params_CHANGE:
            return {
                district_code: action.payload || 520000000000 // 改变状态
            };
        default:
            return state
    }
}

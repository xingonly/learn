//上帝保佑,永无bug
const path = require("path");
const webpack = require('webpack');
const CleanWebpackPlugin = require('clean-webpack-plugin'); // 清理文件夹
const uglifyJsPlugin = webpack.optimize.UglifyJsPlugin;
const HtmlWebpackPlugin = require('html-webpack-plugin');
const ExtractTextPlugin = require("extract-text-webpack-plugin");

const sourcePath = path.resolve('src')

module.exports = {
    //设置人口文件的绝对路径
    entry: {
        bundle: ["babel-polyfill", path.resolve("src/index.jsx")],
        vendor: ['react', 'react-dom']
    },
    output: {
        path: path.resolve("./static"),
        filename: "[name].[hash:8].js",
    },

    module: {
        // 配置编译打包规则
        rules: [
            {
                test: /\.(js|jsx)$/,
                exclude: /node_modules/,
                use: ['react-hot-loader', 'babel-loader']
            },
            {
                test: /\.css/,
                use: ExtractTextPlugin.extract({
                    fallback: "style-loader",
                    use: [{
                        loader: 'css-loader',
                        options: {
                            // minimize: true
                        }
                    }]
                })
            },
            {
                test: /\.scss/,
                exclude: path.resolve(__dirname, './src/static/scss/app.scss'),
                use: ExtractTextPlugin.extract({
                    fallback: "style-loader",
                    use: [{
                        loader: 'css-loader',
                        options: {
                            // minimize: true,
                            modules: true,
                            localIdentName: '[local][hash:base64:6]'
                        }
                    }, 'postcss-loader', 'sass-loader', 'resolve-url-loader', 'sass-loader?sourceMap']
                })
            },
            {
                test: /\.scss/,
                include: path.resolve(__dirname, './src/static/scss/app.scss'),
                use: ExtractTextPlugin.extract({
                    fallback: "style-loader",
                    use: [{
                        loader: 'css-loader',
                        options: {
                            minimize: true
                        }
                    }, 'postcss-loader', 'sass-loader', 'resolve-url-loader', 'sass-loader?sourceMap']
                })
            },
            {
                test: /\.(woff|woff2|ttf|svg|eot)(\?t=[\s\S]+)?$/,
                use: ['url-loader?limit=1000&name=[md5:hash:base64:10].[ext]']
            },
            {
                test: /\.(swf)$/,
                use: ['url-loader?limit=1000&name=[md5:hash:base64:10].[ext]']
            },
            {
                test: /\.(jpeg|jpg|png|gif)$/,
                //use: ['url-loader?limit=1000&name=[md5:hash:base64:10].[ext]&outputPath=images/','image-webpack-loader?bypassOnDebug']
                use: ['url-loader?limit=1000&name=[md5:hash:base64:10].[ext]&outputPath=images/']

            },
            {
                test: /\.json$/,
                use: ['json-loader']
            }
        ]
    },

    resolve: {
        extensions: ['.js', '.jsx'],
        alias: {
            resource: path.resolve('./src/util/resource.js'),
            static: path.resolve('./src/static'),
            utils: path.resolve('./src/util/utils.js'),
            components: path.resolve('./src/components'),
            containers: path.resolve('./src/containers'),
            util: path.resolve('./src/util')
        },
        modules: [sourcePath, 'node_modules']
    },
    plugins: [
        new CleanWebpackPlugin(['static']), // 清空目录
        new HtmlWebpackPlugin({
            // title: '贵州省煤矿产业云平',// 标题
            favicon:  path.resolve("./src/static/images/favicon.ico"),
            template: './src/index.html', // 模板文件
            filename: './index.html' // 产出后的文件名称
        }),
        new uglifyJsPlugin({
            compress: {
                warnings: false,
                drop_debugger: true,
                drop_console: true
            }
        }),

        /*
        * For react you can use this plugin for production. It reduces the size of the react lib to ~95kb (yes thats less than the prebuild minimized react.min.js in the bower package).
        * */
        new webpack.DefinePlugin({
            'process.env': {
                NODE_ENV: JSON.stringify('production')
            }
        }),

        new webpack.optimize.CommonsChunkPlugin({
            names: ['vendor'],
            minChunks: Infinity,
            filename: '[name].js'
        }),

        new ExtractTextPlugin("bundle.[hash:8].css"),
    ]
};

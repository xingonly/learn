import React, { Component } from 'react';
import {
  Route,
  Switch,
  Redirect,
  withRouter
} from "react-router-dom";
import Main from "./components/main/main"
import Logined from "./components/login/logined"
import Forget from './components/login/logins/forget'
import Create from './components/login/logins/create'
import Authentica from './components/mine/mypages/authentica'
import Recovery from "./components/mine/mypages/recovery"
import Invitation from "./components/mine/mypages/invitat/invitation"
import BankCard from "./components/mine/mypages/bankcard"
import HelpCenter from "./components/mine/mypages/helpcenter"
import FeedBack from "./components/mine/mypages/feedback"
import SystemSetup from "./components/mine/mypages/systemsetup/systemsetup"
import aboutUs from "./components/mine/mypages/systemsetup/system/aboutus"
import amendPwd from "./components/mine/mypages/systemsetup/system/amendpwd"
import verSions from "./components/mine/mypages/systemsetup/system/versions"
import addUp from "./components/mine/mypages/invitat/children/addup"
import Rule from "./components/mine/mypages/invitat/children/rule"
import Win from "./components/mine/mypages/invitat/children/win"
class App extends Component {
  componentDidMount(){
    let tok = localStorage.getItem("token")
    if(tok == null){
      localStorage.setItem("token","")
    }
  }
  render() {
    return (
          <Switch>
            <Route path = "/" exact render={()=><Redirect to="/main"/>}></Route>
            <Route path = "/main"  component={Main}></Route>
            <Route path = "/logined" component={Logined}></Route>
            <Route path = "/forget" component={Forget}></Route>
            <Route path = "/create" component={Create}></Route>
            <Route path = "/authentica" component={Authentica}></Route>
            <Route path = "/recovery" component={Recovery}></Route>
            <Route path = "/invitation" component={Invitation}></Route>
            <Route path = "/bankcard" component={BankCard}></Route>
            <Route path = "/helpcenter" component={HelpCenter}></Route>
            <Route path = "/feedback" component={FeedBack}></Route>
            <Route path = "/systemsetup" component={SystemSetup}></Route>
            <Route path = "/addup" component={addUp}></Route>
            <Route path = "/rule" component={Rule}></Route>
            <Route path = "/win" component={Win}></Route>
            <Route path = "/aboutus" component={aboutUs}></Route>
            <Route path = "/amendpwd" component={amendPwd}></Route>
            <Route path = "/versions" component={verSions}></Route>
          </Switch>
    );
  }
}
 
export default withRouter(App);

import React , {Component} from "react"

class Order extends Component {

    render(){
        return(
            <div className="me">
               Order
            </div>
        )
    }
}
export default Order
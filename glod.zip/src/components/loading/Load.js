import React , {Component} from "react"
import "./Load.css"
class Load extends Component {
    constructor(){
        super()
        this.state={

        }
    }
    render(){
        return(
            <div className="load">
               启动页
            </div>
        )
    }
}
export default Load
import React , {Component} from "react"
import './Advert.css'
class Advert extends Component {
    constructor(){
        super()
        this.state={
            del:true
        }
    }
    getDel(){
        this.setState({
          del:!this.state.del
        })
    }
    render(){
        return(
            <div className="advert">
               广告页
               {
                   this.state.del?<div id="versions">
                    <div className="mi">
                        <p onClick={()=>{
                        this.getDel()
                        }}>X</p>
                        <button>立即升级</button>
                    </div>
                    </div>:null
                }
            </div>
        )
    }
}
export default Advert
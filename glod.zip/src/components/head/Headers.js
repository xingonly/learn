import React , {Component} from "react"
import './header.css'
class Headers extends Component {
    constructor(){
        super()
        this.state={

        }
    }
    render(){
        return(
            <div className="bigHeader">
                <div className="header">
                  <p><i className="icon iconfont icon-xiaoxi2"></i><i></i></p>
                  <h1><span>五组金服</span></h1>
                  <p>
                    <i className="icon iconfont icon-fangdajing"></i>
                    <i className="icon iconfont icon-gouwuche"></i>
                 </p>
               </div>
               <div className="redSmallCircle"><p><span></span></p></div>
               <div className="redCircle"><p><span><small>1</small></span></p></div>
            </div>
        )
    }
}
export default Headers;
import React , {Component} from "react"
import Headers from "../head/Headers"
import "./home.css"
import { Carousel, WingBlank } from 'antd-mobile';
class Home extends Component {
    constructor(){
        super()
        this.state={
          data: ['1', '2', '3'],
          imgHeight: 200,
        }
    }
     componentDidMount() {
      setTimeout(() => {
        this.setState({
          data: ['https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1528473983739&di=d103bbf28091aa5824dda11ade16dcb7&imgtype=0&src=http%3A%2F%2Fimg.zcool.cn%2Fcommunity%2F011b1e554316e30000019ae9c649b4.jpg%401280w_1l_2o_100sh.png', 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1528473917086&di=b5cfdb4a9b05b2c6ac9eacaf88d5bad5&imgtype=0&src=http%3A%2F%2Fimg.zcool.cn%2Fcommunity%2F01d6405938f2a1a8012193a3df2122.jpg%402o.jpg', 'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1529068653&di=eea103ebac1e87eb8d2eb758e60ed00f&imgtype=jpg&er=1&src=http%3A%2F%2Fimg.zcool.cn%2Fcommunity%2F0128c157d4c3480000018c1be504b9.png'],
        });
      }, 100);
  }
    render(){
        return(
            <div className="home">
               <Headers></Headers>
               <div className="content">
                   <div className="wrap">
                      <WingBlank>
                          <Carousel
                            autoplay={true}
                            infinite
                          >
                            {this.state.data.map(val => (
                                  <a
                                    key={val}
                                    href="http://www.alipay.com"
                                    style={{ display: 'inline-block', width: '100%', height: this.state.imgHeight }}
                                  >
                                <img
                                  src={val}
                                  alt=""
                                  style={{ width: '100%', verticalAlign: 'top' }}
                                  onLoad={() => {
                                    window.dispatchEvent(new Event('resize'));
                                    this.setState({ imgHeight: 'auto' });
                                  }}
                                />
                              </a>
                            ))}
                        </Carousel>
                      </WingBlank>
                   </div>
                   <div className="Longitudinal">
                        <WingBlank>
                            <Carousel className="my-carousel"
                              vertical
                              dots={false}
                              dragging={false}
                              swiping={false}
                              autoplay
                              infinite
                            >
                              <div className="v-item">carousel 1</div>
                              <div className="v-item">carousel 2</div>
                              <div className="v-item">carousel 3</div>
                            </Carousel>
                        </WingBlank>
                   </div>
                   <div className="apple">
                        <dl>
                           <dt>
                                <img src="https://gss1.bdstatic.com/-vo3dSag_xI4khGkpoWK1HF6hhy/baike/c0%3Dbaike150%2C5%2C5%2C150%2C50/sign=a4751d3d3dd3d539d53007915bee8235/203fb80e7bec54e75b4e27ddb2389b504ec26a56.jpg"/>
                           </dt>
                           <dd>
                               <p>您的手机</p>
                               <p>型号：iphone7s</p>
                               <p>内存：64G</p>
                               <p>最高回收价：4000</p>
                           </dd>
                       </dl>
                       <button className="btnMany">马上评估，立即拿钱</button>
                   </div>
               </div>
            </div>
        )
    }
}
export default Home
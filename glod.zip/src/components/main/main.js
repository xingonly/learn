import React, { Component } from 'react';

import {
  Route,
  NavLink,
  Switch,
  withRouter
} from "react-router-dom";
import './App.css';
import Home from "../home/home"
import Order from '../order/order'
import Mine from "../mine/mine"
import 'antd-mobile/dist/antd-mobile.css';
class App extends Component {
  constructor(props){
    super(props)
    this.state={

    }
  }
  TopathName(){
    let token = localStorage.getItem("token")
     const { history } = this.props;
    if(token === ""){
      history.push("/logined")
    }else{
      history.push("/main/mine")
    }
  }
  render() {
    return (
      <div className="App">
        <section>
          <Switch>
            <Route path="/main" exact component={Home}></Route>
            <Route path="/main/order" exact component={Order}></Route>
            <Route path="/main/mine" exact component={Mine}></Route>
          </Switch>
        </section>
        <footer>
          <NavLink to="/main" >主页</NavLink>
          <NavLink to="/main/order" >订单</NavLink>
          <a onClick={this.TopathName.bind(this)}>我的</a>
        </footer>
      </div>
    );
  }
}
let newApp = withRouter(App)
export default newApp;
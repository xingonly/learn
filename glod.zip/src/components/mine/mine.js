import React , {Component} from "react"
import './mine.css'
import {
    NavLink
} from "react-router-dom";

class Mine extends Component {
    constructor(){
        super()
        this.state={

        }
    }
    render(){
        return(
            <div className="me">
               <h3>我的</h3>
               <div className="box">
                    <div className="logo"><i className="icon iconfont icon-default-avatar"></i></div>
                    <p>ID:1556700188</p>
               </div>
               <div className="list">
                    <NavLink to="/authentica" ><span><i className="icon iconfont icon-xuanzhong-01"></i>认证中心</span><i className="icon iconfont icon-chevron-thin-right"></i></NavLink>
                    <NavLink to="/recovery" ><span><i className="icon iconfont icon-wenjian"></i>回收记录</span><i className="icon iconfont icon-chevron-thin-right"></i></NavLink>
                    <NavLink to="/invitation" ><span><i className="icon iconfont icon-user"></i>邀请有礼</span><i className="icon iconfont icon-chevron-thin-right"></i></NavLink>
                    <NavLink to="/bankcard" ><span><i className="icon iconfont icon-qiaquan"></i>银行卡</span><i className="icon iconfont icon-chevron-thin-right"></i></NavLink>
                    <NavLink to="/helpcenter" ><span><i className="icon iconfont icon-kefu"></i>帮助中心</span><i className="icon iconfont icon-chevron-thin-right"></i></NavLink>
                    <NavLink to="/feedback" ><span><i className="icon iconfont icon-xinxi"></i>意见反馈</span><i className="icon iconfont icon-chevron-thin-right"></i></NavLink>
                    <NavLink to="/systemsetup" ><span><i className="icon iconfont icon-shezhi1"></i>系统设置</span><i className="icon iconfont icon-chevron-thin-right"></i></NavLink>
               </div>
            </div>
        )
    }
}
export default Mine
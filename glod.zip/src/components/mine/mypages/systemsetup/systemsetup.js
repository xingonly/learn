import React , {Component} from "react"
import './systemsetup.css'

import { ActionSheet,Button} from 'antd-mobile';
const isIPhone = new RegExp('\\biPhone\\b|\\biPod\\b', 'i').test(window.navigator.userAgent);
let wrapProps;
if (isIPhone) {
  wrapProps = {
    onTouchStart: e => e.preventDefault(),
  };
}

class SystemSetup extends Component {
    constructor(){
        super()
        this.state={
            checked:'none'
        }
    }
    showActionSheet = () => {
      const BUTTONS = [ '确定', '取消'];
      ActionSheet.showActionSheetWithOptions({
        options: BUTTONS,
        cancelButtonIndex: BUTTONS.length - 1,
        destructiveButtonIndex: BUTTONS.length - 2,
        // title: 'title',
        message: '确定要退出当前账号吗?',
        maskClosable:false,
        'data-seed': 'logId',
        wrapProps,
      },
      (buttonIndex) => {
        if(buttonIndex === 0){
            this.props.history.push("/main")
            localStorage.setItem("token","")
        }else{
            this.props.history.push("/systemsetup")
        }
        
        this.setState({ clicked: BUTTONS[buttonIndex] });
      });
     
    }
    back(){
        this.props.history.push("/main/mine")
    }
    aboutus(){
        this.props.history.push("/aboutus")
    }
    versions(){
        this.props.history.push("/versions")
    }
    amendpwd(){
        this.props.history.push("/amendpwd")
    }
    render(){
        return(
            <div className="me">
                <header><span onClick={this.back.bind(this)}><i className="icon iconfont icon-zuojiantou-01"></i></span><strong>系统设置</strong><strong></strong></header>
                <ul>
                    <li>清除缓存<span><i className="icon iconfont icon-youjiantou-01"></i></span></li>
                    <li onClick={this.aboutus.bind(this)}>关于我们<span><i className="icon iconfont icon-youjiantou-01"></i></span></li>
                    <li onClick={this.versions.bind(this)}>版本说明<span><i className="icon iconfont icon-youjiantou-01"></i></span></li>
                    <li onClick={this.amendpwd.bind(this)}>修改密码<span><i className="icon iconfont icon-youjiantou-01"></i></span></li>
                </ul>
                <Button className="btn" onClick={this.showActionSheet}>退出登录</Button>
            </div>
        )
    }
}
export default SystemSetup
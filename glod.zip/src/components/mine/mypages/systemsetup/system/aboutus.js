import React , {Component} from 'react'
import "./aboutus.css"
import {connect} from 'react-redux'
class AboutUs extends Component{
    constructor(props){
        super()
        this.state={

        }
    }
    back(){
        this.props.history.push("/systemsetup")
    }
    render(){
        const {aboutus}=this.props;
        return (
            <div className="about">
                <header><span onClick={this.back.bind(this)}><i className="icon iconfont icon-zuojiantou-01"></i></span><strong>系统设置</strong><strong></strong></header>
                <div>
                    {
                        aboutus.map((item,key)=>{
                            console.log(item)
                            return <div key={key}>
                            <dl>
                                <dt><img src={item.img} alt=""/>
                                </dt>
                                <dd>{item.name}</dd>
                            </dl>
                            <ul>
                                <li>公司介绍:{item.company}</li>
                                <li>客服热线:{item.hotline}</li>
                                <li>客服邮箱:{item.email}</li>
                                <li>微信公众号:{item.accounts}</li>
                                <li>官方QQ群:{item.qq}</li>
                                <li>当前版本:{item.versions}</li>
                            </ul>
                            </div>

                        })
                    }
                </div>
            </div>
        )
    }
}
const mapStateToProps = (state) => {
    return {
        aboutus:state.getall.getsystem.about
    }
}
export default connect(mapStateToProps)(AboutUs)

import React , {Component} from 'react'
import './amendpwd.css'
class AboutUs extends Component{
    constructor(props){
        super()
        this.state={

        }
    }
    back(){
        this.props.history.push("/systemsetup")
    }
    render(){
        return (
            <div className="amendpwd">
                <header><span onClick={this.back.bind(this)}><i className="icon iconfont icon-zuojiantou-01"></i></span><strong>修改密码</strong><b>完成</b></header>
                <ul>
                <li><span>旧密码</span><input type="password" placeholder="请输入旧密码"/></li>
                <li><span>新密码</span><input type="password" placeholder="请输入新密码(6至20位数字或字母)"/></li>
                <li><span>确认密码</span><input type="password" placeholder="请再次输入新密码"/></li>
                </ul>
            </div>
        )
    }
}
export default AboutUs;
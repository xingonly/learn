import React , {Component} from 'react'
import './versions.css'
import {connect} from 'react-redux'
class Versions extends Component{
    constructor(props){
        super()
        this.state={

        }
    }
    back(){
        this.props.history.push("/systemsetup")
    }
    render(){
        let {versions}=this.props;
        return (
            <div className="versions">
                <header><span onClick={this.back.bind(this)}><i className="icon iconfont icon-zuojiantou-01"></i></span><strong>版本说明</strong><strong></strong></header>
                <dl>
                    <dt><img src="https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1528714990254&di=23c65bf3c9410f9fe070d31ee5d85ddb&imgtype=0&src=http%3A%2F%2Fimgsrc.baidu.com%2Fimgad%2Fpic%2Fitem%2F43a7d933c895d143a26d03eb79f082025baf07da.jpg"/></dt>
                    <dd>版本不息，优化不止</dd>
                </dl>
                <div>
                    {
                        versions.map((item,key)=>{
                            return <h4 key={key}>
                                <strong><b>{item.version}</b><span>{item.time}</span></strong>
                                <p>{item.tit}</p>
                            </h4>
                        })
                    }
                </div>
            </div>
        )
    }
}
const mapStateToProps = (state) => {
    return {
        versions:state.getall.getsystem.version
    }
}
export default connect(mapStateToProps)(Versions)
import React , {Component} from "react"
import "./helpcenter.css"
import "../../../font/iconfont.css"
import { connect } from "react-redux"
class HelpCenter extends Component {
    constructor(props){
        super(props)
        this.state={
            
        }
    }
    back(){
        this.props.history.push("/main/mine")
    }
    render(){
        const {helpcenter}=this.props;
        return(
            <div className="help_center">
                <header className="helpcenter_header">
                    <i className="icon iconfont icon-xiangzuo" onClick={this.back.bind(this)}></i>
                    <span>服务中心</span>
                </header>
                <section className="helpcenter_section">
                    <div className="helpcenter_font">
                        <div className="helpcenter_box">
                            <dl>
                                <dt>
                                    <i className="icon iconfont icon-weixin1"></i>
                                </dt>
                                <dd>在线客服</dd>
                            </dl>
                        </div>
                        <div className="helpcenter_box">
                            <dl>
                                <dt>
                                    <i className="icon iconfont icon-dianhua"></i>
                                </dt>
                                <dd>客服热线</dd>
                            </dl>
                        </div>
                    </div>
                    <div className="helpcenter_question">
                            <p className="question">常见问题</p>
                            <div>
                                {
                                    
                                    helpcenter!==null&&helpcenter.map((item,key)=>{
                                        
                                        return Object.keys(item).length !=3 ?
                                        <div key={key}>
                                            <p>问：{item.question}</p>
                                            <p>答：{item.answer}</p>
                                        </div>:<div key={key}>
                                            <p>问：{item.question}</p>
                                            <p>答：{item.answer}</p>
                                            <p>{item.anr}</p>
                                        </div>
                                    })
                                }
                            </div>
                        </div>
                </section>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        helpcenter:state.getall.gethelpcenter
    }
}
export default connect(mapStateToProps)(HelpCenter)
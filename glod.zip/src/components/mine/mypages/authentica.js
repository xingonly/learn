import React , {Component} from "react"
import "./authentica.css"
import "../../../font/iconfont.css"
import { connect } from "react-redux"
import {
    NavLink
} from "react-router-dom";

class Authentica extends Component {
    constructor(props){
        super(props)
        this.state={
            
        }
    }
    back(){
        this.props.history.push("/main/mine")
    }
    render(){
        const {authentica}=this.props;
        return(
            <div className="authentica">
                <header>
                    <i className="icon iconfont icon-xiangzuo" onClick={this.back.bind(this)}></i>
                    <span onClick={this.back.bind(this)}>认证中心</span>
                </header>
                <section>
                    {
                        authentica!==null&&authentica.map((item,key) => {
                            return <ul key={key} className="authentica_ul">
                                        <li className="left">
                                            <i className={item.font}></i>  
                                            <span className="authentica_name">{item.name}</span>
                                        </li>
                                        {
                                            item.children.map((items,index) => {
                                                return <li key={index} className="right">
                                                    <i className={items.icon}></i>  
                                                    <span>{items.cname}</span>
                                                    <NavLink to={items.url}><i className="icon iconfont icon-angle-right"></i></NavLink>
                                                </li>
                                            })
                                        }
                                        
                                    </ul>
                        })
                    }
                    
                </section>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        authentica:state.getall.getauthentica
    }
}
export default connect(mapStateToProps)(Authentica)
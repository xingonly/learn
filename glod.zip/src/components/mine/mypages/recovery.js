import React , {Component} from "react"

class Recovery extends Component {
    constructor(){
        super()
        this.state={

        }
    }
    render(){
        return(
            <div className="me">
                回收
            </div>
        )
    }
}
export default Recovery
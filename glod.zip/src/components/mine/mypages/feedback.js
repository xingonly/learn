import React , {Component} from "react"
import './feedback.css'
import { connect } from "react-redux"
import { DatePickerView,List, TextareaItem ,Picker, WhiteSpace,ImagePicker, WingBlank, SegmentedControl,Toast} from 'antd-mobile';
import { createForm } from 'rc-form';
import arrayTreeFilter from 'array-tree-filter';

// import {datas} from '../../../mock/data/feedback.json'
import { district, provinceLite } from 'antd-mobile-demo-data';
class FeedBack extends Component {
    constructor(props){
        super(props)
        this.state={
            data: [],
            cols: 1,
            pickerValue: [],
            datas:this.props.datas
        }
    }
    feedIcon(){
        this.props.history.push('/main/mine')
    };
    feedbtn(){
          Toast.info('发送成功', 1);
    }
    render(){
        return(
            <div className="feedback">
                <div className="feedHead">
                   <p className="feedIcon" onClick={this.feedIcon.bind(this)}><i className="icon iconfont icon-xiangzuo"></i></p>
                   <h1><span>意见反馈</span></h1>
                </div>
                <div className="feedSect">
                    <div className="feed" >
                        <SwitchExample datas={this.state.datas}/>
                    </div>
                    <div className="feedsele">
                        <TextareaItemExample/>
                    </div>
                    <div className="feedQQ">
                      <List>
                         <TextareaItem placeholder="手机/邮箱/QQ(选填)"/>
                      </List>
                    </div>
                    <div className="feedImg">
                    <span>上传图片(最多六张)</span>
                      <ImagePickerExample/>
                    </div>
                    <button className="feedBtn" onClick={this.feedbtn}>提交</button>
                </div>
            </div>
        )
    }
}

let SwitchExample = (props)=>{
    const { getFieldProps } = props.form;
    const datas=props.datas
    return (
        <Picker data={datas} cols={1} {...getFieldProps('district3')} className="forss">
            <List.Item arrow="horizontal">请选择反馈类型</List.Item>
        </Picker>
    )
}
SwitchExample = createForm()(SwitchExample);


let TextareaItemExample = (props)=>{
    const { getFieldProps } = props.form;
    return (
           <List>
                 <TextareaItem placeholder='请写下您对五组金服的感受,我们讲认真听取您的意见,努力提供更优质的服务' rows={7}
                   count={100}/>
            </List>
    )
}
TextareaItemExample = createForm()(TextareaItemExample);


const data = [{
  url: 'https://zos.alipayobjects.com/rmsportal/PZUUCKTRIHWiZSY.jpeg',
  id: '2121',
}, {
  url: 'https://zos.alipayobjects.com/rmsportal/hqQWgTXdrlmVVYi.jpeg',
  id: '2122',
}];

class ImagePickerExample extends React.Component {
  state = {
    files: data,
    multiple: false,
  }
  onChange = (files, type, index) => {
    console.log(files, type, index);
    this.setState({
      files,
    });
  }
  onSegChange = (e) => {
    const index = e.nativeEvent.selectedSegmentIndex;
    this.setState({
      multiple: index === 1,
    });
  }

  render() {
    const { files } = this.state;
    return (
      <WingBlank>
        <ImagePicker
          files={files}
          onChange={this.onChange}
          onImageClick={(index, fs) => console.log(index, fs)}
          selectable={files.length < 6}
          multiple={this.state.multiple}
        />
      </WingBlank>
    );
  }
}
const mapStateToProps = (state) => {
    return {
        datas:state.getall.getfeedback
    }
}
export default connect(mapStateToProps)(FeedBack)
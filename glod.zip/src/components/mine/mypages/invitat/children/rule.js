import React , {Component} from "react"
import {
    Link
} from "react-router-dom";
import './rule.css'
import { connect } from "react-redux"

class Rule extends Component {
    constructor(props){
        super(props)
        this.state={

        }
    }
    render(){
        const {invitat}=this.props;
        return(
            <div className="rule">
                <div className="gz">
                    <Link to="/invitation" ><span><i className="icon iconfont icon-chevron-thin-left"></i></span></Link>
                    <b>邀请好友规则介绍</b>
                    <span></span>
                </div>
                <ul className="js">
                    {
                        invitat.map((item,key)=>{
                            return <li key={key}>{item.add}</li>
                        })
                    }
                </ul>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        invitat:state.getall.getinvitat
    }
}

export default connect(mapStateToProps)(Rule)
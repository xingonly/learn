import React , {Component} from "react"
import {
    Link
} from "react-router-dom";
import './win.css'
import { connect } from "react-redux"

class Win extends Component {
    constructor(){
        super()
        this.state={

        }
    }
    render(){
        const {invitat}=this.props;
        return(
            <div className="win">
                <div className="jl">
                    <Link to="/invitation" ><span><i className="icon iconfont icon-chevron-thin-left"></i></span></Link>
                    <b>奖金明细</b>
                    <span></span>
                </div>
                <section>
                <div className="lists">
                    <dl>
                        <dt><i className="icon iconfont icon-wode"></i></dt>
                        <dd>
                            <p>成功邀请</p>
                            <p><span>10</span>人</p>
                        </dd>
                    </dl>
                    <dl>
                        <dt><i className="icon iconfont icon-31"></i></dt>
                        <dd>
                            <p>累积奖励</p>
                            <p><span>1000.00</span>元</p>
                        </dd>
                    </dl>
                </div>
                <div className="boxs">
                    <p className="pp">奖励明细</p>
                    <div className="mx">
                        {
                            invitat.map((item,key)=>{
                                return <dl key={key}>
                                    <dt><i className={item.logo}></i></dt>
                                    <dd>
                                        <p><span>{item.name}</span><span>类型:{item.type}</span></p>
                                        <p><span>{item.tel}</span><span>时间:{item.time}</span></p>
                                    </dd>
                                </dl>
                            })
                        }
                    </div>
                </div>
                </section>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        invitat:state.getall.getinvitat
    }
}

export default connect(mapStateToProps)(Win)
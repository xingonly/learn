import React , {Component} from "react"

class Addup extends Component {
    constructor(){
        super()
        this.state={

        }
    }
    render(){
        return(
            <div className="addup">
                累积奖励
            </div>
        )
    }
}
export default Addup
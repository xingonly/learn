import React , {Component} from "react"
import './invitation.css'
import {
    NavLink
} from "react-router-dom";
import { connect } from "react-redux"

class Invitation extends Component {
    constructor(props){
        super(props)
        this.state={
            
        }
    }
    render(){
        const {invitat}=this.props;
        return(
            <div className="yq">
                <div className="yq1">
                <div className="head">
                    <NavLink to="/main/mine" ><span><i className="icon iconfont icon-chevron-thin-left"></i></span></NavLink>
                    <span>邀请有礼</span>
                    <NavLink to="/rule" ><span><i className="icon iconfont icon-38"></i></span></NavLink>
                </div>
                <div className="yhj">
                    <h1><i className="icon iconfont icon-youhuiquan-01"></i></h1>
                    <p className="p1">邀请即得</p>
                    <p className="p2">￥100优惠劵</p>
                    <button onClick={this.btnClick.bind(this)}>立即邀请</button>
                </div>
                <div className="lists">
                    <dl>
                        <dt><i className="icon iconfont icon-wode"></i></dt>
                        <NavLink to="/win" >
                        <dd>
                            <p>成功邀请</p>
                            <p><span>10</span>人</p>
                        </dd>
                        </NavLink>
                    </dl>
                    <dl>
                        <dt><i className="icon iconfont icon-31"></i></dt>
                        <NavLink to="/win" >
                        <dd>
                            <p>累积奖励</p>
                            <p><span>1000.00</span>元</p>
                        </dd>
                        </NavLink>
                    </dl>
                </div>
               </div> 
               <div className="yq2">
                    <div className="err" onClick={this.errClick.bind(this)}><i className="icon iconfont icon-guanbi-01"></i></div>
                    <p className="hy">分享给好友</p>
                    <div className="fx">
                        {
                            invitat.map((item,key)=>{
                                return <dl key={key}>
                                    <dt><i className={item.icon}></i></dt>
                                    <dd>{item.tit}</dd>
                                </dl>
                            })
                        }
                    </div>
               </div>
            </div>
        )
    }
    btnClick(){
        var yq1 = document.querySelector('.yq1');
        var yq2 = document.querySelector('.yq2');
        yq1.style.display='none';
        yq2.style.display='block'
    }
    errClick(){
        var yq1 = document.querySelector('.yq1');
        var yq2 = document.querySelector('.yq2');
        yq2.style.display='none';
        yq1.style.display='block'
    }
}

const mapStateToProps = (state) => {
    return {
        invitat:state.getall.getinvitat
    }
}
export default connect(mapStateToProps)(Invitation)
import React , {Component} from "react"
import './backcard.css'
import { Toast } from 'antd-mobile';
import { connect } from "react-redux";
class Bankcard extends Component {
    constructor(props){
        super(props)
        this.state={
            
        }
    }
    
    cardIcon(){
        this.props.history.push('/main/mine')
    }
    howToast() {
        Toast.info('短信已发送，请注意查收', 1);
    }
    render(){
        const {banks} = this.props
        const reg = /^(\d{4})(\d*)(\d{4})$/;
        return(
            <div className="backcard">
                <div className="cardHead">
                   <p className="cardIcon" onClick={this.cardIcon.bind(this)}><i className="icon iconfont icon-xiangzuo"></i></p>
                   <h1><span>绑定银行卡</span></h1>
                </div>
                <section className="cardSect">
                  <form>
                  {
                    banks!==null&&banks.map((item,key)=>{
                        let backcon=item.backcon.replace(reg,"$1****$2")
                        return <p key={key}><span>{item.bank}</span><strong className="backStrong">{backcon}</strong></p>
                    })
                  }
                  <ul>
                        <li>温馨提示</li>
                        <li>1.审核通过后,我司会讲回收金额支付到账到该银行卡。</li>
                        <li>2.若重新绑定新卡,则新卡将激活为收款银行卡</li>
                    </ul>
                    <input type="button" onClick={this.howToast}  defaultValue="重新绑卡" className="card"/>
                  </form>
                </section>
            </div>
        )
    }
}
const mapStateToProps = (state) => {
    return {
        banks:state.getall.getbackcard
    }
}
export default connect(mapStateToProps)(Bankcard)

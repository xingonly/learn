import React ,{Component} from 'react';
import './create.css'

class Create extends Component{
    constructor(){
        super()
        this.state={
            submitState:true
        }
    }
    back(){
        console.log(this.props)
        this.props.history.push("/logined")
    }
    render(){
        return (
            <div className="create">
            <header>
                <span onClick={this.back.bind(this)}>
                    <i className="icon iconfont icon-zuojiantou-01"></i>
                </span>
            </header>
                <p>
                    <img src='http://img.zcool.cn/community/01f343596de3e1a8012193a36fefb4.jpg@2o.jpg' alt=""/>
                </p>
                <ul>
                    <li>
                        <span><i className="icon iconfont icon-shouji1"></i></span>
                        <input type="text" placeholder="输入用户名" /></li>
                    <li>
                        <span><i className="icon iconfont icon-xiaoxi"></i></span>
                        <input type="text" placeholder="请输入验证码" />
                        <b>获取验证码</b>
                    </li>
                    <li>
                        <span><i className="icon iconfont icon-biaoqian"></i></span>
                        <input type="password" placeholder="设置登录密码" />
                    </li>
                    <li>
                        <input type="checkbox" disabled={this.state.submitState}/>
                        <small>已阅读并同意《<em>用户服务协议</em>》</small>
                    </li>
                    <li>
                        <button>登录</button>
                    </li>
                </ul>

            </div>
        )
    }
}
export default Create;
import React , {Component} from "react"
import './forget.css'
import { connect } from "react-redux"
class Forget extends Component {
    constructor(props){
        super(props)
        this.state={
            info:{
                setname:"",
                setpwd:"",
                setyzm:""
            },
            sjs:null,
            submitState:true
        }
    }
    back(){
        this.props.history.push('/logined')
    }
    sName(e){
        let input = e.target
        let key = input.name
        let info = this.state.info
        let newinfo = Object.assign(info,{
            [key]:input.value
        })
        let flg = false
        for(let key in newinfo){
            if(!newinfo[key]){
                flg = true
            }
        }
        this.setState({
            submitState:flg
        })
    }
    Yzm(){
        this.sjs = this.suiji()
        this.setState({
            sjs:this.sjs
        })
        alert('已发送手机验证码'+this.sjs);

    }
    suiji(){
        var str='';
        for(var i=0;i<6;i++){
            var num=Math.floor(Math.random()*9)
            str+=num;
        }
        return str;
    }
    Resets(){
        this.props.data.map( (val,ind) => {
            if(val.name !== this.state.info.setname){
                alert("该用户没有注册过")
            }else if(this.state.info.setyzm !== this.state.sjs){
                alert("验证码输入错误")
            }else{
                alert("成功修改")
                this.props.history.push('/logined')
                let pwd = this.state.info.setpwd;
                this.props.dispatch({
                    type:"SUCCESS",
                    spwd:pwd
                })
            }
        })
    }
    render(){
        let {setname,setpwd,setyzm} = this.state.info
        return(
            <div className="forget">
            <header>
                <span onClick={this.back.bind(this)}>
                    <i className="icon iconfont icon-zuojiantou-01"></i>
                </span>
                <strong>重置密码</strong>
                <strong></strong>
            </header>
                <ul>
                    <li>
                        <span><i className="icon iconfont icon-shouji1"></i></span>
                        <input type="text" placeholder="输入用户名" 
                            name="setname"
                            value={setname} 
                            onChange={this.sName.bind(this)}
                        />
                    </li>
                    <li>
                        <span><i className="icon iconfont icon-xiaoxi"></i></span>
                        <input type="text" placeholder="验证码" 
                            name="setyzm"
                            value={setyzm} 
                            onChange={this.sName.bind(this)}
                        />
                        <b onClick={this.Yzm.bind(this)}>获取验证码</b>
                    </li>
                    <li>
                        <span><i className="icon iconfont icon-biaoqian"></i></span>
                        <input type="password" placeholder="输入新密码" 
                            name="setpwd"
                            value={setpwd} 
                            onChange={this.sName.bind(this)}
                        />
                    </li>
                    <li>
                        <button 
                            onClick={this.Resets.bind(this)}
                            disabled={this.state.submitState}
                            className={this.state.submitState?"":"bg"}
                        >重置</button>
                    </li>
                </ul>
            </div>
        )
    }
}

const mapStateToProps = (state) => {
    return {
        data:state.getlogin.log
    }
}
export default connect(mapStateToProps)(Forget) 
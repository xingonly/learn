import React , {Component} from "react";
import './logined.css';
import { connect } from "react-redux"
import { getLogined } from "../../store/actions"
//antd滑动开关
import { List, Switch  } from 'antd-mobile';
import { createForm } from 'rc-form';
let SwitchExample = (props)=>{
    const { getFieldProps } = props.form;
    return (
            <List.Item
                extra={<Switch
                {...getFieldProps('Switch1', {
                    initialValue: false,
                    valuePropName: 'checked',
                })}
                onClick={(checked) => { 
                    props.callbackParent(checked)
                }}
                />}
            ></List.Item>
    )
}
SwitchExample = createForm()(SwitchExample);

class Login extends Component {
    constructor(props){
        super(props)
        this.state={
            info:{
                sname:"",
                spwd:""
            },
            submitState:true,
            istype:"password"
        }
    }
    logineds(){
        this.props.history.push('/')
    }
    forgets(){
        this.props.history.push("/forget")
    }
    creates(){
        this.props.history.push("/create")
    }
    logining(){
        const {data}=this.props;
        console.log(data)
        let name = data[0].name;
        let pwd = data[0].pwd;
        let {sname,spwd} = this.state.info
        if(name === sname && pwd === spwd){
            localStorage.setItem("token","登陆")
            this.props.history.push('/main/mine')
        }else{
            alert("用户名或密码输入有误")
        }
    }
    setinp(e){
        let input = e.target
        let key = input.name
        let info = this.state.info
        let newinfo = Object.assign(info,{
            [key]:input.value
        })
        let flg = false
        for(let key in newinfo){
            if(!newinfo[key]){
                flg = true
            }
        }
        this.setState({
            submitState:flg
        })
    }
    onChildChanged(newstate){
        if(newstate){
            this.setState({
                istype:"text"
            })
        }else{
            this.setState({
                istype:"password"
            })
        }
    }
    render(){
        const {sname,spwd} = this.state.info
        return(
            <div className="login">
                <p>
                    <img src='http://img.zcool.cn/community/01f343596de3e1a8012193a36fefb4.jpg@2o.jpg' alt=""/>
                </p>
                <ul>
                    <li>
                        <span>
                            <i className="icon iconfont icon-shouji1"></i>
                        </span>
                        <input type="text" placeholder="请输入用用户名" 
                            value={sname} name="sname"
                            onChange={this.setinp.bind(this)}/>
                    </li>
                    <li>
                        <span>
                            <i className="icon iconfont icon-biaoqian"></i>
                        </span>
                        <input type = {this.state.istype} placeholder = "登录密码" 
                            value = {spwd} name="spwd"
                            onChange = {this.setinp.bind(this)}/>
                        <b>
                            <SwitchExample callbackParent={this.onChildChanged.bind(this)}  ></SwitchExample>
                        </b>
                    </li>
                    <li>
                        <small onClick={this.forgets.bind(this)}>忘记密码</small>
                    </li>
                    <li>
                        <button 
                            onClick={this.logining.bind(this)} 
                            disabled={this.state.submitState}
                            className={this.state.submitState?"":"btn"}
                        >登录
                        </button>
                    </li>
                    <li>
                        <small onClick={this.creates.bind(this)}>创建账号</small>
                    </li>
                </ul>
                <h5>
                    <button><i className="icon iconfont icon-weixin"></i>微信账号登录</button>
                    <button><i className="icon iconfont icon-xinlangweibo1"></i>微博账号登录</button>
                </h5>
                <h4 onClick={this.logineds.bind(this)}>
                    <i className="icon iconfont icon-guanbi-01"></i>
                </h4>
            </div>
        )
    }
    componentDidMount(){
        this.props.initLogin()
    }
}
const mapDispath = (dispatch) => {
    return {
        initLogin(){
            dispatch(getLogined)
        }
    }
}
const mapStateToProps = (state) => {
    return {
        data:state.getlogin.log
    }
}
export default connect(mapStateToProps,mapDispath)(Login)
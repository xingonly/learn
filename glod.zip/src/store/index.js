//  store 包括  action  reducer  state
import {createStore,applyMiddleware} from 'redux'
import thunkMiddleware from "redux-thunk"//异步加载
import reducer from './reduces/index'

export default new createStore(reducer,applyMiddleware(thunkMiddleware))

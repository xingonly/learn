import axios from "axios"
export const LOGINED = "LOGINED";
export const SUCCESS = "SUCCESS";

export const getLogined = (dispatch)=>{
    axios.get("/login").then((res)=>{
        let log = res.data
        dispatch({type:LOGINED,log})
    })
}


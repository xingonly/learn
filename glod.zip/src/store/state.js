import logined from "../mock/data/logined.json";
import backcard from "../mock/data/backcard.json";
import helpcenter from "../mock/data/helpcenter.json";
import homelist from "../mock/data/homeList.json";
import invitat from "../mock/data/invitat.json";
import authentica from "../mock/data/authentica.json"
import feedback from "../mock/data/feedback.json"
import system from "../mock/data/system.json"
let initState={
    getlogin:logined,
    getbackcard:backcard,
    gethelpcenter:helpcenter,
    gethomelist:homelist,
    getinvitat:invitat,
    getauthentica:authentica,
    getfeedback:feedback,
    getsystem:system
}

export default initState
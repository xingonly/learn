import initState from "../state"
import {combineReducers} from "redux"//辅助函数  帮我们执行多个reducer 返回唯一对象
import getlogin from "./logined"

const getall = (state = initState) => {
    return state
}
const infos = combineReducers({
    getlogin,
    getall
})

export default infos
import { LOGINED } from "../actions"
import { SUCCESS } from "../actions"
let getLog = {
    [LOGINED](state,action){
       state.log = action.log
    },
    [SUCCESS](state,action){
        let {spwd} = action
        let obj = Object.assign([],state.log,[{name:state.log[0].name,pwd:spwd}])
        console.log(obj)
        state.log = obj.log 
    }
}
let logined = (state={},action)=>{
    getLog[action.type] && getLog[action.type](state,action)
    return {...state}
}
export default logined

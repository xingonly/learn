import Mock from "mockjs"
import  logined from "./data/logined.json"
Mock.setup({
    timeout:"400-600"
})
Mock.mock("/login",(req,res)=>{
    return logined
})
